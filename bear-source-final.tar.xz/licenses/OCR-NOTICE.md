# Offline OCR components

Tesseract.js 6.0.1 and tesseract.js-core 6.0.0, Apache-2.0; licenses included alongside this notice.
https://github.com/naptha/tesseract.js
https://github.com/naptha/tesseract.js-core

Language data from @tesseract.js-data/chi_sim 1.0.0 and @tesseract.js-data/eng 1.0.0, 4.0.0_best_int model variants, Apache-2.0.
https://github.com/naptha/tessdata

All runtime JS, WASM and language files live in web/ocr. No runtime CDN requests. Engine loads only when the user explicitly chooses a receipt image and is terminated after recognition or cancellation. Raw recognized text is not persisted; only reviewed fields, an optional compressed image, and the input file fingerprint are stored locally.

## 1.4.0 打包精简

仅保留 LSTM 与 SIMD LSTM 两种 `.wasm.js`，按设备自动选择。该发布文件自身内嵌 WASM，不再重复打包独立 `.wasm`；未使用的 legacy 引擎也移除。简体中文和英文模型保留，运行时仍无 CDN 或识别服务请求。资源散列见 `tools/ocr-assets.json`。
