# 2.1 图标与伴侣插画素材

本版新增图标与透明伴侣插画于 2026-11-17 使用图像生成工具制作，为参考一二布布角色的主题二创，未附官方授权证明。后续发布时仍须保留原角色权利人的权益；不能据此声称官方出品。

## 视觉制作说明

主题为一二布布相伴记录日常：奶茶棕色布布与白色一二依偎，捧着心形封面的奶油色手账本，点缀珊瑚色爱心。保留深棕粗描边、温暖低饱和配色、扁平插画与一二胸前的小黑领结，使图标覆盖生活记录、日历、美食与账本，而非只代表一起吃饭。

生成两份原始图：一份用于完整图标的奶油色背景图，一份透明背景伴侣插画。工程中的尺寸变化属于等比例缩放与格式转换；页面动效由 CSS 与 `mascot-motion.js` 实现，不是素材内置的官方动画。

## 工程输出

| 用途 | 资源 | 规格 |
| --- | --- | --- |
| Android 常规桌面图标 | `android/res/mipmap-*/ic_launcher.png` | mdpi/hdpi/xhdpi/xxhdpi/xxxhdpi：48/72/96/144/192px |
| Android 自适应图标 | `android/res/mipmap-anydpi-v26/ic_launcher.xml` | 奶油色背景与透明伴侣前景组合 |
| 图标前景与组件插画 | `android/res/drawable-nodpi/bear_companion.png` | 512px 透明 PNG |
| Web 图标与关于页 | `web/assets/app-icon.png` | 256px PNG |
| App 内组件预览插画 | `web/assets/bear-companion.webp` | 256px 透明 WebP |

原始生成大图与临时处理文件不加入 APK；日常构建无需调用图像生成服务。原有 36 幅主题图集与心情插画继续使用，未以新图标统一替换各个页面的情境插画。

音效来源另见根目录 `AUDIO-SOURCES.md`（2.1 计时铃声）和 `licenses/AUDIO-SOURCES.md`（1.5 界面音效）。
