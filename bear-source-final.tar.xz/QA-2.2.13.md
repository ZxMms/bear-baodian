# 熊熊宝典 2.2.13：分享日期、天气与手动保存相册

版本：2.2.13 / build 33。日期：2026-11-19。

## 日期和天气分享

- 在日历点击某一天，再点「分享这一天」。标题加入星期，保留农历；复制文字与图片信息一致。
- 「附上当天的天气与风况」默认勾选，可以关闭。更新天气时只刷新天气说明，不重置照片、记录、账单和天气选项。
- 进入当天分享时，通过已有原生 `refreshNow` 按首页选定位置查询。复用正在进行的请求；不重新申请 GPS、不创建本地天气缓存或历史天气表。还没有所选位置时提示先去首页开启天气。
- 仅附上当天、资料时间可核实且两小时以内的天气。资料时间用北京时间，并核对日期；跨日、历史、未来、错误、缺少时间或过期时不会套用今天或上次的天气。用户仍可生成记录卡，预览明确说明未附天气。
- 来源有风力等级时显示等级；有可核实的数值风速、阵风时使用 m/s；无数值不当作静风，不自行补造或换算风力等级。
- 天气卡显示所选地区、天气和温度、风况、资料时间与来源。中央气象台有站点名则补站点，Open-Meteo 保留来源和 CC BY 4.0 标记；不把查询时间冒充观测时间。不包含原始坐标。
- 每张分页卡片都保留日期和所选天气。菜谱分享不附当天的星期或天气，避免混淆菜谱与某次生活记录。账单仍默认不分享。

## 微信状态与保存选择

- 旧有「保存图片」走系统文件保存器，不等同于保存到媒体相册。新增独立按钮「保存到相册 · 用于微信状态」。
- **生成预览、复制文字、普通系统分享均不会写入相册。仅用户主动点该按钮才保存。** 多页时只保存当前页，切页后可以决定是否再保存；没有自动保存开关或默认自动保存行为。
- Android 10 及以上通过 MediaStore 写入 JPG 到 `Pictures/熊熊宝典`，写入期间使用 `IS_PENDING`；完整写入并关闭输出流后才发布为可见图片。无需新增存储权限。Android 8/9 不显示这个专用相册按钮，保留原有系统文件保存。
- 图片导出在后台线程进行，使用 95% JPEG 质量。重复点击在一次写入完成前合并为等待提示；只有发布成功才提示保存完成。创建、写入、发布失败时清理这次创建的媒体项，不动原卡片和其他照片；清理失败保留原始失败信息。
- 普通分享继续使用只读 content URI、单图／多图系统分享，ClipData 改用图片类型信息，同时在分享 Intent 和 chooser 上携带读取授权。未直接为所有应用永久授权，不开放本机数据库或附件目录。
- 新相册入口用于让用户从微信状态相册选择图片，不会替用户发布状态。没有使用未经核实的微信内部页面名称、深层链接或虚构 SDK 接口。

## 已执行验证

- 35 个 JavaScript 测试文件通过，42 个生产 JavaScript 文件通过语法检查。逐文件结果见 `tools/share-release-results.json`。
- 新增纯逻辑测试：星期、周日、闰日、跨年，气温与风力、风速、阵风和静风，缺数据／过期／跨午夜／历史／未来／失败状态，关闭天气，账单默认不分享及不输出坐标。
- 新增真实应用 DOM 交互测试：实际分享入口和表单、异步天气更新、选项保留、图片预览和复制文字一致、错误后继续分享、历史日期不查询、多页选择当前页保存，以及菜谱隔离。原生桥使用隔离替身，断言预览和普通分享不会调用相册保存，明确点击才调用一次。
- 使用测试专用原生 Canvas 引擎生成实际 PNG，检查了日期、农历、天气区块和正文的样例排版，并生成多页卡验证分页流程。这不是安卓 WebView 截图或微信端验收。测试数据只存在于隔离测试中，没有加入应用数据。
- 新增 Java 相册提交测试通过：成功顺序，分配失败、空 URI、写入失败、发布失败、发布异常、清理异常的处理。该测试验证提交逻辑，不冒充 MediaStore 真机测试。
- Android 原生代码编译成功，APK v2/v3 签名校验通过；86 个网页资源与源码逐字节一致。证书 SHA-256：`2da5e732bbfad01f29b1b3bae570f2cd8ac6a4014e03df80613614f7e22c303b`，与上一版相同。
- SQLite、既有记录和附件路径保持不变，未新增生产运行时依赖或音视频文件。新增 Canvas 依赖仅用于开发测试，不进入 APK。

## 尚需真机确认

没有连接用户安卓手机或微信，因此没有复现微信状态「获取资源失败」的具体根因，也不能承诺所有微信版本都会接受系统分享的临时图片。本版提供相册 JPG 路径供手动选择，并改进普通分享信息；仍需确认实际相册可见性、微信照片权限、微信状态选图以及用户手机上的分享预览。星期及天气功能的生成、逻辑与交互已在上述测试中验证。

## 复现新增测试

在工程根目录执行（Node.js 24 或兼容版本，JDK 17 及以上）：

```sh
npm install --prefix tools/ui-test-runtime --no-audit --no-fund
TZ=Asia/Shanghai node tools/share-weather-tests.mjs
TZ=Asia/Shanghai node tools/share-flow-tests.mjs
mkdir -p /tmp/bear-share-tests
javac -d /tmp/bear-share-tests android/src/com/xiongxiong/calendar/ShareAlbumCommit.java android/test/com/xiongxiong/calendar/ShareAlbumCommitTest.java
java -cp /tmp/bear-share-tests com.xiongxiong.calendar.ShareAlbumCommitTest
```

## 平台实现依据

- Android MediaStore 的媒体写入、`RELATIVE_PATH` 与 `IS_PENDING`：[Android 官方文档](https://developer.android.com/training/data-storage/shared/media)。
- 图片 ClipData 类型与 URI：[Android ClipData 文档](https://developer.android.com/reference/android/content/ClipData)。

文档用于核对 Android 接口行为，不作为微信故障已修复的证据。
