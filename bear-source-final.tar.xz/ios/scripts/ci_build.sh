#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build/artifacts
xcodebuild -version
python3 scripts/prepare_resources.py
node Tests/bridge-tests.mjs
xcodebuild -resolvePackageDependencies -project BearCalendar.xcodeproj -scheme BearCalendar
# Pick an installed iPhone simulator instead of hard-coding an OS release.
device_id=$(xcrun simctl list devices available -j | python3 -c 'import json,sys; d=json.load(sys.stdin); phones=[v["udid"] for k,vs in d["devices"].items() if "iOS" in k for v in vs if "iPhone" in v["name"] and v.get("isAvailable")]; assert phones, "No iPhone simulator available"; print(phones[0])')
xcodebuild -project BearCalendar.xcodeproj -scheme BearCalendar -destination "platform=iOS Simulator,id=$device_id,arch=$(uname -m)" -derivedDataPath build/DerivedData -resultBundlePath build/artifacts/BearCalendarTests.xcresult CODE_SIGNING_ALLOWED=NO ONLY_ACTIVE_ARCH=YES test 2>&1 | tee build/artifacts/simulator-tests.log
xcodebuild -project BearCalendar.xcodeproj -scheme BearCalendar -configuration Release -destination 'generic/platform=iOS' -archivePath build/BearCalendar-unsigned.xcarchive CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO archive 2>&1 | tee build/artifacts/device-archive.log
ditto -c -k --sequesterRsrc --keepParent build/BearCalendar-unsigned.xcarchive build/artifacts/BearCalendar-unsigned.xcarchive.zip
mkdir -p build/sideload/Payload
ditto build/BearCalendar-unsigned.xcarchive/Products/Applications/BearCalendar.app build/sideload/Payload/BearCalendar.app
(cd build/sideload && /usr/bin/zip -qry ../artifacts/BearBaodian-unsigned.ipa Payload)
ditto -c -k --sequesterRsrc --keepParent build/DerivedData/Build/Products/Debug-iphonesimulator/BearCalendar.app build/artifacts/BearCalendar-simulator.app.zip
cat > build/artifacts/README.txt <<'EOF'
熊熊宝典 iOS 构建产物
BearCalendar-simulator.app.zip：仅供 Mac 的 iOS 模拟器使用。
BearCalendar-unsigned.xcarchive.zip：iPhone 架构未签名归档，需要 Apple 证书和描述文件签名后才能安装。
BearBaodian-unsigned.ipa：供 SideStore 等工具用你自己的 Apple 账号重新签名安装；最低 iOS 16。
未签名 IPA 不能通过直接点击安装，也不是 TestFlight 邀请。SideStore 的首次配置和续签请遵循其官方文档：https://docs.sidestore.io/
EOF
