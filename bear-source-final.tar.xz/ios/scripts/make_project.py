#!/usr/bin/env python3
"""Deterministic Xcode project; no XcodeGen, CocoaPods, Node or signing keys required."""
from pathlib import Path
import hashlib
root=Path(__file__).resolve().parents[1]
objects={}
def oid(name): return hashlib.sha256(name.encode()).hexdigest()[:24].upper()
def obj(name,body):
    ident=oid(name);objects[ident]=body;return ident
def q(s): return '"'+s.replace('\\','\\\\').replace('"','\\"')+'"'
def seq(xs): return '('+','.join(xs)+',)' if xs else '()'
def file(path,kind): return obj('file:'+path,f'isa = PBXFileReference; lastKnownFileType = {q(kind)}; path = {q(path)}; sourceTree = "<group>";')
def build(ref): return obj('build:'+ref,f'isa = PBXBuildFile; fileRef = {ref};')
swift=[p.name for p in sorted((root/'BearCalendar').glob('*.swift'))]
source_refs=[file(x,'sourcecode.swift') for x in swift]
resources=[('web','folder'),('bridge.js','sourcecode.javascript'),('seed.json','text.json'),('Assets.xcassets','folder.assetcatalog'),('PrivacyInfo.xcprivacy','text.xml'),('bear-reminder.wav','audio.wav')]
resource_refs=[file(p,k) for p,k in resources]
info=file('Info.plist','text.plist.xml')
app_group=obj('appgroup',f'isa = PBXGroup; children = {seq(source_refs+resource_refs+[info])}; path = BearCalendar; sourceTree = "<group>";')
test_ref=file('BearCalendarTests.swift','sourcecode.swift')
test_group=obj('testgroup',f'isa = PBXGroup; children = {seq([test_ref])}; path = Tests; sourceTree = "<group>";')
app=obj('appproduct','isa = PBXFileReference; explicitFileType = wrapper.application; path = BearCalendar.app; sourceTree = BUILT_PRODUCTS_DIR;')
test=obj('testproduct','isa = PBXFileReference; explicitFileType = wrapper.cfbundle; path = BearCalendarTests.xctest; sourceTree = BUILT_PRODUCTS_DIR;')
products=obj('products',f'isa = PBXGroup; children = {seq([app,test])}; name = Products; sourceTree = "<group>";')
main=obj('main',f'isa = PBXGroup; children = {seq([app_group,test_group,products])}; sourceTree = "<group>";')
package=obj('zip-package','isa = XCRemoteSwiftPackageReference; repositoryURL = "https://github.com/weichsel/ZIPFoundation.git"; requirement = { kind = exactVersion; version = 0.9.20; };')
product=obj('zip-product',f'isa = XCSwiftPackageProductDependency; package = {package}; productName = ZIPFoundation;')
zip_build=obj('zip-link',f'isa = PBXBuildFile; productRef = {product};')
def phase(name,isa,files): return obj(name,f'isa = {isa}; buildActionMask = 2147483647; files = {seq(files)}; runOnlyForDeploymentPostprocessing = 0;')
sources=phase('sources','PBXSourcesBuildPhase',[build(r) for r in source_refs])
res=phase('resources','PBXResourcesBuildPhase',[build(r) for r in resource_refs])
frameworks=phase('frameworks','PBXFrameworksBuildPhase',[zip_build])
ts=phase('test-sources','PBXSourcesBuildPhase',[build(test_ref)])
tf=phase('test-frameworks','PBXFrameworksBuildPhase',[])
tr=phase('test-resources','PBXResourcesBuildPhase',[])
common={'SDKROOT':'iphoneos','IPHONEOS_DEPLOYMENT_TARGET':'16.0','SWIFT_VERSION':'5.0','CLANG_ENABLE_MODULES':'YES','CLANG_ENABLE_OBJC_ARC':'YES','ENABLE_USER_SCRIPT_SANDBOXING':'YES','GCC_C_LANGUAGE_STANDARD':'gnu17'}
appsettings={'PRODUCT_NAME':'$(TARGET_NAME)','PRODUCT_BUNDLE_IDENTIFIER':'com.xiongxiong.calendar.ios','INFOPLIST_FILE':'BearCalendar/Info.plist','CODE_SIGN_STYLE':'Automatic','DEVELOPMENT_TEAM':'','CURRENT_PROJECT_VERSION':'1','MARKETING_VERSION':'2.2.14','TARGETED_DEVICE_FAMILY':'1,2','ASSETCATALOG_COMPILER_APPICON_NAME':'AppIcon','SWIFT_EMIT_LOC_STRINGS':'YES','LD_RUNPATH_SEARCH_PATHS':'$(inherited) @executable_path/Frameworks','OTHER_LDFLAGS':'$(inherited) -lsqlite3','SUPPORTED_PLATFORMS':'iphoneos iphonesimulator','SUPPORTS_MACCATALYST':'NO'}
testsettings={'PRODUCT_NAME':'$(TARGET_NAME)','PRODUCT_BUNDLE_IDENTIFIER':'com.xiongxiong.calendar.ios.tests','GENERATE_INFOPLIST_FILE':'YES','CODE_SIGN_STYLE':'Automatic','TEST_HOST':'$(BUILT_PRODUCTS_DIR)/BearCalendar.app/$(BUNDLE_EXECUTABLE_FOLDER_PATH)/BearCalendar','BUNDLE_LOADER':'$(TEST_HOST)','TARGETED_DEVICE_FAMILY':'1,2','LD_RUNPATH_SEARCH_PATHS':'$(inherited) @executable_path/Frameworks @loader_path/Frameworks'}
def configs(name,settings):
    ids=[]
    for mode in ['Debug','Release']:
        opts={**settings,'SWIFT_OPTIMIZATION_LEVEL':'-Onone' if mode=='Debug' else '-O','DEBUG_INFORMATION_FORMAT':'dwarf' if mode=='Debug' else 'dwarf-with-dsym','SWIFT_ACTIVE_COMPILATION_CONDITIONS':'DEBUG $(inherited)' if mode=='Debug' else '$(inherited)'}
        if mode=='Debug': opts['ENABLE_TESTABILITY']='YES'
        conf=obj(name+mode,'isa = XCBuildConfiguration; name = '+mode+'; buildSettings = {'+' '.join(q(k)+' = '+q(v)+';' for k,v in opts.items())+'};');ids.append(conf)
    return obj(name+'configs',f'isa = XCConfigurationList; buildConfigurations = {seq(ids)}; defaultConfigurationIsVisible = 0; defaultConfigurationName = Release;')
pc=configs('project',common); ac=configs('app',appsettings); tc=configs('test',testsettings)
app_id=oid('app-target'); project_id=oid('project')
proxy=obj('proxy',f'isa = PBXContainerItemProxy; containerPortal = {project_id}; proxyType = 1; remoteGlobalIDString = {app_id}; remoteInfo = BearCalendar;')
dep=obj('dependency',f'isa = PBXTargetDependency; target = {app_id}; targetProxy = {proxy};')
obj('app-target',f'isa = PBXNativeTarget; buildConfigurationList = {ac}; buildPhases = {seq([sources,frameworks,res])}; buildRules = (); dependencies = (); name = BearCalendar; packageProductDependencies = {seq([product])}; productName = BearCalendar; productReference = {app}; productType = "com.apple.product-type.application";')
test_id=obj('test-target',f'isa = PBXNativeTarget; buildConfigurationList = {tc}; buildPhases = {seq([ts,tf,tr])}; buildRules = (); dependencies = {seq([dep])}; name = BearCalendarTests; productName = BearCalendarTests; productReference = {test}; productType = "com.apple.product-type.bundle.unit-test";')
obj('project',f'isa = PBXProject; attributes = {{ LastUpgradeCheck = 1600; TargetAttributes = {{ {app_id} = {{ CreatedOnToolsVersion = 16.0; }}; {test_id} = {{ CreatedOnToolsVersion = 16.0; TestTargetID = {app_id}; }}; }}; }}; buildConfigurationList = {pc}; compatibilityVersion = "Xcode 14.0"; developmentRegion = "zh-Hans"; knownRegions = ("zh-Hans",en,Base); mainGroup = {main}; productRefGroup = {products}; packageReferences = {seq([package])}; projectDirPath = ""; projectRoot = ""; targets = {seq([app_id,test_id])};')
folder=root/'BearCalendar.xcodeproj'; folder.mkdir(exist_ok=True)
(folder/'project.pbxproj').write_text('// !$*UTF8*$!\n{ archiveVersion = 1; classes = {}; objectVersion = 56; objects = {\n'+''.join(k+' = { '+v+' };\n' for k,v in objects.items())+'}; rootObject = '+project_id+'; }\n')
scheme=folder/'xcshareddata/xcschemes';scheme.mkdir(parents=True,exist_ok=True)
def ref(id,name):return f'<BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{id}" BuildableName="{name}.app" BlueprintName="{name}" ReferencedContainer="container:BearCalendar.xcodeproj"/>'
appref=ref(app_id,'BearCalendar');testref=ref(test_id,'BearCalendarTests').replace('BearCalendarTests.app','BearCalendarTests.xctest')
(scheme/'BearCalendar.xcscheme').write_text(f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="1600" version="1.3"><BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES">{appref}</BuildActionEntry></BuildActionEntries></BuildAction><TestAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" shouldUseLaunchSchemeArgsEnv="YES"><Testables><TestableReference skipped="NO">{testref}</TestableReference></Testables></TestAction><LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" debugServiceExtension="internal" allowLocationSimulation="YES"><BuildableProductRunnable runnableDebuggingMode="0">{appref}</BuildableProductRunnable></LaunchAction><ProfileAction buildConfiguration="Release" shouldUseLaunchSchemeArgsEnv="YES" savedToolIdentifier="" useCustomWorkingDirectory="NO" debugDocumentVersioning="YES"><BuildableProductRunnable runnableDebuggingMode="0">{appref}</BuildableProductRunnable></ProfileAction><AnalyzeAction buildConfiguration="Debug"/><ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/></Scheme>''')
print('Generated shared Xcode project:',folder)
