// Full two-platform checkout only; install tools/ui-test-runtime dependencies first.
import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
const root = new URL('../../',import.meta.url);
for (const [name,args] of [['ui-flow-tests.mjs',[]],['ui-flow-tests.mjs',['--populated']],['share-flow-tests.mjs',[]],['ledger-statistics-ui-tests.mjs',[]]]) {
  const original = new URL('tools/'+name,root), temporary = new URL('tools/.ios-'+name,root);
  if(!fs.existsSync(original))throw new Error('请在完整双平台源码中执行网页流程回归');
  const source = fs.readFileSync(original,'utf8').replaceAll("new URL('../web/',import.meta.url)","new URL('../ios/BearCalendar/web/',import.meta.url)");
  try {
    fs.writeFileSync(temporary,source);
    const result = spawnSync(process.execPath,[temporary.pathname,...args],{encoding:'utf8',env:{...process.env,TZ:'Asia/Shanghai'}});
    if(result.status!==0)throw new Error(result.stderr||result.stdout||name+' failed');
    if(name==='ui-flow-tests.mjs') { const report=JSON.parse(result.stdout); console.log(`PASS ${name} ${args.join(' ')}: ${report.findings.length} states, ${report.errors.length} errors`); }
    else console.log(result.stdout.trim());
  } finally { fs.rmSync(temporary,{force:true}); }
}
