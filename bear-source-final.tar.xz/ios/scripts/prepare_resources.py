#!/usr/bin/env python3
"""Generate the iOS web bundle; do not edit shared Android resources."""
from pathlib import Path
import shutil, json, hashlib
ios=Path(__file__).resolve().parents[1]
root=ios.parent
out=ios/'BearCalendar'/'web'
if not (root/'web').is_dir():
    if not (out/'index.html').is_file(): raise SystemExit('缺少共享 web 源码与预置资源')
    print('使用 iOS 工程随附的预置资源；无需 Node 或共享安卓工程。')
    raise SystemExit(0)
if out.exists(): shutil.rmtree(out)
shutil.copytree(root/'web',out)
shutil.copy2(ios/'BearCalendar'/'ios.css',out/'ios.css')

def patch(name,old,new):
    file=out/name
    source=file.read_text()
    if old not in source: raise SystemExit('iOS resource patch missing: '+name+' '+old[:60])
    file.write_text(source.replace(old,new))

# Remove Android-only desktop widget entry until a signed WidgetKit target exists.
patch('workbench.js',"${tile('widgets','桌面熊熊','把重要的小日子放到桌面','widget')}", '') if "${tile('widgets','桌面熊熊','把重要的小日子放到桌面','widget')}" in (out/'workbench.js').read_text() else None
import re
file=out/'workbench.js'; source=file.read_text()
source=re.sub(r"\$\{tile\('widgets'[^\n]*?\)\}", '', source)
file.write_text(source)
patch('app.js','若收不到提醒，请检查手机的自启动和省电限制。强行停止应用后，需要重新打开一次。','提醒由 iOS 系统发送。请检查通知声音、静音与专注模式。最多安排最近 60 条，打开 App 时自动补充后续日程。')
patch('kitchen.js',"`计时和 5 秒试响使用所选铃声，遵循系统闹钟音量与勿扰设置。${builtinPreviewAvailable()?'内置短铃声试听使用媒体音量。':''}`", "'计时与 5 秒试响使用所选通知声音，遵循 iPhone 的静音开关、通知音量和专注模式。'")
patch('kitchen.js','在系统页面的「声音 / 铃声」中选择，返回后自动更新。','可选择默认通知声音或熊熊短提示音，对新建计时生效。')
patch('kitchen.js','选择手机铃声 ›','选择提醒声音 ›')
patch('kitchen.js','到点响铃最多 30 秒','通过 iOS 通知提醒')
patch('kitchen.js','计时已结束，已请求系统提醒。响铃最多 30 秒，可在这里或通知中停止。','计时已结束，已请求系统提醒。通知声音与显示由 iOS 控制。')
patch('kitchen.js','停止响铃','清除通知')
patch('kitchen.js','响铃已停止，已完成的计时还留在这里。','通知已清除，已完成的计时还留在这里。')
# No Android instructions in the iPhone package.
for file in out.glob('*.js'):
    file.write_text(file.read_text().replace('安卓 App','手机 App').replace('新版安卓','新版手机'))
# Record the shared source revision; this file contains no device or user data.
manifest={p.relative_to(root/'web').as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((root/'web').rglob('*')) if p.is_file()}
(ios/'shared-web-sha256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(f'iOS resources prepared: {len(manifest)} shared files; Android source unchanged')
