#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! command -v xcodebuild >/dev/null 2>&1; then
  echo '需要在安装 Xcode 的 Mac 上执行；当前环境不能验证 iOS SDK 编译。' >&2
  exit 2
fi
python3 scripts/prepare_resources.py
xcodebuild -resolvePackageDependencies -project BearCalendar.xcodeproj -scheme BearCalendar
xcodebuild -project BearCalendar.xcodeproj -scheme BearCalendar -destination 'generic/platform=iOS Simulator' -derivedDataPath build CODE_SIGNING_ALLOWED=NO build
if [ "$#" -gt 0 ]; then
  xcodebuild -project BearCalendar.xcodeproj -scheme BearCalendar -destination "$1" -derivedDataPath build CODE_SIGNING_ALLOWED=NO test
else
  echo '模拟器构建完成。要执行单元测试，添加参数，例如 platform=iOS Simulator,id=<模拟器 UDID>'
fi
