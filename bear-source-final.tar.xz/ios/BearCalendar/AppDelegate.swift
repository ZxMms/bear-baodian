import UIKit
import UserNotifications

@main
final class AppDelegate: UIResponder, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    var window: UIWindow?
    var controller: BearViewController?
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        UNUserNotificationCenter.current().delegate = self
        window = UIWindow(frame: UIScreen.main.bounds)
        do { controller = BearViewController(store: try Store()); window?.rootViewController = controller }
        catch {
            let screen = UIViewController(); screen.view.backgroundColor = UIColor(red:1,green:0.98,blue:0.95,alpha:1)
            let label = UILabel(); label.text = "熊熊宝典暂未能打开\n\(error.localizedDescription)\n请保留应用，避免删除本机记录。"; label.numberOfLines = 0; label.textAlignment = .center
            label.translatesAutoresizingMaskIntoConstraints = false; screen.view.addSubview(label)
            NSLayoutConstraint.activate([label.centerYAnchor.constraint(equalTo:screen.view.centerYAnchor),label.leadingAnchor.constraint(equalTo:screen.view.leadingAnchor,constant:28),label.trailingAnchor.constraint(equalTo:screen.view.trailingAnchor,constant:-28)])
            window?.rootViewController = screen
        }
        window?.makeKeyAndVisible(); return true
    }
    func applicationDidBecomeActive(_ application: UIApplication) { controller?.becameActive() }
    func applicationDidEnterBackground(_ application: UIApplication) { controller?.weather.cancelLocation(silent:true); controller?.audio?.stop() }
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) { completionHandler([.banner,.list,.sound]) }
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        DispatchQueue.main.async {
            self.controller?.reminders.openEntry = response.notification.request.content.userInfo
            self.controller?.emit("bearIOSResume", []); completionHandler()
        }
    }
}
