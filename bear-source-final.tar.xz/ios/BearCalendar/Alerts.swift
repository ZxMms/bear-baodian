import Foundation

final class Alerts {
    let weather: Weather
    var changed: (([String:Any])->Void)?
    private(set) var state: [String:Any] = ["province":"","alerts":[],"loading":false,"updatedAt":0,"error":"","truncated":false]
    private var task: Task<Void,Never>?, generation = UUID()
    init(weather:Weather) { self.weather = weather }
    func select(_ province:String) {
        task?.cancel(); generation = UUID()
        state = ["province":province,"alerts":[],"loading":false,"updatedAt":0,"error":"","truncated":false]; changed?(state)
        if !province.isEmpty { refresh() }
    }
    func refresh() {
        guard let province = state["province"] as? String, !province.isEmpty, state["loading"] as? Bool != true else { return }
        task?.cancel(); let ticket = UUID(); generation = ticket; state["loading"] = true; state["error"] = ""; changed?(state)
        task = Task {
            var rows = [String:[String:Any]](), incomplete = false
            do {
                let formatter = DateFormatter(); formatter.locale = Locale(identifier:"en_US_POSIX"); formatter.timeZone = TimeZone(identifier:"Asia/Shanghai"); formatter.dateFormat = "yyyy/MM/dd HH:mm"; formatter.isLenient = false
                var page = 1, pages = 1
                repeat {
                    var url = URLComponents(string:"https://www.nmc.cn/rest/findAlarm")!
                    url.queryItems = [URLQueryItem(name:"pageNo",value:String(page)),URLQueryItem(name:"pageSize",value:"100"),URLQueryItem(name:"signaltype",value:""),URLQueryItem(name:"signallevel",value:""),URLQueryItem(name:"province",value:province)]
                    let raw = try await weather.get(url.url!)
                    guard raw["code"] as? Int == 0, let data = raw["data"] as? [String:Any], let pageData = data["page"] as? [String:Any], let list = pageData["list"] as? [[String:Any]], list.count <= 100, pageData["pageNo"] as? Int == page else { throw BearError.message("预警资料结构异常") }
                    pages = max(1,max(pageData["totalPage"] as? Int ?? 1,((pageData["count"] as? Int ?? list.count)+99)/100)); incomplete = incomplete || pages > 5
                    for item in list + (data["provinceAlarms"] as? [[String:Any]] ?? []) {
                        guard let id = item["alertid"] as? String, id.range(of:"^[0-9]{14}_[0-9]{14}$",options:.regularExpression) != nil, let title = item["title"] as? String, title.hasPrefix(province), title.count <= 180, let time = formatter.date(from:item["issuetime"] as? String ?? ""), time.timeIntervalSinceNow <= 300 else { incomplete = true; continue }
                        if time.timeIntervalSinceNow < -86400 { continue }
                        let level = [("红色","red"),("橙色","orange"),("黄色","yellow"),("蓝色","blue")].first { title.contains($0.0) }?.1 ?? "unknown"
                        rows[id] = ["id":id,"title":title,"issuedAt":time.timeIntervalSince1970*1000,"level":level,"url":"https://www.nmc.cn/publish/alarm/\(id).html"]
                    }
                    page += 1
                } while page <= min(pages,5) && !Task.isCancelled
                guard !Task.isCancelled else { return }
                let result = Array(rows.values).sorted { ($0["issuedAt"] as? Double ?? 0) > ($1["issuedAt"] as? Double ?? 0) }, truncated = incomplete
                await MainActor.run { guard self.generation == ticket else { return }; self.state = ["province":province,"alerts":result,"loading":false,"updatedAt":JSON.now,"error":truncated ? "只取得部分发布，请同时查看官方完整列表。" : "","truncated":truncated]; self.changed?(self.state) }
            } catch {
                guard !Task.isCancelled else { return }
                await MainActor.run { guard self.generation == ticket else { return }; self.state["loading"] = false; self.state["error"] = "本次预警查询未完成，请重试或查看官网。"; self.state["truncated"] = true; self.changed?(self.state) }
            }
        }
    }
}
