import Foundation

enum BearError: LocalizedError {
    case message(String)
    var errorDescription: String? { if case .message(let text) = self { return text }; return nil }
}
enum JSON {
    static func data(_ value: Any) throws -> Data {
        try JSONSerialization.data(withJSONObject: value, options: [.fragmentsAllowed, .sortedKeys])
    }
    static func string(_ value: Any) -> String { (try? String(data: data(value), encoding: .utf8)) ?? "null" }
    static func parse(_ text: String) throws -> Any { try JSONSerialization.jsonObject(with: Data(text.utf8), options: [.fragmentsAllowed]) }
    static var now: Double { Date().timeIntervalSince1970 * 1000 }
}
