import Foundation
import CoreLocation

final class Weather: NSObject, CLLocationManagerDelegate {
    let manager = CLLocationManager(), geocoder = CLGeocoder()
    var changed: (([String:Any]) -> Void)?, citiesChanged: (([String:Any]) -> Void)?
    private(set) var state: [String:Any] = ["native":true,"place":NSNull(),"weather":NSNull(),"loading":false,"error":""]
    private var locationGeneration = UUID(), fetchGeneration = UUID(), locating = false
    private var timeout: DispatchWorkItem?, fetchTask: Task<Void,Never>?
    private var catalog = [[String:Any]]()
    private let session: URLSession
    override init() {
        let config = URLSessionConfiguration.ephemeral; config.urlCache = nil; config.requestCachePolicy = .reloadIgnoringLocalCacheData; config.timeoutIntervalForRequest = 10; config.timeoutIntervalForResource = 20
        session = URLSession(configuration:config)
        super.init(); manager.delegate = self; manager.desiredAccuracy = kCLLocationAccuracyBest
        if let url = Bundle.main.url(forResource:"nmc-cities",withExtension:"json",subdirectory:"web"), let data = try? Data(contentsOf:url), let object = try? JSONSerialization.jsonObject(with:data) as? [String:Any] { catalog = object["cities"] as? [[String:Any]] ?? [] }
        if let place = UserDefaults.standard.dictionary(forKey:"weatherPlace") { state["place"] = place }
    }
    private func publish() { changed?(state) }
    private func locationState(_ status: String, _ phase: String, _ detail: String) {
        let granted = [.authorizedAlways,.authorizedWhenInUse].contains(manager.authorizationStatus)
        state["locationStatus"] = ["status":status,"phase":phase,"detail":detail,"permission":granted ? (manager.accuracyAuthorization == .fullAccuracy ? "fine" : "coarse") : "none","serviceEnabled":CLLocationManager.locationServicesEnabled()]
    }
    func locate() {
        cancelLocation(silent:true); fetchTask?.cancel(); fetchGeneration = UUID(); state["loading"] = false; state["error"] = ""
        guard CLLocationManager.locationServicesEnabled() else { locationState("services-off","failed","请在 iPhone 设置中开启定位服务。"); publish(); return }
        locating = true; locationGeneration = UUID()
        switch manager.authorizationStatus {
        case .notDetermined: locationState("permission-pending","locating","允许使用期间访问位置后，查询附近天气。"); publish(); manager.requestWhenInUseAuthorization()
        case .authorizedAlways,.authorizedWhenInUse: startLocation()
        default: locating = false; locationState("permission-denied","failed","请在系统设置中允许熊熊宝典使用位置。"); publish()
        }
    }
    private func startLocation() {
        locationState("waiting","locating","正在获取当前位置，最多等待 15 秒。"); publish()
        manager.startUpdatingLocation()
        let generation = locationGeneration
        let deadline = DispatchWorkItem { [weak self] in guard let self, self.locationGeneration == generation, self.locating else { return }; self.cancelLocation(silent:true); self.locationState("timeout","failed","暂未获得新的位置。可重试，或手动选择所在区县。"); self.publish() }
        timeout = deadline; DispatchQueue.main.asyncAfter(deadline:.now()+15,execute:deadline)
    }
    func cancelLocation(silent: Bool = false) {
        timeout?.cancel(); timeout = nil; locating = false; locationGeneration = UUID(); manager.stopUpdatingLocation(); geocoder.cancelGeocode()
        if !silent { locationState("cancelled","idle","已停止定位，可手动选择城市。"); publish() }
    }
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        guard locating else { return }
        if [.authorizedAlways,.authorizedWhenInUse].contains(manager.authorizationStatus) { startLocation() }
        else if manager.authorizationStatus != .notDetermined { cancelLocation(silent:true); locationState("permission-denied","failed","位置权限未开启，可手动选择城市。"); publish() }
    }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        guard locating else { return }
        if (error as? CLError)?.code == .locationUnknown { return }
        cancelLocation(silent:true); locationState("providers-failed","failed","手机暂未能返回位置，请重试或选择城市。"); publish()
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard locating, let fix = locations.filter({ $0.horizontalAccuracy >= 0 && $0.horizontalAccuracy <= 5000 && abs($0.timestamp.timeIntervalSinceNow) <= 60 }).min(by: { $0.horizontalAccuracy < $1.horizontalAccuracy }) else { return }
        // Accept a new Core Location fix immediately; don't spin waiting for GPS alone.
        locating = false; manager.stopUpdatingLocation(); timeout?.cancel(); let generation = locationGeneration
        locationState("waiting","locating","已获取位置，正在识别所在区县…"); publish()
        var completed = false
        let finish: (CLPlacemark?) -> Void = { [weak self] placemark in
            guard let self, generation == self.locationGeneration, !completed else { return }; completed = true; self.timeout?.cancel()
            let province = placemark?.administrativeArea ?? "", city = placemark?.locality ?? "", district = placemark?.subLocality ?? ""
            let name = !district.isEmpty ? district : !city.isEmpty ? city : "定位附近"
            var place: [String:Any] = ["name":name,"displayName":district.isEmpty ? name : "\(city.isEmpty ? province : city) · \(district)","source":"location","latitude":fix.coordinate.latitude,"longitude":fix.coordinate.longitude,"locatedAt":fix.timestamp.timeIntervalSince1970*1000,"accuracyMeters":fix.horizontalAccuracy,"fixProvider":"fused","admin1":province,"countryCode":placemark?.isoCountryCode ?? "","alertArea":["province":province,"city":city,"district":district,"source":"geocoder"]]
            // Match the geocoded administrative name, never nearest city coordinates.
            if let station = self.catalog.first(where: { ($0["province"] as? String) == province && Self.areaName($0["city"] as? String ?? "") == Self.areaName(name) }) { place["nmcCode"] = station["code"] }
            self.locationState("success","ready",district.isEmpty ? "已取得当前位置；区县名称暂未识别，不使用旧地区替代。" : "位置已更新。"); self.select(place)
        }
        let deadline = DispatchWorkItem { finish(nil) }; timeout = deadline; DispatchQueue.main.asyncAfter(deadline:.now()+8,execute:deadline)
        geocoder.reverseGeocodeLocation(fix,preferredLocale:Locale(identifier:"zh_CN")) { marks,_ in DispatchQueue.main.async { finish(marks?.first) } }
    }
    static func areaName(_ name: String) -> String { name.replacingOccurrences(of:"[市区县]$",with:"",options:.regularExpression) }
    func select(_ input: [String:Any]) {
        guard let lat = input["latitude"] as? Double, let lon = input["longitude"] as? Double, lat.isFinite, lon.isFinite, (-90...90).contains(lat), (-180...180).contains(lon) else { state["error"] = "该地区缺少坐标，请用定位或输入完整地名"; state["loading"] = false; publish(); return }
        if input["source"] as? String != "location" { cancelLocation(silent:true); state["locationStatus"] = NSNull() }
        var place = input; if place["source"] == nil { place["source"] = "city" }
        state["place"] = place; state["weather"] = NSNull(); UserDefaults.standard.set(place,forKey:"weatherPlace"); refresh(saved:true)
    }
    func disable() { cancelLocation(silent:true); fetchTask?.cancel(); fetchGeneration = UUID(); UserDefaults.standard.removeObject(forKey:"weatherPlace"); state = ["native":true,"place":NSNull(),"weather":NSNull(),"loading":false,"error":""]; publish() }
    func refresh(saved: Bool = false) {
        guard let place = state["place"] as? [String:Any] else { return }
        if !saved, place["source"] as? String == "location" { locate(); return }
        fetchTask?.cancel(); let generation = UUID(); fetchGeneration = generation
        state["loading"] = true; state["error"] = ""; state["phase"] = "正在联网查询最新天气…"; state["refreshNotice"] = ""; publish()
        fetchTask = Task { [weak self] in
            guard let self else { return }
            do {
                var report: [String:Any]?
                if let code = place["nmcCode"] as? String, code.range(of:"^[A-Za-z0-9]{1,16}$",options:.regularExpression) != nil { report = try? await self.nmc(code) }
                if report == nil { report = try await self.openMeteo(place) }
                guard !Task.isCancelled else { return }
                let ready = report!
                await MainActor.run { guard self.fetchGeneration == generation else { return }; self.state["weather"] = ready; self.state["loading"] = false; self.state["checkedAt"] = JSON.now; self.state["refreshOutcome"] = "success"; self.state["refreshNotice"] = ""; self.publish() }
            } catch {
                guard !Task.isCancelled else { return }
                await MainActor.run { guard self.fetchGeneration == generation else { return }; self.state["loading"] = false; self.state["error"] = "天气服务暂未连通，请重试。"; self.state["refreshOutcome"] = "failed"; self.state["refreshNotice"] = "本次查询未成功，不会把旧资料标为最新。"; self.publish() }
            }
        }
    }
    func get(_ url: URL) async throws -> [String:Any] {
        var request = URLRequest(url:url,cachePolicy:.reloadIgnoringLocalCacheData,timeoutInterval:10); request.setValue("no-cache",forHTTPHeaderField:"Cache-Control")
        let (data,response) = try await session.data(for:request)
        guard let http = response as? HTTPURLResponse, http.statusCode == 200, data.count <= 4 * 1024 * 1024, let object = try JSONSerialization.jsonObject(with:data) as? [String:Any] else { throw BearError.message("天气来源返回异常") }
        return object
    }
    private func openMeteo(_ place: [String:Any]) async throws -> [String:Any] {
        let lat = place["latitude"] as! Double, lon = place["longitude"] as! Double
        let raw = try await get(URL(string:"https://api.open-meteo.com/v1/forecast?latitude=\(lat)&longitude=\(lon)&current=temperature_2m,weather_code,is_day,wind_speed_10m,wind_direction_10m,wind_gusts_10m&wind_speed_unit=ms&timeformat=unixtime&timezone=auto")!)
        guard let current = raw["current"] as? [String:Any], let units = raw["current_units"] as? [String:Any], units["wind_speed_10m"] as? String == "m/s", let temperature = current["temperature_2m"] as? Double, (-100...100).contains(temperature), let code = current["weather_code"] as? Int, let observed = current["time"] as? Double, abs(Date().timeIntervalSince1970-observed) < 10800 else { throw BearError.message("天气资料不完整或已过期") }
        return ["provider":"open-meteo","temperature":temperature,"code":code,"isDay":current["is_day"] as? Int == 1,"windSpeed":current["wind_speed_10m"] ?? NSNull(),"windDirection":current["wind_direction_10m"] ?? NSNull(),"windGust":current["wind_gusts_10m"] ?? NSNull(),"observedAt":observed*1000,"updatedAt":JSON.now,"checkedAt":JSON.now]
    }
    private func nmc(_ code: String) async throws -> [String:Any] {
        let raw = try await get(URL(string:"https://www.nmc.cn/rest/real/\(code)")!)
        guard let station = raw["station"] as? [String:Any], station["code"] as? String == code, let weather = raw["weather"] as? [String:Any], let temperature = weather["temperature"] as? Double, (-100...100).contains(temperature), let text = weather["info"] as? String, !text.isEmpty, text != "9999", let published = raw["publish_time"] as? String else { throw BearError.message("站点资料不完整") }
        let formatter = DateFormatter(); formatter.locale = Locale(identifier:"en_US_POSIX"); formatter.timeZone = TimeZone(identifier:"Asia/Shanghai"); formatter.dateFormat = "yyyy-MM-dd HH:mm"; formatter.isLenient = false
        guard let observed = formatter.date(from:published), observed.timeIntervalSinceNow <= 300, observed.timeIntervalSinceNow >= -10800 else { throw BearError.message("站点资料尚未更新") }
        let map = [0:0,1:2,2:3,3:80,4:95,5:96,6:67,7:61,8:63,9:65,10:65,11:65,12:65,13:85,14:71,15:73,16:75,17:75,18:45,19:66,21:63,22:65,23:65,24:65,25:65,26:73,27:75,28:75]
        guard let source = Int(weather["img"] as? String ?? ""), let weatherCode = map[source] else { throw BearError.message("站点没有晴雨状况") }
        let wind = raw["wind"] as? [String:Any] ?? [:]; var calendar = Calendar(identifier:.gregorian); calendar.timeZone = TimeZone(identifier:"Asia/Shanghai")!; let hour = calendar.component(.hour,from:Date())
        let power = wind["power"] as? String ?? "", direction = wind["direct"] as? String ?? ""
        return ["provider":"nmc","temperature":temperature,"conditionText":text,"code":weatherCode,"isDay":hour>=6 && hour<18,"windSpeed":NSNull(),"windGust":NSNull(),"windDirectionText":direction == "9999" ? "" : direction,"windPower":power == "9999" ? "" : power,"observedAt":observed.timeIntervalSince1970*1000,"updatedAt":JSON.now,"checkedAt":JSON.now,"sourceUrl":"https://www.nmc.cn" + (station["url"] as? String ?? "/publish/forecast.html"),"city":station["city"] ?? "","admin1":station["province"] ?? ""]
    }
    func search(_ query: String) {
        let query = String(query.trimmingCharacters(in:.whitespacesAndNewlines).prefix(80))
        guard !query.isEmpty else { citiesChanged?(["query":query,"results":[]]); return }
        Task {
            do {
                let marks = try await CLGeocoder().geocodeAddressString(query, in:nil, preferredLocale:Locale(identifier:"zh_CN"))
                let results = marks.prefix(40).compactMap { mark -> [String:Any]? in
                    guard let location = mark.location else { return nil }
                    let name = mark.subLocality ?? mark.locality ?? mark.name ?? query, province = mark.administrativeArea ?? ""
                    var place: [String:Any] = ["name":name,"latitude":location.coordinate.latitude,"longitude":location.coordinate.longitude,"admin1":province,"countryCode":mark.isoCountryCode ?? "","region":province,"alertArea":["province":province,"city":mark.locality ?? "","district":mark.subLocality ?? "","source":"geocoder"]]
                    if let station = catalog.first(where:{ ($0["province"] as? String) == province && Self.areaName($0["city"] as? String ?? "") == Self.areaName(name) }) { place["nmcCode"] = station["code"] }
                    return place
                }
                await MainActor.run { self.citiesChanged?(["query":query,"results":results]) }
            } catch { await MainActor.run { self.citiesChanged?(["query":query,"results":[],"error":"暂未找到地区，请输入完整的市、区名称后重试"]) } }
        }
    }
}
