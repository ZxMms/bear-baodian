import Foundation
import ZIPFoundation

/// The same format-1 ZIP used by Android. All methods run on Store.queue.
final class Backup {
    let store: Store
    private var staged: (token: String, folder: URL, rows: [[String: Any]])?
    init(store: Store) { self.store = store }
    func export() throws -> URL {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: folder) }
        let rows = try store.snapshot(), records = try JSON.data(rows), refs = Store.references(rows).sorted()
        guard records.count <= 16 * 1024 * 1024 else { throw BearError.message("记录超过备份支持的 16 MB 上限") }
        var size = records.count, files = [[String: Any]]()
        for path in refs {
            let data = try Data(contentsOf: store.file(path)), digest = Store.digest(data)
            guard URL(fileURLWithPath:path).lastPathComponent.hasPrefix(digest + ".") else { throw BearError.message("附件校验失败，请保留本机数据") }
            size += data.count
            guard size <= 512 * 1024 * 1024 else { throw BearError.message("完整备份超过 512 MB") }
            files.append(["path":path,"size":data.count,"sha256":digest])
        }
        let manifest: [String: Any] = ["app":"com.xiongxiong.calendar","format":1,"created":JSON.now,"counts":try store.counts(),"recordsSha256":Store.digest(records),"files":files]
        try records.write(to: folder.appendingPathComponent("records.json"))
        try JSON.data(manifest).write(to: folder.appendingPathComponent("manifest.json"))
        let exportFolder = FileManager.default.temporaryDirectory.appendingPathComponent("export-" + UUID().uuidString)
        try FileManager.default.createDirectory(at: exportFolder, withIntermediateDirectories: true)
        let formatter = DateFormatter(); formatter.dateFormat = "yyyyMMdd-HHmm"
        let url = exportFolder.appendingPathComponent("熊熊宝典备份_\(formatter.string(from: Date())).zip")
        do {
            let archive = try Archive(url: url, accessMode: .create)
            for name in ["manifest.json", "records.json"] { try archive.addEntry(with: name, relativeTo: folder, compressionMethod: .deflate) }
            for path in refs { try archive.addEntry(with: path, relativeTo: store.root, compressionMethod: .none) }
            return url
        } catch { try? FileManager.default.removeItem(at: exportFolder); throw error }
    }
    func inspect(_ url: URL) throws -> [String: Any] {
        if let staged { try? FileManager.default.removeItem(at: staged.folder) }; staged = nil
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent("restore-" + UUID().uuidString)
        try FileManager.default.createDirectory(at: folder.appendingPathComponent("media"), withIntermediateDirectories: true)
        do {
            let archive = try Archive(url: url, accessMode: .read)
            var names = Set<String>(), total: Int64 = 0
            for entry in archive {
                let name = entry.path, limit = name.hasPrefix("media/") ? 32 * 1024 * 1024 : 16 * 1024 * 1024
                guard entry.type == .file, names.insert(name).inserted, names.count <= 20002,
                      name == "manifest.json" || name == "records.json" || Store.validMedia(name),
                      Int64(entry.uncompressedSize) <= Int64(limit) else { throw BearError.message("备份结构或文件大小无效") }
                total += Int64(entry.uncompressedSize)
                guard total <= 512 * 1024 * 1024 else { throw BearError.message("备份解压后超过 512 MB") }
                // Stream with a second actual-byte bound; don't trust ZIP header sizes.
                let destination = folder.appendingPathComponent(name)
                guard FileManager.default.createFile(atPath: destination.path, contents: nil) else { throw BearError.message("无法准备恢复文件") }
                let handle = try FileHandle(forWritingTo: destination); defer { try? handle.close() }
                var bytes = 0
                _ = try archive.extract(entry) { data in
                    bytes += data.count; guard bytes <= limit else { throw BearError.message("备份文件超出限制") }
                    try handle.write(contentsOf: data)
                }
                guard bytes == Int(entry.uncompressedSize) else { throw BearError.message("备份文件不完整") }
            }
            let records = try Data(contentsOf: folder.appendingPathComponent("records.json"))
            guard let manifest = try JSONSerialization.jsonObject(with: Data(contentsOf: folder.appendingPathComponent("manifest.json"))) as? [String:Any], manifest["app"] as? String == "com.xiongxiong.calendar", manifest["format"] as? Int == 1, manifest["recordsSha256"] as? String == Store.digest(records), let rows = try JSONSerialization.jsonObject(with: records) as? [[String:Any]], let declared = manifest["files"] as? [[String:Any]], let counts = manifest["counts"] as? [String:Int] else { throw BearError.message("不是完整的熊熊宝典备份") }
            var keys = Set<String>(), actual = Dictionary(uniqueKeysWithValues: Store.stores.map { ($0,0) })
            for row in rows {
                guard let name = row["store"] as? String, let key = row["key"] as? String, let value = row["value"], keys.insert(name + "\0" + key).inserted else { throw BearError.message("备份记录有重复或缺失") }
                try Store.validate(name,key,value); actual[name,default:0] += 1
                try validateAttachments(value)
            }
            guard actual == counts else { throw BearError.message("备份记录数量不一致") }
            var files = Set<String>()
            for file in declared {
                guard let path = file["path"] as? String, Store.validMedia(path), files.insert(path).inserted else { throw BearError.message("附件名称无效") }
                let data = try Data(contentsOf: folder.appendingPathComponent(path)), digest = Store.digest(data)
                guard file["size"] as? Int == data.count, file["sha256"] as? String == digest, URL(fileURLWithPath:path).lastPathComponent.hasPrefix(digest + ".") else { throw BearError.message("备份附件校验失败") }
            }
            guard Store.references(rows) == files, names == files.union(["manifest.json","records.json"]) else { throw BearError.message("备份附件不完整") }
            let token = UUID().uuidString; staged = (token,folder,rows)
            return ["type":"preview","token":token,"manifest":manifest]
        } catch { try? FileManager.default.removeItem(at: folder); throw error }
    }
    private func validateAttachments(_ value: Any, field: String = "") throws {
        if let dict = value as? [String:Any] { for (key,child) in dict { try validateAttachments(child,field:key) }; return }
        if let array = value as? [Any] { for child in array { try validateAttachments(child,field:field) }; return }
        if let text = value as? String, ["photos","cover","receipt","receiptImage","audio","src"].contains(field), !text.isEmpty {
            guard Store.validMedia(text) else { throw BearError.message("备份含不支持的外部附件") }
        }
    }
    func merge(_ token: String) throws -> [String:Int] {
        guard let staged, staged.token == token else { throw BearError.message("备份预览已过期，请重新选择") }
        for path in Store.references(staged.rows) {
            let target = try store.file(path)
            if !FileManager.default.fileExists(atPath: target.path) { try FileManager.default.copyItem(at: staged.folder.appendingPathComponent(path), to: target) }
        }
        let result = try store.transaction { () -> [String:Int] in
            var added = 0, kept = 0
            for row in staged.rows {
                if try !store.query("SELECT key FROM records WHERE store=? AND key=?", [row["store"] as! String,row["key"] as! String]).isEmpty { kept += 1; continue }
                try store.put(row,add:true); added += 1
            }
            return ["added":added,"kept":kept]
        }
        try? FileManager.default.removeItem(at: staged.folder); self.staged = nil
        return result
    }
}
