import Foundation
import UserNotifications

final class Reminders {
    let center = UNUserNotificationCenter.current()
    var openEntry: [AnyHashable:Any]?
    private let defaults = UserDefaults.standard
    private var syncing = false
    private var pendingSync: (([String:Any]) -> Void)?
    func settings(_ completion: @escaping ([String:Any]) -> Void) {
        center.getNotificationSettings { settings in
            self.center.getPendingNotificationRequests { requests in
                DispatchQueue.main.async {
                    completion(["native":true,"enabled":settings.authorizationStatus == .authorized || settings.authorizationStatus == .provisional,"exact":true,"scheduled":requests.filter { $0.identifier.hasPrefix("entry:") }.count,"channelSound":settings.soundSetting == .enabled])
                }
            }
        }
    }
    func requestPermission(_ completion: @escaping (Bool) -> Void) {
        center.requestAuthorization(options:[.alert,.sound,.badge]) { allowed,_ in DispatchQueue.main.async { if allowed { self.rebuild { _ in } }; completion(allowed) } }
    }
    func sync(_ records: [[String:Any]], completion: @escaping ([String:Any]) -> Void) {
        defaults.set(records,forKey:"reminderRules"); rebuild(completion:completion)
    }
    func rebuild(completion: @escaping ([String:Any]) -> Void) {
        // Keep the newest rule set when a resume and a save arrive together.
        if syncing { let previous = pendingSync; pendingSync = { result in previous?(result); completion(result) }; return }
        syncing = true
        settings { status in
            guard status["enabled"] as? Bool == true else { self.finish(status,completion); return }
            self.center.getPendingNotificationRequests { requests in
                let timers = requests.filter { !$0.identifier.hasPrefix("entry:") }.count
                let rules = self.defaults.array(forKey:"reminderRules") as? [[String:Any]] ?? []
                let schedule = ReminderSchedule.upcoming(rules,now:Date()).prefix(max(0,60-timers))
                self.center.removePendingNotificationRequests(withIdentifiers:requests.filter { $0.identifier.hasPrefix("entry:") }.map(\.identifier))
                let group = DispatchGroup(), errors = NSLock(); var failures = 0
                for item in schedule {
                    let content = UNMutableNotificationContent(); content.title = item.title; content.body = "熊熊帮你记着这件小事"; content.sound = .default
                    content.userInfo = ["id":item.recordID,"date":item.entryDate]; content.threadIdentifier = "bear-reminders"
                    let trigger = UNCalendarNotificationTrigger(dateMatching:Calendar.current.dateComponents([.year,.month,.day,.hour,.minute],from:item.fire),repeats:false)
                    group.enter(); self.center.add(UNNotificationRequest(identifier:item.id,content:content,trigger:trigger)) { error in if error != nil { errors.lock(); failures += 1; errors.unlock() }; group.leave() }
                }
                group.notify(queue:.main) {
                    var result = status; result["scheduled"] = schedule.count - failures
                    if failures > 0 { result["error"] = "部分提醒未能安排，请重新打开应用重试" }
                    self.finish(result,completion)
                }
            }
        }
    }
    private func finish(_ result: [String:Any], _ completion: @escaping ([String:Any]) -> Void) {
        syncing = false; completion(result)
        if let pending = pendingSync { pendingSync = nil; rebuild(completion:pending) }
    }
    func timer(_ id: String, title: String, seconds: Double, completion: @escaping ([String:Any]) -> Void) {
        guard !id.isEmpty, id.count <= 200, seconds.isFinite, seconds >= 1, seconds <= 14400 else { completion(["ok":false,"message":"计时长度无效"]); return }
        requestPermission { allowed in
            guard allowed else { completion(["ok":false,"message":"请先在设置中允许熊熊宝典通知"]); return }
            self.center.getPendingNotificationRequests { requests in
                let identifier = "timer:" + id
                guard requests.count < 64 || requests.contains(where: { $0.identifier == identifier }) else { DispatchQueue.main.async { completion(["ok":false,"message":"系统提醒数量已满，请取消部分提醒后再试"]) }; return }
                let content = UNMutableNotificationContent(); content.title = title; content.body = "计时到啦，看看锅里的美味吧"; content.threadIdentifier = "bear-cooking"
                content.sound = self.defaults.string(forKey:"timerSound") == "bear" ? UNNotificationSound(named:UNNotificationSoundName("bear-reminder.wav")) : .default
                let end = JSON.now + seconds * 1000
                self.center.add(UNNotificationRequest(identifier:identifier,content:content,trigger:UNTimeIntervalNotificationTrigger(timeInterval:seconds,repeats:false))) { error in DispatchQueue.main.async {
                    if let error { completion(["ok":false,"message":error.localizedDescription]); return }
                    var timers = self.defaults.dictionary(forKey:"timers") ?? [:]; timers[id] = ["endAt":end,"title":title]; self.defaults.set(timers,forKey:"timers")
                    completion(["ok":true,"endAt":end,"notifications":true,"deliveryStatus":"scheduled","message":"已安排系统通知。响铃遵循 iPhone 的静音与专注模式。"])
                } }
            }
        }
    }
    func timerStatus(_ id: String, completion: @escaping ([String:Any]) -> Void) {
        let timer = defaults.dictionary(forKey:"timers")?[id] as? [String:Any]
        guard let end = timer?["endAt"] as? Double else { completion(["known":false]); return }
        center.getPendingNotificationRequests { requests in
            self.center.getDeliveredNotifications { delivered in DispatchQueue.main.async {
                let active = requests.contains { $0.identifier == "timer:" + id }, finished = end <= JSON.now
                let seen = delivered.contains { $0.request.identifier == "timer:" + id }
                completion(["known":true,"endAt":end,"active":active,"finished":finished,"deliveryStatus":active ? "scheduled" : seen ? "delivered" : "unconfirmed","deliveryError":finished && !seen ? "提醒时间已到；系统可能已清除通知，无法确认是否响铃。" : ""])
            } }
        }
    }
    func cancel(_ id: String) {
        center.removePendingNotificationRequests(withIdentifiers:["timer:"+id]); center.removeDeliveredNotifications(withIdentifiers:["timer:"+id])
        var timers = defaults.dictionary(forKey:"timers") ?? [:]; timers.removeValue(forKey:id); defaults.set(timers,forKey:"timers")
    }
    func ringHealth(completion: @escaping ([String:Any]) -> Void) {
        settings { status in
            var result = status; result["notifications"] = status["enabled"]
            let builtin = self.defaults.string(forKey:"timerSound") == "bear"
            result["soundKind"] = builtin ? "ios-bear" : "system"; result["soundName"] = builtin ? "熊熊短提示音" : "iPhone 默认通知声音"
            result["message"] = "iOS 通知声音受静音开关、通知音量和专注模式影响。可用 5 秒试响检查；应用无法读取静音与专注状态。"
            completion(result)
        }
    }
}

struct ScheduledReminder {
    let recordID: String, title: String, entryDate: String, fire: Date
    var id: String { "entry:\(recordID):\(entryDate)" }
}
enum ReminderSchedule {
    static func upcoming(_ rules: [[String:Any]], now: Date, calendar: Calendar = .current) -> [ScheduledReminder] {
        let formatter = DateFormatter(); formatter.locale = Locale(identifier:"en_US_POSIX"); formatter.calendar = calendar; formatter.timeZone = calendar.timeZone; formatter.dateFormat = "yyyy-MM-dd"; formatter.isLenient = false
        let dayStart = calendar.startOfDay(for:now), horizon = calendar.date(byAdding:.day,value:400,to:dayStart)!
        var output = [ScheduledReminder]()
        for rule in rules {
            guard let id = rule["id"] as? String, let date = rule["date"] as? String, let start = formatter.date(from:date), let time = rule["time"] as? String else { continue }
            let clock = time.split(separator:":").compactMap { Int($0) }; guard clock.count == 2, (0...23).contains(clock[0]), (0...59).contains(clock[1]) else { continue }
            let ahead = min(365,max(0,rule["days"] as? Int ?? 0)), type = rule["recurrence"] as? String ?? (rule["annual"] as? Bool == true ? "yearly" : "none")
            let workDates = Set(rule["workDates"] as? [String] ?? [])
            var cursor = dayStart
            while cursor <= horizon {
                let key = formatter.string(from:cursor), components = calendar.dateComponents([.month,.day,.weekday],from:cursor)
                var matches = false
                if cursor >= start {
                    switch type {
                    case "yearly": matches = key.suffix(5) == date.suffix(5)
                    case "monthly":
                        let day = rule["monthDay"] as? Int ?? 0, last = calendar.range(of:.day,in:.month,for:cursor)?.count ?? 0
                        matches = (1...31).contains(day) && components.day == (rule["overflow"] as? String == "skip" ? day : min(day,last))
                    case "last-workday":
                        if rule["workMode"] as? String != "weekdays" { matches = workDates.contains(key) }
                        else if let range = calendar.range(of:.day,in:.month,for:cursor), let monthStart = calendar.date(from:calendar.dateComponents([.year,.month],from:cursor)), var last = calendar.date(byAdding:.day,value:range.count-1,to:monthStart) {
                            while [1,7].contains(calendar.component(.weekday,from:last)) { last = calendar.date(byAdding:.day,value:-1,to:last)! }
                            matches = calendar.isDate(cursor,inSameDayAs:last)
                        }
                    default: matches = key == date
                    }
                }
                if matches, let reminderDay = calendar.date(byAdding:.day,value:-ahead,to:cursor), let fire = calendar.date(bySettingHour:clock[0],minute:clock[1],second:0,of:reminderDay), fire > now {
                    output.append(ScheduledReminder(recordID:id,title:String((rule["title"] as? String ?? "熊熊提醒").prefix(100)),entryDate:key,fire:fire))
                }
                cursor = calendar.date(byAdding:.day,value:1,to:cursor)!
            }
        }
        return output.sorted { $0.fire == $1.fire ? $0.id < $1.id : $0.fire < $1.fire }
    }
}
