/* iOS-only adapter. Android's shared web bundle stays byte-for-byte unchanged. */
(() => {
  'use strict';
  if (location.protocol !== 'bearapp:' || location.host !== 'app' || window.top !== window) return;
  const invoke = (service, method, args = []) => {
    const raw = window.prompt('__BEAR_IOS__' + JSON.stringify({service,method,args}), '');
    const response = raw ? JSON.parse(raw) : {ok:false,error:'系统接口暂不可用'};
    if (!response.ok) throw new Error(response.error || '操作未完成');
    return response.value;
  };
  const bind = (service, jsonMethods, valueMethods = []) => {
    const adapter = {};
    for (const method of jsonMethods) adapter[method] = (...args) => JSON.stringify(invoke(service,method,args));
    for (const method of valueMethods) adapter[method] = (...args) => invoke(service,method,args);
    window[service] = Object.freeze(adapter);
  };
  bind('BearApp',['info','startCookingTimer','cookingTimerStatus','cookingRingingStatus','testCookingRinging'],['setImagePickLimit','cancelCookingTimer','stopCookingTimerRinging','cancelCookingRingingTest','cookingNotificationSettings','chooseCookingRingtone','openRecipeLink','refreshInterface','consumeWidgetAction']);
  bind('BearShare',['prepare'],['share','save','saveToAlbum','canSaveToAlbum','copy']);
  bind('BearCalendarAudio',[],['play','playAtVolume','stop']);
  bind('BearReminders',['status','sync'],['requestPermission','test','settings','exactSettings','consumeOpenEntry']);
  bind('BearWeather',['state'],['refreshNow','refresh','refreshSavedPlace','select','locate','locatePrecise','cancelLocate','locationSettings','settings','disable','search']);
  bind('BearWeatherAlerts',['state'],['selectProvince','disable','refresh','refreshIfNeeded']);
  window.bearIOSResume = () => { document.dispatchEvent(new Event('visibilitychange')); window.bearOpenNotification?.(); window.bearReminderStatusChanged?.(''); };
  let photoInput = null, photoRequest = 0;
  window.BearStore = Object.freeze({
    request(id,input) { window.webkit.messageHandlers.bear.postMessage({type:'store',id:String(id),input}); },
    exportBackup() { invoke('BearStore','exportBackup'); },
    chooseBackup() { invoke('BearStore','chooseBackup'); }
  });
  window.bearIOSPhotos = (request, images, error) => {
    if (request !== photoRequest || !photoInput) return;
    const input = photoInput; photoInput = null;
    if (error) { window.bearShareResult?.(error); return; }
    if (!images?.length || !input.isConnected) return;
    const transfer = new DataTransfer();
    images.forEach((item,index) => {
      const bytes = Uint8Array.from(atob(item.data), c => c.charCodeAt(0));
      transfer.items.add(new File([bytes],`熊熊照片-${index+1}.jpg`,{type:'image/jpeg',lastModified:Date.now()}));
    });
    input.files = transfer.files;
    input.dispatchEvent(new Event('change',{bubbles:true}));
  };
  document.addEventListener('click', event => {
    const input = event.target;
    if (input?.tagName !== 'INPUT' || input.type !== 'file' || !input.accept.includes('image')) return;
    event.preventDefault(); event.stopImmediatePropagation();
    if (photoInput) return;
    photoInput = input;
    window.webkit.messageHandlers.bear.postMessage({type:'photos',id:++photoRequest,multiple:input.multiple});
  },true);
  document.addEventListener('DOMContentLoaded', () => {
    document.documentElement.dataset.platform = 'ios';
    const css = document.createElement('link'); css.rel='stylesheet'; css.href='ios.css'; document.head.append(css);
    const appearance = () => window.webkit.messageHandlers.bear.postMessage({type:'appearance',dark:document.documentElement.dataset.theme === 'night'});
    new MutationObserver(appearance).observe(document.documentElement,{attributes:true,attributeFilter:['data-theme']}); appearance();
  },{once:true});
})();
