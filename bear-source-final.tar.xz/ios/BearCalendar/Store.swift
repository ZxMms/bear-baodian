import Foundation
import SQLite3
import CryptoKit

/// Every access, including backup, runs on `queue`. Attachments are immutable SHA-256 files.
final class Store {
    static let stores = ["entries", "recipes", "moods", "ledger", "ledgerCategories", "settings"]
    static let mediaPattern = "^media/[a-f0-9]{64}\\.(jpg|jpeg|png|webp|gif|wav|mp3|m4a|ogg|aac)$"
    let queue = DispatchQueue(label: "com.xiongxiong.calendar.store", qos: .userInitiated)
    let root: URL
    private var db: OpaquePointer?
    private let transient = unsafeBitCast(-1, to: sqlite3_destructor_type.self)
    init(root: URL? = nil, seed: URL? = Bundle.main.url(forResource: "seed", withExtension: "json")) throws {
        self.root = try root ?? FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true).appendingPathComponent("BearCalendar", isDirectory: true)
        try FileManager.default.createDirectory(at: self.root.appendingPathComponent("media"), withIntermediateDirectories: true, attributes: [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication])
        guard sqlite3_open_v2(self.root.appendingPathComponent("bear.sqlite").path, &db, SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_FULLMUTEX, nil) == SQLITE_OK else { throw BearError.message("无法打开本机数据库") }
        sqlite3_busy_timeout(db, 5000)
        try execute("PRAGMA journal_mode=WAL")
        try execute("PRAGMA synchronous=FULL")
        try execute("CREATE TABLE IF NOT EXISTS records(store TEXT NOT NULL, key TEXT NOT NULL, payload TEXT NOT NULL, PRIMARY KEY(store,key))")
        try execute("CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        if try meta("ready") == nil {
            try transaction {
                if let seed, let rows = try JSONSerialization.jsonObject(with: Data(contentsOf: seed)) as? [[String: Any]] {
                    for row in rows { _ = try put(row, add: true) }
                } else { throw BearError.message("缺少内置菜谱，请重新构建应用") }
                try setMeta("ready", "1")
            }
        }
    }
    deinit { sqlite3_close(db) }
    func execute(_ sql: String, _ values: [String] = []) throws {
        var statement: OpaquePointer?
        guard sqlite3_prepare_v2(db, sql, -1, &statement, nil) == SQLITE_OK else { throw databaseError() }
        defer { sqlite3_finalize(statement) }
        for (i, value) in values.enumerated() { sqlite3_bind_text(statement, Int32(i + 1), value, -1, transient) }
        let result = sqlite3_step(statement)
        guard result == SQLITE_DONE || result == SQLITE_ROW else { throw databaseError() }
    }
    func query(_ sql: String, _ values: [String] = []) throws -> [[String]] {
        var statement: OpaquePointer?
        guard sqlite3_prepare_v2(db, sql, -1, &statement, nil) == SQLITE_OK else { throw databaseError() }
        defer { sqlite3_finalize(statement) }
        for (i, value) in values.enumerated() { sqlite3_bind_text(statement, Int32(i + 1), value, -1, transient) }
        var rows = [[String]]()
        while true {
            let result = sqlite3_step(statement)
            if result == SQLITE_DONE { return rows }
            guard result == SQLITE_ROW else { throw databaseError() }
            rows.append((0..<sqlite3_column_count(statement)).map { index in
                sqlite3_column_text(statement, index).map { String(cString: $0) } ?? ""
            })
        }
    }
    private func databaseError() -> Error { BearError.message(sqlite3_errcode(db) == SQLITE_CONSTRAINT ? "这条记录已经存在，请刷新后查看" : "本机存储未完成，原数据仍保留") }
    func transaction<T>(_ work: () throws -> T) throws -> T {
        try execute("BEGIN IMMEDIATE")
        do { let result = try work(); try execute("COMMIT"); return result }
        catch { try? execute("ROLLBACK"); throw error }
    }
    func meta(_ key: String) throws -> String? { try query("SELECT value FROM meta WHERE key=?", [key]).first?.first }
    func setMeta(_ key: String, _ value: String) throws { try execute("INSERT OR REPLACE INTO meta(key,value) VALUES(?,?)", [key, value]) }
    static func digest(_ data: Data) -> String { SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined() }
    static func validMedia(_ path: String) -> Bool { path.range(of: mediaPattern, options: .regularExpression) != nil }
    func file(_ path: String) throws -> URL {
        guard Self.validMedia(path) else { throw BearError.message("附件路径无效") }
        return root.appendingPathComponent(path)
    }
    static func validate(_ store: String, _ key: String, _ value: Any) throws {
        guard stores.contains(store), !key.isEmpty, key.utf8.count <= 512, !key.contains("\0") else { throw BearError.message("记录类型或编号无效") }
        if store != "settings" {
            guard let row = value as? [String: Any], row[store == "moods" ? "date" : "id"] as? String == key else { throw BearError.message("记录编号不一致") }
            if let photos = row["photos"] as? [Any], photos.count > (store == "ledger" ? 5 : 20) { throw BearError.message("照片数量超出限制") }
        }
    }
    private func normalize(_ value: Any, depth: Int = 0) throws -> Any {
        guard depth < 50 else { throw BearError.message("记录层级过多") }
        if let object = value as? [String: Any] { return try object.mapValues { try normalize($0, depth: depth + 1) } }
        if let array = value as? [Any] { return try array.map { try normalize($0, depth: depth + 1) } }
        guard let string = value as? String else { return value }
        if string.hasPrefix("media/") { guard FileManager.default.fileExists(atPath: try file(string).path) else { throw BearError.message("附件缺失") }; return string }
        guard string.hasPrefix("data:image/") || string.hasPrefix("data:audio/") else { return string }
        let parts = string.split(separator: ",", maxSplits: 1).map(String.init)
        let extensions = ["data:image/jpeg;base64": "jpg", "data:image/png;base64": "png", "data:image/webp;base64": "webp", "data:image/gif;base64": "gif", "data:audio/wav;base64": "wav", "data:audio/mpeg;base64": "mp3", "data:audio/mp4;base64": "m4a", "data:audio/ogg;base64": "ogg"]
        guard parts.count == 2, let ext = extensions[parts[0]], let data = Data(base64Encoded: parts[1]), !data.isEmpty, data.count <= 32 * 1024 * 1024 else { throw BearError.message("图片或音频无效，单个附件上限 32 MB") }
        let path = "media/\(Self.digest(data)).\(ext)", url = try file(path)
        if !FileManager.default.fileExists(atPath: url.path) { try data.write(to: url, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication]) }
        return path
    }
    @discardableResult func put(_ request: [String: Any], add: Bool = false) throws -> Any {
        let store = request["store"] as? String ?? "", key = request["key"] as? String ?? "", value = request["value"] ?? NSNull()
        try Self.validate(store, key, value)
        let normalized = try normalize(value), payload = try JSON.data(normalized)
        guard payload.count <= 16 * 1024 * 1024 else { throw BearError.message("记录过大") }
        try execute("\(add ? "INSERT" : "INSERT OR REPLACE") INTO records(store,key,payload) VALUES(?,?,?)", [store, key, String(decoding: payload, as: UTF8.self)])
        return normalized
    }
    func snapshot() throws -> [[String: Any]] {
        try query("SELECT store,key,payload FROM records ORDER BY store,key").map { ["store": $0[0], "key": $0[1], "value": try JSON.parse($0[2])] }
    }
    static func references(_ value: Any) -> Set<String> {
        if let object = value as? [String: Any] { return object.values.reduce(into: Set<String>()) { $0.formUnion(references($1)) } }
        if let array = value as? [Any] { return array.reduce(into: Set<String>()) { $0.formUnion(references($1)) } }
        if let string = value as? String, validMedia(string) { return [string] }
        return []
    }
    func counts() throws -> [String: Int] {
        var counts = Dictionary(uniqueKeysWithValues: Self.stores.map { ($0, 0) })
        for row in try query("SELECT store,COUNT(*) FROM records GROUP BY store") { counts[row[0]] = Int(row[1]) ?? 0 }
        return counts
    }
    func request(_ request: [String: Any]) throws -> Any {
        let op = request["op"] as? String ?? "", store = request["store"] as? String ?? "", key = request["key"] as? String ?? ""
        if ["all", "get", "remove", "soft-delete", "restore", "purge-trash-item"].contains(op) {
            guard Self.stores.contains(store), op == "all" || !key.isEmpty else { throw BearError.message("无效的存储请求") }
        }
        switch op {
        case "status": return ["ready": true, "engine": "SQLite", "counts": try counts(), "lastBackup": try meta("lastBackup") ?? ""]
        case "stats":
            let files = try FileManager.default.contentsOfDirectory(at: root.appendingPathComponent("media"), includingPropertiesForKeys: [.fileSizeKey])
            let bytes = try files.reduce(0) { try $0 + ($1.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0) }
            return ["counts": try counts(), "attachments": files.count, "attachmentBytes": bytes, "lastBackup": try meta("lastBackup") ?? ""]
        case "all": return ["value": try query("SELECT payload FROM records WHERE store=? ORDER BY key", [store]).map { try JSON.parse($0[0]) }]
        case "get": return ["value": try query("SELECT payload FROM records WHERE store=? AND key=?", [store,key]).first.map { try JSON.parse($0[0]) } ?? NSNull()]
        case "put": return ["value": try transaction { try put(request, add: request["add"] as? Bool ?? false) }]
        case "put-batch":
            guard let rows = request["rows"] as? [[String: Any]], (1...20).contains(rows.count) else { throw BearError.message("批量保存内容无效") }
            let keys = rows.map { ($0["store"] as? String ?? "") + "\0" + ($0["key"] as? String ?? "") }
            guard Set(keys).count == rows.count else { throw BearError.message("同一次保存不能重复写入同一条记录") }
            return ["rows": try transaction { try rows.map { row -> [String: Any] in var output = row; output["value"] = try put(row, add: row["add"] as? Bool ?? false); return output } }]
        case "remove": try execute("DELETE FROM records WHERE store=? AND key=?", [store,key]); return [:]
        case "soft-delete", "restore", "purge-trash-item":
            guard ["entries","recipes","ledger"].contains(store) else { throw BearError.message("这类数据不支持最近删除") }
            return try transaction {
                guard let text = try query("SELECT payload FROM records WHERE store=? AND key=?", [store,key]).first?.first, var row = try JSON.parse(text) as? [String: Any] else { return ["value": NSNull()] }
                if op == "soft-delete" { row["_deletedAt"] = JSON.now; row["_deleteExpiresAt"] = JSON.now + 30 * 86400000 }
                else if op == "restore" { row.removeValue(forKey: "_deletedAt"); row.removeValue(forKey: "_deleteExpiresAt") }
                else { guard row["_deletedAt"] != nil else { throw BearError.message("请先移到最近删除") }; try execute("DELETE FROM records WHERE store=? AND key=?", [store,key]); return ["value": row] }
                return ["value": try put(["store":store,"key":key,"value":row])]
            }
        case "purge-trash":
            return try transaction {
                var count = 0
                for row in try snapshot() where ["entries","recipes","ledger"].contains(row["store"] as? String ?? "") {
                    if let value = row["value"] as? [String: Any], value["_deletedAt"] != nil, request["expiredOnly"] as? Bool != true || (value["_deleteExpiresAt"] as? Double ?? Double.greatestFiniteMagnitude) <= JSON.now {
                        try execute("DELETE FROM records WHERE store=? AND key=?", [row["store"] as! String, row["key"] as! String]); count += 1
                    }
                }
                return ["removed":count]
            }
        case "cleanup-files":
            guard try meta("lastBackup") != nil else { throw BearError.message("请先导出完整备份") }
            let refs = Self.references(try snapshot()); var freed = 0
            for url in try FileManager.default.contentsOfDirectory(at: root.appendingPathComponent("media"), includingPropertiesForKeys: [.fileSizeKey]) where !refs.contains("media/" + url.lastPathComponent) {
                freed += try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0; try FileManager.default.removeItem(at: url)
            }
            return ["freedBytes":freed]
        default: throw BearError.message("此版本不支持这项存储操作")
        }
    }
}
