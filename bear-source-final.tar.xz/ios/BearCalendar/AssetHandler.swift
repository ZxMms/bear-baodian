import Foundation
import WebKit
import UniformTypeIdentifiers

final class AssetHandler: NSObject, WKURLSchemeHandler {
    let root: URL, media: URL
    init(root: URL, media: URL) { self.root = root; self.media = media }
    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        guard let url = urlSchemeTask.request.url, url.scheme == "bearapp", url.host == "app", ["GET","HEAD"].contains(urlSchemeTask.request.httpMethod ?? "GET") else { urlSchemeTask.didFailWithError(URLError(.badURL)); return }
        let path = url.path.isEmpty || url.path == "/" ? "index.html" : String(url.path.dropFirst())
        guard !path.contains("\\"), !path.split(separator:"/").contains(".."), !path.contains("\0") else { urlSchemeTask.didFailWithError(URLError(.noPermissionsToReadFile)); return }
        let base = path.hasPrefix("media/") ? media : root
        if path.hasPrefix("media/"), !Store.validMedia(path) { urlSchemeTask.didFailWithError(URLError(.badURL)); return }
        let file = base.appendingPathComponent(path).standardizedFileURL
        guard file.path.hasPrefix(base.standardizedFileURL.path + "/") else { urlSchemeTask.didFailWithError(URLError(.noPermissionsToReadFile)); return }
        do {
            let bytes = try Data(contentsOf:file,options:.mappedIfSafe)
            let custom = ["js":"text/javascript","mjs":"text/javascript","css":"text/css","json":"application/json","wasm":"application/wasm","webp":"image/webp","svg":"image/svg+xml"]
            let mime = custom[file.pathExtension] ?? UTType(filenameExtension:file.pathExtension)?.preferredMIMEType ?? "application/octet-stream"
            let response = HTTPURLResponse(url:url,statusCode:200,httpVersion:"HTTP/1.1",headerFields:["Content-Type":mime,"Content-Length":String(bytes.count),"Cache-Control":"no-store","Access-Control-Allow-Origin":"bearapp://app","X-Content-Type-Options":"nosniff"])!
            urlSchemeTask.didReceive(response)
            if urlSchemeTask.request.httpMethod != "HEAD" { urlSchemeTask.didReceive(bytes) }
            urlSchemeTask.didFinish()
        } catch { urlSchemeTask.didFailWithError(URLError(.fileDoesNotExist)) }
    }
    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) { }
}
