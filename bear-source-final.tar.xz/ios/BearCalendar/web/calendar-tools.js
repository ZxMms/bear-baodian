// Offline mainland-China holiday schedules, verified 2026-11-16.
// Sources and package attribution are also recorded in README.md.
export const holidaySources = {
  2026: { published: "2025-11-04", document: "国办发明电〔2025〕7号", url: "https://www.gov.cn/zhengce/zhengceku/202511/content_7047091.htm" },
  2027: { published: "2026-11-05", document: "国办发明电〔2026〕10号", url: "https://www.gov.cn/zhengce/content/202611/content_7085101.htm" },
};
export const holidays = [
  ["元旦", "2026-01-01", "2026-01-03"], ["春节", "2026-02-15", "2026-02-23"],
  ["清明节", "2026-04-04", "2026-04-06"], ["劳动节", "2026-05-01", "2026-05-05"],
  ["端午节", "2026-06-19", "2026-06-21"], ["中秋节", "2026-09-25", "2026-09-27"],
  ["国庆节", "2026-10-01", "2026-10-07"],
  ["元旦", "2027-01-01", "2027-01-03"], ["春节", "2027-02-05", "2027-02-13"],
  ["清明节", "2027-04-03", "2027-04-05"], ["劳动节", "2027-05-01", "2027-05-05"],
  ["端午节", "2027-06-09", "2027-06-09"], ["中秋节", "2027-09-15", "2027-09-15"],
  ["国庆节", "2027-10-01", "2027-10-07"],
].map(([name, start, end]) => ({ name, start, end, id: `auto-holiday-${start}` }));
const workdays = new Set(["2026-01-04", "2026-02-14", "2026-02-28", "2026-05-09", "2026-09-20", "2026-10-10", "2027-01-31", "2027-02-14", "2027-05-08", "2027-09-26", "2027-10-09"]);
export const workModes = { official: "按国家放假、调休安排", "five-day": "固定双休，法定假期也休息", weekdays: "只按周一至周五计算" };
const dateOnly = (date) => date.toISOString().slice(0, 10);
export const daysBetween = (start, end) => Math.round((Date.parse(end + "T00:00:00Z") - Date.parse(start + "T00:00:00Z")) / 86400000);
export function dayPolicy(date) {
  const holiday = holidays.find((item) => item.start <= date && item.end >= date);
  return { holiday, work: workdays.has(date), known: Boolean(holidaySources[Number(date.slice(0, 4))]) };
}
export function lastWorkday(year, month, mode = "official") {
  if (!workModes[mode]) throw new Error("Unknown workday rule");
  if (mode !== "weekdays" && !holidaySources[year]) return null;
  const day = new Date(Date.UTC(year, month, 0, 12));
  while (day.getUTCMonth() === month - 1) {
    const key = dateOnly(day), weekday = day.getUTCDay(), policy = dayPolicy(key);
    const regular = weekday !== 0 && weekday !== 6;
    const works = mode === "weekdays" ? regular : mode === "five-day" ? regular && !policy.holiday : policy.work || (regular && !policy.holiday);
    if (works) return key;
    day.setUTCDate(day.getUTCDate() - 1);
  }
  return null;
}
export function nextPayday(today, mode = "official") {
  const [year, month] = today.split("-").map(Number);
  for (let step = 0; step < 2; step++) {
    const target = new Date(Date.UTC(year, month - 1 + step, 1, 12));
    const date = lastWorkday(target.getUTCFullYear(), target.getUTCMonth() + 1, mode);
    if (!date) return null;
    if (date >= today) return date;
  }
  return null;
}
export function nextHoliday(today) { return holidays.find((holiday) => holiday.end >= today) || null; }

// One rule drives calendar markers, countdowns and native notification schedules.
export const repeatTypes = { none: "仅这一次", yearly: "每年这一天", monthly: "每月固定几号", "last-workday": "每月最后一个工作日" };
export function recurrenceFor(entry) {
  return entry.recurrence || { type: entry.kind === "anniversary" && entry.repeat ? "yearly" : "none" };
}
export function monthOccurrence(year, month, rule) {
  if (rule.type === "last-workday") return lastWorkday(year, month, rule.workMode || "official");
  const last = new Date(Date.UTC(year, month, 0)).getUTCDate();
  const day = Number(rule.day);
  if (!Number.isInteger(day) || day < 1 || day > 31 || (day > last && rule.overflow === "skip")) return null;
  return `${String(year).padStart(4, "0")}-${String(month).padStart(2, "0")}-${String(Math.min(day, last)).padStart(2, "0")}`;
}
export function nextScheduledDate(start, rule, from) {
  if (!start || !from) return null;
  const floor = start > from ? start : from;
  if (!rule || rule.type === "none") return start >= from ? start : null;
  const [year, month] = floor.split("-").map(Number);
  if (rule.type === "yearly") {
    for (let y = year; y <= Math.min(9999, year + 8); y++) {
      const candidate = String(y).padStart(4, "0") + start.slice(4);
      if (new Date(candidate + "T12:00:00Z").toISOString().slice(0, 10) === candidate && candidate >= floor) return candidate;
    }
    return null;
  }
  if (!["monthly", "last-workday"].includes(rule.type)) return null;
  for (let step = 0; step < 24; step++) {
    const target = new Date(Date.UTC(year, month - 1 + step, 1, 12)), y = target.getUTCFullYear(), m = target.getUTCMonth() + 1;
    if (y > 9999) return null;
    if (rule.type === "last-workday" && rule.workMode !== "weekdays" && !holidaySources[y]) return null;
    const candidate = monthOccurrence(y, m, rule);
    if (candidate && candidate >= floor) return candidate;
  }
  return null;
}
export function ruleDescription(rule, date = "") {
  if (!rule || rule.type === "none") return "仅这一次";
  if (rule.type === "yearly") return date ? `每年 ${Number(date.slice(5, 7))} 月 ${Number(date.slice(8))} 日` : "每年这一天";
  if (rule.type === "monthly") return `每月 ${rule.day} 号`;
  return "每月最后一个工作日";
}
export function knownWorkDates(start, mode) {
  return Object.keys(holidaySources).flatMap((year) => Array.from({ length: 12 }, (_, i) => lastWorkday(Number(year), i + 1, mode)))
    .filter((date) => date && date >= start);
}

const lunarCache = new Map();
export function lunarLabel(date) {
  if (lunarCache.has(date)) return lunarCache.get(date);
  try {
    const [year, month, day] = date.split("-").map(Number);
    if (year < 1900 || year > 2100 || !globalThis.Solar) return { short: "", full: "", term: "" };
    const lunar = globalThis.Solar.fromYmd(year, month, day).getLunar();
    const lunarMonth = lunar.getMonthInChinese() + "月", lunarDay = lunar.getDayInChinese();
    const term = lunar.getJieQi();
    const result = { short: term || (lunar.getDay() === 1 ? lunarMonth : lunarDay),
      full: `农历${lunar.getYearInGanZhi()}年 ${lunarMonth}${lunarDay}`, term };
    lunarCache.set(date, result);
    return result;
  } catch { return { short: "", full: "农历暂不可用", term: "" }; }
}
export function countdownParts(date, time = "00:00", now = Date.now()) {
  const target = new Date(`${date}T${time}:00`).getTime();
  if (!Number.isFinite(target)) return null;
  const remaining = Math.max(0, Math.ceil((target - now) / 1000));
  return { days: Math.floor(remaining / 86400), hours: Math.floor(remaining % 86400 / 3600),
    minutes: Math.floor(remaining % 3600 / 60), seconds: remaining % 60, done: target <= now, target };
}
