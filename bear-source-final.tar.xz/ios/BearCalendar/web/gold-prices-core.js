// All values come from the named source. Never substitute a request time for a quote time.
export const goldSources={quote:'https://ugfe.jr.jd.com/uc-stock/?pageKey=ZL5vVEgPNDY4lBKr&sourceType=stock&uCode=SGE-Au99.99',brands:'https://precious.smm.cn/gold-price'};
export function chinaDay(time=Date.now()){return new Date(time+8*3600000).toISOString().slice(0,10);}
export function quoteTime(time){return new Date(time+8*3600000).toISOString().slice(0,16).replace('T',' ')+' 北京时间';}
const price=value=>{const n=typeof value==='string'&& !/^\d+(?:\.\d+)?$/.test(value)?NaN:Number(value);return Number.isFinite(n)&&n>0&&n<1000000?n:null;};
export function validGoldDate(value,now=Date.now()){return /^20\d{2}-\d{2}-\d{2}$/.test(value)&&Number.isFinite(Date.parse(value+'T00:00:00Z'))&&new Date(value+'T00:00:00Z').toISOString().slice(0,10)===value&&value<=chinaDay(now);}
function payload(raw){const p=typeof raw==='string'?JSON.parse(raw):raw;if(p?.success!==true||p.resultCode!==0||!p.resultData?.data)throw new Error('报价来源暂未返回有效数据');return p.resultData.data;}
export function parseGoldQuote(raw,now=Date.now()){
  const d=payload(raw),p=price(d.currentPrice),time=Number(d.currentTime),previous=price(d.closedYesterday);
  if(!p||!Number.isFinite(time)||time<Date.UTC(2020,0,1)||time>now+300000||d.stockCode!=='Au99.99')throw new Error('报价或更新时间不完整，请稍后重试');
  return {price:p,time,date:chinaDay(time),previous,change:previous?p-previous:null,percent:previous?(p-previous)/previous*100:null,open:price(d.open),high:price(d.maxPrice),low:price(d.minPrice)};
}
export function parseGoldHistory(raw,now=Date.now()){
  const d=payload(raw),rows=d.kLineDtoList;if(!Array.isArray(rows)||rows.length>3000)throw new Error('暂无可用的趋势数据');
  const found=new Map();for(const r of rows){const p=price(r.close);if(p&&validGoldDate(String(r.date),now))found.set(r.date,{date:r.date,price:p});}
  const points=[...found.values()].sort((a,b)=>a.date.localeCompare(b.date));if(!points.length)throw new Error('暂无可用的趋势数据');return points;
}
export function goldPeriod(points,days,now=Date.now()){
  const end=chinaDay(now),start=new Date(Date.parse(end+'T00:00:00Z')-(days-1)*86400000).toISOString().slice(0,10);
  return points.filter(p=>p.date>=start&&p.date<=end);
}
const text=s=>s.replace(/<[^>]*>/g,'').replace(/&nbsp;|&#160;/g,' ').replace(/&amp;/g,'&').trim();
export function parseGoldBrands(raw,now=Date.now()){
  if(typeof raw!=='string'||raw.length>1500000)throw new Error('品牌报价暂不可用');
  const result=new Map();
  // Parse table text only: no external HTML or scripts are inserted into the app.
  for(const row of raw.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)){
    const cells=[...row[1].matchAll(/<td\b[^>]*>([\s\S]*?)<\/td>/gi)].map(m=>text(m[1]));
    if(cells.length!==4)continue;
    const [brand,product,value,date]=cells,p=price(value);
    if(!p||brand.length>24||product.length>40||!validGoldDate(date,now)||!/黄金|足金|金条/.test(product)||/铂|白银|回购|回收|换新/.test(product))continue;
    const key=brand+'|'+product;if(!result.has(key)||result.get(key).date<date)result.set(key,{brand,product,price:p,date,type:/金条|投资/.test(product)?'bar':'jewelry'});
  }
  const rows=[...result.values()].sort((a,b)=>b.date.localeCompare(a.date)||a.brand.localeCompare(b.brand,'zh-CN'));
  if(!rows.length)throw new Error('品牌来源尚未提供可用报价');return rows;
}
