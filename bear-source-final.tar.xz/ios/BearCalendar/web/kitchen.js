import {getSetting,putSetting,saveItemsAtomically,categories} from './model.js?v=37';
import {bearArt} from './illustrations.js?v=37';
import {icon} from './icons.js?v=37';
import {mealSlots,localDateKey,isDateKey,addDays,weekStart,weekDays,ingredientLines,cookingSteps,timerSeconds,timerRemaining,durationText,emptyWeek,normalizeWeek,shoppingCandidates,cookingHistory,newCookingSession,reconcileSession,cookingOpenChoice,activeMiniTimers,mealPlanForDay} from './kitchen-core.js?v=37';

let ui,sessions={},activeRecipe=null,currentWeek=null,clock=null,saveTail=Promise.resolve(),wakeLock=null,wakePending=false,lastViewKey='';
let previewAudio=null,previewGeneration=0,previewPlaying=false;
let ringHealth=null,ringTest=null,nextRingHealthCheck=0;
let pendingCooking=null,miniTimer=null,miniObserver=null;
const RING_TEST_ID='__bear_ring_test__';
const scrollPositions=new Map(),rememberScroll=new Set(['kitchen-planner','kitchen-shopping']);
const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uid=()=>globalThis.crypto?.randomUUID?.()||Date.now().toString(36)+Math.random().toString(36).slice(2);
const recipes=()=>ui.getRecipes()||[];
const recipeFor=id=>recipes().find(recipe=>recipe.id===id);
const mealName=id=>mealSlots.find(slot=>slot.id===id)?.name||'';
const short=key=>`${Number(key.slice(5,7))}月${Number(key.slice(8))}日`;
const nativeTimers=()=>typeof window.BearApp?.startCookingTimer==='function';
function store(key,value){const snapshot=JSON.parse(JSON.stringify(value));const next=saveTail.catch(()=>{}).then(()=>putSetting(key,snapshot));saveTail=next;return next;}
const saveSessions=()=>store('kitchen-sessions',sessions);
function announce(message){ui.announce?.(message);}
const builtinPreviewAvailable=()=>!nativeTimers()||(ringHealth?.soundKind==='builtin'&&ringHealth.soundName==='加加加短铃声')||(!ringHealth?.soundKind&&typeof window.BearApp?.chooseCookingRingtone!=='function');
const currentRingName=()=>ringHealth?.soundName||(nativeTimers()?'系统计时铃声':'加加加短铃声');
function ringNote(){return nativeTimers()?'计时与 5 秒试响使用所选通知声音，遵循 iPhone 的静音开关、通知音量和专注模式。':'浏览器可试听铃声；页面关闭或在后台时不保证提醒。';}
function paintPreview(){const button=ui?.sheet.querySelector('[data-kitchen-action="timer-preview"]');if(button){button.hidden=!builtinPreviewAvailable();button.textContent=previewPlaying?'停止试听':'试听加加加短铃声';button.setAttribute?.('aria-pressed',String(previewPlaying));}}
function readRingHealth(){
  if(typeof window.BearApp?.cookingRingingStatus!=='function')return;
  try{ringHealth=JSON.parse(window.BearApp.cookingRingingStatus());}catch{ringHealth={message:'暂时未能读取系统响铃状态，请重试检查。'};}
  if(previewPlaying&&!builtinPreviewAvailable())stopPreview();
}
function applyRingStatus(timer,status){
  for(const key of ['notifications','soundEnabled','alarmVolume','interruptionFilter','deliveryStatus','deliveryError'])if(status[key]!==undefined)timer[key]=status[key];
}
function ringHealthMarkup(){
  if(!ringHealth)return '';
  const info=[];
  if(typeof ringHealth.notifications==='boolean')info.push(ringHealth.notifications?'通知已开启':'通知未开启');
  if(typeof ringHealth.channelSound==='boolean')info.push(ringHealth.channelSound?'铃声已开启':'计时通知为静音');
  if(Number.isFinite(ringHealth.alarmVolume)&&ringHealth.alarmVolume>=0&&Number.isFinite(ringHealth.alarmMaxVolume)&&ringHealth.alarmMaxVolume>0)info.push(`闹钟音量 ${ringHealth.alarmVolume} / ${ringHealth.alarmMaxVolume}`);
  if(Number.isFinite(ringHealth.mediaVolume)&&ringHealth.mediaVolume>=0)info.push(`试听媒体音量 ${ringHealth.mediaVolume}`);
  const dnd={1:'勿扰已关闭',2:'勿扰：优先提醒',3:'勿扰：禁止打扰',4:'勿扰：允许闹钟'}[ringHealth.interruptionFilter];if(dnd)info.push(dnd);
  const testMessage=ringTest?.deliveryStatus==='retrying'?'试响通知暂未发出，正在重试。':['failed','unconfirmed','blocked'].includes(ringTest?.deliveryStatus)?ringTest.deliveryError||'试响暂未确认，请检查系统设置。':'';
  return `${testMessage?`<p>${escape(testMessage)}</p>`:''}<p>${escape(ringHealth.message||'可点「5 秒试响」检查到点提醒。')}</p><small>${info.map(escape).join(' · ')}</small>`;
}
function checkRingTest(){
  if(!ringTest)return;
  ringTest.checked=true;
  try{const status=JSON.parse(window.BearApp.cookingTimerStatus(RING_TEST_ID));applyRingStatus(ringTest,status);if(!status.known){ringTest.deliveryStatus='unconfirmed';ringTest.deliveryError='暂未找到试响提醒，请取消后再试。';}}
  catch{ringTest.deliveryStatus='unconfirmed';ringTest.deliveryError='暂未确认试响通知，请检查系统设置。';}
  readRingHealth();
}
function paintRingControls(){
  const name=ui?.sheet.querySelector('[data-kitchen-ring-name]');if(name)name.textContent=currentRingName();
  const note=ui?.sheet.querySelector('[data-kitchen-ring-note]');if(note)note.textContent=ringNote();
  const box=ui?.sheet.querySelector('[data-kitchen-ring-health]');if(box){const markup=ringHealthMarkup();if(box.innerHTML!==markup)box.innerHTML=markup;box.hidden=!ringHealth;}
  const test=ui?.sheet.querySelector('[data-kitchen-action="timer-ring-test"]');if(test)test.textContent=ringTest?(Date.now()<ringTest.endAt?`取消试响 · ${Math.max(1,Math.ceil((ringTest.endAt-Date.now())/1000))} 秒`:'停止试响'):'5 秒试响';
}
async function toggleRingTest(){
  if(ringTest){if(typeof window.BearApp?.cancelCookingRingingTest!=='function'||window.BearApp.cancelCookingRingingTest()===false)throw new Error('试响暂未停止，请在通知中停止');ringTest=null;paintRingControls();announce('试响已取消');return;}
  if(typeof window.BearApp?.testCookingRinging!=='function')throw new Error('请安装新版手机 App 后使用 5 秒试响');
  stopPreview();const result=JSON.parse(window.BearApp.testCookingRinging());
  if(!result.ok)throw new Error(result.message||'试响未能安排，请重试');
  ringTest={endAt:Number(result.endAt)||Date.now()+5000,checked:false};readRingHealth();paintRingControls();
  announce(`已安排 5 秒试响，不会改动当前做菜计时。${result.message||''}`);
}
function stopPreview(){previewGeneration++;const audio=previewAudio;previewAudio=null;previewPlaying=false;if(audio){audio.pause();try{audio.currentTime=0;}catch{}}paintPreview();}
async function togglePreview(){
  if(previewPlaying){stopPreview();return;}
  if(!builtinPreviewAvailable()){announce('当前使用手机所选铃声，请点「5 秒试响」试听');return;}
  if(document.visibilityState==='hidden')return;
  const generation=++previewGeneration;
  try{
    const audio=new Audio('assets/cooking-alarm.mp3');previewAudio=audio;audio.preload='auto';audio.loop=false;audio.volume=.75;
    previewPlaying=true;paintPreview();
    audio.addEventListener('ended',()=>{if(previewAudio===audio)stopPreview();},{once:true});
    audio.addEventListener('error',()=>{if(previewAudio===audio){stopPreview();announce('铃声暂时没能播放，请再试一次');}},{once:true});
    await audio.play();
    if(generation!==previewGeneration||document.visibilityState==='hidden'||!ui.sheet.open||ui.sheet.dataset.view!=='cooking'){audio.pause();return;}
  }catch{if(generation===previewGeneration){stopPreview();announce('铃声暂时没能播放，请再点一次试听');}}
}
function show(title,content,view){
  if(view!=='cooking')stopPreview();
  if(ui.sheet.open&&rememberScroll.has(ui.sheet.dataset.view)&&lastViewKey)scrollPositions.set(lastViewKey,ui.sheet.querySelector('.sheet-content')?.scrollTop||0);
  ui.open(title,content);ui.sheet.dataset.view=view;lastViewKey=`${view}:${currentWeek?.week||''}`;
  if(rememberScroll.has(view)){const panel=ui.sheet.querySelector('.sheet-content');if(panel)panel.scrollTop=scrollPositions.get(lastViewKey)||0;}
  refreshKitchenTimer();
}
function releaseAwake(){if(wakeLock){wakeLock.release().catch(()=>{});wakeLock=null;}}
async function keepAwake(){if(wakeLock||wakePending)return;if(document.visibilityState==='visible'&&ui.sheet.open&&ui.sheet.dataset.view==='cooking'&&navigator.wakeLock){wakePending=true;try{wakeLock=await navigator.wakeLock.request('screen');wakeLock.addEventListener('release',()=>{wakeLock=null;});if(document.visibilityState!=='visible'||!ui.sheet.open||ui.sheet.dataset.view!=='cooking')releaseAwake();}catch{}finally{wakePending=false;}}}
async function syncNativeTimers(){
  readRingHealth();
  if(typeof window.BearApp?.cookingTimerStatus!=='function')return;
  let changed=false;
  for(const session of Object.values(sessions)){
    if(!session?.timer?.system)continue;
    if(session.timer.notified&&session.recipeId!==activeRecipe?.id&&session.timer.deliveryStatus!=='retrying')continue;
    try{const status=JSON.parse(window.BearApp.cookingTimerStatus(session.recipeId));
      const before=JSON.stringify(session.timer);applyRingStatus(session.timer,status);if(before!==JSON.stringify(session.timer))changed=true;
      if(status.known&&Number.isFinite(Number(status.endAt))&&Number(status.endAt)>0){
        const endAt=status.finished?Math.min(Date.now(),Number(status.endAt)):Number(status.endAt);
        if(session.timer.endAt!==endAt){session.timer.endAt=endAt;changed=true;}
      }else if(!status.known&&!session.timer.notified){const message='系统中没有这次计时提醒。当前只显示剩余时间，想重新提醒可取消后再开始。';if(session.timer.message!==message){session.timer.message=message;changed=true;}}
    }catch{}
  }
  if(changed)await saveSessions();
}
export async function initKitchen(callbacks){
  ui=callbacks;const saved=await getSetting('kitchen-sessions');sessions=saved&&typeof saved==='object'&&!Array.isArray(saved)?saved:{};
  if(clock)clearInterval(clock);clock=setInterval(tick,1000);
  ui.sheet.addEventListener('close',()=>{releaseAwake();stopPreview();refreshKitchenTimer();});
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden'){releaseAwake();stopPreview();}else{syncNativeTimers().then(()=>{tick();keepAwake();}).catch(error=>announce(error.message));}});
  await syncNativeTimers();tick();
}
function tick(){
  let changed=false;
  for(const session of Object.values(sessions))if(session?.timer&&Number.isFinite(session.timer.endAt)&&session.timer.endAt<=Date.now()&&!session.timer.notified){
    if(session.timer.system&&typeof window.BearApp?.cookingTimerStatus==='function'){
      try{const status=JSON.parse(window.BearApp.cookingTimerStatus(session.recipeId));applyRingStatus(session.timer,status);
        if(status.active&&Number(status.endAt)>Date.now()){session.timer.endAt=Number(status.endAt);changed=true;continue;}
      }catch{session.timer.deliveryError='未能确认系统提醒，请检查通知设置';session.timer.deliveryStatus='unconfirmed';}
    }
    session.timer.notified=true;changed=true;announce(`「${session.title}」的计时到了，看看锅里的美味吧`);
  }
  if(changed)saveSessions().catch(error=>announce(error.message));
  refreshKitchenTimer();
  const visible=ui?.sheet.open&&ui.sheet.dataset.view==='cooking';
  if(!visible){releaseAwake();if(previewPlaying)stopPreview();return;}
  if(ringTest&&Date.now()>=ringTest.endAt&&!ringTest.checked)checkRingTest();
  if(ringTest&&Date.now()>ringTest.endAt+30000)ringTest=null;
  if(Date.now()>=nextRingHealthCheck){nextRingHealthCheck=Date.now()+5000;readRingHealth();if(ringTest?.deliveryStatus==='retrying')checkRingTest();const current=sessions[activeRecipe?.id]?.timer;if(current?.system&&current.deliveryStatus==='retrying'){try{applyRingStatus(current,JSON.parse(window.BearApp.cookingTimerStatus(activeRecipe.id)));saveSessions().catch(()=>{});}catch{}}}
  const session=sessions[activeRecipe?.id],counter=ui.sheet.querySelector('[data-kitchen-clock]');
  if(counter&&session?.timer){const remaining=timerRemaining(session.timer.endAt),label=remaining?durationText(remaining):'时间到啦';if(counter.textContent!==label)counter.textContent=label;counter.classList.toggle('is-done',remaining===0);const message=ui.sheet.querySelector('[data-kitchen-timer-message]');if(message)message.textContent=timerMessage(session.timer,remaining);const stop=ui.sheet.querySelector('[data-kitchen-ring-stop]');if(stop){stop.hidden=remaining>0||!session.timer.system;stop.disabled=Boolean(session.timer.ringStopped);stop.textContent=session.timer.ringStopped?'已清除通知':'清除通知';}const clear=ui.sheet.querySelector('[data-kitchen-timer-clear]');if(clear)clear.textContent=remaining?'取消计时':'重新计时';}
  paintPreview();
  paintRingControls();
}
function timerMessage(timer,remaining){
  if(remaining)return timer.message||'再次打开做菜模式，可继续查看计时。';
  if(timer.ringStopped)return '通知已清除，已完成的计时还留在这里。';
  if(!timer.system)return '计时已结束。浏览器只提供页面提示，手机 App 可在后台响铃。';
  if(timer.deliveryStatus==='retrying')return '计时已结束，系统提醒暂未送达，正在重试。';
  if(timer.deliveryStatus==='expired')return '这次计时已经结束较久，不再补响。可以重新开启计时。';
  if(timer.deliveryStatus==='blocked')return '计时已结束，提醒触发时通知未开启。可点「检查响铃」查看。';
  if(['failed','unconfirmed'].includes(timer.deliveryStatus))return `计时已结束，${timer.deliveryError||'未能确认系统提醒是否送达'}。可点「检查响铃」查看。`;
  if(timer.notifications===false)return '计时已结束。通知未开启，后台无法响铃。';
  if(timer.soundEnabled===false)return '计时已结束。计时通知设为静音，可在响铃设置中调整。';
  if(timer.alarmVolume===0)return '计时已结束。系统闹钟音量为 0，请调高闹钟音量后试响。';
  if(timer.interruptionFilter===3)return '计时已结束。当前勿扰模式可能阻止响铃，请检查系统设置。';
  return '计时已结束，已请求系统提醒。通知声音与显示由 iOS 控制。';
}
function ringControlsMarkup(){
  const native=nativeTimers(),canChoose=native&&(typeof window.BearApp?.chooseCookingRingtone==='function'||typeof window.BearApp?.cookingNotificationSettings==='function');
  return `<div class="kitchen-ring-info"><div><small>${native?'当前计时铃声':'内置铃声'}</small><strong data-kitchen-ring-name>${escape(currentRingName())}</strong><small>${native?'通过 iOS 通知提醒':'手机 App 支持后台响铃'}</small></div>${canChoose?'<button type="button" class="text-button" data-kitchen-action="timer-ring-choose">选择提醒声音 ›</button>':''}</div>
    ${canChoose?'<p class="kitchen-ring-note">可选择默认通知声音或熊熊短提示音，对新建计时生效。</p>':''}
    <button type="button" class="text-button kitchen-builtin-preview" data-kitchen-action="timer-preview" aria-pressed="${previewPlaying}" ${builtinPreviewAvailable()?'':'hidden'}>${previewPlaying?'停止试听':'试听加加加短铃声'}</button>
    <p class="kitchen-ring-note" data-kitchen-ring-note>${ringNote()}</p>
    ${native?`<div class="kitchen-ring-check-actions">${typeof window.BearApp?.testCookingRinging==='function'?'<button type="button" class="secondary" data-kitchen-action="timer-ring-test">5 秒试响</button>':''}<button type="button" class="text-button" data-kitchen-action="timer-ring-check">检查响铃</button></div><div class="kitchen-ring-health" data-kitchen-ring-health ${ringHealth?'':'hidden'} aria-live="polite">${ringHealthMarkup()}</div>`:''}`;
}
function timerMarkup(session){
  const timer=session.timer,remaining=timer?timerRemaining(timer.endAt):0;
  return `<section class="kitchen-timer"><div><h3>${icon('clock')}熊熊计时器</h3><p>${timer?escape(timer.label):'需要煎、蒸、炖多久？自己设一个小提醒。'}</p></div>${timer?`<strong data-kitchen-clock class="${remaining?'':'is-done'}" role="timer" aria-label="剩余时间">${remaining?durationText(remaining):'时间到啦'}</strong><div class="kitchen-timer-actions"><button type="button" class="secondary" data-kitchen-action="timer-ring-stop" data-kitchen-ring-stop ${remaining||!timer.system?'hidden':''} ${timer.ringStopped?'disabled':''}>${timer.ringStopped?'已清除通知':'清除通知'}</button><button type="button" class="text-button" data-kitchen-action="timer-stop" data-kitchen-timer-clear>${remaining?'取消计时':'重新计时'}</button></div><p class="photo-hint" data-kitchen-timer-message>${escape(timerMessage(timer,remaining))}</p>`:`<form data-form="kitchen-timer"><label for="kitchen-minutes">计时分钟</label><div class="kitchen-timer-input"><input id="kitchen-minutes" name="minutes" type="number" min="1" max="240" inputmode="numeric" value="5" required><button class="secondary" type="submit">开始计时</button></div><p class="form-error" role="alert"></p></form>`}${ringControlsMarkup()}</section>`;
}
function cookingMarkup(recipe,session){
  const steps=cookingSteps(recipe.steps),ingredients=ingredientLines(recipe.ingredients),step=Math.min(session.step,Math.max(0,steps.length-1)),history=cookingHistory(ui.getEntries()||[],recipe.id);
  return `<div class="kitchen-cooking-header">${bearArt('kitchen',recipe.id,'kitchen-mode-bear',10)}<div><p>${escape(recipe.category||'我的菜谱')}</p><h3>${escape(recipe.title)}</h3><small>成品记录日期：${escape(session.date)}</small></div></div>
    ${session.completedAt?`<div class="kitchen-completed"><strong>这次已经做好啦 ♡</strong><p>成品记录可以继续补充照片；想再做一次，也可以重新开始。</p><button type="button" class="secondary" data-kitchen-action="cooking-restart">重新开始做这道菜</button></div>`:''}
    <details class="kitchen-ingredients" ${!steps.length?'open':''}><summary>准备食材 <span>${session.checked.length} / ${ingredients.length}</span></summary>${ingredients.length?ingredients.map((text,index)=>`<label class="kitchen-check"><input type="checkbox" name="kitchenIngredient" value="${index}" ${session.checked.includes(index)?'checked':''}><span>${escape(text)}</span></label>`).join(''):'<p class="photo-hint">这道菜还没有写食材，可以先返回菜谱补充。</p>'}</details>
    ${steps.length?`<section class="kitchen-step"><div class="kitchen-step-label"><span>第 ${step+1} 步</span><small>共 ${steps.length} 步</small></div><p>${escape(steps[step])}</p><div class="kitchen-step-progress" aria-hidden="true"><i style="width:${(step+1)/steps.length*100}%"></i></div><div class="kitchen-step-actions"><button type="button" class="secondary" data-kitchen-action="step-prev" ${step===0?'disabled':''}>${icon('back')}上一步</button><button type="button" class="secondary" data-kitchen-action="step-next" ${step===steps.length-1?'disabled':''}>下一步${icon('back','kitchen-forward')}</button></div></section>`:`<p class="kitchen-no-steps">这道菜还没有步骤。可以先准备食材，也可以返回菜谱把做法补上。</p>`}
    ${timerMarkup(session)}<button type="button" class="primary kitchen-finish" data-kitchen-action="cooking-finish">${icon('check')}做好啦，拍张成品照</button><button type="button" class="text-button kitchen-history-link" data-kitchen-history="${escape(recipe.id)}">已经记录过 ${history.length} 次 · 看历次成品 ›</button><p class="photo-hint">步骤和勾选会自动保存。${nativeTimers()?'后台提醒以手机通知和准时提醒权限为准。':'浏览器关闭后无法保证提醒，App 可使用系统计时通知。'}</p>`;
}
export function mountKitchenTimer(host=document.body){
  if(miniTimer||!host?.appendChild||!document.createElement)return miniTimer;
  miniTimer=document.createElement('button');miniTimer.type='button';miniTimer.className='kitchen-mini-timer';miniTimer.hidden=true;
  miniTimer.addEventListener('click',event=>{event.stopPropagation();const session=sessions[miniTimer.dataset.recipeId];if(!session)return;const resume=()=>activateCooking(recipeFor(session.recipeId)||{id:session.recipeId,title:session.title,ingredients:session.ingredients,steps:session.steps},session.date).catch(error=>announce(error.message));if(ui.confirmLeave)ui.confirmLeave(resume);else resume();});
  host.appendChild(miniTimer);
  if(typeof MutationObserver!=='undefined'){miniObserver=new MutationObserver(refreshKitchenTimer);miniObserver.observe(ui.sheet,{attributes:true,attributeFilter:['open','data-view']});}
  refreshKitchenTimer();return miniTimer;
}
export function refreshKitchenTimer(){
  if(!miniTimer)return;
  const active=activeMiniTimers(sessions),session=active[0];
  miniTimer.hidden=!session||Boolean(ui.sheet.open)||document.visibilityState==='hidden';
  document.body?.classList?.toggle('has-kitchen-mini-timer',!miniTimer.hidden);
  if(miniTimer.hidden)return;
  const remaining=timerRemaining(session.timer.endAt),label=remaining?durationText(remaining):'时间到啦';
  const key=`${session.recipeId}:${label}:${active.length}`;
  if(miniTimer.dataset.renderKey!==key){miniTimer.dataset.recipeId=session.recipeId;miniTimer.dataset.renderKey=key;miniTimer.innerHTML=`<span class="kitchen-mini-icon">${icon('clock')}</span><span class="kitchen-mini-copy"><strong>${escape(session.title)}</strong><small>${active.length>1?`另有 ${active.length-1} 个计时 · `:''}点此回到做菜步骤</small></span><b>${label}</b>${icon('back','kitchen-forward')}`;miniTimer.setAttribute('aria-label',`${session.title}，${remaining?'剩余 '+label:'时间到啦'}，返回做菜步骤`);}
}
async function activateCooking(recipe,date){
  activeRecipe=recipe;pendingCooking=null;
  const next=reconcileSession(sessions[recipe.id],recipe,date),snapshot={...sessions,[recipe.id]:next};
  await store('kitchen-sessions',snapshot);sessions=snapshot;
  await syncNativeTimers();show('跟熊熊做饭',cookingMarkup(recipe,sessions[recipe.id]),'cooking');keepAwake();tick();
}
function chooseCooking(recipe,date){
  const old=sessions[recipe.id];pendingCooking={recipe,date};releaseAwake();
  show('这次想怎么做',`<div class="kitchen-session-choice">${bearArt('kitchen',recipe.id,'kitchen-choice-bear',10)}<h3>${escape(recipe.title)}</h3><p>上次的步骤和勾选，已经替你收好了。</p><button type="button" class="secondary" data-kitchen-action="cooking-continue"><span><strong>${old.completedAt?'回到上次做菜进度':'继续上次做菜'}</strong><small>美食记录日期：${escape(old.date)}${old.completedAt?' · 已完成':''}</small></span>${icon('back','kitchen-forward')}</button><button type="button" class="primary" data-kitchen-action="cooking-new"><span><strong>${old.timer?'停止原计时，重新开始':'重新做一份'}</strong><small>美食记录日期：${escape(date)}${date===localDateKey()?' · 今天':''}</small></span>${icon('plus')}</button><p class="photo-hint">${old.timer?'重新开始会停止这道菜原有的计时，清空本次步骤和食材勾选；以前保存的美食照片和日记会保留。':'重新开始会重置步骤和食材勾选；以前保存的美食照片和日记会保留。'}</p></div>`,'kitchen-session-choice');
}
export async function openCooking(recipe,date){
  if(!recipe){announce('这道菜谱暂时找不到了');return;}
  const choice=cookingOpenChoice(sessions[recipe.id],recipe,date);
  if(choice.needsChoice){chooseCooking(recipe,choice.date);return;}
  await activateCooking(recipe,choice.date);
}
function redrawCooking(){
  if(!activeRecipe)return;
  const previous=ui.sheet.querySelector('.sheet-content'),scrollTop=previous?.scrollTop||0,expanded=ui.sheet.querySelector('.kitchen-ingredients')?.open;
  const focused=document.activeElement?.dataset?.kitchenAction;
  show('跟熊熊做饭',cookingMarkup(activeRecipe,sessions[activeRecipe.id]),'cooking');
  const details=ui.sheet.querySelector('.kitchen-ingredients');if(details&&expanded!==undefined)details.open=expanded;
  const content=ui.sheet.querySelector('.sheet-content');if(content)content.scrollTop=scrollTop;
  if(focused){const target=ui.sheet.querySelector(`[data-kitchen-action="${focused}"]`);if(target&&!target.disabled)target.focus({preventScroll:true});}
  tick();keepAwake();
}
async function stopTimer(){if(!activeRecipe)return;stopPreview();try{if(window.BearApp?.cancelCookingTimer?.(activeRecipe.id)===false)throw new Error('系统计时暂未取消，请重试');}catch(error){throw new Error(error.message||'系统计时暂未取消，请重试');}sessions[activeRecipe.id].timer=null;await saveSessions();}
export function openCookingHistory(recipe){
  if(!recipe)return;const history=cookingHistory(ui.getEntries()||[],recipe.id);
  show('这道菜的成品日记',`<p class="detail-meta">${escape(recipe.title)} · ${history.length} 次美食记录</p>${history.length?`<div class="kitchen-history">${history.map(entry=>`<button type="button" data-kitchen-entry="${escape(entry.id)}" data-kitchen-date="${escape(entry.date)}">${entry.photos?.[0]?ui.imageMarkup(entry.photos[0],'kitchen-history-photo','成品照片'):bearArt('kitchen',entry.id,'kitchen-history-bear')}<span><strong>${escape(short(entry.date))} · ${escape(entry.title)}</strong><small>${escape(entry.note||'这次的美味，收好啦')}</small></span><b aria-hidden="true">›</b></button>`).join('')}</div>`:`<div class="kitchen-empty">${bearArt('kitchen',recipe.id,'kitchen-empty-bear',11)}<p>做完拍张照，慢慢收集自己的拿手菜。</p></div>`}<button type="button" class="primary" data-kitchen-cook="${escape(recipe.id)}">${icon('recipes')}开始做这道菜</button>`,'kitchen-history');
}
export async function openMealPlanner(date=localDateKey()){
  const start=weekStart(isDateKey(date)?date:localDateKey());currentWeek=normalizeWeek(await getSetting('kitchen-week:'+start),start);showPlanner();
}
export async function getMealPlan(date=localDateKey()){
  if(!isDateKey(date))throw new Error('日期无效');
  await saveTail.catch(()=>{});const start=weekStart(date),week=normalizeWeek(await getSetting('kitchen-week:'+start),start);
  return mealPlanForDay(week,recipes(),date);
}
export async function addShoppingItems(date,items){
  if(!isDateKey(date)||!Array.isArray(items))throw new Error('请重新选择买菜日期和食材');
  const start=weekStart(date),key='kitchen-week:'+start;
  const additions=items.map(item=>({text:String(item?.text||'').trim(),recipeTitle:String(item?.recipeTitle||'').trim().slice(0,120),recipeId:String(item?.recipeId||'').slice(0,200),source:String(item?.sourceKey||'').slice(0,500)}));
  if(additions.some(item=>!item.text||item.text.length>120))throw new Error('采购项目请填写 1–120 个字');
  const next=saveTail.catch(()=>{}).then(async()=>{
    const week=normalizeWeek(await getSetting(key),start),added=[];
    for(const item of additions){
      if(week.shopping.some(old=>(item.source&&old.source===item.source)||(!old.done&&old.text===item.text&&(old.recipeTitle||'')===item.recipeTitle)))continue;
      const row={id:uid(),...item,date,done:false};week.shopping.push(row);added.push(row);
    }
    if(week.shopping.length>500)throw new Error('这周清单已有很多项目，请先整理一下');
    if(added.length){week.updated=Date.now();await saveItemsAtomically([{store:'settings',key,value:week}]);}
    if(currentWeek?.week===start)currentWeek=week;
    return {added:added.length,items:added,week:start};
  });saveTail=next;return next;
}
async function actOnPlannedMeal(id,date,action){
  const day=await getMealPlan(date),plan=day.plans.find(item=>item.id===id);
  if(!plan){announce('这一餐的安排已经变了，请重新打开日期查看');return;}
  if(action==='log'){
    if(ui.recordPlannedMeal)ui.recordPlannedMeal({title:plan.title,date,recipeId:plan.recipe?.id,meal:plan.meal});
    else if(plan.recipe)ui.recordMeal(plan.recipe,date);
    return;
  }
  if(plan.recipe){await openCooking(plan.recipe,date);return;}
  show('这一餐的安排',`<div class="kitchen-manual-meal">${bearArt('kitchen',plan.id,'kitchen-choice-bear',10)}<p class="detail-meta">${escape(date)} · ${escape(plan.mealName)}</p><h3>${escape(plan.title)}</h3><p>这是一道手动安排的菜，还没有食材和做法。做好后，可以直接记下这次的美味。</p><button type="button" class="primary" data-kitchen-plan-log="${escape(plan.id)}" data-kitchen-date="${escape(date)}">${icon('plus')}记下这份美食</button><button type="button" class="secondary" data-kitchen-action="planner" data-kitchen-date="${escape(date)}">到周菜单补充菜谱</button></div>`,'kitchen-manual-meal');
}
function showPlanner(){
  const days=weekDays(currentWeek.week),today=localDateKey();
  const dayCards=days.map((date,index)=>`<section class="kitchen-plan-day ${date===today?'is-today':''}"><h3>${['周一','周二','周三','周四','周五','周六','周日'][index]}<small>${short(date)}${date===today?' · 今天':''}</small></h3>${mealSlots.map(meal=>{
    const planned=currentWeek.plans.filter(plan=>plan.date===date&&plan.meal===meal.id);
    return `<div class="kitchen-meal"><div class="kitchen-meal-label"><strong>${meal.name}</strong><button type="button" class="text-button" data-kitchen-action="plan-add" data-kitchen-date="${date}" data-kitchen-meal="${meal.id}" aria-label="安排${short(date)}${meal.name}">${icon('plus')}安排</button></div>${planned.length?planned.map(plannedDishMarkup).join(''):'<p class="kitchen-unplanned">留点自由发挥的空间</p>'}</div>`;
  }).join('')}</section>`).join('');
  show('一周吃什么',`<div class="kitchen-week-nav"><button type="button" class="secondary" data-kitchen-action="week-prev" aria-label="菜单上一周">${icon('back')}</button><div><strong>${short(days[0])} — ${short(days[6])}</strong><button type="button" class="text-button" data-kitchen-action="week-today">回到本周</button></div><button type="button" class="secondary" data-kitchen-action="week-next" aria-label="菜单下一周">${icon('back','kitchen-forward')}</button></div><div class="kitchen-week-intro">${bearArt('kitchen',currentWeek.week,'kitchen-plan-bear',6)}<p>选一道拿手菜，或随手写个菜名，<br>慢慢安排这一周的美味。</p></div><button type="button" class="secondary kitchen-shopping-open" data-kitchen-action="shopping">${icon('journal')}买菜清单 · ${currentWeek.shopping.filter(x=>!x.done).length} 项待买${icon('back','kitchen-forward')}</button><div class="kitchen-week-days">${dayCards}</div><p class="photo-hint">安排菜单不会自动生成美食记录或账单；手动菜名只留在这一周，是否收藏由你决定。</p>`,'kitchen-planner');
}
function plannedDishMarkup(plan){
  const recipe=recipeFor(plan.recipeId),title=recipe?.title||plan.title||'原菜谱已删除';
  const action=recipe?`data-kitchen-cook="${escape(recipe.id)}" data-kitchen-date="${plan.date}"`:`data-kitchen-edit-plan="${escape(plan.id)}"`;
  return `<div class="kitchen-planned-recipe"><button type="button" ${action}>${escape(title)}<small>${recipe?'开始做 ›':plan.title?'仅本周 · 点此修改 ›':'点此重新安排 ›'}</small></button><button type="button" class="kitchen-plan-remove" data-kitchen-remove-plan="${escape(plan.id)}" aria-label="移除${escape(title)}">${icon('close')}</button></div>`;
}
function editPlan(date,meal,id=''){
  const list=recipes(),old=currentWeek.plans.find(plan=>plan.id===id),manual=Boolean(old?.title&&!recipeFor(old.recipeId))||!list.length;
  show(old?'修改这一餐':'安排一道菜',`<form data-form="kitchen-plan" data-id="${escape(id)}"><div class="kitchen-plan-when"><div><label for="kitchen-plan-date">日期</label><select id="kitchen-plan-date" name="date">${weekDays(currentWeek.week).map(day=>`<option value="${day}" ${day===date?'selected':''}>${short(day)} · ${['周日','周一','周二','周三','周四','周五','周六'][new Date(day+'T12:00:00').getDay()]}</option>`).join('')}</select></div><div><label for="kitchen-meal">哪一餐</label><select id="kitchen-meal" name="meal">${mealSlots.map(slot=>`<option value="${slot.id}" ${slot.id===meal?'selected':''}>${slot.name}</option>`).join('')}</select></div></div>
    <fieldset class="kitchen-plan-source"><legend class="visually-hidden">怎么安排这道菜</legend><label><input type="radio" name="planSource" value="recipe" ${manual?'':'checked'} ${list.length?'':'disabled'}><span>从菜谱选</span></label><label><input type="radio" name="planSource" value="manual" ${manual?'checked':''}><span>手动填写</span></label></fieldset>
    <fieldset class="kitchen-plan-fields" data-plan-source="recipe" ${manual?'hidden disabled':''}><legend class="visually-hidden">选择已有菜谱</legend><label for="kitchen-recipe">选一道菜</label><select id="kitchen-recipe" name="recipeId">${list.map(recipe=>`<option value="${escape(recipe.id)}" ${old?.recipeId===recipe.id?'selected':''}>${escape(recipe.title)} · ${escape(recipe.category||'其他')}</option>`).join('')}</select><p class="photo-hint">一餐可安排多道菜，同一道菜不会重复加入同一餐。</p></fieldset>
    <fieldset class="kitchen-plan-fields" data-plan-source="manual" ${manual?'':'hidden disabled'}><legend class="visually-hidden">手动填写菜名</legend><label for="kitchen-plan-title">菜名</label><input id="kitchen-plan-title" name="planTitle" value="${escape(old?.title||'')}" maxlength="60" required placeholder="比如：妈妈的红烧肉"><p class="photo-hint">只写菜名，就能放进这一周的菜单。</p>
    <section class="kitchen-plan-collect"><label class="checkbox"><input type="checkbox" name="saveRecipe">同时加入我的菜谱</label><p class="photo-hint">默认只安排这一餐；勾选后，以后也能从菜谱中选它。</p><fieldset class="kitchen-plan-fields" data-plan-details hidden disabled><legend class="visually-hidden">新菜谱的选填信息</legend><label for="kitchen-plan-category">分类 <small>选填</small></label><select id="kitchen-plan-category" name="planCategory">${categories.map(category=>`<option ${category==='其他'?'selected':''}>${category}</option>`).join('')}</select><label for="kitchen-plan-ingredients">食材 <small>选填</small></label><textarea id="kitchen-plan-ingredients" name="planIngredients" maxlength="2000" rows="3" placeholder="例如：五花肉 500 克、姜 3 片"></textarea><label for="kitchen-plan-steps">做法 <small>选填</small></label><textarea id="kitchen-plan-steps" name="planSteps" maxlength="5000" rows="3" placeholder="先收好菜名，做法以后慢慢补也可以"></textarea><p class="photo-hint">封面照片、小红书链接等，可以保存后到菜谱里继续补充。</p></fieldset></section></fieldset>
    <p class="form-error" role="alert"></p><button class="primary" type="submit">${old?'保存安排':'加入这一餐'}</button><button type="button" class="secondary" data-kitchen-action="planner-current">返回周菜单</button></form>`,'kitchen-plan-edit');
  ui.setDraft?.();
}
function updatePlanFields(form){
  const manual=form.querySelector('[name="planSource"]:checked')?.value==='manual';
  for(const fields of form.querySelectorAll('[data-plan-source]')){const active=(fields.dataset.planSource==='manual')===manual;fields.hidden=!active;fields.disabled=!active;}
  const details=form.querySelector('[data-plan-details]'),collect=manual&&Boolean(form.querySelector('[name="saveRecipe"]')?.checked);
  if(details){details.hidden=!collect;details.disabled=!collect;}
}
const sameDishName=(a,b)=>Boolean(a&&b)&&String(a).normalize('NFKC').trim().replace(/\s+/g,' ').toLocaleLowerCase()===String(b).normalize('NFKC').trim().replace(/\s+/g,' ').toLocaleLowerCase();
async function commitPlanWeek(week,recipe=null){
  const snapshot=JSON.parse(JSON.stringify({...week,updated:Date.now()}));
  const rows=[{store:'settings',key:'kitchen-week:'+snapshot.week,value:snapshot}];
  if(recipe)rows.push({store:'recipes',value:recipe});
  const next=saveTail.catch(()=>{}).then(()=>saveItemsAtomically(rows));saveTail=next;
  await next;currentWeek=snapshot;
}
function showShopping(){
  const checked=currentWeek.shopping.filter(x=>x.done).length;
  show('这一周的买菜清单',`<button type="button" class="day-back text-button" data-kitchen-action="planner-current">${icon('back')}返回周菜单</button><div class="kitchen-shopping-heading"><h3>${short(currentWeek.week)}这一周</h3><span>已买 ${checked} / ${currentWeek.shopping.length}</span></div><div class="kitchen-shopping-actions"><button type="button" class="secondary" data-kitchen-action="ingredients-add">从菜单选食材</button><button type="button" class="secondary" data-kitchen-action="shopping-add">${icon('plus')}自己补一项</button></div><p class="photo-hint">保留原食材和用量，不自动合并不同单位。点文字可修改。</p>${currentWeek.shopping.length?`<div class="kitchen-shopping-list">${currentWeek.shopping.map(item=>`<div class="kitchen-shopping-row ${item.done?'is-done':''}"><label><input type="checkbox" name="kitchenShoppingDone" value="${escape(item.id)}" ${item.done?'checked':''} aria-label="已买${escape(item.text)}"></label><button type="button" data-kitchen-shopping-edit="${escape(item.id)}"><strong>${escape(item.text)}</strong>${item.recipeTitle?`<small>${escape(item.recipeTitle)}${isDateKey(item.date)?` · ${escape(short(item.date))}${mealName(item.meal)}`:''}</small>`:''}</button><button type="button" class="kitchen-plan-remove" data-kitchen-shopping-remove="${escape(item.id)}" aria-label="移除${escape(item.text)}">${icon('close')}</button></div>`).join('')}</div>`:`<div class="kitchen-empty">${bearArt('kitchen',currentWeek.week,'kitchen-empty-bear',6)}<p>从菜单挑出需要买的食材，<br>冰箱里已有的就不用再买啦。</p></div>`}<div class="kitchen-shopping-handoffs"><button type="button" class="primary" data-kitchen-action="shopping-pantry">${icon('check')}已买食材，核对放进冰箱</button><button type="button" class="secondary" data-kitchen-action="shopping-record">${icon('ledger')}记一笔买菜支出</button></div><p class="photo-hint">只把勾选已买的食材送去核对，确认后才入冰箱；记账仍由你填写实际金额。菜单调整后，清单会保留。</p>`,'kitchen-shopping');
}
function chooseIngredients(){
  const candidates=shoppingCandidates(currentWeek,recipes());
  if(!candidates.length){announce('菜单里还没有新的食材，可以补充菜谱食材或手动加一项');return;}
  show('挑出需要买的食材',`<form data-form="kitchen-ingredients"><p class="photo-hint">先核对用量，只勾选这次要买的。相同食材来自不同餐次时分开保留。</p>${candidates.map((item,index)=>`<label class="kitchen-ingredient-candidate"><input type="checkbox" name="ingredient" value="${index}" checked><span><strong>${escape(item.text)}</strong><small>${escape(item.recipeTitle)} · ${short(item.date)}${mealName(item.meal)}</small></span></label>`).join('')}<p class="form-error" role="alert"></p><button type="submit" class="primary">加入买菜清单</button><button type="button" class="secondary" data-kitchen-action="shopping">返回清单</button></form>`,'kitchen-ingredients-select');
}
function editShopping(id){
  const item=currentWeek.shopping.find(x=>x.id===id);
  show(item?'修改采购项目':'补充一项食材',`<form data-form="kitchen-shopping-edit" data-id="${escape(item?.id||'')}"><label for="kitchen-shopping-text">要买什么</label><input id="kitchen-shopping-text" name="text" maxlength="120" required placeholder="比如：番茄 2 个" value="${escape(item?.text||'')}"><p class="form-error" role="alert"></p><button type="submit" class="primary">保存到清单</button><button type="button" class="secondary" data-kitchen-action="shopping">返回清单</button></form>`,'kitchen-shopping-edit');
  ui.setDraft?.();
}
export async function kitchenClicked(data){
  if(data.kitchenPlanCook||data.kitchenPlanLog){await actOnPlannedMeal(data.kitchenPlanCook||data.kitchenPlanLog,data.kitchenDate,data.kitchenPlanLog?'log':'cook');return true;}
  if(data.kitchenCook){await openCooking(recipeFor(data.kitchenCook),data.kitchenDate);return true;}
  if(data.kitchenHistory){openCookingHistory(recipeFor(data.kitchenHistory));return true;}
  if(data.kitchenEntry){ui.openEntry?.(data.kitchenEntry,data.kitchenDate);return true;}
  if(data.kitchenEditPlan){const plan=currentWeek.plans.find(item=>item.id===data.kitchenEditPlan);if(plan)editPlan(plan.date,plan.meal,plan.id);return true;}
  if(data.kitchenRemovePlan){await commitPlanWeek({...currentWeek,plans:currentWeek.plans.filter(plan=>plan.id!==data.kitchenRemovePlan)});showPlanner();return true;}
  if(data.kitchenShoppingEdit){editShopping(data.kitchenShoppingEdit);return true;}
  if(data.kitchenShoppingRemove){await commitPlanWeek({...currentWeek,shopping:currentWeek.shopping.filter(item=>item.id!==data.kitchenShoppingRemove)});showShopping();return true;}
  const action=data.kitchenAction;if(!action)return false;
  if(action==='planner'){await openMealPlanner(data.kitchenDate);return true;}
  if(action==='planner-current'){if(ui.sheet.dataset.view==='kitchen-plan-edit'&&ui.confirmLeave)ui.confirmLeave(showPlanner);else showPlanner();return true;}
  if(action==='week-prev'||action==='week-next'){await openMealPlanner(addDays(currentWeek.week,action==='week-prev'?-7:7));return true;}
  if(action==='week-today'){await openMealPlanner();return true;}
  if(action==='plan-add'){editPlan(data.kitchenDate,data.kitchenMeal);return true;}
  if(action==='shopping'){if(ui.sheet.dataset.view==='kitchen-shopping-edit'&&ui.confirmLeave)ui.confirmLeave(showShopping);else showShopping();return true;}
  if(action==='ingredients-add'){chooseIngredients();return true;}
  if(action==='shopping-add'){editShopping();return true;}
  if(action==='shopping-pantry'){
    const items=currentWeek.shopping.filter(item=>item.done).map(item=>({id:item.id,text:item.text,sourceKey:`shopping:${currentWeek.week}:${item.id}`}));
    if(!items.length){announce('先勾选已经买好的食材，再核对放进冰箱');return true;}
    if(!ui.openPantryIntake){announce('冰箱入口暂时未准备好，请重新打开 App');return true;}
    await ui.openPantryIntake(items,localDateKey());return true;
  }
  if(action==='shopping-record'){const names=currentWeek.shopping.filter(item=>item.done).map(item=>item.text);ui.recordShopping?.(`买菜 · ${short(currentWeek.week)}这一周${names.length?'：'+names.join('、'):''}`.slice(0,200));return true;}
  if(action==='timer-stop'){await stopTimer();redrawCooking();return true;}
  if(action==='timer-preview'){await togglePreview();return true;}
  if(action==='timer-ring-test'){await toggleRingTest();return true;}
  if(action==='timer-ring-check'){await syncNativeTimers();redrawCooking();announce(ringHealth?.message||'请在手机 App 内检查响铃状态');return true;}
  if(action==='timer-ring-choose'){
    stopPreview();
    if(typeof window.BearApp?.chooseCookingRingtone==='function')window.BearApp.chooseCookingRingtone();
    else if(typeof window.BearApp?.cookingNotificationSettings==='function'){window.BearApp.cookingNotificationSettings();announce('在系统页面的「声音 / 铃声」中选择，返回后自动更新');}
    else announce('请在手机 App 内选择手机铃声');
    return true;
  }
  if(action==='timer-ring-settings'){stopPreview();if(window.BearApp?.cookingNotificationSettings)window.BearApp.cookingNotificationSettings();else announce('请在手机 App 内设置计时铃声与通知');return true;}
  if(action==='timer-ring-stop'){
    const session=sessions[activeRecipe?.id];if(!session?.timer||timerRemaining(session.timer.endAt)>0)return true;
    stopPreview();if(!window.BearApp?.stopCookingTimerRinging)throw new Error('请更新手机 App 后清除通知，也可以在通知中停止');
    if(window.BearApp.stopCookingTimerRinging(activeRecipe.id)===false)throw new Error('暂时没能停止，请在通知中点“清除通知”');
    session.timer.ringStopped=true;session.updated=Date.now();await saveSessions();tick();announce('响铃已停止');return true;
  }
  if(action==='step-prev'||action==='step-next'){const session=sessions[activeRecipe.id];session.step=Math.max(0,Math.min(Math.max(0,cookingSteps(activeRecipe.steps).length-1),session.step+(action==='step-prev'?-1:1)));session.updated=Date.now();await saveSessions();redrawCooking();return true;}
  if(action==='cooking-restart'){chooseCooking(activeRecipe,localDateKey());return true;}
  if(action==='cooking-continue'){
    const choice=pendingCooking;if(!choice)return true;await activateCooking(choice.recipe,sessions[choice.recipe.id].date);return true;
  }
  if(action==='cooking-new'){
    const choice=pendingCooking;if(!choice)return true;
    const old=sessions[choice.recipe.id];
    if(old?.timer){
      if(window.BearApp?.cancelCookingTimer?.(choice.recipe.id)===false)throw new Error('原计时暂未取消，请重试；原进度已保留');
      old.timer=null;
    }
    const snapshot={...sessions,[choice.recipe.id]:newCookingSession(choice.recipe,choice.date)};
    try{await store('kitchen-sessions',snapshot);}catch(error){await saveSessions().catch(()=>{});throw new Error('新进度未保存，请重试。'+error.message);}
    sessions=snapshot;activeRecipe=choice.recipe;pendingCooking=null;show('跟熊熊做饭',cookingMarkup(activeRecipe,sessions[activeRecipe.id]),'cooking');keepAwake();tick();return true;
  }
  if(action==='cooking-finish'){await stopTimer();const session=sessions[activeRecipe.id];session.completedAt=Date.now();await saveSessions();releaseAwake();ui.recordMeal(activeRecipe,session.date);return true;}
  return false;
}
export async function kitchenChanged(input){
  if(input.form?.dataset.form==='kitchen-plan'&&['planSource','saveRecipe'].includes(input.name)){updatePlanFields(input.form);return true;}
  if(input.name==='kitchenIngredient'&&activeRecipe){const session=sessions[activeRecipe.id],index=Number(input.value),checked=new Set(session.checked);input.checked?checked.add(index):checked.delete(index);session.checked=[...checked].sort((a,b)=>a-b);session.updated=Date.now();await saveSessions();const count=ui.sheet.querySelector('.kitchen-ingredients summary span');if(count)count.textContent=`${session.checked.length} / ${ingredientLines(activeRecipe.ingredients).length}`;return true;}
  if(input.name==='kitchenShoppingDone'&&currentWeek){const item=currentWeek.shopping.find(x=>x.id===input.value);if(item){const done=input.checked;try{await commitPlanWeek({...currentWeek,shopping:currentWeek.shopping.map(row=>row.id===item.id?{...row,done}:row)});}catch(error){input.checked=item.done;throw error;}input.closest('.kitchen-shopping-row')?.classList.toggle('is-done',done);const count=ui.sheet.querySelector('.kitchen-shopping-heading span');if(count)count.textContent=`已买 ${currentWeek.shopping.filter(x=>x.done).length} / ${currentWeek.shopping.length}`;}return true;}
  // Meal-planner fields share names with food-entry fields; keep them out of that handler.
  return Boolean(input.form?.dataset.form?.startsWith('kitchen-'));
}
export async function kitchenSubmitted(form){
  const kind=form.dataset.form;if(!kind?.startsWith('kitchen-'))return false;
  const values=new FormData(form);
  if(kind==='kitchen-timer'){
    const seconds=timerSeconds(values.get('minutes')),session=sessions[activeRecipe.id],label=`${activeRecipe.title} · 第 ${session.step+1} 步`;
    stopPreview();let timer={endAt:Date.now()+seconds*1000,label,notified:false,ringStopped:false,message:'浏览器只提供页面提示；关闭后无法保证提醒，重新打开仍可查看计时结果。'};
    if(nativeTimers()){
      const result=JSON.parse(window.BearApp.startCookingTimer(activeRecipe.id,label,seconds));
      if(!result.ok)throw new Error(result.message||'暂时无法开始系统计时，请再试一次');
      if(Number.isFinite(Number(result.endAt))&&Number(result.endAt)>0)timer.endAt=Number(result.endAt);timer.system=true;timer.notifications=result.notifications;timer.soundEnabled=result.soundEnabled;
      applyRingStatus(timer,result);readRingHealth();
      timer.message=result.message||(result.notifications?(result.exact?'已安排系统计时提醒':'系统可能稍晚提醒，请留意锅中情况'):'通知权限未开启，计时会保存，但不会弹出通知');
    }
    session.timer=timer;session.updated=Date.now();await saveSessions();redrawCooking();announce('熊熊帮你记着时间啦');return true;
  }
  if(kind==='kitchen-plan'){
    if(form.dataset.saved==='true')return true;
    const date=String(values.get('date')),meal=String(values.get('meal')),manual=values.get('planSource')==='manual',old=currentWeek.plans.find(plan=>plan.id===form.dataset.id);
    if(!weekDays(currentWeek.week).includes(date)||!mealSlots.some(x=>x.id===meal))throw new Error('请重新选择日期和餐次');
    if(form.dataset.id&&!old)throw new Error('这道菜的安排已经变了，请返回周菜单重新打开');
    if(!old&&currentWeek.plans.length>=100)throw new Error('这一周已安排了很多道菜，先整理一下吧');
    let recipe=null,plan={id:old?.id||uid(),date,meal};
    if(manual){
      const title=String(values.get('planTitle')||'').trim();
      if(!title||title.length>60)throw new Error('请填写 1–60 个字的菜名');
      plan.title=title;
      if(values.get('saveRecipe')){
        if(recipes().some(item=>sameDishName(item.title,title)))throw new Error('菜谱里已有同名菜，请切换到“从菜谱选”，不会重复创建');
        const ingredients=String(values.get('planIngredients')||'').trim(),steps=String(values.get('planSteps')||'').trim(),category=String(values.get('planCategory')||'其他');
        if(ingredients.length>2000||steps.length>5000)throw new Error('食材最多 2000 字，做法最多 5000 字，可以分段精简一下');
        if(!categories.includes(category))throw new Error('请重新选择菜谱分类');
        recipe={id:uid(),title,category,ingredients,steps,photos:[],starter:false,created:Date.now()};
        plan={id:plan.id,date,meal,recipeId:recipe.id};
      }
    }else{
      const chosen=recipeFor(String(values.get('recipeId')||''));
      if(!chosen)throw new Error('请重新选择菜谱，或切换到“手动填写”');
      plan.recipeId=chosen.id;
    }
    const title=recipe?.title||recipeFor(plan.recipeId)?.title||plan.title;
    if(currentWeek.plans.some(item=>item.id!==old?.id&&item.date===date&&item.meal===meal&&((plan.recipeId&&item.recipeId===plan.recipeId)||sameDishName(recipeFor(item.recipeId)?.title||item.title,title))))throw new Error('这一餐已经安排这道菜啦');
    const plans=old?currentWeek.plans.map(item=>item.id===old.id?plan:item):[...currentWeek.plans,plan];
    await commitPlanWeek({...currentWeek,plans},recipe);form.dataset.saved='true';
    let refreshed=true;if(recipe){try{ui.onRecipeSaved?.(recipe);await ui.refreshData?.();}catch{refreshed=false;}}
    showPlanner();announce(!refreshed?'菜单和菜谱已经保存，请重新打开 App 刷新菜谱':recipe?'这一餐安排好了，也收进菜谱啦':old?'这一餐已更新':'这一餐安排好啦');return true;
  }
  if(kind==='kitchen-ingredients'){
    const candidates=shoppingCandidates(currentWeek,recipes()),selected=[...new Set(values.getAll('ingredient').map(Number))].map(index=>candidates[index]).filter(Boolean);
    if(currentWeek.shopping.length+selected.length>500)throw new Error('这周清单已有很多项目，请先整理一下');
    await commitPlanWeek({...currentWeek,shopping:[...currentWeek.shopping,...selected.map(candidate=>({id:uid(),...candidate,done:false}))],ingredientSources:[...currentWeek.ingredientSources,...selected.map(candidate=>candidate.source)]});showShopping();announce(selected.length?`已加入 ${selected.length} 项食材`:'没有添加新食材');return true;
  }
  if(kind==='kitchen-shopping-edit'){
    const text=String(values.get('text')||'').trim();if(!text||text.length>120)throw new Error('请填写 1–120 个字的采购项目');
    const old=currentWeek.shopping.find(item=>item.id===form.dataset.id);if(!old&&currentWeek.shopping.length>=500)throw new Error('请先整理一下这周的清单');
    const shopping=old?currentWeek.shopping.map(item=>item.id===old.id?{...item,text}:item):[...currentWeek.shopping,{id:uid(),text,done:false}];
    await commitPlanWeek({...currentWeek,shopping});showShopping();return true;
  }
  return false;
}
// Caller may refresh this after restore; active recipe pointers are resolved again on opening.
export async function refreshKitchen(){const saved=await getSetting('kitchen-sessions');sessions=saved&&typeof saved==='object'&&!Array.isArray(saved)?saved:{};await syncNativeTimers();tick();}
