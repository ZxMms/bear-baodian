// Direction lock keeps vertical page scrolling and date taps separate from month swipes.
export function swipeAxis(dx, dy) {
  if (Math.max(Math.abs(dx), Math.abs(dy)) < 10) return "pending";
  return Math.abs(dx) > Math.abs(dy) * 1.4 ? "horizontal" : "vertical";
}
export function swipeMonth(dx, dy, width) {
  const threshold = Math.max(48, Math.min(72, width * .18));
  return Math.abs(dx) >= threshold && Math.abs(dx) > Math.abs(dy) * 1.4 ? (dx < 0 ? 1 : -1) : 0;
}
export function bindCalendarSwipe(root, { canStart, changeMonth }) {
  let gesture = null, suppressUntil = 0;
  const clear = () => {
    if (gesture?.grid) {
      gesture.grid.classList.remove("is-dragging");
      gesture.grid.style.removeProperty("transform");
    }
    gesture = null;
  };
  root.addEventListener("pointerdown", (event) => {
    if (!event.isPrimary) { if (gesture) suppressUntil = Date.now() + 600; clear(); return; }
    suppressUntil = 0;
    const calendar = event.target.closest(".calendar");
    if (!calendar || !canStart() || event.button !== 0 || event.target.closest(".month-controls, .today-link")) return;
    clear();
    gesture = { id: event.pointerId, x: event.clientX, y: event.clientY, dx: 0, dy: 0,
      axis: "pending", width: calendar.clientWidth, grid: calendar.querySelector(".day-grid") };
  });
  window.addEventListener("pointermove", (event) => {
    if (!gesture || event.pointerId !== gesture.id) return;
    gesture.dx = event.clientX - gesture.x; gesture.dy = event.clientY - gesture.y;
    if (gesture.axis === "pending") gesture.axis = swipeAxis(gesture.dx, gesture.dy);
    if (gesture.axis !== "pending") suppressUntil = Date.now() + 600;
    if (gesture.axis !== "horizontal") return;
    if (event.cancelable) event.preventDefault();
    gesture.grid.classList.add("is-dragging");
    if (document.documentElement.dataset.reducedMotion !== 'true' && !matchMedia("(prefers-reduced-motion: reduce)").matches)
      gesture.grid.style.transform = `translateX(${Math.max(-38, Math.min(38, gesture.dx * .25))}px)`;
  }, { passive: false });
  window.addEventListener("pointerup", (event) => {
    if (!gesture || event.pointerId !== gesture.id) return;
    const delta = gesture.axis === "horizontal" ? swipeMonth(event.clientX - gesture.x, event.clientY - gesture.y, gesture.width) : 0;
    clear();
    if (delta && canStart()) changeMonth(delta);
  });
  window.addEventListener("pointercancel", () => { if (gesture) suppressUntil = Date.now() + 600; clear(); });
  window.addEventListener("blur", clear);
  document.addEventListener("visibilitychange", () => { if (document.hidden) clear(); });
  root.addEventListener("click", (event) => {
    if (event.detail && Date.now() < suppressUntil && event.target.closest(".calendar")) {
      event.preventDefault(); event.stopImmediatePropagation(); suppressUntil = 0;
    }
  }, true);
}
