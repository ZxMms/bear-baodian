import {validLedgerDate} from './ledger-core.js?v=38';

export const periodModes = Object.freeze({week:'周',month:'月',quarter:'季度',year:'年',custom:'自选'});
const DAY=86400000, MIN='1900-01-01', MAX='9999-12-31';
const stamp=value=>Date.parse(value+'T00:00:00Z');
const key=value=>new Date(value).toISOString().slice(0,10);
const bound=value=>Math.max(stamp(MIN),Math.min(stamp(MAX),value));
const date=(year,month,day=1)=>key(bound(Date.UTC(year,month-1,day)));
const short=value=>`${Number(value.slice(5,7))}月${Number(value.slice(8))}日`;
export const periodDays=period=>Math.round((stamp(period.end)-stamp(period.start))/DAY)+1;
export function ledgerPeriod(mode,anchor,custom={}) {
  if(!Object.prototype.hasOwnProperty.call(periodModes,mode))throw new Error('请选择统计维度');
  if(mode==='custom')anchor=custom.start;
  if(!validLedgerDate(anchor))throw new Error('请选择正确的日期');
  const [year,month]=anchor.split('-').map(Number);
  let start,end,title;
  if(mode==='custom') {
    start=custom.start;end=custom.end;
    if(!validLedgerDate(end))throw new Error('请选择正确的结束日期');
    if(start>end)throw new Error('结束日期不能早于开始日期');
    title=start===end?`${year}年${short(start)}`:'自选日期';
  } else if(mode==='week') {
    const weekday=(new Date(stamp(anchor)).getUTCDay()+6)%7;
    const first=stamp(anchor)-weekday*DAY;
    start=key(bound(first));end=key(bound(first+6*DAY));
    title=start.slice(0,4)===end.slice(0,4)?`${year}年 · ${short(start)}—${short(end)}`:`${start}—${end}`;
  } else if(mode==='month') {
    start=date(year,month);end=date(year,month+1,0);title=`${year}年${month}月`;
  } else if(mode==='quarter') {
    const first=Math.floor((month-1)/3)*3+1;
    start=date(year,first);end=date(year,first+3,0);title=`${year}年 · 第${Math.ceil(month/3)}季度`;
  } else {
    start=date(year,1);end=date(year,12,31);title=`${year}年`;
  }
  return {mode,anchor,start,end,title};
}
export function shiftLedgerPeriod(period,step) {
  if(![-1,1].includes(step))return null;
  if(period.mode==='week') {
    const next=stamp(period.start)+7*DAY*step;
    return next<stamp(MIN)||next>stamp(MAX)?null:ledgerPeriod('week',key(next));
  }
  if(period.mode==='custom') {
    const length=periodDays(period);
    const start=stamp(period.start)+length*DAY*step,end=stamp(period.end)+length*DAY*step;
    if(start<stamp(MIN)||end>stamp(MAX))return null;
    return ledgerPeriod(period.mode,key(start),{start:key(start),end:key(end)});
  }
  const [year,month]=period.start.split('-').map(Number);
  const delta={month:1,quarter:3,year:12}[period.mode]*step;
  const next=Date.UTC(year,month-1+delta,1);
  if(next<stamp(MIN)||next>stamp(MAX))return null;
  return ledgerPeriod(period.mode,key(next));
}
export function periodRows(rows,period) {
  return rows.filter(row=>!row._deletedAt&&['expense','income'].includes(row.type)&&validLedgerDate(row.date)&&row.date>=period.start&&row.date<=period.end&&Number.isSafeInteger(row.cents)&&row.cents>0);
}
function add(a,b) {
  const result=a+b;
  if(!Number.isSafeInteger(result))throw new Error('累计金额超出可计算范围');
  return result;
}
export function periodSummary(rows,period) {
  const selected=periodRows(rows,period);let income=0,expense=0;
  for(const row of selected)if(row.type==='income')income=add(income,row.cents);else expense=add(expense,row.cents);
  return {income,expense,net:income-expense,count:selected.length};
}
export function periodCategories(rows,period,type) {
  const groups=new Map();
  for(const row of periodRows(rows,period))if(row.type===type) {
    const id=typeof row.category==='string'&&row.category?row.category:'uncategorized';
    const group=groups.get(id)||{id,cents:0,count:0};group.cents=add(group.cents,row.cents);group.count++;groups.set(id,group);
  }
  return [...groups.values()].sort((a,b)=>b.cents-a.cents||a.id.localeCompare(b.id));
}
// Bound the number of plotted buckets even for a user-selected multi-year range.
export function periodTrend(rows,period,type) {
  const points=[];
  const daily=['week','month'].includes(period.mode)||(period.mode==='custom'&&periodDays(period)<=62);
  const [firstYear,firstMonth]=period.start.split('-').map(Number),[lastYear,lastMonth]=period.end.split('-').map(Number);
  const months=(lastYear-firstYear)*12+lastMonth-firstMonth+1;
  const unit=daily?'day':months<=24?'month':'year';
  const push=(start,end,label)=>points.push({start:start<period.start?period.start:start,end:end>period.end?period.end:end,label,cents:0});
  if(daily) {
    for(let time=stamp(period.start);time<=stamp(period.end);time+=DAY){const day=key(time);push(day,day,short(day));}
  } else if(unit==='month') {
    for(let i=0;i<months;i++) {
      const begin=new Date(Date.UTC(firstYear,firstMonth-1+i,1)),y=begin.getUTCFullYear(),m=begin.getUTCMonth()+1;
      push(date(y,m),date(y,m+1,0),firstYear===lastYear?`${m}月`:`${y}/${m}`);
    }
  } else {
    const step=Math.ceil((lastYear-firstYear+1)/24);
    for(let year=firstYear;year<=lastYear;year+=step){const end=Math.min(lastYear,year+step-1);push(date(year,1),date(end,12,31),year===end?`${year}年`:`${year}—${end}年`);}
  }
  for(const row of periodRows(rows,period))if(row.type===type){const point=points.find(point=>row.date>=point.start&&row.date<=point.end);if(point)point.cents=add(point.cents,row.cents);}
  return {unit,points};
}
export function percentageText(cents,total) {
  if(!total||!cents)return '0%';
  const value=cents/total*100;
  return value<.1?'不足 0.1%':`${value.toFixed(1)}%`;
}
export function pieSlices(groups) {
  const positive=groups.filter(group=>Number.isSafeInteger(group.cents)&&group.cents>0);
  const total=positive.reduce((sum,group)=>add(sum,group.cents),0);let angle=-Math.PI/2;
  return positive.map(group=>{
    const share=group.cents/total,next=angle+share*2*Math.PI;
    const x=a=>(110+Math.cos(a)*96).toFixed(6),y=a=>(110+Math.sin(a)*96).toFixed(6);
    const path=`M110,110 L${x(angle)},${y(angle)} A96,96 0 ${share>.5?1:0},1 ${x(next)},${y(next)} Z`;
    angle=next;return {...group,share,path,full:positive.length===1,percent:percentageText(group.cents,total)};
  });
}
