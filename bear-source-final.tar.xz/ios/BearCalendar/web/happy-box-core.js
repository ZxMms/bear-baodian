// A deliberately curated collection: nothing is selected from a mood automatically.
export const HAPPY_BOX_KEY = 'feature:happy-box';
export const HAPPY_BOX_LIMIT = 500;
const text = (value, max) => typeof value === 'string' ? value.trim().slice(0, max) : '';
export const safeHappyPhoto = src => typeof src === 'string' && (/^media\/[a-f0-9]{64}\.(jpg|png|webp|gif)$/.test(src) || /^data:image\/(jpeg|png|webp|gif);base64,[A-Za-z0-9+/=]+$/.test(src));
const photos = list => [...new Set((Array.isArray(list) ? list : []).filter(safeHappyPhoto))].slice(0, 5);
const stamp = value => Number.isFinite(value) && value > 0 ? value : 0;
function validDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value || '')) return '';
  const date = new Date(`${value}T12:00:00`);
  return date.getFullYear() >= 1900 && `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}` === value ? value : '';
}
export function happySources(entries, query = '') {
  const term = String(query || '').trim().toLocaleLowerCase();
  return (Array.isArray(entries) ? entries : []).filter(row => row && !row._deletedAt && !row.deletedAt && ['life','meal','memo'].includes(row.kind) && typeof row.id === 'string' && row.id && (!term || `${row.title || ''}\n${row.note || ''}\n${row.date || ''}`.toLocaleLowerCase().includes(term)))
    .map(row => ({id:row.id,kind:row.kind,date:validDate(row.date),title:text(row.title,80) || '生活里的小开心',note:text(row.note,5000),photos:photos(row.photos)}))
    .sort((a,b) => b.date.localeCompare(a.date));
}
export function normalizeHappyBox(value) {
  const seen = new Set(), items = [];
  for (const row of Array.isArray(value?.items) ? value.items : []) {
    const id = text(row?.id,160);
    if (!id || seen.has(id)) continue;
    seen.add(id);
    items.push({id,sourceId:text(row.sourceId,160),sourceKind:['life','meal','memo'].includes(row.sourceKind)?row.sourceKind:'life',title:text(row.title,80)||'生活里的小开心',note:text(row.note,1000),date:validDate(row.date),photos:photos(row.photos),createdAt:stamp(row.createdAt),updatedAt:stamp(row.updatedAt)});
  }
  return {version:1,items,updatedAt:stamp(value?.updatedAt)};
}
export function makeHappySnapshot(source, selection, existing = null, now = Date.now(), id = '') {
  if (!source?.id || !['life','meal','memo'].includes(source.kind) || source._deletedAt || source.deletedAt) throw new Error('这条记录暂时不能放进开心盒');
  const title = text(selection?.title,80);
  if (!title) throw new Error('给这份开心起一个名字吧');
  const selected = Array.isArray(selection?.photoIndices) ? selection.photoIndices : [];
  if (selected.some(value => !/^\d+$/.test(String(value)))) throw new Error('请重新选择要收好的照片');
  const indexes = [...new Set(selected.map(Number))];
  const available = photos(source.photos);
  if (indexes.length > 5 || indexes.some(index => index >= available.length)) throw new Error('照片已变化，请重新选择');
  const itemId = text(existing?.id || id,160);
  if (!itemId) throw new Error('暂时无法创建开心卡片，请重试');
  return {id:itemId,sourceId:source.id,sourceKind:source.kind,title,note:text(selection?.note,1000),date:validDate(source.date),photos:indexes.map(index=>available[index]),createdAt:stamp(existing?.createdAt)||now,updatedAt:now};
}
export function upsertHappyItem(value, item, now = Date.now()) {
  const current = normalizeHappyBox(value), duplicate = current.items.find(row => row.sourceId && row.sourceId === item.sourceId);
  const next = normalizeHappyBox({items:[item]}).items[0];
  if (!next) throw new Error('这份开心暂时无法保存');
  const old = current.items.find(row=>row.id===next.id) || duplicate;
  if (!old && current.items.length >= HAPPY_BOX_LIMIT) throw new Error(`开心盒已收好 ${HAPPY_BOX_LIMIT} 份回忆，先整理几份再添加吧`);
  if (old) {next.id=old.id;next.createdAt=old.createdAt||next.createdAt;}
  return {version:1,items:[next,...current.items.filter(row=>row.id!==next.id&&(!next.sourceId||row.sourceId!==next.sourceId))],updatedAt:now};
}
export function removeHappyItem(value, id, now = Date.now()) {
  const current=normalizeHappyBox(value);
  return {...current,items:current.items.filter(row=>row.id!==id),updatedAt:now};
}
export function chooseHappyItem(value, previousId = '', random = Math.random) {
  const items=normalizeHappyBox(value).items;
  if(!items.length)return null;
  const pool=items.length>1?items.filter(row=>row.id!==previousId):items;
  const sample=Number(random()), fraction=Number.isFinite(sample)?Math.min(.999999999,Math.max(0,sample)):0;
  return pool[Math.floor(fraction*pool.length)];
}
