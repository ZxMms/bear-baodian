import {nativeAvailable,nativeRequest,clearLegacyCopy} from './native-store.js?v=37';
let ui;
const names={entries:'手账记录',recipes:'菜谱',moods:'每日心情',ledger:'账单',ledgerCategories:'记账分类',settings:'设置与生活工具'};
const bytes=value=>value<1024*1024?`${(value/1024).toFixed(1)} KB`:`${(value/1024/1024).toFixed(1)} MB`;
const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function initStorageSettings(callbacks){ui=callbacks;window.bearBackupResult=async result=>{
  if(result.type==='preview'){
    const m=result.manifest;
    ui.open('恢复备份前核对',`<p class="mood-rule">备份时间：${escape(new Date(m.created).toLocaleString('zh-CN'))}</p><div class="storage-counts">${Object.entries(names).map(([key,name])=>`<div><span>${name}</span><b>${m.counts[key]||0}</b></div>`).join('')}<div><span>照片 / 音频附件</span><b>${m.files.length}</b></div></div><p class="photo-hint">采用合并恢复：补回本机缺少的记录。同一条记录和已有设置保留本机版本，不覆盖后来修改的内容。</p><p class="photo-hint">冰箱、开心盒、愿望小罐、买金目标按整个集合恢复：本机已有某个集合时，会完整保留本机这一组，不补入备份里的单条。换到没有这组数据的新手机时，会恢复备份中的整组内容。</p><button type="button" class="primary" data-storage-restore="${result.token}">合并恢复这些记录</button>`);ui.sheet.dataset.view='restore-preview';return;
  }
  ui.announce(result.message||'');
  const status=ui.sheet.querySelector('.storage-status');if(status)status.textContent=result.message||'';
  if(result.type==='exported'&&ui.sheet.dataset.view==='storage')await showStorageSettings();
};}
export async function showStorageSettings(){
  const native=nativeAvailable(),stats=native?await nativeRequest({op:'stats'}):null;
  ui.open('数据与备份',`<div class="storage-intro"><span aria-hidden="true">▤</span><h3>${native?'数据安心住在手机里':'浏览器预览数据'}</h3><p>${native?'SQLite 保存记录，照片和音频单独保存在应用私有目录。':'浏览器预览仍使用 IndexedDB；SQLite 和文件备份在手机 App 中使用。'}</p></div>${stats?`<div class="storage-counts">${Object.entries(names).map(([key,name])=>`<div><span>${name}</span><b>${stats.counts[key]||0}</b></div>`).join('')}<div><span>附件</span><b>${stats.attachments} 个 · ${bytes(stats.attachmentBytes)}</b></div></div><p class="photo-hint">${stats.lastBackup?'最近导出：'+escape(new Date(Number(stats.lastBackup)).toLocaleString('zh-CN')):'还没有导出备份'}</p>`:''}<button type="button" class="primary" data-storage-action="export" ${native?'':'disabled'}>导出完整备份</button><button type="button" class="secondary storage-restore" data-storage-action="choose" ${native?'':'disabled'}>选择备份并恢复</button><p class="photo-hint">备份包括手账、菜谱、心情、账单、预算、周菜单、冰箱、开心盒、愿望小罐、买金目标、音效设置和全部附件。系统权限与天气缓存不包含在备份中。卸载会删除本机数据，请把备份保存到应用外的位置。</p>${native?`<div class="storage-legacy"><strong>升级前的旧副本</strong><p>完成迁移后先保留旧副本。导出完整备份后，可以清理旧副本及闲置附件以释放空间。</p><button type="button" class="text-button" data-storage-action="cleanup" ${stats.lastBackup?'':'disabled'}>清理旧副本和闲置附件</button></div>`:''}<p class="storage-status" role="status"></p>`);ui.sheet.dataset.view='storage';
}
export async function storageClicked(data){
  if(data.storageRestore){const button=ui.sheet.querySelector('[data-storage-restore]');button.disabled=true;button.textContent='正在合并恢复…';try{const result=await nativeRequest({op:'restore-confirm',token:data.storageRestore});ui.announce(`恢复完成：新增 ${result.added} 项，保留本机 ${result.kept} 项`);location.reload();}catch(error){button.disabled=false;button.textContent='重试合并恢复';throw error;}return true;}
  if(!data.storageAction)return false;
  if(data.storageAction==='open'){await showStorageSettings();return true;}
  if(!nativeAvailable()){ui.announce('请在手机 App 中使用备份功能');return true;}
  if(data.storageAction==='export')window.BearStore.exportBackup();
  if(data.storageAction==='choose')window.BearStore.chooseBackup();
  if(data.storageAction==='cleanup'){
    ui.open('清理升级前副本？','<p class="mood-rule">只清理升级前的 IndexedDB 副本和当前记录不再引用的附件。正在使用的 SQLite 记录、照片和音频会保留。</p><p class="photo-hint">请确认刚导出的完整备份已保存在你能找到的位置。</p><button type="button" class="primary" data-storage-action="cleanup-confirm">确认已有备份并清理</button><button type="button" class="secondary storage-restore" data-storage-action="open">暂不清理</button>');ui.sheet.dataset.view='storage-cleanup';
  }
  if(data.storageAction==='cleanup-confirm'){await clearLegacyCopy();const result=await nativeRequest({op:'cleanup-files'});await showStorageSettings();ui.announce('旧副本已清理，另清理闲置附件 '+bytes(result.freedBytes));}
  return true;
}
