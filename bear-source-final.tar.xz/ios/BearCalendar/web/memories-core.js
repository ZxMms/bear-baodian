const pad = value => String(value).padStart(2,"0");
export const memoryDateKey = (date = new Date()) => `${date.getFullYear()}-${pad(date.getMonth()+1)}-${pad(date.getDate())}`;
export function validMemoryDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value || "")) return false;
  const date = new Date(`${value}T12:00:00`);
  return Number(value.slice(0,4)) >= 1900 && !Number.isNaN(date.getTime()) && memoryDateKey(date) === value;
}
export function capsuleDue(entry, now = new Date()) {
  if (!validMemoryDate(entry?.date) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(entry.time || "09:00")) return false;
  return new Date(`${entry.date}T${entry.time || "09:00"}:00`).getTime() <= now.getTime();
}
export const capsuleIsHidden = (entry, now = new Date()) => entry?.kind === "capsule" && !capsuleDue(entry, now);
export function memoryReferenceDate(today, mode = "year") {
  if (!validMemoryDate(today)) return "";
  const [year,month,day] = today.split("-").map(Number);
  const target = new Date(year,month-1+(mode === "quarter" ? -3 : 0),1,12);
  if (mode !== "quarter") target.setFullYear(year-1);
  const last = new Date(target.getFullYear(),target.getMonth()+1,0,12).getDate();
  // There is no "same day" in a shorter month: do not silently move a memory.
  if (day > last || target.getFullYear() < 1900) return "";
  target.setDate(day);
  return memoryDateKey(target);
}
export function memoryRows(entries, today, mode = "year") {
  const target = memoryReferenceDate(today,mode);
  return {date:target,rows:(entries || []).filter(row=>!row._deletedAt && !row.deletedAt && row.kind !== "capsule" && row.date === target).sort((a,b)=>(b.created||0)-(a.created||0))};
}
export function magazineMonthData({entries=[],moods=[],ledger=[],recipes=[],categories=[]}, month, today=memoryDateKey()) {
  if (!/^\d{4}-\d{2}$/.test(month) || !validMemoryDate(month+"-01") || month > today.slice(0,7)) throw new Error("请选择今天或以前的月份");
  const inMonth = row=>!row._deletedAt && !row.deletedAt && validMemoryDate(row.date) && row.date.slice(0,7)===month && row.date<=today;
  const selectedEntries=entries.filter(row=>inMonth(row) && row.kind!=="capsule").sort((a,b)=>b.date.localeCompare(a.date)||(b.created||0)-(a.created||0));
  const selectedMoods=moods.filter(inMonth), selectedLedger=ledger.filter(row=>inMonth(row)&&Number.isSafeInteger(row.cents)&&row.cents>0&&["expense","income"].includes(row.type));
  const meals=selectedEntries.filter(row=>row.kind==="meal"), moodCounts={}, categoryCounts=new Map();
  for (const row of selectedMoods) moodCounts[row.mood]=(moodCounts[row.mood]||0)+1;
  let expense=0,income=0;
  for (const row of selectedLedger) {
    if(row.type==="expense") {expense+=row.cents;categoryCounts.set(row.category,(categoryCounts.get(row.category)||0)+row.cents);}
    else income+=row.cents;
  }
  if(!Number.isSafeInteger(expense)||!Number.isSafeInteger(income))throw new Error("这个月的累计金额超出支持范围");
  const categoryNames=new Map(categories.map(row=>[row.id,row.name]));
  const spending=[...categoryCounts].map(([id,cents])=>({id,name:categoryNames.get(id)||"未分类",cents,ratio:expense?cents/expense:0})).sort((a,b)=>b.cents-a.cents);
  const recipeNames=new Map(recipes.map(row=>[row.id,row.title]));
  const dishCounts=new Map();for(const meal of meals){const name=meal.recipeId&&recipeNames.get(meal.recipeId)||meal.title||"一份美食";dishCounts.set(name,(dishCounts.get(name)||0)+1);}
  const dishes=[...dishCounts].map(([name,count])=>({name,count})).sort((a,b)=>b.count-a.count||a.name.localeCompare(b.name,"zh-CN"));
  const photos=[],seen=new Set();
  for(const [store,rows] of [["entry",selectedEntries],["ledger",selectedLedger]])for(const row of rows)for(let index=0;index<(row.photos||[]).length;index++){
    const src=row.photos[index];if(typeof src!=="string"||seen.has(src))continue;seen.add(src);
    photos.push({key:`${store}:${row.id}:${index}`,src,store,id:row.id,date:row.date,label:store==="entry"?row.title||"生活照片":row.note||"消费照片"});
  }
  return {month,entries:selectedEntries,moods:selectedMoods,ledger:selectedLedger,meals,moodCounts,spending,dishes,photos,expense,income,days:new Set(selectedEntries.map(row=>row.date)).size};
}
export function defaultMagazineSelection(data) {
  return {title:`${Number(data.month.slice(5))} 月的熊熊月刊`,letter:"那些被认真记住的小事，都值得再翻一遍。把这个月的片刻收好，留给以后的自己慢慢看。",entryIds:data.entries.slice(0,8).map(row=>row.id),photoKeys:data.photos.filter(photo=>photo.store==="entry").slice(0,9).map(photo=>photo.key),includeMood:true,includeMeals:true,includeLedger:false,excerpts:{}};
}
export function normalizeMagazineSelection(data, input={}) {
  const defaults=defaultMagazineSelection(data), entries=new Set(data.entries.map(row=>row.id)),photos=new Set(data.photos.map(photo=>photo.key));
  return {title:String(input.title??defaults.title).trim().slice(0,48)||defaults.title,letter:String(input.letter??defaults.letter).trim().slice(0,600),entryIds:[...new Set(Array.isArray(input.entryIds)?input.entryIds:defaults.entryIds)].filter(id=>entries.has(id)),photoKeys:[...new Set(Array.isArray(input.photoKeys)?input.photoKeys:defaults.photoKeys)].filter(key=>photos.has(key)),includeMood:input.includeMood??true,includeMeals:input.includeMeals??true,includeLedger:input.includeLedger===true,excerpts:Object.fromEntries(Object.entries(input.excerpts||{}).filter(([id])=>entries.has(id)).map(([id,text])=>[id,String(text).slice(0,500)]))};
}
export function magazineSections(data, selection, moodNames={}) {
  const chosen=normalizeMagazineSelection(data,selection),sections=[];
  if(chosen.letter)sections.push({title:"熊熊陪你翻一翻",text:chosen.letter});
  sections.push({title:"这个月，写下的小日子",text:`${data.entries.length} 条生活记录 · ${data.days} 个有记录的日子\n统计范围：${data.month} 已到来的日期；没有记录的日子不作推测。`});
  if(chosen.includeMood)sections.push({title:"记下来的心情",text:data.moods.length?`${data.moods.length} 天心情记录\n`+Object.entries(data.moodCounts).map(([key,count])=>`${moodNames[key]||key} ${count} 天`).join(" · "):"这个月还没有心情记录。"});
  if(chosen.includeMeals)sections.push({title:"好好吃饭的日子",text:data.meals.length?`${data.meals.length} 份美食记录\n`+data.dishes.slice(0,8).map(dish=>`${dish.name} · ${dish.count} 次`).join("\n"):"这个月还没有美食记录。"});
  if(chosen.includeLedger)sections.push({title:"记录里的收支",text:`支出 ¥${(data.expense/100).toFixed(2)} · 收入 ¥${(data.income/100).toFixed(2)}\n仅按已录入账单统计`,spending:data.spending});
  const selectedPhotos=data.photos.filter(photo=>chosen.photoKeys.includes(photo.key));
  if(selectedPhotos.length)sections.push({title:"想留下的画面",photos:selectedPhotos.map(photo=>photo.src)});
  for(const entry of data.entries.filter(row=>chosen.entryIds.includes(row.id)).reverse())sections.push({title:`${entry.date.slice(5).replace("-","月")}日 · ${entry.title||"生活小事"}`,text:chosen.excerpts[entry.id]??String(entry.note||"").slice(0,180)});
  return {title:chosen.title,subtitle:`${data.month} · 我的一二布布生活记录`,sections};
}
