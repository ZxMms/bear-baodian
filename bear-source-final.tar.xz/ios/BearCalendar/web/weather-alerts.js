import { areaForPlace, placeScopeKey, buildAlertView } from './weather-alert-scope.js?v=38';
const esc = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
export const provinces = ['北京市','天津市','河北省','山西省','内蒙古自治区','辽宁省','吉林省','黑龙江省','上海市','江苏省','浙江省','安徽省','福建省','江西省','山东省','河南省','湖北省','湖南省','广东省','广西壮族自治区','海南省','重庆市','四川省','贵州省','云南省','西藏自治区','陕西省','甘肃省','青海省','宁夏回族自治区','新疆维吾尔自治区'];
const english = ['Beijing','Tianjin','Hebei','Shanxi','Inner Mongolia','Liaoning','Jilin','Heilongjiang','Shanghai','Jiangsu','Zhejiang','Anhui','Fujian','Jiangxi','Shandong','Henan','Hubei','Hunan','Guangdong','Guangxi','Hainan','Chongqing','Sichuan','Guizhou','Yunnan','Tibet','Shaanxi','Gansu','Qinghai','Ningxia','Xinjiang'];
export function provinceForPlace(place) {
  if (!place || place.countryCode !== 'CN') return '';
  if (provinces.includes(place.admin1)) return place.admin1;
  const index = english.findIndex(name => name.toLowerCase() === String(place.admin1 || '').toLowerCase());
  return index >= 0 ? provinces[index] : '';
}
export function safeAlertUrl(value) {
  try { const url = new URL(value); return url.protocol === 'https:' && url.hostname === 'www.nmc.cn' && !url.port && !url.username && !url.password && !url.search && !url.hash && /^\/publish\/alarm(?:\/[A-Za-z0-9_-]+)?\.html$/.test(url.pathname) ? url.href : null; } catch { return null; }
}
export function alertsStale(data, now = Date.now()) {
  return !Number.isFinite(data?.updatedAt) || data.updatedAt <= 0 || now - data.updatedAt > 1800000 || data.updatedAt > now + 300000 || Boolean(data.error);
}
export function recentAlerts(data, now = Date.now()) {
  return (Array.isArray(data?.alerts) ? data.alerts : []).filter(row => row && typeof row === 'object' && typeof row.issuedAt === 'number' && Number.isFinite(row.issuedAt) && now - row.issuedAt <= 86400000 && row.issuedAt <= now + 300000 && safeAlertUrl(row.url)).slice(0, 500);
}
const stamp = time => new Date(time).toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai', month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' });
const official = 'https://www.nmc.cn/publish/alarm.html';
let state = {province:'', alerts:[], updatedAt:0, loading:false, error:'', truncated:false}, ui, native, pendingProvince = null, lastPlace = '';
let currentPlace = null, scopeKey = '', mode = 'legacy';
const expanded = {local:false,parent:false,other:false,unknown:false};
function resetExpanded() { for (const key of Object.keys(expanded)) expanded[key] = false; }
function saveMode(value) { mode=value; try { localStorage.setItem('bear-warning-mode',value); } catch { } }
function scopedArea() { return mode !== 'manual' && state.province === provinceForPlace(currentPlace) ? areaForPlace(currentPlace,state.province) : null; }

export function initWeatherAlerts(callbacks) {
  ui = callbacks; native = window.BearWeatherAlerts;
  try { lastPlace = localStorage.getItem('bear-warning-place') || ''; } catch { }
  try { if (native) state = JSON.parse(native.state()); } catch { }
  try { const savedMode=localStorage.getItem('bear-warning-mode'); if (['follow','manual','off'].includes(savedMode)) mode=savedMode; } catch { }
  if (mode === 'legacy' && lastPlace && !state.province) mode='off';
  pendingProvince = state.province || '';
  window.bearWeatherAlertsChanged = payload => {
    let next; try { next = JSON.parse(payload); } catch { return; }
    if (pendingProvince !== null && next.province !== pendingProvince) return;
    state = next;
    paintWeatherAlerts(); ui.repaint();
  };
  if (mode === 'off' && state.province) chooseProvince('');
}
function chooseProvince(province) {
  pendingProvince = province; resetExpanded();
  state = {province, alerts:[], updatedAt:0, loading:Boolean(province), error:'', truncated:false};
  if (province) native?.selectProvince(province); else native?.disable();
  paintWeatherAlerts(); ui?.repaint();
}
export function syncAlertsPlace(place) {
  currentPlace = place;
  const nextScope = placeScopeKey(place,provinceForPlace(place));
  if (nextScope !== scopeKey) { scopeKey=nextScope; resetExpanded(); paintWeatherAlerts(); }
  if (!native || !place) return;
  const legacyKey = `${Math.round(place.latitude * 100) / 100},${Math.round(place.longitude * 100) / 100},${place.name}`;
  const key = place.nmcCode ? `nmc:${place.nmcCode}` : legacyKey;
  const same = key === lastPlace;
  const migrated = Boolean(place.nmcCode) && lastPlace === legacyKey;
  if (mode === 'legacy') {
    if ((same || migrated) && state.province && state.province !== provinceForPlace(place)) saveMode('manual');
    else saveMode('follow');
  }
  if (!same) { lastPlace=key; try { localStorage.setItem('bear-warning-place',key); } catch { } }
  if (mode === 'off' || mode === 'manual') return;
  if (!same && !migrated || state.province !== provinceForPlace(place)) chooseProvince(provinceForPlace(place));
}
export function clearWeatherAlerts() {
  lastPlace = ''; currentPlace=null; scopeKey=''; saveMode('off'); try { localStorage.removeItem('bear-warning-place'); } catch { }
  chooseProvince('');
}
export function refreshAlertsIfNeeded() { native?.refreshIfNeeded?.(); }
export function refreshAlertsNow() { if (state.province) native?.refresh?.(); }
export function alertSummary() {
  const area=scopedArea(), rows=buildAlertView(recentAlerts(state),area).local;
  if (!rows.length) return '';
  return `<button type="button" class="weather-alert-summary" data-weather-action="view-alerts"><span aria-hidden="true">!</span><small>${esc(area.label)} · ${alertsStale(state) ? '上次查询的本地发布' : '本地近期发布'}<b>${esc(rows[0].title)}</b></small><i aria-hidden="true">›</i></button>`;
}
function alertRows(rows) {
  return `<div class="weather-alert-list">${rows.map(row => {
    const level = ['red','orange','yellow','blue'].includes(row.level) ? row.level : 'unknown';
    const label = {red:'红色',orange:'橙色',yellow:'黄色',blue:'蓝色',unknown:'预警'}[level];
    return `<button type="button" class="weather-alert-row" data-weather-alert-url="${esc(row.url)}"><span class="weather-alert-level level-${level}">${label}</span><span><strong>${esc(row.title)}</strong><small>${stamp(row.issuedAt)} 发布 · 查看官方原文 ›</small></span></button>`;
  }).join('')}</div>`;
}
function foldedRows(key,label,rows) {
  if (!rows.length) return '';
  return `<div class="weather-alert-fold"><button type="button" class="weather-alert-fold-toggle" data-weather-alert-action="${key}-toggle" aria-expanded="${expanded[key]}"><span>${label} <small>${rows.length} 条</small></span><b aria-hidden="true">${expanded[key]?'−':'+'}</b></button>${expanded[key] ? alertRows(rows) : ''}</div>`;
}
export function alertsSection() {
  const rows=recentAlerts(state), area=scopedArea(), groups=buildAlertView(rows,area), stale=alertsStale(state);
  let body='';
  if (!state.province) body='<p class="weather-help">预警可跟随天气位置。尚未识别到市县时，可手动确认预警地区。</p>';
  else {
    if (state.loading) body+='<p class="weather-progress" role="status">正在联网查询预警…</p>';
    if (state.error) body+=`<p class="weather-error" role="status">${esc(state.error)}<br>暂时无法确认最新预警，请查看官网。</p>`;
    if (state.updatedAt>0) body+=`<p class="weather-help">${stale?'上次查询':'查询于'} ${stamp(state.updatedAt)}${stale?' · 信息待更新':''}（北京时间）</p>`;
    if (area) {
      body+=`<div class="weather-alert-local-label"><strong>${esc(area.label)} · 本地发布</strong><small>${area.mode==='district'?'所在区县及市级发布':area.mode==='city'?'按已识别城市筛选':'按所选地区名称筛选'}</small></div>`;
      if (groups.local.length) {
        body+=alertRows(expanded.local?groups.local:groups.local.slice(0,3));
        if (groups.local.length>3) body+=`<button type="button" class="weather-alert-more" data-weather-alert-action="local-more" aria-expanded="${expanded.local}">${expanded.local?'收起本地列表':`查看其余 ${groups.local.length-3} 条本地发布`} <span aria-hidden="true">${expanded.local?'⌃':'⌄'}</span></button>`;
      } else if (state.updatedAt>0 && !state.loading && !state.error) body+=`<p class="weather-help">${stale?'本次会话中的信息已过时，请重新查询。':'本次列表未查到名称明确匹配的本地发布，请同时留意省级参考。'}</p>`;
    } else body+='<p class="weather-help">尚未确认市县范围，以下信息需核对具体地区；不会将全省预警当作本地预警。</p>';
    body+=foldedRows('parent','省级参考',groups.parent)+foldedRows('unknown',area?'范围待确认':'省内近期发布 · 待确认范围',groups.unknown)+foldedRows('other','其他市县',groups.other);
    if (!rows.length && !area && state.updatedAt>0 && !state.loading && !state.error) body+=`<p class="weather-help">${stale?'本次会话中的信息已过时，请重新查询。':'本次列表未查到近 24 小时发布的信息，请以官网为准。'}</p>`;
    if (state.truncated) body+='<p class="weather-help">目前只取得部分近期信息，可能遗漏本地发布，请查看官网完整列表。</p>';
    body+='<p class="weather-alert-note">按发布单位筛选近 24 小时信息，不等同于当前生效预警。具体影响范围、解除及防御指南以官方原文为准。</p>';
  }
  const follow=provinceForPlace(currentPlace);
  if (follow && (mode!=='follow' || state.province!==follow)) body+='<button type="button" class="weather-alert-more" data-weather-alert-action="follow-location">跟随当前天气位置 ›</button>';
  return `<section class="weather-alert-panel" aria-label="气象预警"><div class="weather-alert-heading"><div><span class="weather-eyebrow">只把身边的提醒放在前面</span><h3>气象预警</h3></div><button type="button" class="weather-region-button" data-weather-alert-action="regions">${esc(area?.label || state.province || '选择地区')} <span aria-hidden="true">⌄</span></button></div>${body}<div class="weather-alert-footer"><button type="button" class="text-button" data-weather-alert-url="${official}">中央气象台官网 ↗</button>${state.province?`<button type="button" class="text-button" data-weather-alert-action="refresh" ${state.loading?'disabled':''}>刷新预警</button>`:''}</div></section>`;
}
const panelMarkup = new WeakMap();
export function paintWeatherAlerts() {
  const panel = document.querySelector('#weather-alerts');
  if (panel) {
    const html = alertsSection();
    if (panelMarkup.get(panel) === html) return;
    const selectedAction = panel.contains?.(document.activeElement) ? document.activeElement.dataset.weatherAlertAction : '';
    panel.innerHTML = html;
    panelMarkup.set(panel, html);
    if (['local-more','parent-toggle','other-toggle','unknown-toggle'].includes(selectedAction)) {
      panel.querySelector(`[data-weather-alert-action="${selectedAction}"]`)?.focus({preventScroll:true});
    }
  }
}
export function alertsClick(data) {
  if (data.weatherAlertUrl) {
    const url = safeAlertUrl(data.weatherAlertUrl);
    if (!url) { ui.announce('预警链接不可用，请查看中央气象台官网'); return true; }
    if (window.BearApp?.openRecipeLink) { if (!window.BearApp.openRecipeLink(url)) ui.announce('暂时无法打开官网'); }
    else window.open(url, '_blank', 'noopener,noreferrer');
    return true;
  }
  if (data.weatherAlertProvince) {
    if (!native) { ui.announce('安装手机 App 后可查询官方预警'); return true; }
    if (provinces.includes(data.weatherAlertProvince)) { saveMode('manual'); chooseProvince(data.weatherAlertProvince); ui.backWeather(false); }
    return true;
  }
  if (!data.weatherAlertAction) return false;
  const action=data.weatherAlertAction;
  if (action==='local-more' || ['parent-toggle','other-toggle','unknown-toggle'].includes(action)) {
    const key=action==='local-more'?'local':action.split('-')[0]; expanded[key]=!expanded[key]; paintWeatherAlerts(); return true;
  }
  if (action==='follow-location') { saveMode('follow'); chooseProvince(provinceForPlace(currentPlace)); ui.backWeather(false); return true; }
  if (data.weatherAlertAction === 'regions') ui.open('预警地区', `<p class="weather-help">默认跟随天气位置筛选本地发布。也可手选省份，展开查看省内信息；具体影响市县以原文为准。</p><div class="weather-province-grid">${provinces.map(name => `<button type="button" class="secondary ${state.province === name ? 'is-selected' : ''}" aria-pressed="${state.province === name}" data-weather-alert-province="${name}">${name}</button>`).join('')}</div>${state.province ? '<button type="button" class="text-button reminder-system" data-weather-alert-action="disable">关闭预警并清除所选地区</button>' : ''}<button type="button" class="text-button reminder-system" data-weather-action="open">‹ 返回天气</button>`);
  else if (data.weatherAlertAction === 'refresh') native?.refresh();
  else if (data.weatherAlertAction === 'disable') { saveMode('off'); chooseProvince(''); ui.backWeather(false); }
  return true;
}
