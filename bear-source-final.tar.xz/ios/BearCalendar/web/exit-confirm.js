// A separate top-layer dialog keeps the editor, caret and scroll position intact.
let active = null;
const reducedMotion = () => document.documentElement.dataset.reducedMotion === 'true' || matchMedia('(prefers-reduced-motion: reduce)').matches;

export const exitConfirmationOpen = () => Boolean(active);

function restoreEditor(state) {
  const {focus, selection, region, scrollTop} = state;
  if (focus?.isConnected && !focus.disabled) {
    focus.focus({preventScroll:true});
    if (selection) try { focus.setSelectionRange(...selection); } catch {}
  }
  if (region?.isConnected) region.scrollTop = scrollTop;
}

function remove(state, restore) {
  if (state.removed) return;
  state.removed = true;
  if (active === state) active = null;
  if (state.dialog.open) state.dialog.close();
  state.dialog.remove();
  if (restore) restoreEditor(state);
}

export function destroyExitConfirmation() {
  if (active) { active.cancelled=true;remove(active, false); }
}

async function dismiss(state, restore = true) {
  if (state.removed || state.leaving) return;
  state.leaving = true;
  if (!reducedMotion() && typeof state.dialog.animate === 'function') {
    state.dialog.classList.add('is-leaving');
    const animation = state.dialog.animate([{opacity:1,transform:'translateY(0) scale(1)'},{opacity:0,transform:'translateY(5px) scale(.985)'}],{duration:120,easing:'ease-in',fill:'forwards'});
    await Promise.race([animation.finished.catch(()=>{}),new Promise(resolve=>setTimeout(resolve,160))]);
  }
  remove(state, restore);
}

export function exitConfirmationBack() {
  if (!active) return false;
  if (!active.pending && !active.leaving) void dismiss(active);
  return true;
}

export function showExitConfirmation({canSaveDraft=false,editingExisting=false,art='',focusTarget,region,saveDraft,discard,onExit}={}) {
  if (active) return;
  const dialog=document.createElement('dialog');
  dialog.className='exit-confirm';
  dialog.setAttribute('role','alertdialog');
  dialog.setAttribute('aria-labelledby','exit-confirm-title');
  dialog.setAttribute('aria-describedby','exit-confirm-description');
  const description=canSaveDraft?'这次填写还没保存，留作草稿也可以。':editingExisting?'这次修改还没保存，原来的内容会保留。':'这次修改还没保存，可以继续填写。';
  dialog.innerHTML=`<div class="exit-confirm-content"><div class="exit-confirm-art" aria-hidden="true">${art}<span class="exit-confirm-heart">♡</span></div><h2 id="exit-confirm-title">这一页，还没收好</h2><p id="exit-confirm-description">${description}</p><div class="exit-confirm-actions"><button type="button" class="exit-confirm-continue" data-exit-choice="continue" autofocus>继续填写</button>${canSaveDraft?'<button type="button" class="exit-confirm-draft" data-exit-choice="draft">留作草稿，下次再写</button>':''}<button type="button" class="exit-confirm-discard" data-exit-choice="discard">放弃本次${editingExisting?'修改':'填写'}</button></div><p class="exit-confirm-status" role="status" aria-live="polite" hidden></p></div>`;
  let selection=null;
  const focus=focusTarget?.isConnected?focusTarget:document.activeElement;
  try { if (typeof focus?.selectionStart === 'number') selection=[focus.selectionStart,focus.selectionEnd,focus.selectionDirection]; } catch {}
  const state={dialog,focus,selection,region,scrollTop:region?.scrollTop||0,pending:false,leaving:false,removed:false};
  active=state;
  const status=dialog.querySelector('.exit-confirm-status');
  function setPending(value,copy='') {
    state.pending=value;
    dialog.setAttribute('aria-busy',String(value));
    for (const button of dialog.querySelectorAll('button')) button.disabled=value;
    status.textContent=copy;status.hidden=!copy;status.classList.remove('is-error');
  }
  async function choose(choice) {
    if (active!==state||state.pending||state.leaving||state.removed) return;
    if (choice==='continue') {await dismiss(state);return;}
    if (!['draft','discard'].includes(choice)) return;
    setPending(true,choice==='draft'?'正在收好这页…':'正在退出编辑…');
    try {
      if (choice==='draft') {
        if (!canSaveDraft||!saveDraft) throw new Error('这一页暂不支持保存草稿');
        if (await saveDraft() === false) throw new Error('草稿暂时没存好，填写内容还在。请稍后重试。');
      } else await discard?.();
      if (active!==state||state.removed) return;
      await dismiss(state,false);
      // A navigation can replace the editor while an asynchronous operation settles.
      if (!state.cancelled) onExit?.(choice);
    } catch (error) {
      if (active!==state||state.removed) return;
      setPending(false);
      status.textContent=error?.message||'暂时没能完成，填写内容还在，请重试。';
      status.hidden=false;status.classList.add('is-error');
      dialog.querySelector('[data-exit-choice="continue"]').focus({preventScroll:true});
    }
  }
  dialog.addEventListener('click',event=>{
    event.stopPropagation();
    const button=event.target.closest('[data-exit-choice]');
    if (button) void choose(button.dataset.exitChoice);
    else if (event.target===dialog) {
      const r=dialog.getBoundingClientRect();
      if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)exitConfirmationBack();
    }
  });
  dialog.addEventListener('cancel',event=>{event.preventDefault();event.stopPropagation();exitConfirmationBack();});
  dialog.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();event.stopPropagation();exitConfirmationBack();}});
  dialog.addEventListener('close',()=>{if(!state.removed){state.cancelled=true;remove(state,true);}});
  document.body.append(dialog);dialog.showModal();
  dialog.querySelector('[data-exit-choice="continue"]').focus({preventScroll:true});
}
