// Local calendar and cooking helpers. Ingredient amounts remain the user's original text.
export const mealSlots = [{id:'breakfast',name:'早餐'},{id:'lunch',name:'午餐'},{id:'dinner',name:'晚餐'}];
export function isDateKey(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(value))) return false;
  const d=new Date(value+'T12:00:00');
  return Number.isFinite(d.getTime()) && d.getFullYear()>=1900 && d.getFullYear()<=9999 && [String(d.getFullYear()).padStart(4,'0'),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-')===value;
}
export function localDateKey(date=new Date()) {
  return [String(date.getFullYear()).padStart(4,'0'),String(date.getMonth()+1).padStart(2,'0'),String(date.getDate()).padStart(2,'0')].join('-');
}
export function addDays(key,offset) {
  if (!isDateKey(key)||!Number.isInteger(offset)) throw new Error('日期无效');
  const d=new Date(key+'T12:00:00');d.setDate(d.getDate()+offset);const result=localDateKey(d);
  if (!isDateKey(result)) throw new Error('超出支持的日期范围');return result;
}
export function weekStart(key=localDateKey()) {
  if(!isDateKey(key))throw new Error('日期无效');
  const day=new Date(key+'T12:00:00').getDay();return addDays(key,-((day+6)%7));
}
export const weekDays=start=>Array.from({length:7},(_,i)=>addDays(start,i));
export function ingredientLines(value='') {
  const text=String(value).trim();if(!text)return [];
  const parts=text.includes('\n')?text.split(/\n+/):text.split(/[、；;]/);
  return parts.map(line=>line.replace(/^\s*[-•●]\s*/, '').trim()).filter(Boolean).slice(0,100);
}
export function cookingSteps(value='') {
  const text=String(value).trim();if(!text)return [];
  // Split only explicit numbered steps or line breaks, never guess at cooking times.
  const split=text.replace(/\s+(?=(?:步骤\s*)?\d{1,2}[、.)）]\s*[^\d])/g,'\n').split(/\n+/);
  return split.map(line=>line.replace(/^\s*(?:步骤\s*)?\d{1,2}[、.)）:]\s*(?=\D)/, '').trim()).filter(Boolean).slice(0,100);
}
export function timerSeconds(value) {
  const n=Number(value);if(!Number.isInteger(n)||n<1||n>240)throw new Error('计时请填 1–240 分钟');return n*60;
}
export function timerRemaining(endAt,now=Date.now()) {return Math.max(0,Math.ceil((Number(endAt)-now)/1000))||0;}
export function durationText(seconds) {
  const n=Math.max(0,Math.floor(Number(seconds)||0));
  return `${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;
}
export function emptyWeek(start) {return {week:start,plans:[],shopping:[],ingredientSources:[],updated:Date.now()};}
export function normalizeWeek(value,start) {
  const validDays=new Set(weekDays(start)),validMeals=new Set(mealSlots.map(x=>x.id));
  if(!value||value.week!==start)return emptyWeek(start);
  const plans=Array.isArray(value.plans)?value.plans.filter(x=>x&&typeof x.id==='string'&&validDays.has(x.date)&&validMeals.has(x.meal)&&((typeof x.recipeId==='string'&&x.recipeId.trim())||(typeof x.title==='string'&&x.title.trim()))).slice(0,100).map(x=>typeof x.recipeId==='string'&&x.recipeId.trim()?x:{id:x.id,date:x.date,meal:x.meal,title:x.title.trim().slice(0,60)}):[];
  const shopping=Array.isArray(value.shopping)?value.shopping.filter(x=>x&&typeof x.id==='string'&&typeof x.text==='string'&&x.text.trim()).map(x=>({...x,done:Boolean(x.done)})).slice(0,500):[];
  return {week:start,plans,shopping,ingredientSources:Array.isArray(value.ingredientSources)?value.ingredientSources.filter(x=>typeof x==='string').slice(0,10000):[],updated:Number(value.updated)||0};
}
export function shoppingCandidates(week,recipes) {
  const used=new Set(week.ingredientSources),byId=new Map(recipes.map(recipe=>[recipe.id,recipe]));
  return week.plans.flatMap(plan=>{
    const recipe=byId.get(plan.recipeId);if(!recipe)return [];
    return ingredientLines(recipe.ingredients).map((text,index)=>({source:`${plan.id}:${index}:${text}`,text,recipeTitle:recipe.title,date:plan.date,meal:plan.meal}));
  }).filter(item=>!used.has(item.source));
}
export function cookingHistory(entries,recipeId) {
  return entries.filter(item=>item.kind==='meal'&&item.recipeId===recipeId&&!item.deletedAt&&!item._deletedAt).sort((a,b)=>b.date.localeCompare(a.date)||(b.created||0)-(a.created||0));
}
export function newCookingSession(recipe,date=localDateKey()) {
  return {recipeId:recipe.id,title:recipe.title,date,step:0,checked:[],ingredients:String(recipe.ingredients||''),steps:String(recipe.steps||''),timer:null,completedAt:null,updated:Date.now()};
}
export function reconcileSession(saved,recipe,date) {
  const fresh=newCookingSession(recipe,isDateKey(date)?date:localDateKey());
  if(!saved||saved.recipeId!==recipe.id)return fresh;
  const sameIngredients=saved.ingredients===fresh.ingredients,sameSteps=saved.steps===fresh.steps;
  return {...fresh,...saved,title:recipe.title,date:isDateKey(date)?date:isDateKey(saved.date)?saved.date:localDateKey(),ingredients:fresh.ingredients,steps:fresh.steps,checked:sameIngredients&&Array.isArray(saved.checked)?[...new Set(saved.checked.filter(i=>Number.isInteger(i)&&i>=0&&i<ingredientLines(recipe.ingredients).length))]:[],step:sameSteps?Math.max(0,Math.min(Math.floor(Number(saved.step)||0),Math.max(0,cookingSteps(recipe.steps).length-1))):0};
}

// Opening a different day must not silently move an unfinished cooking session.
export function cookingOpenChoice(saved,recipe,targetDate=localDateKey()) {
  const date=isDateKey(targetDate)?targetDate:localDateKey();
  const exists=Boolean(saved&&saved.recipeId===recipe.id&&isDateKey(saved.date));
  return {date,needsChoice:exists&&(saved.date!==date||Boolean(saved.completedAt)),savedDate:exists?saved.date:null};
}
export function activeMiniTimers(sessions,now=Date.now()) {
  return Object.values(sessions||{}).filter(session=>session?.timer&&Number.isFinite(session.timer.endAt)&&!session.timer.ringStopped&&(session.timer.endAt>now||session.timer.endAt>now-60000)).sort((a,b)=>a.timer.endAt-b.timer.endAt);
}
export function mealPlanForDay(week,recipes,date) {
  const byId=new Map(recipes.map(recipe=>[recipe.id,recipe]));
  const plans=week.plans.filter(plan=>plan.date===date).map(plan=>{
    const recipe=byId.get(plan.recipeId);
    return {...plan,title:recipe?.title||plan.title||'原菜谱已删除',mealName:mealSlots.find(meal=>meal.id===plan.meal)?.name||'',recipe:recipe||null};
  }).sort((a,b)=>mealSlots.findIndex(meal=>meal.id===a.meal)-mealSlots.findIndex(meal=>meal.id===b.meal));
  return {date,plans,recipes:plans.map(plan=>plan.recipe).filter(Boolean)};
}
