// Food names are matched conservatively; quantities remain the user's original text.
import {isDateKey,localDateKey} from './kitchen-core.js?v=35';
export {isDateKey,localDateKey};
export const cookwareOptions=[['','暂时不填'],['wok','一口炒锅'],['pan','一口煎锅'],['pot','一口煮锅'],['rice-cooker','电饭煲'],['air-fryer','空气炸锅'],['microwave','微波炉'],['oven','烤箱'],['none','免开火'],['multiple','需要多种厨具']];
export const difficultyOptions=[['','暂时不填'],['easy','新手友好'],['normal','日常难度'],['advanced','需要经验']];
export const cleanupOptions=[['','暂时不填'],['low','少洗碗'],['normal','日常收拾'],['high','需要多收拾一会儿']];
const aliases=new Map([['西红柿','番茄'],['马铃薯','土豆'],['食盐','盐'],['白砂糖','白糖'],['小葱','葱'],['香葱','葱'],['土鸡蛋','鸡蛋'],['鸡蛋液','鸡蛋'],['鲜虾','虾'],['新鲜虾','虾'],['花菜','菜花']]);
export function ingredientRows(value=''){
  const rows=[];let text='',depth=0;const chars=String(value).normalize('NFKC');
  for(let i=0;i<chars.length;i++){const c=chars[i];if(c==='('||c==='[')depth++;if(c===')'||c===']')depth=Math.max(0,depth-1);
    const separator=c==='\n'||(depth===0&&/[、;；,，]/.test(c)&&!(c===','&&/\d/.test(chars[i-1]||'')&&/\d/.test(chars[i+1]||'')));
    if(separator){if(text.trim())rows.push(text.trim());text='';}else text+=c;
  }if(text.trim())rows.push(text.trim());return rows.map(x=>x.replace(/^\s*[-•●]\s*/,'').trim()).filter(Boolean).slice(0,150);
}
export function splitIngredient(value=''){
  const text=String(value).normalize('NFKC').trim().replace(/^[-•●]\s*/,''),plain=text.replace(/\([^)]*\)/g,'').trim();
  const suffix=plain.match(/\s*(?:约\s*)?(?:(?:\d+(?:[.,]\d+)?(?:\/\d+)?(?:\s*[-~～]\s*\d+(?:\.\d+)?)?|半|[一二三四五六七八九十两]+)\s*(?:kg|ml|g|l|千克|公斤|毫升|毫克|克|升|个|颗|只|根|把|片|块|袋|盒|瓶|包|杯|碗|汤匙|茶匙|小勺|大勺|勺|匙|斤|两|瓣|条|段|张|罐|份|枚|朵)|适量|少许|若干)\s*$/i);
  const name=(suffix?plain.slice(0,suffix.index):plain).trim();
  return {name:name||plain,quantity:suffix?suffix[0].trim():''};
}
export function foodKey(value){const name=splitIngredient(value).name.toLowerCase().replace(/\s+/g,'').replace(/^新鲜/,'').trim();return aliases.get(name)||name;}
export function normalizePantry(value){
  const source=Array.isArray(value)?value:Array.isArray(value?.items)?value.items:[];
  const seen=new Set();const items=source.filter(x=>x&&typeof x.id==='string'&&!seen.has(x.id)&&seen.add(x.id)&&typeof x.name==='string'&&x.name.trim()).map(x=>({...x,id:x.id,name:x.name.trim().slice(0,60),quantity:String(x.quantity||'').slice(0,80),wantedBy:isDateKey(x.wantedBy)?x.wantedBy:'',usedAt:Number(x.usedAt)>0?Number(x.usedAt):null,deletedAt:Number(x.deletedAt)>0?Number(x.deletedAt):null,sourceKey:typeof x.sourceKey==='string'?x.sourceKey.slice(0,400):'',created:Number(x.created)||0,updated:Number(x.updated)||0}));
  return {version:1,items};
}
export function validatePantryInput(input){
  const name=String(input.name||'').trim(),quantity=String(input.quantity||'').trim(),wantedBy=String(input.wantedBy||'').trim();
  if(!name||name.length>60)throw new Error('食材名称请填 1–60 个字');
  if(quantity.length>80)throw new Error('数量请控制在 80 个字以内');
  if(wantedBy&&!isDateKey(wantedBy))throw new Error('请填写正确的希望用完日期');
  return {name,quantity,wantedBy};
}
export const activePantry=items=>items.filter(x=>!x.usedAt&&!x.deletedAt);
export function plannedUseDays(item,date=localDateKey()){return isDateKey(item.wantedBy)&&isDateKey(date)?Math.round((Date.parse(item.wantedBy+'T00:00:00Z')-Date.parse(date+'T00:00:00Z'))/86400000):null;}
export function sortPantry(items,date=localDateKey()){return [...items].sort((a,b)=>{const da=plannedUseDays(a,date),db=plannedUseDays(b,date);return (da??Infinity)-(db??Infinity)||(b.created||0)-(a.created||0)||a.name.localeCompare(b.name,'zh-CN');});}
export function matchRecipeIngredients(recipe,items,date=localDateKey()){
  const pantry=activePantry(items),byName=new Map();for(const item of pantry){const key=foodKey(item.name);if(key)byName.set(key,[...(byName.get(key)||[]),item]);}
  const ingredients=ingredientRows(recipe.ingredients).map((text,index)=>{const name=splitIngredient(text).name,key=foodKey(name),matches=byName.get(key)||[];return {index,text,name,key,matches,matched:matches.length>0,soon:matches.some(item=>{const days=plannedUseDays(item,date);return days!==null&&days<=3;})};});
  const matched=ingredients.filter(x=>x.matched),missing=ingredients.filter(x=>!x.matched),soon=ingredients.filter(x=>x.soon);
  return {ingredients,matched,missing,soon,coverage:ingredients.length?matched.length/ingredients.length:0,known:ingredients.length>0};
}
export function normalizedEffort(recipe={}){
  const x=recipe.effort&&typeof recipe.effort==='object'?recipe.effort:{};
  return {minutes:Number.isInteger(x.minutes)&&x.minutes>=1&&x.minutes<=1440?x.minutes:null,difficulty:difficultyOptions.some(([v])=>v===x.difficulty)?x.difficulty:'',cookware:cookwareOptions.some(([v])=>v===x.cookware)?x.cookware:'',cleanup:cleanupOptions.some(([v])=>v===x.cleanup)?x.cleanup:''};
}
export function validateEffort(input){
  const raw=String(input.minutes??'').trim(),minutes=raw===''?null:Number(raw);
  if(minutes!==null&&(!Number.isInteger(minutes)||minutes<1||minutes>1440))throw new Error('总用时请填 1–1440 的整数分钟，或留空');
  for(const [field,options]of [['difficulty',difficultyOptions],['cookware',cookwareOptions],['cleanup',cleanupOptions]])if(!options.some(([v])=>v===(input[field]||'')))throw new Error('请重新选择省心标签');
  return {minutes,difficulty:input.difficulty||'',cookware:input.cookware||'',cleanup:input.cleanup||''};
}
export function effortLabels(recipe){const e=normalizedEffort(recipe),labels=[];if(e.minutes)labels.push(`${e.minutes} 分钟`);for(const [value,options]of [[e.difficulty,difficultyOptions],[e.cookware,cookwareOptions],[e.cleanup,cleanupOptions]])if(value)labels.push(options.find(([v])=>v===value)[1]);return labels;}
export function easyRecipes(recipes,items,filters={},date=localDateKey()){
  return recipes.filter(recipe=>!recipe._deletedAt&&!recipe.deletedAt).map(recipe=>({recipe,effort:normalizedEffort(recipe),match:matchRecipeIngredients(recipe,items,date)})).filter(({effort:e})=>(!filters.quick||(e.minutes!==null&&e.minutes<=15))&&(!filters.onePot||['wok','pan','pot'].includes(e.cookware))&&(!filters.lowCleanup||e.cleanup==='low')).sort((a,b)=>{
    if(filters.pantry){const order=b.match.soon.length-a.match.soon.length||b.match.coverage-a.match.coverage||b.match.matched.length-a.match.matched.length;if(order)return order;}
    return (a.effort.minutes??Infinity)-(b.effort.minutes??Infinity)||a.recipe.title.localeCompare(b.recipe.title,'zh-CN');
  });
}
export function missingForMeals(meals,items,date=localDateKey()){
  return meals.flatMap((meal,index)=>{const recipe=meal.recipe||meal,match=matchRecipeIngredients(recipe,items,date);return match.missing.map(item=>({id:`${meal.planId||recipe.id||index}:${item.index}:${item.text}`,text:item.text,name:item.name,recipeTitle:recipe.title,recipeId:recipe.id,meal:meal.meal||'',sourceKey:`pantry:${date}:${meal.planId||recipe.id||index}:${item.index}:${item.text}`}));});
}
