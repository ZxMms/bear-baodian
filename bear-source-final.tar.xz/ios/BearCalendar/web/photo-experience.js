import {clamp,normalizeCoverFocus,coverPosition,coverStyle,movePhoto,fittedSize,clampPan,zoomAt,swipeStep,focusAfterDrag,outputSize,validPhotoSource,headerDimensions} from './photo-experience-core.js';
export {normalizeCoverFocus,coverPosition,coverStyle};
let ui={},viewer=null,focusEditor=null,processing=Promise.resolve();
const decorated=new WeakSet();
const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const announce=message=>ui.announce?.(message);
function restoreFocus(previous){
  const openDialogs=[...document.querySelectorAll('dialog[open]')],scope=openDialogs[openDialogs.length-1]||document.querySelector('#app')||document.body;
  if(previous?.isConnected&&previous!==document.body&&!previous.disabled&&!previous.closest('[inert]')&&scope.contains(previous)){previous.focus({preventScroll:true});return;}
  const target=scope.querySelector('button[aria-current="page"]')||scope.querySelector('button:not(:disabled),input:not(:disabled):not([type=hidden]),select:not(:disabled),[tabindex="0"]');
  target?.focus({preventScroll:true});
}
const svg=(name)=>{const paths={back:'<path d="m14 6-6 6 6 6"/>',next:'<path d="m10 6 6 6-6 6"/>',minus:'<path d="M5 12h14"/>',plus:'<path d="M5 12h14M12 5v14"/>',close:'<path d="m6 6 12 12M18 6 6 18"/>',frame:'<path d="M8 4H4v4m12-4h4v4M4 16v4h4m12-4v4h-4"/>',move:'<path d="M8 5h.01M16 5h.01M8 12h.01M16 12h.01M8 19h.01M16 19h.01"/>',focus:'<path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5"/><circle cx="12" cy="12" r="3"/>'};return `<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${paths[name]||''}</svg>`;};
export function initPhotoExperience(callbacks){ui=callbacks||{};}
export function photoExperienceBack(){
  if(focusEditor){focusEditor.close();return true;}
  if(viewer){viewer.close();return true;}
  return false;
}
export const photoExperienceOpen=()=>Boolean(viewer||focusEditor);

export function showPhotoViewer({photos,index=0,title='',onClose}={}){
  if(!Array.isArray(photos)||!photos.length){announce('还没有可以查看的照片');return false;}
  viewer?.close(false);
  const previousFocus=document.activeElement,dialog=document.createElement('dialog');
  dialog.className='photo-lightbox';dialog.setAttribute('aria-label',title?`${title}的照片`:'照片浏览');
  dialog.innerHTML=`<header class="photo-lightbox-header"><button type="button" data-photo-ux="close" aria-label="关闭照片返回详情">${svg('back')}<span>返回</span></button><div><strong>${escape(title||'生活照片')}</strong><span class="photo-lightbox-count" aria-live="polite"></span></div><button type="button" data-photo-ux="reset" aria-label="恢复完整比例">${svg('frame')}<span>适合屏幕</span></button></header><div class="photo-lightbox-stage" aria-label="照片，可双指缩放或左右滑动" tabindex="0"><img class="photo-lightbox-image" draggable="false" alt=""><p class="photo-lightbox-error" hidden>这张照片暂时无法读取</p></div><footer class="photo-lightbox-footer"><div class="photo-lightbox-controls"><button type="button" data-photo-ux="previous" aria-label="上一张照片">${svg('back')}</button><button type="button" data-photo-ux="out" aria-label="缩小照片">${svg('minus')}</button><span class="photo-lightbox-zoom" aria-live="polite">100%</span><button type="button" data-photo-ux="in" aria-label="放大照片">${svg('plus')}</button><button type="button" data-photo-ux="next" aria-label="下一张照片">${svg('next')}</button></div><p>左右滑动换照片 · 双击或双指放大</p></footer>`;
  document.body.append(dialog);
  const stage=dialog.querySelector('.photo-lightbox-stage'),image=dialog.querySelector('img'),error=dialog.querySelector('.photo-lightbox-error');
  let position=clamp(Math.floor(Number(index)||0),0,photos.length-1),scale=1,x=0,y=0,size={width:0,height:0},pointerMap=new Map(),gesture=null,lastTap=null,lastTouchAt=0,imageReady=false,closed=false,resizeObserver;
  const dimensions=()=>({width:stage.clientWidth,height:stage.clientHeight});
  const localPoint=p=>{const r=stage.getBoundingClientRect();return {x:p.x-r.left-r.width/2,y:p.y-r.top-r.height/2};};
  function apply(previewX=0){
    const area=dimensions(),pan=clampPan(x,y,scale,size.width,size.height,area.width,area.height);x=pan.x;y=pan.y;
    image.style.transform=`translate(-50%,-50%) translate(${x+previewX}px,${y}px) scale(${scale})`;
    dialog.querySelector('.photo-lightbox-zoom').textContent=`${Math.round(scale*100)}%`;
    dialog.querySelector('[data-photo-ux="out"]').disabled=!imageReady||scale<=1;
    dialog.querySelector('[data-photo-ux="in"]').disabled=!imageReady||scale>=6;
    dialog.querySelector('[data-photo-ux="reset"]').disabled=!imageReady;
  }
  function measure(){
    const area=dimensions();size=fittedSize(image.naturalWidth,image.naturalHeight,area.width,area.height);
    image.style.width=`${size.width}px`;image.style.height=`${size.height}px`;apply();
  }
  function reset(){scale=1;x=0;y=0;apply();}
  function change(delta){
    const next=clamp(position+delta,0,photos.length-1);if(next===position){apply();return;}
    position=next;render();
  }
  function render(){
    scale=1;x=0;y=0;gesture=null;pointerMap.clear();lastTap=null;imageReady=false;image.style.opacity='0';error.hidden=true;
    dialog.querySelector('.photo-lightbox-count').textContent=`${position+1} / ${photos.length}`;
    dialog.querySelector('[data-photo-ux="previous"]').disabled=position===0;
    dialog.querySelector('[data-photo-ux="next"]').disabled=position===photos.length-1;
    image.alt=`${title||'照片'}，第 ${position+1} 张，共 ${photos.length} 张`;
    if(validPhotoSource(photos[position]))image.src=photos[position];else{image.removeAttribute('src');error.hidden=false;}
    apply();
  }
  image.onload=()=>{imageReady=true;measure();image.style.opacity='1';};
  image.onerror=()=>{imageReady=false;image.style.opacity='0';error.hidden=false;apply();};
  function zoom(next,point={x:0,y:0}){if(!imageReady)return;const value=zoomAt({scale,x,y},next,point);scale=value.scale;x=value.x;y=value.y;apply();}
  function beginPinch(){
    const [a,b]=[...pointerMap.values()];const middle=localPoint({x:(a.x+b.x)/2,y:(a.y+b.y)/2});
    gesture={mode:'pinch',distance:Math.max(1,Math.hypot(b.x-a.x,b.y-a.y)),scale,contentX:(middle.x-x)/scale,contentY:(middle.y-y)/scale};
  }
  stage.addEventListener('pointerdown',event=>{
    if(event.pointerType==='mouse'&&event.button!==0)return;
    if(event.pointerType!=='mouse')lastTouchAt=Date.now();
    event.preventDefault();stage.setPointerCapture(event.pointerId);pointerMap.set(event.pointerId,{x:event.clientX,y:event.clientY});
    if(pointerMap.size===2)beginPinch();
    else if(pointerMap.size===1)gesture={mode:scale>1.01?'pan':'swipe',startX:event.clientX,startY:event.clientY,x,y,at:Date.now(),moved:false};
  });
  stage.addEventListener('pointermove',event=>{
    if(!pointerMap.has(event.pointerId)||!gesture)return;event.preventDefault();pointerMap.set(event.pointerId,{x:event.clientX,y:event.clientY});
    if(pointerMap.size>=2){
      if(gesture.mode!=='pinch')beginPinch();
      const [a,b]=[...pointerMap.values()],middle=localPoint({x:(a.x+b.x)/2,y:(a.y+b.y)/2});
      scale=clamp(gesture.scale*Math.hypot(b.x-a.x,b.y-a.y)/gesture.distance,1,6);x=middle.x-gesture.contentX*scale;y=middle.y-gesture.contentY*scale;apply();return;
    }
    const dx=event.clientX-gesture.startX,dy=event.clientY-gesture.startY;
    if(Math.abs(dx)+Math.abs(dy)>8)gesture.moved=true;
    if(gesture.mode==='pan'){x=gesture.x+dx;y=gesture.y+dy;apply();}
    else if(gesture.mode==='swipe')apply(dx*.28);
  });
  function endPointer(event,cancelled=false){
    if(!pointerMap.has(event.pointerId))return;
    const ended=gesture;pointerMap.delete(event.pointerId);
    try{stage.releasePointerCapture(event.pointerId);}catch{}
    if(pointerMap.size){const remaining=[...pointerMap.values()][0];gesture={mode:'pan',startX:remaining.x,startY:remaining.y,x,y,moved:true,at:Date.now()};return;}
    gesture=null;
    if(!cancelled&&ended?.mode==='swipe'){
      const delta=swipeStep(event.clientX-ended.startX,event.clientY-ended.startY,stage.clientWidth);
      if(delta){change(delta);return;}
    }
    if(!cancelled&&event.pointerType!=='mouse'&&ended&&!ended.moved&&ended.mode!=='pinch'){
      const current={x:event.clientX,y:event.clientY,at:Date.now()};
      if(lastTap&&current.at-lastTap.at<320&&Math.hypot(current.x-lastTap.x,current.y-lastTap.y)<35){zoom(scale>1.01?1:2.5,localPoint(current));lastTap=null;return;}
      lastTap=current;
    }
    apply();
  }
  stage.addEventListener('pointerup',event=>endPointer(event));stage.addEventListener('pointercancel',event=>endPointer(event,true));
  stage.addEventListener('dblclick',event=>{event.preventDefault();if(Date.now()-lastTouchAt<700)return;zoom(scale>1.01?1:2.5,localPoint({x:event.clientX,y:event.clientY}));});
  stage.addEventListener('wheel',event=>{if(!event.ctrlKey)return;event.preventDefault();zoom(scale*(event.deltaY<0?1.15:1/1.15),localPoint({x:event.clientX,y:event.clientY}));},{passive:false});
  const api={close(notify=true){
    if(closed)return;closed=true;resizeObserver?.disconnect();window.removeEventListener('resize',measure);
    if(dialog.open)dialog.close();dialog.remove();if(viewer===api)viewer=null;
    if(notify)onClose?.();restoreFocus(previousFocus);
  }};
  viewer=api;
  dialog.addEventListener('click',event=>{event.stopPropagation();const action=event.target.closest('[data-photo-ux]')?.dataset.photoUx;if(action==='close')api.close();if(action==='previous')change(-1);if(action==='next')change(1);if(action==='reset')reset();if(action==='in')zoom(scale*1.5);if(action==='out')zoom(scale/1.5);});
  dialog.addEventListener('keydown',event=>{
    if(event.key==='Escape'){event.preventDefault();event.stopPropagation();api.close();return;}
    if(['ArrowLeft','ArrowRight','+','=','-','0'].includes(event.key)){event.preventDefault();event.stopPropagation();if(event.key==='ArrowLeft')change(-1);if(event.key==='ArrowRight')change(1);if(['+','='].includes(event.key))zoom(scale*1.5);if(event.key==='-')zoom(scale/1.5);if(event.key==='0')reset();}
  });
  dialog.addEventListener('cancel',event=>{event.preventDefault();event.stopPropagation();api.close();});
  dialog.showModal();render();
  if(typeof ResizeObserver!=='undefined'){resizeObserver=new ResizeObserver(measure);resizeObserver.observe(stage);}else window.addEventListener('resize',measure);
  dialog.querySelector('[data-photo-ux="close"]').focus({preventScroll:true});return true;
}

export function openCoverFocusEditor({src,focus,onSave}={}){
  if(!validPhotoSource(src)){announce('请先选择一张封面照片');return false;}
  focusEditor?.close();const previousFocus=document.activeElement,dialog=document.createElement('dialog');let value=normalizeCoverFocus(focus),gesture=null,closed=false;
  dialog.className='photo-focus-dialog';dialog.setAttribute('aria-labelledby','photo-focus-title');
  dialog.innerHTML=`<header><h2 id="photo-focus-title">把主角放在中间</h2><button type="button" data-focus-action="close" aria-label="取消封面调整">${svg('close')}</button></header><p>拖动照片调整封面，只改变展示位置。</p><div class="photo-focus-frame"><img src="${src}" alt="封面裁切预览" draggable="false"><span class="photo-focus-grid" aria-hidden="true"></span></div><label>左右位置<input type="range" min="0" max="100" step="1" name="coverX" aria-label="封面水平位置" value="${value.x}"></label><label>上下位置<input type="range" min="0" max="100" step="1" name="coverY" aria-label="封面垂直位置" value="${value.y}"></label><div class="photo-focus-actions"><button type="button" data-focus-action="reset">居中</button><button type="button" data-focus-action="save">保存位置</button></div>`;
  document.body.append(dialog);const frame=dialog.querySelector('.photo-focus-frame'),image=dialog.querySelector('img');
  const apply=()=>{image.style.objectPosition=coverPosition(value);dialog.querySelector('[name="coverX"]').value=value.x;dialog.querySelector('[name="coverY"]').value=value.y;};
  const api={close(){if(closed)return;closed=true;if(dialog.open)dialog.close();dialog.remove();if(focusEditor===api)focusEditor=null;restoreFocus(previousFocus);}};focusEditor=api;
  frame.addEventListener('pointerdown',event=>{if(event.pointerType==='mouse'&&event.button!==0)return;event.preventDefault();frame.setPointerCapture(event.pointerId);const ratio=Math.max(frame.clientWidth/image.naturalWidth,frame.clientHeight/image.naturalHeight);gesture={id:event.pointerId,x:event.clientX,y:event.clientY,focus:{...value},overflowX:image.naturalWidth*ratio-frame.clientWidth,overflowY:image.naturalHeight*ratio-frame.clientHeight};});
  frame.addEventListener('pointermove',event=>{if(gesture?.id!==event.pointerId)return;event.preventDefault();value=focusAfterDrag(gesture.focus,event.clientX-gesture.x,event.clientY-gesture.y,gesture.overflowX,gesture.overflowY);apply();});
  for(const name of ['pointerup','pointercancel'])frame.addEventListener(name,event=>{if(gesture?.id===event.pointerId){gesture=null;try{frame.releasePointerCapture(event.pointerId);}catch{}}});
  dialog.addEventListener('input',event=>{if(event.target.name==='coverX')value.x=Number(event.target.value);if(event.target.name==='coverY')value.y=Number(event.target.value);apply();});
  dialog.addEventListener('click',event=>{event.stopPropagation();const action=event.target.closest('[data-focus-action]')?.dataset.focusAction;if(action==='close')api.close();if(action==='reset'){value={x:50,y:50};apply();}if(action==='save'){const next=normalizeCoverFocus(value);api.close();onSave?.(next);restoreFocus(previousFocus);announce('封面位置已调整，保存菜谱后生效');}});
  dialog.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();event.stopPropagation();api.close();}});
  dialog.addEventListener('cancel',event=>{event.preventDefault();event.stopPropagation();api.close();});dialog.showModal();apply();return true;
}

function applyMove(from,to){
  const photos=ui.getPhotos?.()||[];if(from===to||to<0||to>=photos.length)return false;
  ui.setPhotos?.(movePhoto(photos,from,to));ui.onPhotosChanged?.();announce(`照片已移到第 ${to+1} 张`);return true;
}
export function photoExperienceClicked(data){
  if(data.photoUxMove!==undefined){applyMove(Number(data.photoUxMove),Number(data.photoUxTo));return true;}
  if(data.photoUxFocus!==undefined){openCoverFocusEditor({src:ui.getPhotos?.()[0],focus:ui.getCoverFocus?.(),onSave:value=>{ui.setCoverFocus?.(value);ui.onPhotosChanged?.();}});return true;}
  return false;
}
export function photoExperienceChanged(input){
  if(input.name!=='photoQuality')return false;
  announce((ui.getPhotos?.().length||0)?'画质只影响新选照片。已有照片需要提升清晰度时，请重新选择。':input.value==='clear'?'清晰模式适合长菜谱和文字截图':'普通模式更节省手机空间');return true;
}
export function getPhotoQualityMode(form){return form?.elements?.photoQuality?.value==='clear'?'clear':'standard';}
export function decoratePhotoEditor(container,{cover=false,focus}={}){
  if(!container)return;
  const field=container.matches?.('.photo-field')?container:container.closest('.photo-field')||container;
  field.dataset.photoUxEnabled='true';
  const cards=[...container.querySelectorAll('.photo-card')];
  if(!field.querySelector('[name="photoQuality"]')){
    const controls=document.createElement('div');controls.className='photo-quality-control';controls.innerHTML='<label>照片画质<select name="photoQuality" aria-label="照片画质"><option value="standard">普通照片 · 省空间</option><option value="clear">清晰文字图 · 保留细节</option></select></label><p>清晰模式适合长菜谱和文字截图，仅影响新选择的照片。</p>';
    field.append(controls);
  }
  cards.forEach((card,index)=>{
    card.dataset.photoOrder=String(index);card.querySelectorAll('.photo-reorder-toolbar,.photo-drag-handle,.photo-focus-launch').forEach(e=>e.remove());card.classList.toggle('photo-orderable',!cover&&cards.length>1);
    if(cover){
      const image=card.querySelector('.form-photo');if(image)image.style.objectPosition=coverPosition(focus??ui.getCoverFocus?.());
      const button=document.createElement('button');button.type='button';button.className='photo-focus-launch';button.dataset.photoUxFocus='true';button.innerHTML=`${svg('focus')}<span>调整主体位置</span>`;button.disabled=Boolean(field.querySelector('input')?.disabled)||field.classList.contains('is-processing');card.append(button);
    }else if(cards.length>1){
      const handle=document.createElement('button');handle.type='button';handle.className='photo-drag-handle';handle.setAttribute('aria-label',`拖动第 ${index+1} 张照片排序`);handle.innerHTML=`<span aria-hidden="true">${svg('move')}</span>`;handle.disabled=field.classList.contains('is-processing');card.append(handle);
      const toolbar=document.createElement('div');toolbar.className='photo-reorder-toolbar';toolbar.innerHTML=`<button type="button" data-photo-ux-move="${index}" data-photo-ux-to="${index-1}" aria-label="将第 ${index+1} 张照片前移" ${index===0||field.classList.contains('is-processing')?'disabled':''}>${svg('back')}<span>前移</span></button><button type="button" data-photo-ux-move="${index}" data-photo-ux-to="${index+1}" aria-label="将第 ${index+1} 张照片后移" ${index===cards.length-1||field.classList.contains('is-processing')?'disabled':''}><span>后移</span>${svg('next')}</button>`;card.append(toolbar);
    }
  });
  if(decorated.has(field))return;decorated.add(field);
  field.addEventListener('click',event=>{const button=event.target.closest('[data-photo-ux-move],[data-photo-ux-focus]');if(!button)return;event.preventDefault();event.stopPropagation();photoExperienceClicked(button.dataset);});
  field.addEventListener('change',event=>{if(event.target.name==='photoQuality'){event.stopPropagation();photoExperienceChanged(event.target);field.dispatchEvent(new CustomEvent('photoqualitychange',{bubbles:true}));}});
  let drag=null;
  function finish(cancelled){if(!drag)return;const current=drag;drag=null;current.ghost.remove();current.card.classList.remove('photo-dragging');field.querySelectorAll('.photo-drop-target').forEach(e=>e.classList.remove('photo-drop-target'));if(!cancelled&&current.to!==current.from)applyMove(current.from,current.to);}
  field.addEventListener('pointerdown',event=>{
    const handle=event.target.closest('.photo-drag-handle');if(!handle||handle.disabled||(event.pointerType==='mouse'&&event.button!==0))return;
    event.preventDefault();event.stopPropagation();const card=handle.closest('.photo-card'),image=card.querySelector('.form-photo');if(!image)return;
    const ghost=image.cloneNode();ghost.className='photo-drag-ghost';ghost.removeAttribute('id');ghost.setAttribute('aria-hidden','true');ghost.style.left=`${event.clientX}px`;ghost.style.top=`${event.clientY}px`;(field.closest('dialog')||document.body).append(ghost);
    drag={id:event.pointerId,from:Number(card.dataset.photoOrder),to:Number(card.dataset.photoOrder),card,ghost};card.classList.add('photo-dragging');handle.setPointerCapture(event.pointerId);
  });
  field.addEventListener('pointermove',event=>{
    if(drag?.id!==event.pointerId)return;event.preventDefault();event.stopPropagation();drag.ghost.style.left=`${event.clientX}px`;drag.ghost.style.top=`${event.clientY}px`;
    const target=document.elementFromPoint(event.clientX,event.clientY)?.closest('.photo-card[data-photo-order]');
    if(target&&field.contains(target)){field.querySelectorAll('.photo-drop-target').forEach(e=>e.classList.remove('photo-drop-target'));target.classList.add('photo-drop-target');drag.to=Number(target.dataset.photoOrder);}
  });
  field.addEventListener('pointerup',event=>{if(drag?.id===event.pointerId){event.stopPropagation();finish(false);}});
  field.addEventListener('pointercancel',event=>{if(drag?.id===event.pointerId)finish(true);});
  field.addEventListener('lostpointercapture',event=>{if(drag?.id===event.pointerId)finish(true);});
}

export function photoData(file,{qualityMode='standard'}={}){
  const job=processing.then(()=>compressPhoto(file,qualityMode));processing=job.catch(()=>{});return job;
}
async function compressPhoto(file,qualityMode){
  if(!file||file.size>30*1024*1024)throw new Error('单张照片请小于 30 MB');
  const header=headerDimensions(await file.slice(0,512*1024).arrayBuffer());
  if(header)outputSize(header.width,header.height,qualityMode);
  const source=URL.createObjectURL(file),image=new Image();let canvas;
  try{
    await new Promise((resolve,reject)=>{image.onload=resolve;image.onerror=()=>reject(new Error('这张照片打不开，请试试 JPG 或 PNG'));image.src=source;});
    const result=outputSize(image.naturalWidth,image.naturalHeight,qualityMode);canvas=document.createElement('canvas');canvas.width=result.width;canvas.height=result.height;
    const context=canvas.getContext('2d');if(!context)throw new Error('照片暂时无法处理，请重试');context.fillStyle='#fff';context.fillRect(0,0,result.width,result.height);context.drawImage(image,0,0,result.width,result.height);
    const data=canvas.toDataURL('image/jpeg',result.quality);if(data==='data:,')throw new Error('图片尺寸太大，请先缩小');return data;
  }finally{image.src='';URL.revokeObjectURL(source);if(canvas){canvas.width=1;canvas.height=1;}}
}
