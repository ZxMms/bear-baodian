export const starterLedgerCategories = [
  ["expense", "餐饮", "♨"], ["expense", "买菜", "♧"], ["expense", "交通", "↗"], ["expense", "购物", "◇"],
  ["expense", "居家", "⌂"], ["expense", "娱乐", "♫"], ["expense", "健康", "+"], ["expense", "其他支出", "…"],
  ["income", "工资", "¥"], ["income", "奖金", "☆"], ["income", "礼金", "♡"], ["income", "其他收入", "…"],
].map(([type, name, icon], index) => ({ id: `category-${index}`, type, name, icon }));

// Store integer fen. Never sum floating point currency values.
export function parseAmount(value) {
  const text = String(value).trim();
  if (!/^\d{1,7}(?:\.\d{1,2})?$/.test(text)) throw new Error("金额请填写数字，最多两位小数");
  const [yuan, fen = ""] = text.split(".");
  const cents = Number(yuan) * 100 + Number(fen.padEnd(2, "0"));
  if (cents <= 0) throw new Error("金额需要大于 0");
  return cents;
}
export function amountText(cents) {
  if (!Number.isSafeInteger(cents)) throw new Error("金额超出可显示范围");
  const absolute = Math.abs(cents), whole = String(Math.floor(absolute / 100)).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return (cents < 0 ? "−" : "") + whole + "." + String(absolute % 100).padStart(2, "0");
}
export function monthShift(month, delta) {
  const [year, number] = month.split("-").map(Number), date = new Date(Date.UTC(year, number - 1 + delta, 1));
  return date.getUTCFullYear() >= 1900 && date.getUTCFullYear() <= 9999 ? date.toISOString().slice(0, 7) : month;
}
export function ledgerSummary(rows, month) {
  const selected = rows.filter((row) => row.date.slice(0, 7) === month);
  let income = 0, expense = 0;
  for (const row of selected) {
    if (!Number.isSafeInteger(row.cents) || row.cents <= 0) continue;
    if (row.type === "income") income += row.cents;
    else if (row.type === "expense") expense += row.cents;
  }
  if (!Number.isSafeInteger(income) || !Number.isSafeInteger(expense)) throw new Error("累计金额超出可计算范围");
  return { income, expense, net: income - expense, count: selected.length };
}
export function categorySummary(rows, month, type) {
  const amounts = new Map();
  for (const row of rows) if (row.date.slice(0, 7) === month && row.type === type)
    amounts.set(row.category, (amounts.get(row.category) || 0) + row.cents);
  return [...amounts].map(([id, cents]) => ({id, cents})).sort((a, b) => b.cents - a.cents || a.id.localeCompare(b.id));
}

export function dailyTotals(rows, month, type = "expense") {
  const [year, number] = month.split("-").map(Number);
  const days = new Date(Date.UTC(year, number, 0)).getUTCDate();
  const totals = Array.from({length:days}, (_,i) => ({date:`${month}-${String(i+1).padStart(2,"0")}`, cents:0}));
  for (const row of rows) if(row.type === type && row.date.slice(0,7) === month && Number.isSafeInteger(row.cents) && row.cents>0) {
    const day=Number(row.date.slice(8))-1;
    if(totals[day]) totals[day].cents += row.cents;
  }
  return totals;
}

export function budgetSummary(expense, budget) {
  if(!Number.isSafeInteger(budget) || budget<=0) return null;
  return {remaining:budget-expense, used:expense/budget*100, over:expense>budget};
}

export const worthLabels = Object.freeze(Object.assign(Object.create(null),{ worth: '很值得', okay: '一般', skip: '下次不买了' }));
export function worthSummary(rows, month) {
  const selected = rows.filter(row => row.type === 'expense' && !row._deletedAt && row.date?.slice(0,7) === month);
  return { total: selected.length, rated: selected.filter(row => worthLabels[row.worth]).length,
    worth: selected.filter(row => row.worth === 'worth').length, okay: selected.filter(row => row.worth === 'okay').length,
    skip: selected.filter(row => row.worth === 'skip').length, again: selected.filter(row => row.eatAgain).length };
}
export function validLedgerDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value || '')) return false;
  const [year,month,day] = value.split('-').map(Number);
  if (year < 1900 || year > 9999 || month < 1 || month > 12 || day < 1) return false;
  return day <= new Date(Date.UTC(year,month,0)).getUTCDate();
}
export function normalizeGoods(input, enabled = true) {
  if (!enabled) return null;
  const goods = {name:String(input.name || '').trim().slice(0,80),model:String(input.model || '').trim().slice(0,120),
    purchaseDate:String(input.purchaseDate || ''),warrantyDate:String(input.warrantyDate || ''),returnDate:String(input.returnDate || ''),
    reminder:Boolean(input.reminder),reminderTime:String(input.reminderTime || '09:00')};
  if (!goods.name) throw new Error('给物品写个名称，方便以后找到');
  for (const [key,label] of [['purchaseDate','购买日期'],['warrantyDate','保修到期日'],['returnDate','退换截止日']]) {
    if (goods[key] && !validLedgerDate(goods[key])) throw new Error(`请填写正确的${label}`);
  }
  for (const key of ['warrantyDate','returnDate']) if (goods[key] && goods.purchaseDate && goods[key] < goods.purchaseDate) throw new Error('截止日期不能早于购买日期');
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(goods.reminderTime)) throw new Error('请填写正确的物品提醒时间');
  if (goods.reminder && !goods.warrantyDate && !goods.returnDate) throw new Error('先填写保修到期日或退换截止日，再开启提醒');
  return goods;
}
export function goodsReminders(rows) {
  return rows.filter(row=>!row._deletedAt && row.goods?.reminder).flatMap(row=>[
    ['return','returnDate','退换截止'],['warranty','warrantyDate','保修到期']
  ].filter(([,key])=>validLedgerDate(row.goods[key])).map(([kind,key,label])=>({
    id:`goods-${kind}-${row.id}`,kind:'memo',title:`${row.goods.name} · ${label}`,date:row.goods[key],
    time:row.goods.reminderTime || '09:00',days:0,annual:false,recurrence:'none'
  })));
}
// Both records refer to one event. Existing journal prose and photo choices remain user-owned.
export function entryFromLedger(bill, existing, entryId, categoryName = '生活') {
  if (existing) return {...existing,date:bill.date,ledgerId:bill.id};
  const food = /餐饮|买菜|美食|吃饭/.test(categoryName);
  return {id:entryId,kind:food?'meal':'life',title:(bill.note || bill.goods?.name || `${categoryName}小记`).slice(0,80),
    date:bill.date,time:'',note:bill.note || '',photos:[...(bill.photos || [])],created:bill.created || Date.now(),
    ledgerId:bill.id,linkedFrom:'ledger',recipeId:'',recurrence:{type:'none'},reminder:null};
}
