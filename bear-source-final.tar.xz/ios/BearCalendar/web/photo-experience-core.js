export const clamp = (value, min, max) => Math.min(max, Math.max(min, Number.isFinite(Number(value)) ? Number(value) : min));
export function normalizeCoverFocus(focus) {
  return {x:clamp(focus?.x ?? 50,0,100),y:clamp(focus?.y ?? 50,0,100)};
}
export function coverPosition(focus) { const {x,y}=normalizeCoverFocus(focus); return `${x}% ${y}%`; }
export function coverStyle(focus) { return `object-position:${coverPosition(focus)}`; }
export function movePhoto(photos, from, to) {
  const result=[...photos];
  if(!Number.isInteger(from)||!Number.isInteger(to)||from<0||to<0||from>=result.length||to>=result.length)return result;
  const [photo]=result.splice(from,1);result.splice(to,0,photo);return result;
}
export function fittedSize(width,height,areaWidth,areaHeight) {
  if(!(width>0&&height>0&&areaWidth>0&&areaHeight>0))return {width:0,height:0};
  const ratio=Math.min(areaWidth/width,areaHeight/height);
  return {width:width*ratio,height:height*ratio};
}
export function clampPan(x,y,scale,imageWidth,imageHeight,areaWidth,areaHeight) {
  const maxX=Math.max(0,(imageWidth*scale-areaWidth)/2),maxY=Math.max(0,(imageHeight*scale-areaHeight)/2);
  return {x:clamp(x,-maxX,maxX),y:clamp(y,-maxY,maxY)};
}
export function zoomAt(state,nextScale,point={x:0,y:0}) {
  const scale=clamp(nextScale,1,6),ratio=scale/state.scale;
  return {scale,x:point.x-(point.x-state.x)*ratio,y:point.y-(point.y-state.y)*ratio};
}
export function swipeStep(dx,dy,width) {
  return Math.abs(dx)>=Math.min(90,Math.max(45,width*.18))&&Math.abs(dx)>Math.abs(dy)*1.35 ? dx<0?1:-1 : 0;
}
export function focusAfterDrag(focus,dx,dy,overflowX,overflowY) {
  const old=normalizeCoverFocus(focus);
  return {x:overflowX>1?clamp(old.x-dx/overflowX*100,0,100):old.x,y:overflowY>1?clamp(old.y-dy/overflowY*100,0,100):old.y};
}
export function outputSize(width,height,qualityMode='standard') {
  if(!(width>0&&height>0)||width*height>40000000)throw new Error('图片尺寸太大，请先在相册缩小后再选');
  const clear=qualityMode==='clear',longest=clear?4000:1200,maxPixels=clear?8000000:1440000;
  const ratio=Math.min(1,longest/Math.max(width,height),Math.sqrt(maxPixels/(width*height)));
  return {width:Math.max(1,Math.floor(width*ratio)),height:Math.max(1,Math.floor(height*ratio)),quality:clear?.92:.8};
}
export function validPhotoSource(value) {
  return typeof value==='string'&&(/^data:image\/(jpeg|png|webp|gif);base64,[A-Za-z0-9+/=]+$/.test(value)||/^media\/[a-f0-9]{64}\.(jpg|png|webp|gif)$/.test(value));
}
// Reject oversized common images before asking the browser to decode their pixels.
export function headerDimensions(bytes) {
  const a=bytes instanceof Uint8Array?bytes:new Uint8Array(bytes),v=new DataView(a.buffer,a.byteOffset,a.byteLength);
  if(a.length>=24&&a[0]===137&&a[1]===80&&a[2]===78&&a[3]===71)return {width:v.getUint32(16),height:v.getUint32(20)};
  if(a.length>=10&&String.fromCharCode(...a.slice(0,3))==='GIF')return {width:v.getUint16(6,true),height:v.getUint16(8,true)};
  if(a.length>=30&&String.fromCharCode(...a.slice(0,4))==='RIFF'&&String.fromCharCode(...a.slice(8,12))==='WEBP'){
    const kind=String.fromCharCode(...a.slice(12,16));
    if(kind==='VP8X')return {width:1+a[24]+(a[25]<<8)+(a[26]<<16),height:1+a[27]+(a[28]<<8)+(a[29]<<16)};
    if(kind==='VP8 '&&a[23]===157&&a[24]===1&&a[25]===42)return {width:v.getUint16(26,true)&16383,height:v.getUint16(28,true)&16383};
    if(kind==='VP8L'&&a[20]===47){const bits=v.getUint32(21,true);return {width:(bits&16383)+1,height:((bits>>>14)&16383)+1};}
  }
  if(a.length>=4&&a[0]===255&&a[1]===216){
    let offset=2;
    while(offset+3<a.length){
      if(a[offset]!==255){offset++;continue;}
      const marker=a[offset+1];if(marker===255){offset++;continue;}if(marker===217||marker===218)break;
      if(marker===216||marker===1||(marker>=208&&marker<=215)){offset+=2;continue;}
      const length=v.getUint16(offset+2);if(length<2||offset+length+2>a.length)break;
      if([192,193,194,195,197,198,199,201,202,203,205,206,207].includes(marker)&&length>=7)return {width:v.getUint16(offset+7),height:v.getUint16(offset+5)};
      offset+=2+length;
    }
  }
  return null;
}
