import { loadAll, saveItem, removeItem, dateKey, getLedgerBudgets, saveLedgerBudgets, saveItemsAtomically } from "./model.js?v=34";
import { parseAmount, amountText, ledgerSummary, budgetSummary, worthLabels, validLedgerDate, normalizeGoods, goodsReminders, entryFromLedger } from "./ledger-core.js?v=34";
import { bearArt, artIndex } from "./illustrations.js?v=34";
import { icon } from "./icons.js?v=34";
import {periodModes,ledgerPeriod,shiftLedgerPeriod,periodDays,periodRows,periodSummary,periodCategories,periodTrend,pieSlices,percentageText} from './ledger-periods.js?v=34';

let rows = [], categories = [], ui, selectedMonth = dateKey().slice(0, 7), section = "records", filter = "all", analysisType = "expense";
let budgets = {}, categoryFilter = "", receiptDraft = null, editSeed = null, worthFilter = "all", photoCountObserver = null;
let period=ledgerPeriod('month',dateKey()),pieEventsBound=false;
const chartColors = ["#bb815b","#8c9c70","#d5ad69","#a68ba5","#7eabb1","#d18e89","#8e8bb6","#bda183","#88a58d","#b6a354","#b68195","#7598bd"];
const escape = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
const id = () => globalThis.crypto?.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2);
const categoryFor = (key) => categories.find((item) => item.id === key) || { name: "未分类", icon: "◇" };
const signed = (row) => (row.type === "income" ? "+" : "−") + amountText(row.cents);
const monthLabel = (month) => `${Number(month.slice(0,4))} 年 ${Number(month.slice(5))} 月`;
const labels = {expense:"支出", income:"收入"};
const categoryIcon = category => icon(/餐饮|买菜|美食|吃饭/.test(category.name)?'recipes':/健康|礼/.test(category.name)?'heart':category.type==='income'?'ledger':'tools');
const detailLabel = (symbol,label) => `<span class="ledger-extra-title">${icon(symbol)}${label}</span>${icon('back','ledger-disclosure-chevron')}`;
async function recordsChanged() { try { await ui.onRecordsChanged?.(); return true; } catch { return false; } }
async function finishDraft(form) { try { await ui.onSaved?.(form); return true; } catch { return false; } }

export async function initLedger(callbacks) {
  ui = callbacks;
  if(!pieEventsBound&&typeof document!=='undefined'&&typeof document.addEventListener==='function') {
    const activate=event=>{
      const target=event.target.closest?.('[data-ledger-slice]');
      if(!target||ui.sheet.open||(event.type==='keydown'&&!['Enter',' '].includes(event.key)))return;
      event.preventDefault();
      void ledgerClick({ledgerDrill:target.dataset.ledgerSlice,ledgerDrillType:target.dataset.ledgerSliceType}).catch(error=>ui.announce(error.message));
    };
    document.addEventListener('click',activate);document.addEventListener('keydown',activate);pieEventsBound=true;
  }
  await reloadLedger();
}
function applyPeriod(next) { period=next;selectedMonth=next.anchor.slice(0,7);categoryFilter=''; }
function renderLedgerFocus(selector) { ui.render();if(typeof document!=='undefined')document.querySelector?.(selector)?.focus?.({preventScroll:true}); }
const recordDateLabel=date=>`${period.start.slice(0,4)!==period.end.slice(0,4)?date.slice(0,4)+'年':''}${date.slice(5).replace('-','月')}日`;
const rangeLabel=()=>`${period.start} — ${period.end}`;
const periodUnit=()=>({week:'周',month:'月',quarter:'季度',year:'年',custom:'时段'}[period.mode]);
function chartColor(categoryId) {
  let index=categories.findIndex(category=>category.id===categoryId);
  if(index<0)index=[...categoryId].reduce((hash,char)=>(hash*31+char.charCodeAt(0))>>>0,0);
  return chartColors[index%chartColors.length];
}
function openPeriodPicker(mode=period.mode) {
  ui.open('选择统计日期',`<form data-form="ledger-period"><p class="work-lead">选好日期，收支汇总、分类图和账单会一起更新。</p><label for="ledger-period-mode">统计维度</label><select id="ledger-period-mode" name="periodMode">${Object.entries(periodModes).map(([key,label])=>`<option value="${key}" ${key===mode?'selected':''}>${label==='自选'?'自选起止日期':'按'+label}</option>`).join('')}</select><fieldset class="ledger-period-fields" data-period-anchor ${mode==='custom'?'disabled hidden':''}><label for="ledger-period-date">选择一天</label><input type="date" id="ledger-period-date" name="periodAnchor" value="${period.anchor}" min="1900-01-01" max="9999-12-31" required><p class="photo-hint">自动查看这一天所在的周、月、季度或年。周一是每周的第一天。</p></fieldset><fieldset class="ledger-period-fields" data-period-custom ${mode==='custom'?'':'disabled hidden'}><div class="form-row"><div><label for="ledger-period-start">开始日期</label><input type="date" id="ledger-period-start" name="periodStart" value="${period.start}" min="1900-01-01" max="9999-12-31" required></div><div><label for="ledger-period-end">结束日期</label><input type="date" id="ledger-period-end" name="periodEnd" value="${period.end}" min="1900-01-01" max="9999-12-31" required></div></div><p class="photo-hint">包含开始和结束当天，也可以只选同一天。</p></fieldset><p class="form-error" role="alert"></p><button class="primary" type="submit">查看这段时间</button></form>`);
  ui.setDraft();
}
function periodControls() {
  return `<section class="ledger-period-controls" aria-label="账本统计日期"><div class="ledger-period-tabs" aria-label="统计维度">${Object.entries(periodModes).map(([value,label])=>`<button type="button" data-ledger-period="${value}" aria-pressed="${period.mode===value}">${label}</button>`).join('')}</div><div class="ledger-period-heading"><button type="button" data-ledger-action="prev" aria-label="上一${periodUnit()}" ${shiftLedgerPeriod(period,-1)?'':'disabled'}>${icon('back')}</button><button type="button" class="ledger-period-date" data-ledger-action="period-picker" aria-label="选择统计日期，当前${rangeLabel()}"><strong class="ledger-period-title">${escape(period.title)}</strong><span>${icon('calendar')}${rangeLabel()}</span></button><button type="button" data-ledger-action="next" aria-label="下一${periodUnit()}" ${shiftLedgerPeriod(period,1)?'':'disabled'}>${icon('back','ledger-forward-icon')}</button></div><div class="ledger-period-footnote"><span>点日期选择 · ${periodDays(period)} 天</span><button type="button" data-ledger-action="today">${period.mode==='custom'?'回到本月':'回到本'+periodUnit()}</button></div></section>`;
}
export async function reloadLedger() {
  [rows, categories, budgets] = await Promise.all([loadAll("ledger"), loadAll("ledgerCategories"), getLedgerBudgets()]);
  budgets ||= {};
  const rank = (item) => /^category-\d+$/.test(item.id) ? Number(item.id.slice(9)) : 1000;
  categories.sort((a,b) => rank(a)-rank(b));
}
export const getLedgerRows = () => rows.map(row=>({...row}));
export const getLedgerCategories = () => categories.map(category=>({...category}));
export const getLedgerDraftContext = () => editSeed ? {...editSeed} : null;
export const ledgerGoodsReminders = () => goodsReminders(rows);
export function ledgerReminderTarget(reminderId) {
  const prefix = ['goods-return-','goods-warranty-'].find(value=>String(reminderId).startsWith(value));
  return prefix ? String(reminderId).slice(prefix.length) : null;
}
export function openLedger(ledgerId, returnDay = '') {
  const item = rows.find(row=>row.id===ledgerId);
  if (!item) { ui.announce('这笔账单已移到最近删除，或暂时不存在'); return false; }
  showLedger(item,returnDay); return true;
}
export const ledgerOn = (date) => rows.filter((item) => item.date === date);
export const hasLedgerOn = (date) => rows.some((item) => item.date === date);
export const ledgerShareEntries = (date) => ledgerOn(date).map(row=>({title:`${labels[row.type]} · ${categoryFor(row.category).name} · ¥${amountText(row.cents)}`,text:row.note || ""}));
function rowMarkup(row, returnDay = "") {
  const category = categoryFor(row.category), photos = Array.isArray(row.photos) ? row.photos : [];
  return `<button type="button" class="ledger-row" data-ledger-id="${row.id}" data-return-day="${returnDay}">${photos.length ? `<span class="ledger-row-photo">${ui.imageMarkup(photos[0],"ledger-thumb","消费照片")}<small>${photos.length} 张</small></span>` : `<span class="ledger-category-icon ${row.type}" aria-hidden="true">${categoryIcon(category)}</span>`}<span class="ledger-row-copy"><strong>${escape(category.name)}</strong><small>${escape(row.note || row.goods?.name || labels[row.type])}</small>${worthLabels[row.worth] || row.eatAgain ? `<span class="ledger-row-tags">${worthLabels[row.worth] ? `<i>${worthLabels[row.worth]}</i>` : ""}${row.eatAgain ? "<i>还想再吃</i>" : ""}</span>` : ""}</span><b class="ledger-amount ${row.type}">${signed(row)}</b></button>`;
}
export function dayLedgerMarkup(date) {
  const items = ledgerOn(date).sort((a,b) => b.created - a.created);
  if (!items.length) return `<button type="button" class="text-button day-ledger-add" data-ledger-action="add" data-ledger-date="${date}" data-return-day="${date}">${icon('plus')}给这一天记一笔账</button>`;
  const sum = ledgerSummary(items, date.slice(0,7));
  return `<section class="day-ledger"><div class="section-title"><h3>这一天的小账本</h3><button type="button" class="text-button" data-ledger-action="add" data-ledger-date="${date}" data-return-day="${date}">${icon('plus')}记一笔</button></div><p class="ledger-day-total">支出 ¥${amountText(sum.expense)} · 收入 ¥${amountText(sum.income)}</p>${items.map((row) => rowMarkup(row, date)).join("")}</section>`;
}
function recordsMarkup() {
  const list = periodRows(rows,period).filter((row) => (filter === "all" || row.type === filter) && (!categoryFilter || (row.category||'uncategorized') === categoryFilter))
    .sort((a,b) => b.date.localeCompare(a.date) || b.created - a.created);
  const groups = new Map();
  for (const row of list) { if (!groups.has(row.date)) groups.set(row.date, []); groups.get(row.date).push(row); }
  return `<div class="ledger-filters" aria-label="账单类型">${[["all","全部"],["expense","支出"],["income","收入"]].map(([value,title]) => `<button type="button" data-ledger-filter="${value}" aria-pressed="${filter === value}">${title}</button>`).join("")}<button type="button" class="ledger-manage" data-ledger-action="categories">分类管理</button></div>
    ${categoryFilter ? `<button type="button" class="ledger-filter-tag" data-ledger-action="clear-category">${escape(categoryFor(categoryFilter).name)} · ${list.length} 笔 · ¥${amountText(list.reduce((total,row)=>total+row.cents,0))}<span>清除筛选 ×</span></button><button type="button" class="text-button ledger-back-analysis" data-ledger-section="analysis">‹ 返回分类统计</button>` : ""}
    ${list.length ? [...groups].map(([date, items]) => { const sum = ledgerSummary(items, date.slice(0,7)); return `<section class="ledger-day-group"><div class="ledger-date-heading"><h3>${recordDateLabel(date)}</h3><small>${filter === "income" ? "收入 ¥" + amountText(sum.income) : filter === "expense" ? "支出 ¥" + amountText(sum.expense) : "支 ¥" + amountText(sum.expense) + " · 收 ¥" + amountText(sum.income)}</small></div><div class="card ledger-rows">${items.map((row)=>rowMarkup(row)).join("")}</div></section>`; }).join("") : `<div class="ledger-empty">${bearArt("moments",selectedMonth,"ledger-empty-bears",0)}<h3>${categoryFilter ? "这个分类在所选时段没有账单" : filter === "all" ? "小日子，也有一本小账" : "这段时间还没有" + labels[filter]}</h3><p>买菜、奶茶、小礼物，慢慢记下来。</p><button type="button" class="secondary" data-ledger-action="add">记下第一笔</button></div>`}`;
}
function reviewMarkup() {
  const scope=periodRows(rows,period).filter(row=>row.type==='expense'),counts={total:scope.length,rated:scope.filter(row=>worthLabels[row.worth]).length,worth:scope.filter(row=>row.worth==='worth').length,again:scope.filter(row=>row.eatAgain).length}, filters=[['all','全部'],['worth','很值得'],['okay','一般'],['skip','下次不买'],['again','还想再吃']];
  const list=scope.filter(row=>(worthFilter==='all'||(worthFilter==='again'?row.eatAgain:row.worth===worthFilter))).sort((a,b)=>b.date.localeCompare(a.date)||b.created-a.created);
  const groups=new Map();for(const row of list){if(!groups.has(row.date))groups.set(row.date,[]);groups.get(row.date).push(row);}
  return `<section class="card ledger-review-intro"><p class="eyebrow">把喜欢留在生活里</p><h3>这笔钱，花得开心吗？</h3><p>点开一笔消费，记下当时的感受。下次想买、想吃时，就有自己的答案。</p><div class="ledger-review-counts"><span><b>${counts.worth}</b>笔很值得</span><span><b>${counts.again}</b>顿还想再吃</span><span><b>${counts.rated}<small> / ${counts.total}</small></b>笔已评价</span></div></section><div class="ledger-review-filters" aria-label="消费感受筛选">${filters.map(([key,label])=>`<button type="button" data-ledger-worth-filter="${key}" aria-pressed="${worthFilter===key}">${label}</button>`).join('')}</div>${list.length?[...groups].map(([date,items])=>`<section class="ledger-day-group"><div class="ledger-date-heading"><h3>${recordDateLabel(date)}</h3><small>${items.length} 笔消费</small></div><div class="card ledger-rows">${items.map(row=>rowMarkup(row)).join('')}</div></section>`).join(''):`<div class="ledger-review-empty"><h3>${worthFilter==='all'?'这段时间还没有消费小记':'还没有这样的消费记录'}</h3><p>在账单详情或编辑时标记感受，就会收进这里。</p></div>`}<p class="ledger-local-note">仅汇总你主动标记的感受 · 可随时修改</p>`;
}
function pieMarkup(ranking,total) {
  if(!total)return `<div class="ledger-pie-empty" aria-label="暂无${labels[analysisType]}分类数据"><span aria-hidden="true">${icon('ledger')}</span><strong>还没有${labels[analysisType]}记录</strong><p>换一段时间看看，或先记下一笔。</p></div>`;
  const slices=pieSlices(ranking).map(group=>{
    const attrs=`fill="${chartColor(group.id)}" class="ledger-pie-slice" data-ledger-slice="${escape(group.id)}" data-ledger-slice-type="${analysisType}" role="button" tabindex="0" aria-label="${escape(categoryFor(group.id).name)}，${labels[analysisType]}${amountText(group.cents)}元，占${group.percent}，查看明细"`;
    const title=`<title>${escape(categoryFor(group.id).name)} · ¥${amountText(group.cents)} · ${group.percent}</title>`;
    return group.full?`<circle cx="110" cy="110" r="96" ${attrs}>${title}</circle>`:`<path d="${group.path}" ${attrs}>${title}</path>`;
  }).join('');
  return `<div class="ledger-pie-wrap"><svg class="ledger-pie" viewBox="0 0 220 220" role="group" aria-label="${labels[analysisType]}分类扇形图，点扇区查看明细">${slices}</svg><div class="ledger-pie-summary"><span>所选时段${labels[analysisType]}</span><strong>¥${amountText(total)}</strong><small>${ranking.length} 个分类 · ${ranking.reduce((sum,group)=>sum+group.count,0)} 笔</small><p>点扇区或下方分类<br>看看每一笔</p></div></div>`;
}

function trendMarkup() {
  const {unit,points}=periodTrend(rows,period,analysisType),peak=Math.max(0,...points.map(item=>item.cents)),scale=peak||100;
  const x=index=>points.length===1?177:45+index/(points.length-1)*264;
  const coords=points.map((point,index)=>[x(index),139-point.cents/scale*104]);
  const path=coords.map(([x,y],index)=>`${index?'L':'M'}${x.toFixed(2)},${y.toFixed(2)}`).join(' ');
  const max=points.find(point=>point.cents===peak),axes=[...new Set([0,Math.floor((points.length-1)/2),points.length-1])];
  const cadence={day:'每日',month:'按月',year:'按年'}[unit];
  return `<section class="card ledger-trend"><div class="section-title"><h3>${cadence}${labels[analysisType]}趋势</h3><span>${points.length} 个统计点</span></div><svg viewBox="0 0 325 182" role="img" aria-label="${escape(period.title)}${labels[analysisType]}趋势，最高${peak?`${escape(max.label)}，${amountText(peak)}元`:'0元'}"><title>仅汇总所选起止日期内的账单，没有记录的时段按零显示</title>${[0,.5,1].map(ratio=>`<line x1="45" y1="${139-ratio*104}" x2="309" y2="${139-ratio*104}" stroke="var(--line)" stroke-dasharray="3 4"/><text x="39" y="${143-ratio*104}" text-anchor="end">${(scale*ratio/100).toLocaleString('zh-CN',{maximumFractionDigits:2,notation:scale>100000?'compact':'standard'})}</text>`).join('')}${points.length>1?`<path d="${path} L${coords.at(-1)[0]},139 L${coords[0][0]},139 Z" fill="var(--surface-soft)"/><path d="${path}" fill="none" stroke="var(--accent)" stroke-width="2.5" stroke-linejoin="round"/>`:''}${points.map((point,index)=>`<circle cx="${coords[index][0]}" cy="${coords[index][1]}" r="${points.length===1?4:point.cents?3:0}" fill="var(--accent)"><title>${point.start}—${point.end}：¥${amountText(point.cents)}</title></circle>`).join('')}${axes.map(index=>`<text x="${x(index)}" y="164" text-anchor="${points.length===1?'middle':index===0?'start':index===points.length-1?'end':'middle'}">${escape(points[index].label)}</text>`).join('')}</svg><p class="photo-hint">单位：元 · 无记录按 0 显示${unit!=='day'?' · 首尾只计入所选日期':''}</p>${peak?`<p class="trend-peak">最高时段 <button type="button" data-ledger-trend-start="${max.start}" data-ledger-trend-end="${max.end}">${escape(max.label)} · ¥${amountText(peak)} ›</button></p>`:'<p class="ledger-analysis-empty">有了记录，就能看到花销与收入的变化。</p>'}</section>`;
}

function budgetMarkup() {
  const amount=budgets[selectedMonth], status=budgetSummary(ledgerSummary(rows,selectedMonth).expense,amount);
  if(!status) return `<button type="button" class="ledger-budget-empty" data-ledger-action="budget"><span>给这个月设个小预算<small>支出进度和剩余额度，一眼就知道</small></span><b>＋</b></button>`;
  return `<section class="ledger-budget ${status.over?'over':''}"><div><span>${status.over?'已超出预算':'预算还剩'}</span><button type="button" data-ledger-action="budget">调整预算 ›</button></div><strong>¥${amountText(Math.abs(status.remaining))}</strong><div class="budget-track" role="progressbar" aria-label="月预算使用进度" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.min(100,status.used).toFixed(1)}" aria-valuetext="已使用预算 ${status.used.toFixed(1)}%"><i style="width:${Math.min(100,status.used)}%"></i></div><p>月预算 ¥${amountText(amount)} · 已用 ${status.used.toFixed(1)}%</p></section>`;
}
function editBudget() {
  ui.open("这个月的小预算", `<form data-form="ledger-budget"><p class="detail-meta">${monthLabel(selectedMonth)} · 仅计算支出</p><label for="ledger-budget">月预算 <small>人民币元</small></label><input id="ledger-budget" name="budgetAmount" inputmode="decimal" maxlength="10" placeholder="比如：3000" value="${budgets[selectedMonth]?(budgets[selectedMonth]/100).toFixed(2):''}"><p class="photo-hint">只应用于所选月份。留空可关闭预算，不影响账单。</p><p class="form-error" role="alert"></p><button type="submit" class="primary">保存预算</button></form>`);
  ui.setDraft();
}
function analysisMarkup() {
  const current=periodSummary(rows,period),previousPeriod=shiftLedgerPeriod(period,-1),previous=previousPeriod?periodSummary(rows,previousPeriod):null;
  const ranking=periodCategories(rows,period,analysisType),total=current[analysisType],before=previous?.[analysisType]||0,difference=total-before;
  const previousName=period.mode==='custom'?'前一等长时段':'上一'+periodUnit();
  const comparison=!previous?'已到可查询的最早时段':before===0?total?`${previousName}未记${labels[analysisType]}，暂不计算变化率`:'两个时段都还没有记录':difference===0?`与${previousName}${labels[analysisType]}持平`:`比${previousName}${difference>0?'多':'少'} ¥${amountText(Math.abs(difference))}（${(Math.abs(difference)/before*100).toFixed(1)}%）`;
  return `<div class="ledger-analysis"><section class="card ledger-ranking"><div class="section-title"><h3>${analysisType==='expense'?'钱花在哪里':'收入从哪里来'}</h3><div class="ledger-mini-tabs" aria-label="分类统计收支类型">${['expense','income'].map(type=>`<button type="button" data-ledger-analysis="${type}" aria-pressed="${analysisType===type}">${labels[type]}</button>`).join('')}</div></div>${pieMarkup(ranking,total)}
    ${ranking.map(group=>`<button type="button" class="ledger-rank" data-ledger-drill="${escape(group.id)}" data-ledger-drill-type="${analysisType}" aria-label="查看${escape(categoryFor(group.id).name)}${labels[analysisType]}明细，${amountText(group.cents)}元，占${percentageText(group.cents,total)}"><div><span><i class="chart-key" style="background:${chartColor(group.id)}"></i>${escape(categoryFor(group.id).name)}<small>${group.count} 笔</small></span><b>¥${amountText(group.cents)} <small>${percentageText(group.cents,total)}</small><em>›</em></b></div><div class="ledger-bar"><i style="width:${group.cents/total*100}%;background:${chartColor(group.id)}"></i></div></button>`).join('')}</section>${trendMarkup()}
    <section class="card ledger-insight"><p class="eyebrow">${labels[analysisType]}对比</p><h3>${escape(comparison)}</h3>${previous?`<div class="ledger-comparison"><div><span>所选时段${labels[analysisType]}</span><strong>¥${amountText(total)}</strong><small>${rangeLabel()}</small></div><div><span>${previousName}${labels[analysisType]}</span><strong>¥${amountText(before)}</strong><small>${previousPeriod.start} — ${previousPeriod.end}</small></div></div>`:''}<p class="photo-hint">按两个完整时段内已录入的账单比较；未结束的时段可能尚未记全。</p></section><p class="ledger-local-note">只分析你记下的账单 · 已删除账单不计入</p></div>`;
}

export function ledgerMarkup() {
  const summary=periodSummary(rows,period);
  return `${periodControls()}<section class="ledger-overview page-hero ledger-page-hero"><div class="ledger-hero-copy"><div class="ledger-overview-top"><span>所选${periodUnit()}支出</span><span>${summary.count} 笔小记录</span></div><strong class="ledger-main-amount" data-ledger-total="expense"><small>¥</small>${amountText(summary.expense)}</strong></div>${bearArt('moments',period.start,'ledger-bear',artIndex(period.start,4))}<div class="ledger-summary"><div><span>收入</span><b data-ledger-total="income">¥${amountText(summary.income)}</b></div><div><span>收支结余</span><b data-ledger-total="net">¥${amountText(summary.net)}</b></div></div></section>
    ${period.mode==='month'?budgetMarkup():''}<button type="button" class="ledger-receipt-entry" data-ledger-action="receipt"><span aria-hidden="true">${icon('journal')}</span><span><strong>截图记账</strong><small>选一张交易截图，核对后入账</small></span><b>›</b></button><div class="ledger-section-tabs" aria-label="账本视图">${[['records','账单记录'],['analysis','收支分析'],['review','消费回顾']].map(([value,label])=>`<button type="button" data-ledger-section="${value}" aria-pressed="${section===value}">${label}</button>`).join('')}</div>
    ${section==='records'?recordsMarkup():section==='review'?reviewMarkup():analysisMarkup()}<button type="button" class="primary ledger-add-button" data-ledger-action="add">${icon('plus')}记一笔账</button>`;
}

function choices(type, selected) {
  return categories.filter((item) => item.type === type).map((item, index) => `<label class="ledger-category-choice"><input type="radio" name="ledgerCategory" value="${item.id}" ${selected === item.id || (!selected && !index) ? "checked" : ""} required><span><i aria-hidden="true">${categoryIcon(item)}</i><b>${escape(item.name)}</b></span></label>`).join("");
}
function optionalSummary(item) {
  const parts=[];
  if(item?.note)parts.push('有备注');
  if(item?.photos?.length)parts.push(`${item.photos.length} 张照片`);
  if(item?.receipt)parts.push('有截图凭证');
  return parts.join(' · ') || '选填 · 记下买了什么、吃了什么';
}
function refreshOptionalSummary(form) {
  if (!form) return;
  const summary=form.querySelector('[data-ledger-optional-summary]');if(!summary)return;
  summary.textContent=optionalSummary({note:form.elements.ledgerNote?.value,photos:ui.getPhotos(),receipt:form.elements.keepReceipt?.checked?'yes':''});
}
export function refreshLedgerForm(form) {
  if(!form || form.dataset.form!=='ledger')return;
  const expense=form.elements.ledgerType?.value!=='income',goodsEnabled=form.elements.goodsEnabled?.checked;
  const expenseFields=form.querySelector('.ledger-expense-only'),goodsFields=form.querySelector('.ledger-goods-fields');
  if(expenseFields)expenseFields.hidden=!expense;
  if(goodsFields){goodsFields.disabled=!expense||!goodsEnabled;goodsFields.hidden=!goodsEnabled;}
  const worth=form.querySelector('[data-ledger-worth-summary]'),goods=form.querySelector('[data-ledger-goods-summary]');
  if(worth)worth.textContent=(worthLabels[form.elements.ledgerWorth?.value]||'选填 · 由你自己评价')+(form.elements.eatAgain?.checked?' · 还想再吃':'');
  if(goods)goods.textContent=goodsEnabled?(form.elements.goodsName?.value?.trim()||'已开启 · 记得补充物品名称'):'选填 · 型号、保修与退换日期';
  refreshOptionalSummary(form);
}
function goodsFields(goods, date) {
  return `<details class="ledger-extra ledger-goods-section" ${goods?'open':''}><summary>${detailLabel("shield","买到的喜欢 · 物品档案")}<small data-ledger-goods-summary>${goods?escape(goods.name):'选填 · 型号、保修与退换日期'}</small></summary><label class="checkbox"><input name="goodsEnabled" type="checkbox" ${goods?'checked':''}>为这笔消费建立物品档案</label><fieldset class="ledger-goods-fields" ${goods?'':'disabled hidden'}><label for="goods-name">物品名称</label><input id="goods-name" name="goodsName" maxlength="80" placeholder="例如：咖啡机、生日礼物" value="${escape(goods?.name||'')}"><label for="goods-model">型号 <small>选填</small></label><input id="goods-model" name="goodsModel" maxlength="120" value="${escape(goods?.model||'')}"><label for="goods-purchase">购买日期</label><input id="goods-purchase" name="goodsPurchase" type="date" min="1900-01-01" max="9999-12-31" value="${escape(goods?.purchaseDate||date)}"><label for="goods-warranty">保修到期日 <small>选填</small></label><input id="goods-warranty" name="goodsWarranty" type="date" min="1900-01-01" max="9999-12-31" value="${escape(goods?.warrantyDate||'')}"><label for="goods-return">退换截止日 <small>选填 · 按商家约定填写</small></label><input id="goods-return" name="goodsReturn" type="date" min="1900-01-01" max="9999-12-31" value="${escape(goods?.returnDate||'')}"><label class="checkbox"><input name="goodsReminder" type="checkbox" ${goods?.reminder?'checked':''}>在截止日提醒我</label><label for="goods-reminder-time">提醒时间</label><input id="goods-reminder-time" name="goodsReminderTime" type="time" value="${escape(goods?.reminderTime||'09:00')}"><p class="photo-hint">照片与截图凭证沿用这笔账单，可在「备注、消费照片与凭证」中补充。日期由你填写，开启后在手机 App 安排本机提醒。</p></fieldset></details>`;
}
function worthFields(item) {
  return `<details class="ledger-extra"><summary>${detailLabel("heart","这笔钱花得值吗")}<small data-ledger-worth-summary>${escape(worthLabels[item?.worth] || '选填 · 由你自己评价')}${item?.eatAgain?' · 还想再吃':''}</small></summary><div class="ledger-worth-choices">${[['','暂不评价'],...Object.entries(worthLabels)].map(([value,label])=>`<label><input type="radio" name="ledgerWorth" value="${value}" ${(item?.worth||'')===value?'checked':''}><span>${label}</span></label>`).join('')}</div><label class="checkbox"><input name="eatAgain" type="checkbox" ${item?.eatAgain?'checked':''}>如果是餐饮消费，这顿还想再吃</label><p class="photo-hint">以后可以在「消费回顾」里一起翻看。</p></details>`;
}
function worthDetail(item, returnDay='') {
  if(item.type!=='expense')return '';
  return `<section class="ledger-worth-detail"><div class="section-title"><h3>这笔钱花得值吗</h3>${item.eatAgain?'<span class="ledger-again-tag">还想再吃</span>':''}</div><div class="ledger-worth-actions">${Object.entries(worthLabels).map(([value,label])=>`<button type="button" data-ledger-worth-set="${item.worth===value?'':value}" data-ledger-worth-id="${item.id}" data-return-day="${returnDay}" aria-pressed="${item.worth===value}">${label}</button>`).join('')}</div><p class="photo-hint">${item.worth?'再点已选感受可取消':'随手记下感受，以后在「消费回顾」里翻看'}</p></section>`;
}
function goodsDetail(item) {
  const goods=item.goods;if(!goods)return '';
  const fields=[['型号',goods.model],['购买日期',goods.purchaseDate],['保修到期',goods.warrantyDate],['退换截止',goods.returnDate]].filter(([,value])=>value);
  return `<section class="ledger-goods-detail"><p class="eyebrow">物品小档案</p><h3>${escape(goods.name)}</h3>${fields.length?`<dl>${fields.map(([label,value])=>`<div><dt>${label}</dt><dd>${escape(value)}</dd></div>`).join('')}</dl>`:''}<p class="photo-hint">${goods.reminder?`已开启截止日 ${escape(goods.reminderTime||'09:00')} 提醒 · 需允许通知`:'可在编辑中补充保修、退换日期并开启提醒'}</p></section>`;
}
export function editLedger(item = null, date = dateKey(), returnDay = "") {
  const duplicate=item?.receiptHash && rows.some(row=>row.id!==item.id && row.receiptHash===item.receiptHash);
  const type = item?.type || (filter === "income" ? "income" : "expense"), selectedDate=item?.date||date;
  ui.open(item?.id ? "编辑这笔账" : item?.receiptImport ? "核对截图账单" : "给小日子记一笔", `<form data-form="ledger" data-id="${item?.id || ""}" data-return-day="${returnDay}">${item?.receiptImport ? `<div class="receipt-review"><strong>识别结果，请逐项核对</strong><p>金额、日期、收支方向和分类都可以修改。</p>${item.warnings?.map(w=>`<p>${escape(w)}</p>`).join("")||""}${duplicate?'<p class="receipt-duplicate">这张截图已经记过，可能会重复记账。</p>':""}</div>` : ""}<div class="ledger-type-picker">${["expense","income"].map((value)=>`<label><input type="radio" name="ledgerType" value="${value}" ${type === value ? "checked" : ""}><span>${labels[value]}</span></label>`).join("")}</div><label for="ledger-amount">金额 <small>人民币元</small></label><input class="ledger-amount-input" id="ledger-amount" name="ledgerAmount" inputmode="decimal" autocomplete="off" maxlength="10" placeholder="0.00" value="${item?.cents ? (item.cents / 100).toFixed(2) : ""}" required>
    ${item?.receiptImport && item.candidates?.length>1 ? `<div class="receipt-candidates"><span>截图中的候选金额</span>${item.candidates.map(c=>`<button type="button" data-ledger-receipt-amount="${c.cents}">¥${amountText(c.cents)}</button>`).join("")}</div>`:""}<fieldset class="ledger-category-field"><legend>分类</legend><div class="ledger-category-choices">${choices(type, item?.category)}</div></fieldset><div class="ledger-date-line"><label for="ledger-date">记到这一天</label><input id="ledger-date" name="ledgerDate" type="date" min="1900-01-01" max="9999-12-31" value="${escape(selectedDate)}" required></div>
    <details class="ledger-extra" ${item?.receiptImport?'open':''}><summary>${detailLabel("journal","备注、消费照片与凭证")}<small data-ledger-optional-summary>${optionalSummary(item)}</small></summary><label for="ledger-note">备注 <small>选填</small></label><input id="ledger-note" name="ledgerNote" maxlength="200" placeholder="比如：晚饭买菜、周末的小礼物" value="${escape(item?.note || "")}">${ui.photoFields(5,"ledger")}${item?.receipt ? `<h3 class="ledger-receipt-heading">截图凭证</h3><img class="receipt-preview" src="${escape(item.receipt)}" alt="账单截图凭证"><label class="checkbox"><input type="checkbox" name="keepReceipt" checked>保存截图作为凭证（仅本机）</label>`:""}</details>
    <div class="ledger-expense-only" ${type==='expense'?'':'hidden'}>${worthFields(item)}${goodsFields(item?.goods,selectedDate)}</div>
    <section class="ledger-life-link"><label class="checkbox"><input type="checkbox" name="ledgerToLife" ${item?.entryId?'checked disabled':''}>${item?.entryId?'已关联一件生活小事':'同时加入生活记录'}</label><p class="photo-hint">${item?.entryId?'日期与关联生活同步；照片、正文之后可分别编辑，金额只在账本计算一次。':'勾选后复用本次照片和备注，新建一条生活/美食记录；金额只计算一次。'}</p></section>
    ${item?.receiptImport ? `<label class="checkbox receipt-confirm"><input type="checkbox" name="receiptConfirmed" required>${duplicate?"我已核对，确认仍需再次记录这张截图":"我已核对金额、日期和收支方向"}</label>`:""}<p class="form-error" role="alert"></p><button type="submit" class="primary">保存账单</button></form>`);
  // ui.open first captures the outgoing form's draft, including its OCR context.
  editSeed=item?{...item}:null;
  receiptDraft=item?.receipt||item?.receiptImport?item:null;
  ui.initPhotos(Array.isArray(item?.photos) ? item.photos : []);
  photoCountObserver?.disconnect();
  if(typeof MutationObserver!=='undefined') {
    const form=ui.sheet.querySelector('[data-form="ledger"]'),count=form?.querySelector('.photo-count');
    photoCountObserver=new MutationObserver(()=>{
      if(!form?.isConnected || !ui.sheet.contains(form)) { photoCountObserver?.disconnect();photoCountObserver=null;editSeed=null;receiptDraft=null;return; }
      refreshOptionalSummary(form);
    });
    if(count)photoCountObserver.observe(count,{childList:true,characterData:true,subtree:true});
    // Release the closed form and its image data as soon as the sheet is replaced.
    photoCountObserver.observe(ui.sheet,{childList:true});
  }
  ui.setDraft();
}
export function ledgerChange(input) {
  if(input?.form?.dataset.form==='ledger-period'&&input.name==='periodMode') {
    const custom=input.value==='custom';
    for(const [selector,enabled] of [['[data-period-anchor]',!custom],['[data-period-custom]',custom]]) {
      const fields=input.form.querySelector(selector);fields.hidden=!enabled;fields.disabled=!enabled;
    }
    return true;
  }
  const form=input?.form;if(!form || form.dataset.form!=='ledger')return false;
  if (input.name === "ledgerType") {
    const previous=form.querySelector('.ledger-category-choices input:checked')?.value,category=categories.find(item=>item.id===previous);
    if(category)form.dataset[category.type+'Category']=category.id;
    form.querySelector(".ledger-category-choices").innerHTML = choices(input.value,form.dataset[input.value+'Category']);
    refreshLedgerForm(form);return true;
  }
  if(['goodsEnabled','goodsName','ledgerWorth','eatAgain','ledgerNote','keepReceipt'].includes(input.name)) {
    refreshLedgerForm(form);return true;
  }
  return false;
}
function showLedger(item, returnDay = "") {
  if (!item) return;
  const category = categoryFor(item.category);
  ui.open("账单详情", `<article class="record-detail record-ledger-detail">
    ${returnDay ? `<button type="button" class="day-back text-button" data-day-back="${escape(returnDay)}">‹ 返回当天概览</button>` : ""}
    <div class="ledger-detail ledger-detail-summary"><span class="ledger-category-icon ${item.type}" aria-hidden="true">${categoryIcon(category)}</span><p>${escape(category.name)} · ${labels[item.type]}</p><strong class="ledger-amount ${item.type}">${signed(item)}</strong><small>${escape(item.date)}</small></div>
    <div class="record-detail-body">
      ${item.note ? `<section class="record-detail-section record-detail-note"><h3>这笔账的小记</h3><p class="detail-text">${escape(item.note)}</p></section>` : ""}
      ${ledgerPhotosMarkup(item,returnDay)}
    </div>
    ${worthDetail(item,returnDay)}${goodsDetail(item)}
    ${item.entryId||item.receipt?`<div class="record-secondary-actions" aria-label="相关记录">
      ${item.entryId?`<button type="button" data-ledger-entry="${escape(item.id)}" data-return-day="${escape(returnDay)}">${icon("journal")}<span>关联生活记录</span></button>`:""}
      ${item.receipt?`<button type="button" data-ledger-receipt-view="${escape(item.id)}" data-return-day="${escape(returnDay)}">${icon("shield")}<span>截图凭证</span></button>`:""}
    </div>`:""}
    <footer class="record-management" aria-label="管理账单"><button type="button" class="text-button" data-ledger-edit="${escape(item.id)}" data-return-day="${escape(returnDay)}">${icon("draft")}<span>编辑账单</span></button><button type="button" class="text-button danger" data-ledger-delete="${escape(item.id)}" data-return-day="${escape(returnDay)}">${icon("trash")}<span>删除</span></button></footer>
  </article>`);
  ui.sheet.dataset.view = "ledger-detail"; ui.sheet.dataset.returnDay = returnDay; ui.sheet.dataset.ledgerId=item.id;
}
function ledgerPhotosMarkup(item, returnDay = "") {
  const photos = Array.isArray(item.photos) ? item.photos : [];
  return photos.length ? `<section class="ledger-photos"><div class="photo-heading"><h3>消费照片</h3><span>${photos.length} 张</span></div><div class="ledger-photo-grid">${photos.map((photo,index)=>`<button type="button" data-ledger-photo="${item.id}" data-ledger-photo-index="${index}" data-return-day="${returnDay}" aria-label="查看消费照片 ${index+1}">${ui.imageMarkup(photo,"ledger-detail-photo",`消费照片 ${index+1}`)}</button>`).join("")}</div><p class="photo-hint">吃过的美味、买到的喜欢 · 点照片看大图</p></section>` : "";
}
function showLedgerPhoto(item, index = 0, returnDay = "") {
  if (!item?.photos?.length) return;
  index = Math.max(0,Math.min(item.photos.length-1,Number.isFinite(index) ? Math.floor(index) : 0));
  if(ui.showPhotos){ui.showPhotos({photos:item.photos,index,title:item.note||categoryFor(item.category).name});return;}
  ui.open(`消费照片 ${index+1} / ${item.photos.length}`, `<button type="button" class="day-back text-button" data-ledger-id="${item.id}" data-return-day="${returnDay}">‹ 返回账单详情</button><p class="photo-view-title">${escape(item.note || categoryFor(item.category).name)}</p><div class="photo-viewer">${ui.imageMarkup(item.photos[index],"photo-full",`消费照片 ${index+1}`)}</div><div class="photo-controls"><button type="button" class="secondary" data-ledger-photo="${item.id}" data-ledger-photo-index="${index-1}" data-return-day="${returnDay}" ${index===0?"disabled":""}>‹ 上一张</button><span>${index+1} / ${item.photos.length}</span><button type="button" class="secondary" data-ledger-photo="${item.id}" data-ledger-photo-index="${index+1}" data-return-day="${returnDay}" ${index===item.photos.length-1?"disabled":""}>下一张 ›</button></div>`);
  ui.sheet.dataset.view="ledger-photo"; ui.sheet.dataset.ledgerId=item.id; ui.sheet.dataset.returnDay=returnDay;
}
export function ledgerBack() {
  if (!["ledger-photo","ledger-receipt"].includes(ui?.sheet.dataset.view)) return false;
  showLedger(rows.find(item=>item.id===ui.sheet.dataset.ledgerId),ui.sheet.dataset.returnDay);
  return true;
}
function showCategories() {
  ui.open("整理记账分类", `<p class="mood-rule">支出、收入分别分类。修改名称后，已有账单也会同步显示新名称。</p>${["expense","income"].map(type=>`<div class="section-title"><h3>${labels[type]}分类</h3><button type="button" class="text-button" data-ledger-new-category="${type}">${icon('plus')}添加分类</button></div><div class="ledger-category-list">${categories.filter(item=>item.type === type).map(item=>`<button type="button" data-ledger-category="${item.id}"><span>${categoryIcon(item)} ${escape(item.name)}</span><small>编辑 ›</small></button>`).join("")}</div>`).join("")}`);
}
function editCategory(item, type) {
  ui.open(item ? "编辑分类" : "添加分类", `<form data-form="ledger-category" data-id="${item?.id || ""}" data-type="${item?.type || type}"><p class="detail-meta">${labels[item?.type || type]}分类</p><label for="ledger-category-name">分类名称</label><input id="ledger-category-name" name="categoryName" value="${escape(item?.name || "")}" maxlength="8" placeholder="比如：旅行、宠物" required><p class="photo-hint">最多 8 个字，同一类型下不重复。</p><p class="form-error" role="alert"></p><button type="submit" class="primary">保存分类</button></form>`);
  ui.setDraft();
}
export async function submitLedger(form) {
  const values = new FormData(form);
  if(form.dataset.form==='ledger-period') {
    const next=ledgerPeriod(values.get('periodMode'),values.get('periodAnchor'),{start:values.get('periodStart'),end:values.get('periodEnd')});
    applyPeriod(next);ui.close();renderLedgerFocus('[data-ledger-action="period-picker"]');ui.announce('统计日期已更新');return;
  }
  if (form.dataset.form === "ledger-budget") {
    const value=String(values.get("budgetAmount") || "").trim(), next={...budgets};
    if(value) next[selectedMonth]=parseAmount(value); else delete next[selectedMonth];
    await saveLedgerBudgets(next); budgets=next; const cleared=await finishDraft(form); ui.close(); ui.render(); ui.announce(cleared?(value?"这个月的小预算，记好啦":"已关闭这个月的预算"):"预算已保存；草稿清理未完成"); return;
  }
  if (form.dataset.form === "ledger-category") {
    const name = String(values.get("categoryName") || "").trim(), type = form.dataset.type;
    if(!['expense','income'].includes(type))throw new Error('请选择正确的收支类型');
    if (!name || name.length > 8) throw new Error("分类名称请填写 1–8 个字");
    if (categories.some(item=>item.type === type && item.name === name && item.id !== form.dataset.id)) throw new Error("这个分类已经有啦，换个名字吧");
    const old = categories.find(item=>item.id === form.dataset.id), category = {id:old?.id || id(),type,name,icon:old?.icon || "◇"};
    await saveItem("ledgerCategories", category); categories = [...categories.filter(item=>item.id !== category.id),category];
    form.dataset.id=category.id;const cleared=await finishDraft(form);
    ui.render(); showCategories(); ui.announce(cleared?"分类已保存":"分类已保存；草稿清理未完成"); return;
  }
  const cents = parseAmount(values.get("ledgerAmount")), type = values.get("ledgerType"), category = values.get("ledgerCategory"), date = values.get("ledgerDate");
  if (!["expense","income"].includes(type) || !categories.some(item=>item.id === category && item.type === type)) throw new Error("请选择正确的收支分类");
  if (!validLedgerDate(date)) throw new Error("请填写正确的记账日期");
  if(receiptDraft?.receiptImport && !values.has("receiptConfirmed"))throw new Error("请核对识别结果后再保存");
  const photos = ui.getPhotos();
  if (photos.length > 5) throw new Error("每笔账单最多添加 5 张消费照片");
  const old = rows.find(item=>item.id === form.dataset.id);
  if(form.dataset.id&&!old)throw new Error('原账单已移入最近删除，或已被清除。请先恢复原账单再继续编辑');
  const goods=type==='expense'?normalizeGoods({name:values.get('goodsName'),model:values.get('goodsModel'),purchaseDate:values.get('goodsPurchase'),warrantyDate:values.get('goodsWarranty'),returnDate:values.get('goodsReturn'),reminder:values.has('goodsReminder'),reminderTime:values.get('goodsReminderTime')},values.has('goodsEnabled')):null;
  const worth=type==='expense'&&worthLabels[values.get('ledgerWorth')]?values.get('ledgerWorth'):'';
  const item = {...old,id:old?.id || id(),type,category,date,cents,photos,note:String(values.get("ledgerNote") || "").trim(),created:old?.created || Date.now(),receipt:values.has("keepReceipt")?receiptDraft?.receipt||"":"",receiptHash:receiptDraft?.receiptHash||old?.receiptHash||"",worth,eatAgain:type==='expense'&&values.has('eatAgain'),goods};
  const writes=[{store:'ledger',key:item.id,value:item}];
  if(old?.entryId || values.has('ledgerToLife')) {
    const entries=await loadAll('entries'), linked=old?.entryId?entries.find(entry=>entry.id===old.entryId):null;
    if(linked || !old?.entryId) {
      const entry=entryFromLedger(item,linked,linked?.id||id(),categoryFor(category).name);item.entryId=entry.id;
      writes.push({store:'entries',key:entry.id,value:entry});
    }
  }
  await saveItemsAtomically(writes); rows = [...rows.filter(row=>row.id !== item.id), item];
  if(date<period.start||date>period.end)applyPeriod(ledgerPeriod(period.mode==='custom'?'month':period.mode,date));
  selectedMonth=period.anchor.slice(0,7);section = "records";
  // The commit succeeded. Even if a downstream refresh fails, retrying this form edits
  // the saved record instead of creating a second bill and a second journal entry.
  form.dataset.id=item.id;editSeed={...item};receiptDraft=item.receipt?item:null;
  const draftCleared=await finishDraft(form);
  const refreshed=await recordsChanged();
  if (filter !== "all" && filter !== type) filter = "all";
  if(categoryFilter && categoryFilter!==category)categoryFilter='';
  ui.close();
  ui.render();
  const returnDay=form.dataset.returnDay?date:'';
  if(returnDay)ui.showDay(returnDay);
  showLedger(item,returnDay);
  ui.announce(!draftCleared?"账单已保存；草稿清理未完成，可在我的草稿中删除":refreshed?"这笔账，熊熊记好啦":"账单已保存；关联页面或提醒稍后重新打开时刷新");
}
export async function ledgerClick(data) {
  if(data.ledgerPeriod) {
    if(!Object.prototype.hasOwnProperty.call(periodModes,data.ledgerPeriod))return true;
    if(data.ledgerPeriod==='custom')openPeriodPicker('custom');
    else {applyPeriod(ledgerPeriod(data.ledgerPeriod,period.anchor));renderLedgerFocus(`[data-ledger-period="${data.ledgerPeriod}"]`);}
    return true;
  }
  if(data.ledgerTrendStart&&data.ledgerTrendEnd) {
    applyPeriod(ledgerPeriod('custom',data.ledgerTrendStart,{start:data.ledgerTrendStart,end:data.ledgerTrendEnd}));
    filter=analysisType;section='records';renderLedgerFocus('[data-ledger-action="period-picker"]');return true;
  }
  if(data.ledgerEntry) {
    const bill=rows.find(row=>row.id===data.ledgerEntry),entry=bill?.entryId?(await loadAll('entries')).find(row=>row.id===bill.entryId):null;
    if(!entry)ui.announce('关联生活记录已在最近删除中，恢复后可继续查看');else if(ui.openEntry)ui.openEntry(entry.id,data.returnDay||'');
    return true;
  }
  if(data.ledgerWorthFilter) {worthFilter=data.ledgerWorthFilter;section='review';ui.render();return true;}
  if(data.ledgerWorthSet!==undefined) {
    const row=rows.find(item=>item.id===data.ledgerWorthId);if(!row||row.type!=='expense')return true;
    const next={...row,worth:worthLabels[data.ledgerWorthSet]?data.ledgerWorthSet:''};await saveItem('ledger',next);rows=rows.map(item=>item.id===next.id?next:item);await recordsChanged();ui.render();
    const panel=ui.sheet.dataset.view==='ledger-detail'&&ui.sheet.dataset.ledgerId===next.id?ui.sheet.querySelector?.('.ledger-worth-detail'):null;
    if(panel)panel.outerHTML=worthDetail(next,data.returnDay||'');else showLedger(next,data.returnDay||'');
    ui.announce('已记下你的消费感受');return true;
  }
  if (data.ledgerReceiptAmount) { const amount=ui.sheet.querySelector('[name="ledgerAmount"]'),cents=Number(data.ledgerReceiptAmount);if(amount&&Number.isSafeInteger(cents)&&cents>0) { amount.value=(cents/100).toFixed(2);amount.dispatchEvent(new Event('input',{bubbles:true})); } return true; }
  if (data.ledgerPhoto) { showLedgerPhoto(rows.find(item=>item.id===data.ledgerPhoto),Number(data.ledgerPhotoIndex),data.returnDay||""); return true; }
  if (data.ledgerReceiptView) {
    const row=rows.find(item=>item.id===data.ledgerReceiptView),returnDay=data.returnDay||"";
    if(row?.receipt){
      ui.open("账单截图凭证",`<button type="button" class="day-back text-button" data-ledger-id="${row.id}" data-return-day="${returnDay}">‹ 返回账单详情</button><img class="receipt-full" src="${escape(row.receipt)}" alt="保存的账单截图"><p class="photo-hint">凭证保存在本机，普通日期分享不会附上这张截图。</p>`);
      ui.sheet.dataset.view="ledger-receipt";ui.sheet.dataset.ledgerId=row.id;ui.sheet.dataset.returnDay=returnDay;
    }return true;
  }
  if (data.ledgerDrill&&['income','expense'].includes(data.ledgerDrillType)) { categoryFilter=data.ledgerDrill; filter=data.ledgerDrillType; section="records"; renderLedgerFocus('.ledger-filter-tag');return true; }
  if (data.ledgerTrendDay) { ui.showDay(data.ledgerTrendDay); return true; }
  if (data.ledgerId) { showLedger(rows.find(item=>item.id === data.ledgerId), data.returnDay); return true; }
  if (data.ledgerEdit) { const item=rows.find(item=>item.id===data.ledgerEdit);if(item)editLedger(item,dateKey(),data.returnDay);else ui.announce('这笔账单已移到最近删除，或暂时不存在');return true; }
  if (data.ledgerDelete) {
    const item = rows.find(row=>row.id === data.ledgerDelete);
    if(!item){ui.announce('这笔账单已移到最近删除，或暂时不存在');return true;}
    ui.open("删除这笔账？", `<p class="detail-meta">${escape(categoryFor(item.category).name)} · ${signed(item)}<br>移入最近删除后不计入收支，可在 30 天内恢复。${item.entryId?"关联的生活记录会保留。":""}</p><div class="sheet-actions"><button type="button" class="secondary" data-ledger-id="${item.id}" data-return-day="${data.returnDay || ""}">取消</button><button type="button" class="primary destructive" data-ledger-remove="${item.id}" data-return-day="${data.returnDay || ""}">确认删除</button></div>`); return true;
  }
  if (data.ledgerRemove) { await removeItem("ledger",data.ledgerRemove); rows=rows.filter(row=>row.id !== data.ledgerRemove); await recordsChanged(); ui.close(); ui.render(); if(data.returnDay) ui.showDay(data.returnDay); ui.announce("账单已移入最近删除，统计已更新");ui.onDeleted?.({store:'ledger',id:data.ledgerRemove}); return true; }
  if (data.ledgerCategory) { editCategory(categories.find(item=>item.id === data.ledgerCategory)); return true; }
  if (data.ledgerNewCategory) { editCategory(null, data.ledgerNewCategory); return true; }
  if (data.ledgerSection) { section = data.ledgerSection; ui.render(); return true; }
  if (data.ledgerFilter) { categoryFilter=""; filter = data.ledgerFilter; ui.render(); return true; }
  if (data.ledgerAnalysis) { analysisType = data.ledgerAnalysis; ui.render(); return true; }
  if (!data.ledgerAction) return false;
  if(data.ledgerAction==='period-picker'){openPeriodPicker();return true;}
  if (data.ledgerAction === "receipt") { ui.openReceipt(); return true; }
  if (data.ledgerAction === "budget") { editBudget(); return true; }
  if (data.ledgerAction === "clear-category") { categoryFilter=""; ui.render(); return true; }
  if (data.ledgerAction === "add") editLedger(null, data.ledgerDate || (dateKey()>=period.start&&dateKey()<=period.end ? dateKey() : period.start), data.returnDay);
  else if (data.ledgerAction === "categories") showCategories();
  else if(['prev','next','today'].includes(data.ledgerAction)) {
    const next=data.ledgerAction==='today'?ledgerPeriod(period.mode==='custom'?'month':period.mode,dateKey()):shiftLedgerPeriod(period,data.ledgerAction==='prev'?-1:1);
    if(next){applyPeriod(next);renderLedgerFocus(`[data-ledger-action="${data.ledgerAction}"]`);}
  }
  return true;
}
