// Native gallery uses the current form's remaining capacity. Browser keeps its regular picker.
export function pickImage(input,limit=1){
  if(!input)return false;
  const capacity=Math.max(0,Math.min(5,Math.floor(Number(limit)||0)));
  if(!capacity)return false;
  try{window.BearApp?.setImagePickLimit(capacity);}catch{}
  input.click();return true;
}
