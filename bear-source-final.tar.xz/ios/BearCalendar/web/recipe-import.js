import {pickImage} from './image-picker.js?v=36';
import {loadOcrLibrary,prepareOcrImage} from './receipt.js?v=36';
import {parseRecipeImage} from './recipe-import-core.js?v=36';
import {bearArt} from './illustrations.js?v=36';
let ui,active=null;
export function initRecipeImport(callbacks){ui=callbacks;}
export function openRecipeImport(){
 ui.open('图片录入菜谱',`<div class="receipt-intro">${bearArt('kitchen','recipe-import','',10)}<h3>把好吃的，收进菜谱</h3><p>选一张菜谱截图，熊熊帮你整理菜名、食材和做法。</p></div><input id="recipe-image-file" type="file" accept="image/*" hidden><button type="button" class="primary" data-recipe-import="choose">选择菜谱图片</button><p class="photo-hint">一次识别一张图片，仅在本机处理。选择文字清晰的截图更容易识别，核对后再保存；封面可以另选。</p><p class="form-error recipe-import-error" role="alert"></p>`);ui.sheet.dataset.view='recipe-import';
}
export async function recipeImportClicked(data){
 if(!data.recipeImport)return false;
 if(data.recipeImport==='open')openRecipeImport();
 if(data.recipeImport==='choose')pickImage(ui.sheet.querySelector('#recipe-image-file'));
 if(data.recipeImport==='cancel'){cancelRecipeImport();openRecipeImport();}
 return true;
}
export function cancelRecipeImport(){if(!active)return;active.cancelled=true;active.rejectCancel?.(new Error('cancelled'));active.worker?.terminate().catch(()=>{});active=null;}
export async function recipeImageChanged(input){
 const file=input.files?.[0];if(!file)return;
 const job={cancelled:false,worker:null,timer:null,rejectCancel:null};cancelRecipeImport();active=job;
 ui.open('熊熊正在读菜谱','<p class="recipe-import-progress" role="status">正在整理图片…</p><progress class="receipt-progress" max="100" value="0" aria-label="菜谱识别进度"></progress><p class="photo-hint">识别在手机本地进行，完成后可以修改菜名、食材和做法。</p><button type="button" class="secondary" data-recipe-import="cancel">取消识别</button>');ui.sheet.dataset.view='recipe-import-progress';
 let image,raw='',failed=false;
 try{
  image=await prepareOcrImage(file);if(job.cancelled)return;
  await loadOcrLibrary();if(job.cancelled)return;
  const base=new URL('ocr/',location.href).href;
  const work=(async()=>{
   const worker=await window.Tesseract.createWorker('chi_sim+eng',1,{workerPath:base+'worker.min.js',corePath:base,langPath:base,workerBlobURL:false,cacheMethod:'none',gzip:true,legacyCore:false,legacyLang:false,logger:message=>{if(job.cancelled)return;const text=ui.sheet.querySelector('.recipe-import-progress'),bar=ui.sheet.querySelector('progress');if(text)text.textContent=message.status==='recognizing text'?'正在识别菜谱文字…':'正在准备本机识别…';if(bar)bar.value=message.status==='recognizing text'?20+(message.progress||0)*80:10;}});
   job.worker=worker;if(job.cancelled||job.abandoned){await worker.terminate();return '';}
   await worker.setParameters({tessedit_pageseg_mode:'6',preserve_interword_spaces:'1'});
   const result=await worker.recognize(image.photo);return result.data.text;
  })();
  raw=await Promise.race([work,new Promise((_,reject)=>{job.rejectCancel=reject;job.timer=setTimeout(()=>reject(new Error('识别超时')),90000);})]);
 }catch(error){failed=true;if(!image&&!job.cancelled){openRecipeImport();ui.sheet.querySelector('.recipe-import-error').textContent=error.message;return;}}
 finally{job.abandoned=true;clearTimeout(job.timer);if(job.worker)await job.worker.terminate().catch(()=>{});if(active===job)active=null;}
 if(job.cancelled||!ui.sheet.open||ui.sheet.dataset.view!=='recipe-import-progress')return;
 const parsed=parseRecipeImage(raw);if(failed||!raw.trim())parsed.warnings.unshift('未能读清图片，请对照原图手动填写。');
 ui.edit(parsed,{photo:image.photo,raw:parsed.raw,warnings:parsed.warnings});
}
