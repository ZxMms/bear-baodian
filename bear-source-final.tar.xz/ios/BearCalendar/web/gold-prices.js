import {parseGoldQuote,parseGoldHistory,parseGoldBrands,goldPeriod,chinaDay,quoteTime,goldSources} from './gold-prices-core.js?v=38';
import {icon} from './icons.js?v=38';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=p=>p==null?'—':p.toFixed(2),signed=p=>(p>0?'+':'')+p.toFixed(2);
let ui,tab='quote',days=30,brandType='jewelry',pointDate='',generation=0,serial=0;
const state={},pending=new Map(),parsers={quote:parseGoldQuote,history:parseGoldHistory,brands:parseGoldBrands};
export function initGoldPrices(callbacks){ui=callbacks;window.bearGoldResult=(id,response)=>{
  const job=pending.get(String(id));if(!job)return;pending.delete(String(id));clearTimeout(job.timer);
  if(job.generation!==generation)return;
  try{const r=typeof response==='string'?JSON.parse(response):response;if(!r?.ok)throw new Error(r?.error||'连接暂时没有成功，请重试');state[job.kind]={data:parsers[job.kind](r.body),loading:false};}
  catch(error){state[job.kind]={error:error.message||'报价解析失败，请重试',loading:false};}
  paint();
};}
export function goldPricesEntry(){return `<button type="button" class="gold-entry market-entry" data-market-action="open"><span class="gold-emblem" aria-hidden="true">${icon('ledger')}</span><span class="gold-entry-copy"><strong>金价</strong><small>今日行情 · 品牌金价 · 金价趋势</small></span><span class="gold-entry-arrow" aria-hidden="true">›</span></button>`;}
export function refreshGoldPricesView(){if(ui?.sheet.dataset.view==='gold-prices')paint();}
function open(){tab='quote';pointDate='';ui.open('金价',`<div class="market-shell"><div class="market-top"><span>每一克，心里有数</span><button type="button" class="text-button" data-market-action="refresh">刷新报价</button></div><div class="market-tabs" role="group" aria-label="金价视图">${[['quote','今日金价'],['brands','品牌金价'],['history','金价趋势']].map(([key,label])=>`<button type="button" data-market-action="tab" data-market-tab="${key}" aria-pressed="${key===tab}">${label}</button>`).join('')}</div><div id="market-content"></div><button type="button" class="market-goals" data-gold-action="list"><span>我的买金小目标<small>记下购入，慢慢攒成小金库</small></span><b>›</b></button></div>`);ui.sheet.dataset.view='gold-prices';refresh();}
function refresh(){
  generation++;for(const job of pending.values())clearTimeout(job.timer);pending.clear();window.BearGold?.cancel?.();
  for(const kind of Object.keys(parsers)){
    state[kind]={loading:true};
    if(!window.BearGold?.request){state[kind]={error:'请在新版手机 App 中查看金价。',loading:false};continue;}
    const id=String(++serial),job={kind,generation,timer:setTimeout(()=>window.bearGoldResult(id,{ok:false,error:'连接超时，点刷新报价再试一次'}),16000)};pending.set(id,job);
    try{window.BearGold.request(id,kind);}catch{window.bearGoldResult(id,{ok:false,error:'连接暂时没有成功，请重试'});}
  }paint();
}
const source=(key)=>`<button type="button" class="market-source text-button" data-market-action="source" data-market-source="${key}">来源：${key==='brands'?'上海有色网 SMM':'京东金融 · 上金所 Au99.99'} ↗</button>`;
function quoteMarkup(q){const old=q.date!==chinaDay();return `<section class="market-hero"><div class="market-kicker"><span>上金所 Au99.99</span><span class="market-date-badge">${old?'最近交易报价':'今日最新报价'}</span></div><p class="market-label">黄金 9999 · 基础金价</p><div class="market-price">${money(q.price)}<small>元 / 克</small></div>${q.change===null?'':`<p class="market-change ${q.change>0?'market-rise':q.change<0?'market-fall':''}">较昨收 ${signed(q.change)} <span>(${signed(q.percent)}%)</span></p>`}<p class="market-timestamp">报价时间 ${quoteTime(q.time)}</p>${old?'<p class="market-old">尚无今天报价，以上为来源最近一次行情。</p>':''}</section><div class="market-metrics">${[['今日开盘',q.open],['日内最高',q.high],['日内最低',q.low],['昨日收盘',q.previous]].map(([label,value])=>`<div><span>${label}</span><b>${money(value)}</b></div>`).join('')}</div><button type="button" class="market-inline" data-market-action="tab" data-market-tab="history">看看最近的走势 <span>↗</span></button><p class="market-note">基础金价与金店首饰价口径不同。行情可能延迟，实际成交以对应交易渠道为准。</p>${source('quote')}`;}
function brandsMarkup(rows){const today=chinaDay(),shown=rows.filter(r=>r.type===brandType);return `<div class="market-section-heading"><h3>金店参考报价</h3><span>人民币 / 克</span></div><div class="market-filters" role="group" aria-label="品牌报价类型">${[['jewelry','黄金首饰'],['bar','黄金金条']].map(([key,label])=>`<button type="button" data-market-action="brand-type" data-market-type="${key}" aria-pressed="${brandType===key}">${label}</button>`).join('')}</div><p class="market-note">各行保留产品名称与报价日期；工费、门店活动和具体成色以门店为准。</p><div class="market-brands">${shown.map(r=>`<article class="market-brand"><div><strong>${esc(r.brand)}</strong><small>${esc(r.product)}</small><time datetime="${r.date}" class="${r.date===today?'':'market-old'}">${r.date}${r.date===today?' · 今日':' · 旧报价'}</time></div><b>${money(r.price)}</b></article>`).join('')||'<p class="market-note">来源暂未提供此类报价。</p>'}</div>${source('brands')}`;}
function historyMarkup(all){const points=goldPeriod(all,days),selected=points.find(p=>p.date===pointDate)||points.at(-1);let graph='';
  if(points.length>1){const values=points.map(p=>p.price),min=Math.min(...values),max=Math.max(...values),pad=Math.max((max-min)*.12,1),low=min-pad,high=max+pad;
    const first=Date.parse(points[0].date),last=Date.parse(points.at(-1).date),x=p=>14+(Date.parse(p.date)-first)/(last-first)*300,y=p=>18+(high-p.price)/(high-low)*130;
    const path=points.map((p,i)=>(i?'L':'M')+x(p).toFixed(2)+','+y(p).toFixed(2)).join(' ');
    graph=`<svg viewBox="0 0 328 178" role="img" aria-label="上金所 Au99.99 近 ${days} 日价格趋势，单位元每克"><path d="M14 18H314 M14 83H314 M14 148H314" class="market-grid"/><path d="${path}" class="market-line"/><circle cx="${x(selected)}" cy="${y(selected)}" r="4" class="market-dot"/><text x="14" y="173">${points[0].date.slice(5)}</text><text x="314" y="173" text-anchor="end">${points.at(-1).date.slice(5)}</text></svg><div class="market-range"><span>区间最低 ${money(min)}</span><span>区间最高 ${money(max)}</span></div>`;
  }else graph=`<p class="market-empty">${points.length?'这段时间只有一个报价点，暂不连线。':'这段时间暂无交易数据，可切换更长时间范围。'}</p>`;
  return `<div class="market-section-heading"><h3>Au99.99 价格走势</h3><span>元 / 克</span></div><div class="market-filters" role="group" aria-label="趋势时间范围">${[7,30,90].map(n=>`<button type="button" data-market-action="period" data-market-days="${n}" aria-pressed="${days===n}">近 ${n} 日</button>`).join('')}</div>${selected?`<div class="market-selected"><strong>${money(selected.price)}</strong><span>${selected.date} · ${selected.date===chinaDay()?'当日截至查询时':'日线收盘'}</span></div>`:''}<div class="market-chart">${graph}</div>${points.length?`<label class="market-point-label" for="market-point">查看某个交易日</label><select id="market-point" aria-label="查看某个交易日">${[...points].reverse().map(p=>`<option value="${p.date}" ${p.date===selected.date?'selected':''}>${p.date} · ${money(p.price)} 元 / 克</option>`).join('')}</select>`:''}<p class="market-note">仅连接有报价的交易日。今天的数据可能继续变动，不是最终收盘价；趋势不代表品牌首饰价格。</p>${source('quote')}`;
}
function paint(){if(!ui?.sheet.open||ui.sheet.dataset.view!=='gold-prices')return;
  const content=ui.sheet.querySelector('#market-content');if(!content)return;
  ui.sheet.querySelectorAll('[data-market-tab]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.marketTab===tab)));
  const loading=Object.values(state).some(s=>s.loading),refresh=ui.sheet.querySelector('[data-market-action="refresh"]');refresh.disabled=loading;refresh.textContent=loading?'正在查询…':'刷新报价';
  const current=state[tab];content.setAttribute('aria-busy',String(!!current?.loading));
  content.innerHTML=current?.loading?'<div class="market-loading" role="status"><span class="market-skeleton"></span><strong>正在查询最新报价</strong><p>联网读取来源数据，请稍候</p></div>':current?.error?`<div class="market-empty" role="status"><strong>暂时没能取到${tab==='brands'?'品牌报价':tab==='history'?'趋势数据':'金价'}</strong><p>${esc(current.error)}</p><button type="button" class="secondary" data-market-action="refresh" ${loading?'disabled':''}>重新查询</button></div>${source(tab==='brands'?'brands':'quote')}`:current?.data?(tab==='quote'?quoteMarkup(current.data):tab==='brands'?brandsMarkup(current.data):historyMarkup(current.data)):'';
  const select=content.querySelector('#market-point');if(select)select.addEventListener('change',()=>{pointDate=select.value;paint();ui.sheet.querySelector('#market-point')?.focus({preventScroll:true});});
}
export function goldPricesClicked(data){if(!data.marketAction)return false;
  switch(data.marketAction){case 'open':open();break;case 'refresh':if(!Object.values(state).some(s=>s.loading))refresh();break;case 'tab':if(Object.hasOwn(parsers,data.marketTab)){tab=data.marketTab;paint();}break;case 'period':if([7,30,90].includes(Number(data.marketDays))){days=Number(data.marketDays);pointDate='';paint();}break;case 'brand-type':if(['jewelry','bar'].includes(data.marketType)){brandType=data.marketType;paint();}break;case 'source':{const url=goldSources[data.marketSource];if(url){if(window.BearApp?.openRecipeLink){if(!window.BearApp.openRecipeLink(url))ui.announce('暂时无法打开来源网页');}else window.open(url,'_blank','noopener,noreferrer');}break;}}
  return true;
}
