import {getAudioProfile, saveAudioProfile, setSound} from './model.js?v=36';
let profile={volume:0.45,clips:{}},draft,ui,player=null,stopTimer=null;
const sounds={tap:{label:'啊哒哒 · 轻点',hint:'轻点时的一小声回应',file:'tap.wav',length:0.68},saved:{label:'啊哒哒 · 收好啦',hint:'保存成功的小欢呼',file:'saved.wav',length:1.66},recommend:{label:'啊哒哒 · 换一道',hint:'给今天换一点新鲜感',file:'recommend.wav',length:0.92}};
const volume=value=>Math.max(0,Math.min(1,Number.isFinite(Number(value))?Number(value):0.45));
export async function initAudio(callbacks){ui=callbacks;profile=await getAudioProfile()||profile;profile.volume=volume(profile.volume);}
export function stopAudio(){clearTimeout(stopTimer);if(player){player.pause();player.src='';player=null;}try{window.BearCalendarAudio?.stop();}catch{}}
async function playBuiltin(name,level){
  const clip=sounds[name];if(!clip||document.hidden)return false;
  stopAudio();level=volume(level);
  try{if(window.BearCalendarAudio?.playAtVolume(name,level))return true;}catch{}
  const audio=new Audio('assets/'+clip.file);player=audio;audio.volume=level;
  try{await audio.play();if(player===audio)stopTimer=setTimeout(stopAudio,clip.length*1000+100);return true;}catch{if(player===audio)stopAudio();return false;}
}
export function playEffect(name){if(ui.enabled())void playBuiltin(name,profile.volume);}
export function openAudioSettings(){draft={...profile,enabled:ui.enabled()};renderSettings();}
function renderSettings(){
  ui.open('熊熊音效',`<div class="audio-intro"><span aria-hidden="true">♪</span><h3>轻一点，也听得见欢喜</h3><p>声音随 App 自带，随时可以试听。</p></div><form data-form="audio-settings"><label class="checkbox"><input type="checkbox" name="audioEnabled" ${draft.enabled?'checked':''}>开启界面音效</label><div class="audio-volume-label"><label for="audio-volume">音量</label><output id="audio-volume-value">${Math.round(draft.volume*100)}%</output></div><input type="range" id="audio-volume" name="audioVolume" min="0" max="100" step="5" value="${Math.round(draft.volume*100)}" aria-describedby="audio-volume-value"><div class="audio-slots">${Object.entries(sounds).map(([key,clip])=>`<section class="audio-slot audio-builtin"><div><h3>${clip.label}</h3><p>${clip.hint}</p></div><button type="button" class="secondary" data-audio-preview="${key}" aria-label="试听${clip.label}">试听 ♪</button></section>`).join('')}</div><p class="photo-hint">内置「啊哒哒」短音效，无需导入。试听不受上方开关限制；日常操作遵循开关。通知声音在系统通知设置里调整。</p><p class="form-error" role="alert"></p><button type="submit" class="primary">保存音效设置</button></form>`);
  ui.sheet.dataset.view='audio-settings';ui.setDraft();
}
function readDraft(){const form=ui.sheet.querySelector('[data-form="audio-settings"]');if(form){draft.enabled=form.elements.audioEnabled.checked;draft.volume=volume(Number(form.elements.audioVolume.value)/100);}}
export async function audioClicked(data){
  if(!data.audioPreview)return false;readDraft();
  if(draft.volume===0){ui.announce('当前音量为 0，请把音量调高一点再试听');return true;}
  if(await playBuiltin(data.audioPreview,draft.volume))ui.announce('正在试听：'+sounds[data.audioPreview].label);else ui.announce('暂时无法播放，请重新打开 App 后试听');
  return true;
}
export async function submitAudio(){
  readDraft();
  // Retain historical attachments for migration/backup, but the UI needs no audio import.
  await saveAudioProfile(draft);await setSound(draft.enabled);profile={...draft};ui.setEnabled(draft.enabled);ui.close();ui.refresh();ui.announce('音效设置已保存');
  if(draft.enabled)playEffect('saved');
}
export function audioHasChanges(){if(ui.sheet.dataset.view!=='audio-settings')return false;readDraft();return draft.volume!==profile.volume||draft.enabled!==ui.enabled();}
document.addEventListener('input',event=>{if(event.target.id==='audio-volume'){const output=document.querySelector('#audio-volume-value');if(output)output.textContent=event.target.value+'%';}});
document.addEventListener('visibilitychange',()=>{if(document.hidden)stopAudio();});
