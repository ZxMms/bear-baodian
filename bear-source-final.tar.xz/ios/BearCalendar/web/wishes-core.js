export const WISHES_KEY = 'feature:wishes';
export const MAX_CENTS = 9999999999;
const copy = value => JSON.parse(JSON.stringify(value));
const text = (value, limit) => String(value ?? '').trim().slice(0, limit);
const validCents = value => Number.isSafeInteger(value) && value > 0 && value <= MAX_CENTS;
const focusNumber = value => Number.isFinite(Number(value ?? 50)) ? Math.max(0,Math.min(100,Number(value ?? 50))) : 50;
const focus = value => ({x:focusNumber(value?.x),y:focusNumber(value?.y)});
export function wishDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value || '') || value < '1900-01-01') return false;
  const [year, month, day] = value.split('-').map(Number), date = new Date(year, month - 1, day, 12);
  return date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day;
}
export function wishCents(value) {
  const input = String(value ?? '').trim();
  if (!/^(?:0|[1-9]\d{0,7})(?:\.\d{1,2})?$/.test(input)) throw new Error('金额请填写正数，最多两位小数');
  const [whole, fraction = ''] = input.split('.'), cents = Number(whole) * 100 + Number(fraction.padEnd(2, '0'));
  if (!validCents(cents)) throw new Error('金额需大于 0，且不超过 99,999,999.99 元');
  return cents;
}
export function wishMoney(cents) {
  const safe = Number.isSafeInteger(cents) ? cents : 0;
  return `${Math.floor(safe / 100).toLocaleString('zh-CN')}.${String(safe % 100).padStart(2, '0')}`;
}
export function wishProgress(wish) {
  const saved = (wish?.contributions || []).filter(row => !row.removedAt).reduce((sum, row) => sum + row.cents, 0);
  const target = wish?.targetCents || 0;
  return { saved, target, remaining: Math.max(0, target - saved), extra: Math.max(0, saved - target), percent: target ? Math.min(100, saved / target * 100) : 0, ready: target > 0 && saved >= target };
}
export function normalizeWishes(value) {
  const seen = new Set(), source = Array.isArray(value?.wishes) ? value.wishes : [];
  const wishes = source.filter(row => row && typeof row === 'object' && typeof row.id === 'string' && row.id && row.id.length < 200 && !seen.has(row.id) && (seen.add(row.id), true) && validCents(row.targetCents)).map(row => {
    const contributionIds = new Set(); let total = 0;
    const contributions = (Array.isArray(row.contributions) ? row.contributions : []).filter(item => {
      if (!item || !item.id || contributionIds.has(item.id) || !validCents(item.cents) || !wishDate(item.date)) return false;
      if (!item.removedAt && total + item.cents > MAX_CENTS) return false;
      contributionIds.add(item.id); if (!item.removedAt) total += item.cents; return true;
    }).map(item => ({ id: text(item.id, 200), cents: item.cents, date: item.date, note: text(item.note, 240), created: Number(item.created) || 0, removedAt: Number(item.removedAt) || 0 }));
    return { id: row.id, title: text(row.title, 60) || '我的小愿望', note: text(row.note, 1000), targetCents: row.targetCents, photos: Array.isArray(row.photos) ? row.photos.filter(photo => typeof photo === 'string').slice(0, 1) : [], coverFocus:focus(row.coverFocus), contributions, created: Number(row.created) || 0, updated: Number(row.updated) || 0, archivedAt: Number(row.archivedAt) || 0, completedAt: Number(row.completedAt) || 0, completedDate: wishDate(row.completedDate) ? row.completedDate : '', journalId: text(row.journalId, 200) };
  });
  return { version: 1, wishes };
}

// Mutations are serialized; in-memory state only advances after the local write commits.
// Completion and its optional journal entry share one transaction and a stable journal ID.
export function createWishStore({ read, write, atomic, now = () => Date.now(), id = () => globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}${Math.random().toString(36).slice(2)}` }) {
  let state = { version: 1, wishes: [] }, tail = Promise.resolve();
  const enqueue = fn => { const next = tail.then(fn); tail = next.catch(() => {}); return next; };
  const get = (collection, wishId) => { const wish = collection.wishes.find(row => row.id === wishId); if (!wish) throw new Error('这个愿望已经不在当前记录中'); return wish; };
  const editable = wish => { if (wish.archivedAt) throw new Error('请先从归档恢复这个愿望'); if (wish.completedAt) throw new Error('已实现的愿望保留原记录；需要调整时请先重新开启'); };
  const persist = async (next, entry) => {
    if (entry) await atomic([{ store: 'entries', value: entry }, { store: 'settings', key: WISHES_KEY, value: next }]);
    else { const saved = await write(WISHES_KEY, next); if (saved && typeof saved === 'object') next = saved; }
    state = normalizeWishes(next);
  };
  const mutation = fn => enqueue(async () => { const next = copy(state), result = await fn(next); if (result?.skip) return result.value; await persist(next, result?.entry); return result?.value; });
  return {
    load: () => enqueue(async () => { state = normalizeWishes(await read(WISHES_KEY)); return copy(state.wishes); }),
    list: () => copy(state.wishes),
    save: input => mutation(next => {
      const existing = input.id ? get(next, input.id) : null; if (existing) editable(existing);
      if (!existing && next.wishes.length >= 200) throw new Error('已达到 200 个愿望的上限，现有小罐仍可继续使用');
      const title = text(input.title, 60); if (!title) throw new Error('给这个愿望起个名字吧');
      const targetCents = wishCents(input.target), wishId = existing?.id || id(), timestamp = now();
      const wish = { ...existing, id: wishId, title, note: text(input.note, 1000), targetCents, photos: (input.photos || []).filter(photo => typeof photo === 'string').slice(0, 1),coverFocus:focus(input.coverFocus), contributions: existing?.contributions || [], created: existing?.created || timestamp, updated: timestamp, archivedAt: 0, completedAt: 0, completedDate: '', journalId: existing?.journalId || '' };
      next.wishes = [...next.wishes.filter(row => row.id !== wishId), wish]; return { value: wishId };
    }),
    contribute: (wishId, input) => mutation(next => {
      const wish = get(next, wishId); editable(wish); const cents = wishCents(input.amount);
      if (!wishDate(input.date)) throw new Error('请选择正确的记录日期');
      if (wish.contributions.length >= 1000) throw new Error('这个小罐已有 1000 条记录，请新建一个愿望继续记录');
      if (wishProgress(wish).saved + cents > MAX_CENTS) throw new Error('累计金额不能超过 99,999,999.99 元');
      wish.contributions.push({ id: id(), cents, date: input.date, note: text(input.note, 240), created: now(), removedAt: 0 }); wish.updated = now(); return { value: wishId };
    }),
    contributionState: (wishId, contributionId, removed) => mutation(next => {
      const wish = get(next, wishId); editable(wish); const row = wish.contributions.find(item => item.id === contributionId);
      if (!row) throw new Error('找不到这条攒钱记录');
      if (!removed && row.removedAt && wishProgress(wish).saved + row.cents > MAX_CENTS) throw new Error('恢复后累计金额会超过上限');
      row.removedAt = removed ? now() : 0; wish.updated = now(); return { value: wishId };
    }),
    archive: (wishId, archived) => mutation(next => { const wish = get(next, wishId); wish.archivedAt = archived ? now() : 0; wish.updated = now(); return { value: wishId }; }),
    reopen: wishId => mutation(next => { const wish = get(next, wishId); if (wish.archivedAt) throw new Error('请先从归档恢复这个愿望'); wish.completedAt = 0; wish.completedDate = ''; wish.updated = now(); return { value: wishId }; }),
    complete: (wishId, input) => mutation(next => {
      const wish = get(next, wishId);
      if (wish.completedAt) return { skip: true, value: { wishId, journalId: wish.journalId, created: false } };
      editable(wish); if (!wishProgress(wish).ready) throw new Error('先攒到目标金额，再把愿望标记为实现吧');
      if (!wishDate(input.date)) throw new Error('请选择正确的实现日期');
      const timestamp = now(); wish.completedAt = timestamp; wish.completedDate = input.date; wish.updated = timestamp;
      let entry;
      if (input.createJournal && !wish.journalId) {
        wish.journalId = `wish-journal-${wish.id}`;
        entry = { id: wish.journalId, kind: 'life', title: `愿望实现啦：${wish.title}`.slice(0, 60), date: input.date, time: '', note: text(input.note, 3000) || `一点一点攒起来，终于实现了「${wish.title}」。`, photos: [...wish.photos], repeat: false, recurrence: { type: 'none' }, countdown: false, recipeId: '', reminder: null, created: timestamp, wishId: wish.id };
      }
      return { entry, value: { wishId, journalId: wish.journalId, created: Boolean(entry) } };
    })
  };
}
