import {seasonalContext,seasonalMatch} from './food-core.js?v=36';
import {nativeAvailable,nativeRequest,migrateLegacy} from './native-store.js?v=36';
import { recurrenceFor, nextScheduledDate } from "./calendar-tools.js?v=36";
import { starterLedgerCategories } from "./ledger-core.js?v=36";

export const kinds = {
  life: { name: "生活", icon: "✿", color: "rose" },
  meal: { name: "美食", icon: "♨", color: "amber" },
  memo: { name: "备注", icon: "✎", color: "sage" },
  anniversary: { name: "纪念日", icon: "♥", color: "berry" },
  event: { name: "活动", icon: "✦", color: "violet" },
  capsule: { name: "时光胶囊", icon: "✉", color: "violet" },
};

export const categories = ["面食", "海鲜", "肉菜", "素菜", "汤羹", "甜品", "其他"];
export const moods = {
  happy: { name: "开心", icon: "☀", copy: "把今天的开心，分一半给熊熊。" },
  calm: { name: "平静", icon: "☁", copy: "慢慢来，平平淡淡也很好。" },
  hopeful: { name: "期待", icon: "✦", copy: "心里的小期待，正在发芽。" },
  tired: { name: "疲惫", icon: "☾", copy: "辛苦啦，今天也可以慢一点。" },
  sad: { name: "难过", icon: "☂", copy: "不开心也没关系，熊熊陪着你。" },
  angry: { name: "生气", icon: "♨", copy: "先歇一会儿，给自己一点空间。" },
};
export const foodIcons = { 面食: "🍜", 海鲜: "🦐", 肉菜: "🍗", 素菜: "🥬", 汤羹: "🥣", 甜品: "🍓", 其他: "🍽" };

export const starterRecipes = [
  { id: "sample-noodle", title: "番茄鸡蛋面", category: "面食", ingredients: "番茄、鸡蛋、面条、葱、盐", steps: "1. 炒熟鸡蛋后盛出，再把番茄炒软。\n2. 加水煮沸，下入面条。\n3. 面条煮熟后加回鸡蛋，撒葱花。" },
  { id: "sample-shrimp", title: "蒜蓉鲜虾", category: "海鲜", ingredients: "鲜虾、蒜、葱、生抽", steps: "1. 鲜虾去虾线，蒜切末。\n2. 爆香蒜末后放虾翻炒。\n3. 加入生抽和少量水，煮至虾熟透。" },
  { id: "sample-wings", title: "蜜汁鸡翅", category: "肉菜", ingredients: "鸡翅、蜂蜜、生抽、姜", steps: "1. 鸡翅吸干表面水分，用生抽和姜腌制。\n2. 煎至两面金黄，加少量水焖熟。\n3. 加蜂蜜收汁。" },
  { id: "sample-greens", title: "清炒西兰花", category: "素菜", ingredients: "西兰花、蒜、盐", steps: "1. 西兰花洗净切小朵，快速焯水。\n2. 炒香蒜末，放入西兰花翻炒。\n3. 加盐调味，炒熟后装盘。" },
  { id: "sample-soup", title: "玉米胡萝卜汤", category: "汤羹", ingredients: "玉米、胡萝卜、姜、盐", steps: "1. 玉米和胡萝卜切块。\n2. 加水和姜片煮开，转小火炖至胡萝卜软糯。\n3. 加盐调味。" },
  { id: "sample-yogurt", title: "莓果酸奶杯", category: "甜品", ingredients: "草莓、蓝莓、酸奶、燕麦", steps: "1. 莓果洗净，草莓切块。\n2. 杯中交替铺上酸奶、燕麦和水果。\n3. 加上几颗水果装饰。" },
  { id: "sample-chicken-noodle", title: "香菇鸡丝拌面", category: "面食", ingredients: "面条、鸡胸肉、香菇、生抽、香油", steps: "1. 鸡胸肉煮熟撕丝，香菇切片炒熟。\n2. 面条煮熟后沥水。\n3. 加鸡丝、香菇、生抽和香油拌匀。" },
  { id: "sample-fish", title: "葱姜蒸鲈鱼", category: "海鲜", ingredients: "鲈鱼、葱、姜、蒸鱼豉油", steps: "1. 鲈鱼处理干净，铺上姜丝。\n2. 水开后入锅蒸至鱼肉熟透。\n3. 倒去蒸汁，撒葱丝并淋上蒸鱼豉油。" },
].map((recipe) => ({ ...recipe, photos: [], starter: true }));

export function dateKey(date = new Date()) {
  return [String(date.getFullYear()).padStart(4, "0"), String(date.getMonth() + 1).padStart(2, "0"), String(date.getDate()).padStart(2, "0")].join("-");
}
export const fromKey = (key) => new Date(key + "T12:00:00");
const dayNumber = (key) => Date.parse(key + "T00:00:00Z") / 86400000;

export function onDate(entry, key) {
  return nextScheduledDate(entry.date, recurrenceFor(entry), key) === key;
}

export function nextOccurrence(entry, today) {
  return nextScheduledDate(entry.date, recurrenceFor(entry), today);
}

export function rankRecipes(recipes, entries, category, date) {
  const history = new Map(),season=seasonalContext(date);
  for (const entry of entries) {
    if (entry.kind !== "meal" || !entry.recipeId || entry.date > date) continue;
    const dates = history.get(entry.recipeId) || [];
    dates.push(entry.date);
    history.set(entry.recipeId, dates);
  }
  return recipes.filter((recipe) => category === "全部" || recipe.category === category).map((recipe) => {
    const dates = (history.get(recipe.id) || []).sort();
    const gap = dates.length ? dayNumber(date) - dayNumber(dates[dates.length - 1]) : null;
    const seasonal=seasonalMatch(recipe,season);
    const historyScore=gap===null?35:Math.min(gap,60);
    const score=historyScore+seasonal.score-(gap===0?150:gap!==null&&gap<=2?70:0);
    const historyReason = gap === null ? "还没记过这道菜，试试新口味吧" : gap === 0 ? "当天已经记过这道菜" : `距上次做这道菜已经 ${gap} 天`;
    const reason=(seasonal.reason?seasonal.reason+" · ":"")+historyReason;
    return { recipe, score, frequency: dates.length, reason };
  }).sort((a, b) => b.score - a.score || a.frequency - b.frequency || a.recipe.title.localeCompare(b.recipe.title, "zh-CN"));
}

const databaseName = "bear-calendar";
let database, useNative = false;
export async function openStore() {
  if(nativeAvailable()) {
    const status=await nativeRequest({op:'status'});
    if(status.ready){useNative=true;return;}
  }
  database = await new Promise((resolve, reject) => {
    const request = indexedDB.open(databaseName, 3);
    request.onupgradeneeded = (event) => {
      if (event.oldVersion < 1) {
        request.result.createObjectStore("entries", { keyPath: "id" });
        const recipes = request.result.createObjectStore("recipes", { keyPath: "id" });
        for (const recipe of starterRecipes) recipes.add(recipe);
        request.result.createObjectStore("settings");
      }
      if (event.oldVersion < 2) request.result.createObjectStore("moods", { keyPath: "date" });
      if (event.oldVersion < 3) {
        request.result.createObjectStore("ledger", { keyPath: "id" });
        const categories = request.result.createObjectStore("ledgerCategories", { keyPath: "id" });
        for (const category of starterLedgerCategories) categories.add(category);
      }
    };
    request.onsuccess = () => {
      request.result.onversionchange = () => request.result.close();
      resolve(request.result);
    };
    request.onerror = () => reject(request.error);
    request.onblocked = () => reject(new Error("请关闭其他熊熊宝典窗口后重试"));
  });
  if(nativeAvailable()){
    await migrateLegacy(database,nativeRequest,(done,total)=>{
      const text=document.querySelector('.loading');if(text)text.textContent=`正在迁移本机记录 ${done}/${total}，请勿关闭…`;
    });
    database.close();database=null;useNative=true;
  }
}

function transaction(store, mode, action) {
  return new Promise((resolve, reject) => {
    const tx = database.transaction(store, mode);
    const request = action(tx.objectStore(store));
    tx.oncomplete = () => resolve(request.result);
    tx.onabort = () => reject(tx.error || new Error("本机写入未完成"));
    tx.onerror = () => reject(tx.error || request.error);
  });
}
async function nativePut(store,key,value,add=false){
  const result=await nativeRequest({op:'put',store,key,value,add});
  if(value&&typeof value==='object'&&!Array.isArray(value))Object.assign(value,result.value);
  return result.value;
}
const trashStores = new Set(["entries", "recipes", "ledger"]);
const trashLifetime = 30 * 86400000;
const loadRaw = store => useNative ? nativeRequest({op:"all",store}).then(result=>result.value) : transaction(store,"readonly",table=>table.getAll());
export const isDeleted = item => Boolean(item && typeof item === "object" && Number(item._deletedAt) > 0);
export async function loadAll(store, {includeDeleted = false} = {}) {
  const items = await loadRaw(store);
  return includeDeleted || !trashStores.has(store) ? items : items.filter(item=>!isDeleted(item));
}
export const saveItem = (store, item) => useNative?nativePut(store,String(item.id),item):transaction(store, "readwrite", (table) => table.put(item));
export async function saveItemsAtomically(rows) {
  if (!Array.isArray(rows) || !rows.length || rows.length > 20) throw new Error("一次最多保存 20 条关联记录");
  const prepared = rows.map(row=>({store:row.store,key:String(row.key ?? (row.store === "moods" ? row.value?.date : row.value?.id) ?? ""),value:row.value}));
  if (prepared.some(row=>!row.key || row.key.length>300 || row.value===undefined || !["entries","recipes","moods","ledger","ledgerCategories","settings"].includes(row.store) || (row.store!=="settings" && (!row.value || String(row.value[row.store==="moods"?"date":"id"]??"")!==row.key)))) throw new Error("关联记录格式无效");
  if (new Set(prepared.map(row=>row.store+"\0"+row.key)).size !== prepared.length) throw new Error("同一次保存不能重复写入同一条记录");
  if (useNative) {
    const result = await nativeRequest({op:"put-batch",rows:prepared});
    result.rows.forEach((row,index)=>{if(rows[index].value && typeof rows[index].value === "object") Object.assign(rows[index].value,row.value);});
    return result.rows.map(row=>row.value);
  }
  await new Promise((resolve,reject)=>{
    const tx=database.transaction([...new Set(prepared.map(row=>row.store))],"readwrite");
    try { for (const row of prepared) {const table=tx.objectStore(row.store); row.store === "settings" ? table.put(row.value,row.key) : table.put(row.value);} }
    catch(error){tx.abort();reject(error);return;}
    tx.oncomplete=resolve;tx.onabort=()=>reject(tx.error||new Error("关联记录尚未保存，请重试"));tx.onerror=()=>reject(tx.error);
  });
  return rows.map(row=>row.value);
}
export async function saveMealWithRecipe(entry,recipe){
  const linked={...entry,recipeId:recipe.id};
  await saveItemsAtomically([{store:"entries",value:linked},{store:"recipes",value:recipe}]);
  Object.assign(entry,linked);
}
function mutateRecord(store,id,change) {
  return new Promise((resolve,reject)=>{
    const tx=database.transaction(store,"readwrite"),table=tx.objectStore(store),request=table.get(id);let result;
    request.onsuccess=()=>{try{result=change(request.result);if(result===undefined)return;if(result===null)table.delete(id);else table.put(result);}catch(error){tx.abort();reject(error);}};
    tx.oncomplete=()=>resolve(result);tx.onerror=()=>reject(tx.error||request.error);tx.onabort=()=>reject(tx.error||new Error("这条记录暂时没能更新"));
  });
}
export async function removeItem(store,id) {
  id=String(id);
  if (!trashStores.has(store)) return useNative?nativeRequest({op:"remove",store,key:id}):transaction(store,"readwrite",table=>table.delete(id));
  if (useNative) return nativeRequest({op:"soft-delete",store,key:id,now:Date.now()}).then(result=>result.value);
  return mutateRecord(store,id,item=>{if(!item)return undefined;if(isDeleted(item))return item;const now=Date.now();return {...item,_deletedAt:now,_deleteExpiresAt:now+trashLifetime};});
}
export async function loadTrash(now = Date.now()) {
  const groups=await Promise.all([...trashStores].map(async store=>(await loadRaw(store)).filter(isDeleted).map(item=>{
    const deletedAt=Number(item._deletedAt),expiresAt=Number(item._deleteExpiresAt)||deletedAt+trashLifetime;
    return {store,id:item.id,item,deletedAt,expiresAt,expired:expiresAt<=now,remainingDays:Math.max(0,Math.ceil((expiresAt-now)/86400000))};
  })));
  return groups.flat().sort((a,b)=>b.deletedAt-a.deletedAt);
}
export async function restoreItem(store,id) {
  if(!trashStores.has(store)) throw new Error("这类内容不在最近删除中");
  if(useNative) return nativeRequest({op:"restore",store,key:String(id)}).then(result=>result.value);
  return mutateRecord(store,String(id),item=>{if(!item||!isDeleted(item))throw new Error("这条记录已不在最近删除中");const next={...item};delete next._deletedAt;delete next._deleteExpiresAt;return next;});
}
export async function purgeTrashItem(store,id) {
  if(!trashStores.has(store)) throw new Error("这类内容不在最近删除中");
  if(useNative) return nativeRequest({op:"purge-trash-item",store,key:String(id)});
  return mutateRecord(store,String(id),item=>{if(!item)return undefined;if(!isDeleted(item))throw new Error("只能彻底清除最近删除中的记录");return null;});
}
export async function purgeTrash({expiredOnly=true,now=Date.now()}={}) {
  if(useNative) return nativeRequest({op:"purge-trash",expiredOnly,now});
  const items=(await loadTrash(now)).filter(item=>!expiredOnly||item.expired);
  if(!items.length)return {removed:0};
  let removed=0;
  await new Promise((resolve,reject)=>{const tx=database.transaction([...new Set(items.map(item=>item.store))],"readwrite");for(const item of items){const table=tx.objectStore(item.store),request=table.get(item.id);request.onsuccess=()=>{if(isDeleted(request.result)&&(!expiredOnly||(Number(request.result._deleteExpiresAt)||Number(request.result._deletedAt)+trashLifetime)<=now)){table.delete(item.id);removed++;}};}tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error||new Error("最近删除尚未清理完成"));});
  return {removed};
}
export const getSetting=key=>useNative?nativeRequest({op:'get',store:'settings',key}).then(result=>result.value??undefined):transaction('settings','readonly',table=>table.get(key));
export const putSetting=(key,value)=>useNative?nativePut('settings',key,value):transaction('settings','readwrite',table=>table.put(value,key)).then(()=>value);
export const removeSetting=key=>useNative?nativeRequest({op:'remove',store:'settings',key}):transaction('settings','readwrite',table=>table.delete(key));
function draftKey(id){if(typeof id!=="string"||!id||id.length>200)throw new Error("草稿标识无效");return "draft:"+id;}
export function saveDraft(id,draft){if(!draft||typeof draft!=="object"||Array.isArray(draft))throw new Error("草稿内容无效");return putSetting(draftKey(id),{...draft,_type:"draft",draftId:id,savedAt:Date.now()});}
export const loadDraft=id=>getSetting(draftKey(id));
export const clearDraft=id=>removeSetting(draftKey(id));
export async function listDrafts(){return (await loadRaw("settings")).filter(item=>item&&item._type==="draft"&&typeof item.draftId==="string").sort((a,b)=>(b.savedAt||0)-(a.savedAt||0));}
export const getSound=()=>getSetting('sound');
export const setSound=value=>putSetting('sound',value);
export const getDateSettings=()=>getSetting('date-settings');
export const saveDateSettings=value=>putSetting('date-settings',value);
export const getLedgerBudgets=()=>getSetting('ledger-budgets');
export const saveLedgerBudgets=value=>putSetting('ledger-budgets',value);
export const getAudioProfile=()=>getSetting('audio-profile');
export const saveAudioProfile=value=>putSetting('audio-profile',value);
export function saveDailyMood(date, mood) {
  if (date !== dateKey() || !moods[mood]) return Promise.reject(new Error("只能记录今天的心情"));
  const item = { date, mood, created: Date.now() };
  // add() is atomic and rejects duplicate dates, including simultaneous windows.
  return useNative?nativePut("moods",date,item,true):transaction("moods", "readwrite", (table) => table.add(item)).then(() => item);
}
