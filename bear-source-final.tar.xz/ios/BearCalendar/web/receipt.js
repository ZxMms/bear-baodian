import {pickImage} from './image-picker.js?v=35';
import {parseReceipt} from './receipt-core.js?v=35';
import {dateKey} from './model.js?v=35';
import {bearArt} from './illustrations.js?v=35';
let ui, libraryPromise, active=null;
export function initReceipts(callbacks){ui=callbacks;}
export function openReceipt(){
  ui.open('截图记账',`<div class="receipt-intro">${bearArt('moments','receipt','',2)}<h3>让截图变成一笔小账</h3><p>选择一张支付详情截图，熊熊帮你整理金额、日期和分类。</p></div><input id="receipt-file" type="file" accept="image/png,image/jpeg,image/webp" hidden><button type="button" class="primary" data-receipt-action="choose">选择账单截图</button><p class="photo-hint">一次识别一笔，适合微信、支付宝的单笔交易详情。仅在本机识别；核对后才会保存，不会自动入账。</p><p class="form-error receipt-error" role="alert"></p>`);
  ui.sheet.dataset.view='receipt';
}
export function loadOcrLibrary(){
  if(window.Tesseract)return Promise.resolve();
  if(!libraryPromise)libraryPromise=new Promise((resolve,reject)=>{const script=document.createElement('script');script.src='ocr/tesseract.min.js';script.onload=resolve;script.onerror=()=>{libraryPromise=null;reject(new Error('本机识别组件未能加载，请更新 App 后重试'));};document.head.append(script);});
  return libraryPromise;
}
export async function prepareOcrImage(file){
  if(!file.type.startsWith('image/'))throw new Error('请选择图片格式的截图');
  if(file.size>20*1024*1024)throw new Error('这张截图超过 20 MB，请裁剪到需要识别的内容后重试');
  const hash=window.crypto?.subtle?Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',await file.arrayBuffer())),b=>b.toString(16).padStart(2,'0')).join(''):'';
  const url=URL.createObjectURL(file), image=new Image();
  try {
    await new Promise((resolve,reject)=>{image.onload=resolve;image.onerror=()=>reject(new Error('截图未能读取，请换成 JPG 或 PNG'));image.src=url;});
    if(image.naturalWidth*image.naturalHeight>50000000)throw new Error('截图过长，请裁剪到需要识别的内容再识别');
    const scale=Math.min(1,1400/image.naturalWidth,2600/image.naturalHeight),canvas=document.createElement('canvas');canvas.width=Math.round(image.naturalWidth*scale);canvas.height=Math.round(image.naturalHeight*scale);
    const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(image,0,0,canvas.width,canvas.height);
    const photo=canvas.toDataURL('image/jpeg',0.9);canvas.width=0;canvas.height=0;
    return {photo,hash};
  }finally{URL.revokeObjectURL(url);}
}
function progress(status,percent){
  const text=ui.sheet.querySelector('.receipt-progress-text'),bar=ui.sheet.querySelector('.receipt-progress');
  if(text)text.textContent=status;
  if(bar&&percent!=null){bar.value=percent;bar.setAttribute('aria-valuetext',Math.round(percent)+'%');}
}
export async function receiptChanged(input){
  if(input.id!=='receipt-file')return false;
  const file=input.files?.[0];if(!file)return true;
  let image;
  try{image=await prepareOcrImage(file);}catch(error){ui.sheet.querySelector('.receipt-error').textContent=error.message;return true;}
  const job={cancelled:false,worker:null,timer:null,rejectCancel:null};active=job;
  ui.open('熊熊正在读截图',`<img class="receipt-preview" src="${image.photo}" alt="待识别的账单截图"><p class="receipt-progress-text" role="status">正在准备本机识别…</p><progress class="receipt-progress" max="100" value="0" aria-label="截图识别进度"></progress><p class="photo-hint">截图和文字不会发给服务器。首次准备可能稍慢，请稍等。</p><button type="button" class="secondary" data-receipt-action="cancel">取消识别</button>`);
  ui.sheet.dataset.view='receipt-progress';
  let raw='',failed=false;
  try{
    await loadOcrLibrary();if(job.cancelled)return true;
    const base=new URL('ocr/',location.href).href;
    const work=(async()=>{
      const worker=await window.Tesseract.createWorker('chi_sim+eng',1,{workerPath:base+'worker.min.js',corePath:base,langPath:base,workerBlobURL:false,cacheMethod:'none',gzip:true,legacyCore:false,legacyLang:false,logger:message=>{
        if(job.cancelled)return;
        const reading=message.status==='recognizing text';progress(reading?'正在识别文字…':'正在准备本机识别…',reading?20+(message.progress||0)*80:10);
      }});
      job.worker=worker;if(job.cancelled||job.abandoned){await worker.terminate();return '';}
      await worker.setParameters({tessedit_pageseg_mode:'11',preserve_interword_spaces:'1'});
      const result=await worker.recognize(image.photo);return result.data.text;
    })();
    raw=await Promise.race([work,new Promise((_,reject)=>{job.rejectCancel=reject;job.timer=setTimeout(()=>reject(new Error('识别超时')),90000);})]);
  }catch(error){failed=true;}
  finally{job.abandoned=true;clearTimeout(job.timer);if(job.worker)await job.worker.terminate().catch(()=>{});if(active===job)active=null;}
  if(job.cancelled||ui.sheet.dataset.view!=='receipt-progress'||!ui.sheet.open)return true;
  const parsed=parseReceipt(raw,dateKey());
  if(failed||!raw.trim())parsed.warnings.unshift('未能读清截图，已保留图片，请手动填写并核对。');
  ui.edit({...parsed,receipt:image.photo,receiptHash:image.hash,receiptImport:true,note:parsed.merchant?`商家：${parsed.merchant}`:''});
  return true;
}
export async function receiptClick(data){
  if(!data.receiptAction)return false;
  if(data.receiptAction==='choose')pickImage(ui.sheet.querySelector('#receipt-file'));
  if(data.receiptAction==='cancel'){cancelReceipt();openReceipt();}
  return true;
}
export function cancelReceipt(){if(!active)return;active.cancelled=true;active.rejectCancel?.(new Error('cancelled'));active.worker?.terminate().catch(()=>{});active=null;}
