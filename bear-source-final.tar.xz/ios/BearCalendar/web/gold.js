import {getSetting,saveItemsAtomically,loadAll,dateKey} from './model.js?v=37';
import {createGoldStore,goldProgress,goldGrams,goldMoney} from './gold-core.js?v=37';
import {bearArt} from './illustrations.js?v=37';
import {icon} from './icons.js?v=37';
import {reportFormError} from './form-experience.js?v=37';

const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let ui,store,busy=false;
const find=id=>store?.list().find(g=>g.id===id);
const purchases=goal=>goal.purchases.filter(r=>!r.removedAt).sort((a,b)=>b.date.localeCompare(a.date)||b.created-a.created);
const billFor=row=>ui.getLedger().find(b=>b.id===row.ledgerId);
const back=(goalId='')=>`<button type="button" class="text-button gold-back" data-gold-action="${goalId?'detail':'list'}" data-gold-id="${escape(goalId)}">${icon('back')}${goalId?'返回小目标':'全部买金目标'}</button>`;
const progress=goal=>{const p=goldProgress(goal);return `<div class="gold-progress"><div class="gold-progress-label"><span>已购 <b>${goldGrams(p.mg)}</b> 克</span><span>目标 ${goldGrams(goal.targetMg)} 克</span></div><div class="gold-track" role="progressbar" aria-label="${escape(goal.title)}购入进度" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round(p.percent)}" aria-valuetext="已购 ${goldGrams(p.mg)} 克，目标 ${goldGrams(goal.targetMg)} 克"><i style="width:${p.percent}%"></i></div><p>${p.extra?`已超过目标 ${goldGrams(p.extra)} 克`:p.ready?'小目标达成啦，给自己一个拥抱':'还差 '+goldGrams(p.remaining)+' 克 · 按自己的节奏慢慢来'}</p></div>`;};
export async function initGold(callbacks){ui=callbacks;store=createGoldStore({read:getSetting,atomic:saveItemsAtomically,loadLedger:()=>loadAll('ledger',{includeDeleted:true}),loadCategories:()=>loadAll('ledgerCategories')});await store.load();}
export async function refreshGold(){await store?.load();}
export function goldEntryMarkup(){
  const goals=store?.list().filter(g=>!g.archivedAt)||[],goal=goals.sort((a,b)=>b.updated-a.updated)[0],p=goal&&goldProgress(goal);
  return `<button type="button" class="gold-entry" data-gold-action="list"><span class="gold-emblem" aria-hidden="true">${icon('heart')}</span><span class="gold-entry-copy"><strong>买金小目标</strong><small>${goal?`${escape(goal.title)} · 已购 ${goldGrams(p.mg)} / ${goldGrams(goal.targetMg)} 克`:'从喜欢的一小克，攒成自己的小金库'}</small>${goal?`<span class="gold-mini-track" aria-hidden="true"><i style="width:${p.percent}%"></i></span>`:''}</span><span class="gold-entry-arrow" aria-hidden="true">›</span></button>`;
}
export function openGold(){
  const all=store.list().sort((a,b)=>b.updated-a.updated),active=all.filter(g=>!g.archivedAt),archived=all.filter(g=>g.archivedAt);
  const card=goal=>`<button type="button" class="gold-goal-card" data-gold-action="detail" data-gold-id="${escape(goal.id)}"><div class="gold-card-heading"><h3>${escape(goal.title)}</h3><span>${goal.archivedAt?'已归档':goldProgress(goal).ready?'已达成':'慢慢积攒'} ›</span></div>${progress(goal)}</button>`;
  ui.open('买金小目标',`<section class="gold-intro"><div><p class="eyebrow">一点点，攒起金色的期待</p><h3>喜欢的金子<br>慢慢攒成小金库</h3><p>记下每次购入，留住每一步进度。</p></div>${bearArt('moments','gold-goals','gold-bears',3)}</section><button type="button" class="primary gold-wide" data-gold-action="new">${icon('plus')}设一个买金目标</button><div class="gold-goal-list">${active.length?active.map(card).join(''):'<div class="gold-empty"><strong>第一份小金库，从一个目标开始</strong><p>想攒 10 克金，或买一份喜欢的礼物？<br>写下克重，再慢慢记录已经购入的部分。</p></div>'}</div>${archived.length?`<details class="gold-archive"><summary>归档的目标 · ${archived.length}</summary>${archived.map(card).join('')}</details>`:''}<p class="photo-hint gold-footnote">克重按购入记录汇总。均价是你的实付成本，不是实时金价；目标进度不受账本统计日期影响。</p>`);ui.sheet.dataset.view='gold-list';
}
function openGoal(id){
  const goal=find(id);if(!goal){ui.announce('找不到这个目标');openGold();return;}
  const p=goldProgress(goal),rows=purchases(goal);
  ui.open(goal.title,`${back()}<section class="gold-detail-hero"><div class="gold-detail-top"><span class="gold-status">${goal.archivedAt?'暂时收好':p.ready?'小目标达成':'我的金色小期待'}</span>${bearArt('moments',goal.id,'gold-detail-bear',p.ready?11:3)}</div><p class="gold-main-label">${p.ready?'已经攒到':'距离目标还差'}</p><div class="gold-main-number">${goldGrams(p.ready?p.mg:p.remaining)}<small>克</small></div>${progress(goal)}</section><div class="gold-stats"><div><span>累计实付</span><strong>¥${goldMoney(p.cents)}</strong><small>${p.count} 次购入 · 含工费</small></div><div><span>购入均价</span><strong>${p.averageCents===null?'—':'¥'+goldMoney(p.averageCents)}</strong><small>元 / 克 · 含工费</small></div></div>${goal.note?`<p class="gold-note">${escape(goal.note)}</p>`:''}${goal.archivedAt?`<button type="button" class="primary gold-wide" data-gold-action="restore" data-gold-id="${escape(id)}">恢复这个目标</button>`:`<button type="button" class="primary gold-wide" data-gold-action="purchase" data-gold-id="${escape(id)}">${icon('plus')}记一笔购入</button>`}<section class="gold-records"><div class="section-title"><h3>每一克，都算数</h3><span>${rows.length} 笔</span></div>${rows.length?rows.map(row=>`<article class="gold-record"><button type="button" class="gold-record-main" data-gold-action="purchase" data-gold-id="${escape(id)}" data-gold-purchase="${escape(row.id)}"><span><strong>${goldGrams(row.mg)} 克</strong><small>${escape(row.brand||'未填写品牌')} · ${row.date}</small></span><span><b>¥${goldMoney(row.cents)}</b><small>${goal.archivedAt?'查看记录':'查看 / 编辑'} ›</small></span></button>${row.feeCents!==null?`<p>其中工费 ¥${goldMoney(row.feeCents)}</p>`:''}${row.note?`<p>${escape(row.note)}</p>`:''}${billFor(row)?`<button type="button" class="text-button gold-bill-link" data-linked-ledger="${escape(row.ledgerId)}">${icon('ledger')}已同步账本 · 查看账单 ›</button>`:'<span class="gold-unlinked">未计入当前账本</span>'}</article>`).join(''):'<div class="gold-empty"><strong>还没有购入记录</strong><p>已经买到的金子，也可以按实际日期补记。</p></div>'}</section><div class="gold-manage"><button type="button" class="secondary" data-gold-action="edit" data-gold-id="${escape(id)}">编辑目标</button>${!goal.archivedAt?`<button type="button" class="text-button" data-gold-action="archive" data-gold-id="${escape(id)}">收进归档</button>`:''}</div><p class="photo-hint gold-footnote">只汇总你手动记下的购入，不估算实时市值或盈亏。归档保留目标、购入记录和账单。</p>`);ui.sheet.dataset.view='gold-detail';ui.sheet.dataset.goldId=id;
}
function editGoal(goal=null){
  ui.open(goal?'编辑买金目标':'设一个买金目标',`${back(goal?.id)}<form data-form="gold-goal" data-id="${escape(goal?.id||'')}"><label for="gold-title">给小目标起个名字</label><input id="gold-title" name="goldTitle" maxlength="40" value="${escape(goal?.title||'')}" placeholder="比如：攒下我的第一份 10 克金" required><label for="gold-target">想攒多少 <small>克</small></label><input id="gold-target" name="goldTarget" inputmode="decimal" maxlength="10" value="${goal?goal.targetMg/1000:''}" placeholder="比如：10" required><div class="gold-presets" aria-label="常用目标克重">${[3,10,20,50].map(value=>`<button type="button" data-gold-action="preset" data-gold-grams="${value}">${value} 克</button>`).join('')}</div><p class="photo-hint">支持精确到 0.001 克。调整目标会保留已有购入记录。</p><label for="gold-note">留一句期待 <small>选填</small></label><textarea id="gold-note" name="goldNote" maxlength="240" rows="2" placeholder="送给未来的自己，或一份特别的礼物">${escape(goal?.note||'')}</textarea><p class="form-error" role="alert"></p><button type="submit" class="primary">${goal?'保存目标':'收好这个小目标'}</button></form>`);ui.sheet.dataset.view='gold-edit';ui.setDraft();
}
export function openGoldPurchase(goalId,purchaseId=''){
  const goal=find(goalId),row=goal?.purchases.find(r=>r.id===purchaseId&&!r.removedAt);
  if(!goal||purchaseId&&!row)return false;
  if(goal.archivedAt){ui.announce('请先恢复目标，再编辑购入记录');openGoal(goalId);return true;}
  const linked=row&&billFor(row);
  ui.open(row?'编辑这笔购入':'记一笔购入',`${back(goalId)}<form data-form="gold-purchase" data-id="${escape(row?.id||crypto.randomUUID())}" data-goal-id="${escape(goalId)}"><p class="gold-form-context">${escape(goal.title)} · 已购 ${goldGrams(goldProgress(goal).mg)} 克</p><div class="form-row"><div><label for="gold-grams">购入克重 <small>克</small></label><input id="gold-grams" name="goldGrams" inputmode="decimal" maxlength="10" placeholder="0.000" value="${row?row.mg/1000:''}" required></div><div><label for="gold-amount">实付总额 <small>元</small></label><input id="gold-amount" name="goldAmount" inputmode="decimal" maxlength="11" placeholder="含工费的实付金额" value="${row?(row.cents/100).toFixed(2):''}" required></div></div><label for="gold-date">购入日期</label><input id="gold-date" name="goldDate" type="date" min="1900-01-01" max="9999-12-31" value="${row?.date||dateKey()}" required><label for="gold-brand">品牌或购买渠道 <small>选填</small></label><input id="gold-brand" name="goldBrand" maxlength="40" placeholder="比如：周大福、银行金条、积存金" value="${escape(row?.brand||'')}"><details class="gold-extra" ${row?.feeCents!==null&&row?.feeCents!==undefined||row?.note?'open':''}><summary>工费与小备注 <small>选填</small></summary><label for="gold-fee">其中工费 <small>元 · 总工费</small></label><input id="gold-fee" name="goldFee" inputmode="decimal" maxlength="11" placeholder="不知道可留空，无工费填 0" value="${row?.feeCents!==null&&row?.feeCents!==undefined?(row.feeCents/100).toFixed(2):''}"><p class="photo-hint">工费是实付总额的一部分，填写后不会再次相加。</p><label for="gold-purchase-note">购入备注</label><textarea id="gold-purchase-note" name="goldNote" maxlength="240" rows="2" placeholder="款式、成色，或买到它时的小心情">${escape(row?.note||'')}</textarea></details><section class="gold-sync"><label class="checkbox"><input type="checkbox" name="goldSync" ${linked?'checked':''}>同时记入支出账本</label><p>${linked?'已关联一笔账单，保存时更新金额和日期；取消勾选会将该账单移入最近删除。':'勾选后按实付总额计为一笔支出；曾同步后删除的账单会恢复，其他账单不会自动匹配。'}</p></section><p class="form-error" role="alert"></p><button type="submit" class="primary">${row?'保存这笔购入':'记好这次购入'}</button>${row?`<button type="button" class="text-button danger gold-remove" data-gold-action="remove" data-gold-id="${escape(goalId)}" data-gold-purchase="${escape(row.id)}">移除这笔购入记录</button>`:''}</form>`);ui.sheet.dataset.view='gold-purchase';ui.setDraft();return true;
}
const go=next=>ui.confirmLeave(next);
async function refresh(){try{await ui.refreshData();return '';}catch{return '；记录已保存，重新打开后可刷新显示';}}
export async function goldClicked(data){
  if(!data.goldAction)return false;
  const goal=find(data.goldId);
  switch(data.goldAction){
    case 'list':await go(async()=>{await store.load();openGold();});break;
    case 'new':go(()=>editGoal());break;
    case 'detail':go(()=>openGoal(data.goldId));break;
    case 'edit':if(goal)go(()=>editGoal(goal));break;
    case 'purchase':go(()=>openGoldPurchase(data.goldId,data.goldPurchase));break;
    case 'preset':{const input=ui.sheet.querySelector('[name="goldTarget"]');if(input){input.value=data.goldGrams;input.dispatchEvent(new Event('input',{bubbles:true}));}break;}
    case 'archive':case 'restore':if(goal){await store.archive(goal.id,data.goldAction==='archive');await refresh();openGoal(goal.id);ui.announce(data.goldAction==='archive'?'已收进归档，购入记录与账单都保留':'目标已恢复');}break;
    case 'remove':go(()=>{ui.open('移除这笔购入记录？',`<p class="gold-note">这笔记录将不再计入买金进度和购入均价，移除后不能直接恢复。已同步的支出账单会保留，之后可在账本单独编辑或删除。</p><div class="sheet-actions"><button type="button" class="secondary" data-gold-action="purchase" data-gold-id="${escape(data.goldId)}" data-gold-purchase="${escape(data.goldPurchase)}">再想想</button><button type="button" class="primary destructive" data-gold-action="remove-confirm" data-gold-id="${escape(data.goldId)}" data-gold-purchase="${escape(data.goldPurchase)}">确认移除</button></div>`);ui.sheet.dataset.view='confirmation';});break;
    case 'remove-confirm':await store.removePurchase(data.goldId,data.goldPurchase);await refresh();openGoal(data.goldId);ui.announce('购入记录已移除，原有支出账单保留');break;
  }return true;
}
export async function goldSubmitted(form){
  if(!['gold-goal','gold-purchase'].includes(form.dataset.form))return false;
  if(busy)return true;busy=true;
  const values=new FormData(form),goalId=form.dataset.goalId;let id=form.dataset.id;
  try{
    if(form.dataset.form==='gold-goal'){id=await store.saveGoal({id,title:values.get('goldTitle'),target:values.get('goldTarget'),note:values.get('goldNote')});form.dataset.id=id;}
    else await store.savePurchase(goalId,{id,date:values.get('goldDate'),grams:values.get('goldGrams'),amount:values.get('goldAmount'),brand:values.get('goldBrand'),fee:values.get('goldFee'),note:values.get('goldNote'),syncLedger:values.has('goldSync')});
    const warning=await refresh();
    if(ui.sheet.querySelector('form')===form){ui.clearDraft();openGoal(goalId||id);ui.announce((goalId?'这次购入记好啦':'买金目标已收好')+warning);}
  }catch(error){if(error.message?.includes('工费')){const extra=form.querySelector('.gold-extra');if(extra)extra.open=true;}if(!reportFormError(form,error.message||'暂时没能保存，请重试'))ui.announce(error.message);}finally{busy=false;}
  return true;
}

export function refreshGoldView(){if(ui.sheet.dataset.view==='gold-detail')openGoal(ui.sheet.dataset.goldId);else if(ui.sheet.dataset.view==='gold-list')openGold();}
