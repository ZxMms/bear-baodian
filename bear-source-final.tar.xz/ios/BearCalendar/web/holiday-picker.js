import {holidays,holidaySources,daysBetween} from './calendar-tools.js?v=36';
import {dateKey} from './model.js?v=36';
import {icon} from './icons.js?v=36';

const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const validDate=value=>{if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(value)||Number(value.slice(0,4))<1900)return false;const date=new Date(value+'T12:00:00Z');return Number.isFinite(date.getTime())&&date.toISOString().slice(0,10)===value;};
const short=date=>`${Number(date.slice(5,7))}月${Number(date.slice(8,10))}日`;
const range=holiday=>holiday.start===holiday.end?short(holiday.start):`${short(holiday.start)}—${short(holiday.end)}`;
const knownHoliday=id=>holidays.find(item=>item.id===id&&holidaySources[Number(item.start.slice(0,4))]);

// Only a published year may supply dates. A holiday already in progress is not
// offered as a new future countdown; its original saved record remains editable.
export function upcomingHolidays(from=dateKey(),items=holidays,sources=holidaySources){
  if(!validDate(from))return [];
  const seen=new Set();
  return (Array.isArray(items)?items:[]).filter(item=>item&&typeof item.id==='string'&&typeof item.name==='string'&&!seen.has(item.id)&&validDate(item.start)&&validDate(item.end)&&item.end>=item.start&&item.start>=from&&sources?.[Number(item.start.slice(0,4))]&&(seen.add(item.id),true))
    .slice().sort((a,b)=>a.start.localeCompare(b.start)||a.name.localeCompare(b.name,'zh-CN'));
}
function compatible(holiday,date,repeat,countdown){return Boolean(holiday&&holiday.start===date&&repeat==='none'&&countdown);}
function itemHoliday(item){
  const holiday=knownHoliday(item?.holidayId);
  return compatible(holiday,item?.date,item?.recurrence?.type||(item?.repeat?'yearly':'none'),item?.countdown)?holiday:null;
}
function selectedHoliday(form){
  const f=form?.elements,holiday=knownHoliday(f?.holidayId?.value);
  return compatible(holiday,f?.date?.value,f?.repeatType?.value||'none',f?.countdown?.checked)?holiday:null;
}
function panelMarkup(selected,from){
  const future=upcomingHolidays(from),years=[...new Set(future.map(item=>item.start.slice(0,4)))];
  const groups=years.map(year=>`<section class="holiday-choice-year"><h4>${year} 年</h4><div class="holiday-choice-list">${future.filter(item=>item.start.startsWith(year)).map(item=>{
    const days=daysBetween(from,item.start),chosen=item.id===selected?.id;
    return `<button type="button" class="holiday-choice" data-holiday-pick="${esc(item.id)}" aria-pressed="${chosen}"><span class="holiday-choice-symbol">${icon(chosen?'check':'calendar')}</span><span class="holiday-choice-copy"><strong>${esc(item.name)}</strong><small>${range(item)} · 放假 ${daysBetween(item.start,item.end)+1} 天</small></span><span class="holiday-choice-distance">${days===0?'今天开始':`${days} 天后`}</span></button>`;
  }).join('')}</div></section>`).join('');
  return `<p class="holiday-picker-help">选择后自动填入名称和日期，默认倒计时到放假第一天 00:00；可在下方修改时间。</p>
    <details class="holiday-choice-disclosure" ${selected?'':'open'}><summary data-holiday-choice-summary><span>${icon('calendar')}<span>${selected?`${selected.start.slice(0,4)} 年 · ${esc(selected.name)}`:'选择接下来的节假日'}<small>${selected?`${range(selected)} · 换一个假期`:'按开始日期排列，点一下就选好'}</small></span></span><span class="holiday-disclosure-arrow" aria-hidden="true">⌄</span></summary>
      ${groups||'<p class="holiday-picker-empty">暂时没有可选的后续假期。可以先用自定义日期，更新放假安排后再选择。</p>'}
    </details>
    <p class="holiday-selection-note" role="status">${selected?`已选 ${esc(selected.name)}假期 · ${selected.start} 开始；仅记录这一次。${selected.start===from?'今天已经开始，00:00 的倒计时会显示已到时间。':''}`:'只列出尚未开始或今天开始的假期。'}</p>
    <p class="holiday-picker-source">中国大陆法定节假日 · 已收录至 ${Math.max(...Object.keys(holidaySources).map(Number))} 年，后续年份待更新放假安排。</p>`;
}
export function holidayPickerMarkup(item=null,from=dateKey()){
  const selected=itemHoliday(item),mode=selected?'holiday':'custom';
  return `<section class="holiday-picker" data-holiday-picker aria-label="倒计时日期来源"><div class="holiday-picker-label">日期怎么选</div><div class="holiday-mode-control" role="group" aria-label="选择自定义或法定节假日"><button type="button" data-holiday-mode="custom" aria-pressed="${mode==='custom'}">${icon('draft')}自定义日期</button><button type="button" data-holiday-mode="holiday" aria-pressed="${mode==='holiday'}">${icon('calendar')}法定节假日</button></div><input type="hidden" name="countdownSource" value="${mode}"><input type="hidden" name="holidayId" value="${esc(selected?.id||'')}"><div data-holiday-panel ${mode==='custom'?'hidden':''}>${panelMarkup(selected,from)}</div></section>`;
}
export function savedHolidayId(form){
  return form?.elements?.countdownSource?.value==='holiday'?(selectedHoliday(form)?.id||''):'';
}
export function syncHolidayPicker(form,from=dateKey()){
  const f=form?.elements,panel=form?.querySelector('[data-holiday-panel]');
  if(!f?.countdownSource||!f?.holidayId||!panel)return false;
  let selected=selectedHoliday(form);
  if(f.holidayId.value&&!selected){f.holidayId.value='';f.countdownSource.value='custom';}
  const mode=f.countdownSource.value==='holiday'?'holiday':'custom';
  if(mode==='custom'){f.holidayId.value='';selected=null;}
  f.countdownSource.value=mode;panel.hidden=mode!=='holiday';
  for(const button of form.querySelectorAll('[data-holiday-mode]'))button.setAttribute('aria-pressed',String(button.dataset.holidayMode===mode));
  panel.innerHTML=panelMarkup(selected,from);
  return true;
}
export function setHolidayMode(form,mode,from=dateKey()){
  if(!['custom','holiday'].includes(mode)||!form?.elements?.countdownSource)return false;
  form.elements.countdownSource.value=mode;
  if(mode==='custom')form.elements.holidayId.value='';
  return syncHolidayPicker(form,from);
}
export function applyHolidayChoice(form,id,from=dateKey()){
  const holiday=upcomingHolidays(from).find(item=>item.id===id),f=form?.elements;
  if(!holiday||!f?.title||!f.date||!f.time||!f.countdown||!f.repeatType||!f.countdownSource||!f.holidayId)return null;
  f.title.value=`${holiday.name}假期`;f.date.value=holiday.start;f.time.value='00:00';
  f.countdown.checked=true;f.time.required=true;f.repeatType.value='none';
  f.countdownSource.value='holiday';f.holidayId.value=holiday.id;
  syncHolidayPicker(form,from);return holiday;
}
