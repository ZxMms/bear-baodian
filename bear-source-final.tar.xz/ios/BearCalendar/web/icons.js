// Consistent, original 24-unit line icons; no external font or network dependency.
const paths={
 calendar:'M5 5h14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2ZM7 3v4m10-4v4M3 10h18M7 14h2m6 0h2M7 17h2',
 journal:'M6 3h13v18H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3Zm0 0v18M9 8h7m-7 4h7m-7 4h4',
 recipes:'M4 13h16c0 5-3 8-8 8s-8-3-8-8Zm-1 0h18M8 3c-3 3 3 4 0 7m4-7c-3 3 3 4 0 7m4-7c-3 3 3 4 0 7',
 ledger:'M4 5h14a2 2 0 0 1 2 2v13H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h13v2m-2 6h7v5h-7a2.5 2.5 0 0 1 0-5Z',
 search:'M20 20l-5-5M17 10a7 7 0 1 1-14 0 7 7 0 0 1 14 0Z',
 settings:'m10 3-.7 2-2 .8-2-.5L3 8l1.5 1.5-.2 2.3L3 13l1.5 3 2.3-.1 1.7 1.3.5 2.8h4l.6-2.5 2-1.2 2.4.2 1.8-3-1.5-1.7.1-2.1L20 8l-2-3-2.3.7-2-1L13 3Zm5 8a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z',
 plus:'M12 5v14M5 12h14',close:'m6 6 12 12M6 18 18 6',back:'m14 5-7 7 7 7',
 tools:'M4 4h6v6H4Zm10 0h6v6h-6ZM4 14h6v6H4Zm13-1v8m-4-4h8',
 heart:'M12 21 3.6 12.5A5.5 5.5 0 0 1 12 5a5.5 5.5 0 0 1 8.4 7.5Z',
 capsule:'m7 3 10 0m-10 18h10M8 3v5l8 8v5M16 3v5l-8 8v5',
 magazine:'M4 3h16v18H4Zm4 4h8M8 11h8m-8 4h3m2 0h3',
 clock:'M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0ZM12 7v5l3 2',
 shield:'m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6Zm-4 9 3 3 5-6',
 trash:'M3 6h18M9 3h6m-10 3 1 15h12l1-15M10 10v7m4-7v7',
 share:'M12 15V3m-4 4 4-4 4 4M6 10H4v11h16V10h-2',
 draft:'M13 3H4v18h16v-9M9 15l1-5L19 1l4 4-9 9Z',
 moon:'M20 15A9 9 0 0 1 9 3a9 9 0 1 0 11 12Z',
 check:'m5 12 4 4L19 6',bell:'M6 9a6 6 0 0 1 12 0c0 7 3 7 3 9H3c0-2 3-2 3-9Zm4 12h4',
};
export function icon(name,css=''){return `<svg class="ui-icon ${css}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${paths[name]||paths.heart}"/></svg>`;}
