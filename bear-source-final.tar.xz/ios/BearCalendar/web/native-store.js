const stores=['entries','recipes','moods','ledger','ledgerCategories','settings'];
let nextId=0;const pending=new Map();
export const nativeAvailable=()=>typeof window!=='undefined'&&Boolean(window.BearStore);
export function nativeRequest(request){
  return new Promise((resolve,reject)=>{
    const id=String(++nextId),timer=setTimeout(()=>{pending.delete(id);reject(new Error('本机存储响应超时，请重新打开；旧数据仍保留'));},120000);
    pending.set(id,{resolve,reject,timer});
    try{window.BearStore.request(id,JSON.stringify(request));}catch(error){clearTimeout(timer);pending.delete(id);reject(error);}
  });
}
if(typeof window!=='undefined')window.bearStoreResult=(id,response)=>{const job=pending.get(id);if(!job)return;clearTimeout(job.timer);pending.delete(id);response.ok?job.resolve(response.value):job.reject(new Error(response.error||'本机存储未完成'));};
function read(database,store,method){return new Promise((resolve,reject)=>{const tx=database.transaction(store,'readonly'),req=tx.objectStore(store)[method]();tx.oncomplete=()=>resolve(req.result);tx.onerror=()=>reject(tx.error||req.error);tx.onabort=()=>reject(tx.error);});}
function readKey(database,store,key){return new Promise((resolve,reject)=>{const tx=database.transaction(store,'readonly'),req=tx.objectStore(store).get(key);tx.oncomplete=()=>resolve(req.result);tx.onerror=()=>reject(tx.error||req.error);tx.onabort=()=>reject(tx.error);});}
async function fingerprint(value){const bytes=new TextEncoder().encode(JSON.stringify(value));return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('');}
export async function migrateLegacy(database,request=nativeRequest,onProgress=()=>{}){
  const keys={},counts={};for(const store of stores){keys[store]=await read(database,store,'getAllKeys');counts[store]=keys[store].length;}
  const fingerprints=new Map();await request({op:'migration-start',counts});let done=0;const total=Object.values(counts).reduce((a,b)=>a+b,0);
  for(const store of stores)for(const key of keys[store]){
    const value=await readKey(database,store,key);
    if(value===undefined)throw new Error('迁移时原记录发生变化，请重新打开重试');
    fingerprints.set(store+'\0'+key,await fingerprint(value));
    await request({op:'migration-row',store,key:String(key),value});onProgress(++done,total);
  }
  // Re-check source keys and values before committing; never delete the original database here.
  for(const store of stores){const after=await read(database,store,'getAllKeys');if(JSON.stringify(after)!==JSON.stringify(keys[store]))throw new Error('迁移时记录发生变化，请重新打开重试');for(const key of keys[store]){const value=await readKey(database,store,key);if(value===undefined||await fingerprint(value)!==fingerprints.get(store+'\0'+key))throw new Error('迁移时内容发生变化，请重新打开重试');}}
  const completed=await request({op:'migration-finish'});
  for(const store of stores)if(completed.counts[store]!==counts[store])throw new Error('迁移校验未完成，旧数据仍保留');
  try{localStorage.setItem('bear-legacy-copy','retained');}catch{}
  return completed;
}
export async function clearLegacyCopy(){
  const status=await nativeRequest({op:'status'});
  if(!status.ready||!status.lastBackup)throw new Error('请先导出一份完整备份');
  await new Promise((resolve,reject)=>{const request=indexedDB.deleteDatabase('bear-calendar');request.onsuccess=resolve;request.onerror=()=>reject(request.error);request.onblocked=()=>reject(new Error('请关闭其他日历窗口，再清理旧副本'));});
  localStorage.removeItem('bear-legacy-copy');
}
