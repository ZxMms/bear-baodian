// Build only explicitly selected content; money is always opt-in.
export function shareDateParts(date) {
  if (typeof date!=='string' || !/^\d{4}-\d{2}-\d{2}$/.test(date)) return null;
  const day=new Date(date+'T12:00:00Z');
  if (!Number.isFinite(day.getTime()) || day.toISOString().slice(0,10)!==date) return null;
  return {date,year:date.slice(0,4),dayLabel:`${Number(date.slice(5,7))}月${Number(date.slice(8))}日`,weekday:`星期${'日一二三四五六'[day.getUTCDay()]}`};
}
export function shareDateLabel(date) {
  const parts=shareDateParts(date);
  return parts ? `${parts.date} · ${parts.weekday}` : '';
}
export function normalizeShareSource(source) {
  if(source.mode!=='day')return {...source};
  // Support older day callers that placed the ISO date in their title. Never
  // substitute today's weekday for the date the person selected.
  const parts=source.date!==undefined&&source.date!==null&&source.date!==''?shareDateParts(source.date):shareDateParts(String(source.title||'').match(/^\d{4}-\d{2}-\d{2}/)?.[0]);
  if(!parts)throw new Error('分享日期未能识别，请返回日历重新选择这一天');
  return {...source,...parts,title:shareDateLabel(parts.date)};
}
export function selectShareContent(source, { ids = [], mood = false, photos = true, ledger = false, ledgerPhotoIds = [], recipes = false, weather = false } = {}) {
  source=normalizeShareSource(source);
  const selected = new Set(ids), sections = [];
  if (mood && source.mood) sections.push({title:"这一天的心情 · " + source.mood.name, text:source.mood.copy, photos:[]});
  for (const item of source.entries || []) if (selected.has(item.id)) {
    let text = item.note || "";
    if (recipes && item.recipe) text += `${text ? "\n\n" : ""}食材\n${item.recipe.ingredients || "未填写"}\n\n做法\n${item.recipe.steps || "未填写"}`;
    sections.push({title:item.label + " · " + item.title, text, photos:photos ? [...(item.photos || [])] : []});
  }
  const selectedLedgerPhotos=new Set(ledgerPhotoIds);
  for (const item of source.ledger || []) {
    const images=photos&&selectedLedgerPhotos.has(item.id)&&Array.isArray(item.photos)
      ?item.photos.filter(photo=>typeof photo==='string'&&photo).slice(0,5):[];
    if (ledger) sections.push({title:item.title, text:item.text, photos:images});
    else if (images.length) sections.push({title:item.photoTitle||'账单里的生活照片',text:'',photos:images});
  }
  return {mode:source.mode,date:source.date,weekday:source.weekday,title:source.title, subtitle:source.subtitle, weather:weather && source.mode==='day' ? source.weather || null : null, sections};
}
export function shareWeatherText(report) {
  return report ? [report.location,report.summary,report.wind,report.meta].filter(Boolean).join('\n') : '';
}
export function shareText(content) {
  const title=content.mode==='day'?shareDateLabel(content.date)||content.title:content.title;
  return [title, content.subtitle, shareWeatherText(content.weather), ...content.sections.map(item=>[item.title,item.text].filter(Boolean).join("\n")), "来自熊熊宝典 · 把小日子收好"].filter(Boolean).join("\n\n");
}
