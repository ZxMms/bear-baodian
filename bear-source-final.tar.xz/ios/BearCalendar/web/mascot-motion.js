// Only the four page companions move. Photos, lists and editor illustrations stay still.
const HOSTS = '.compact-hero > .mood-companion, .kitchen-hero > .kitchen-bears, .journal-intro > .journal-bears, .ledger-page-hero > .ledger-bear';

export function mascotMotionAllowed({enabled=true,reduced=false,systemReduced=false,hidden=false,modal=false}={}) {
  return enabled && !reduced && !systemReduced && !hidden && !modal;
}

export function initMascotMotion(root) {
  if (!root) return {refresh(){},destroy(){}};
  const doc=root.ownerDocument, win=doc.defaultView, states=new Map();
  const media=win.matchMedia('(prefers-reduced-motion: reduce)');
  let destroyed=false, frame=0;
  const preferencesAllowMotion=()=>mascotMotionAllowed({
    enabled:doc.documentElement.dataset.mascotMotion!=='false',
    reduced:doc.documentElement.dataset.reducedMotion==='true',
    systemReduced:media.matches,
  });
  const allowed=()=>preferencesAllowMotion()&&!doc.hidden&&!doc.querySelector('dialog[open]');
  const restoreAttributes=state=>{
    for(const [name,value] of state.originalAttributes) value===null?state.host.removeAttribute(name):state.host.setAttribute(name,value);
  };
  const syncSemantics=(state,interactive)=>{
    if(!state.customButton||state.interactive===interactive)return;
    state.interactive=interactive;
    if(!interactive){restoreAttributes(state);return;}
    const host=state.host,label=state.originalAttributes.find(([name])=>name==='aria-label')[1];
    host.setAttribute('role','button');host.setAttribute('tabindex','0');
    host.setAttribute('aria-label',`${label||'一二布布'}，轻点回应`);
  };
  const finish=state=>{
    win.clearTimeout(state.timer);state.timer=0;state.responding=false;
    state.host.classList.remove('mascot-responding');
  };
  const sync=()=>{
    if(destroyed)return;
    const enabled=allowed(),interactive=preferencesAllowMotion();
    for(const state of states.values()) {
      // A decorative image only becomes a button when it can offer its response.
      // Background/modal pauses do not alter its semantics or keyboard position.
      syncSemantics(state,interactive);
      const active=enabled&&state.visible&&state.host.isConnected;
      state.host.dataset.mascotActive=String(active);
      if(!active)finish(state);
    }
  };
  const observer=typeof win.IntersectionObserver==='function'?new win.IntersectionObserver(items=>{
    for(const item of items){const state=states.get(item.target);if(state)state.visible=item.isIntersecting&&item.intersectionRatio>0;}
    sync();
  },{threshold:0}):null;
  const checkViewport=()=>{
    frame=0;if(destroyed)return;
    for(const state of states.values()) {
      const r=state.host.getBoundingClientRect();
      state.visible=r.bottom>0&&r.top<win.innerHeight&&r.right>0&&r.left<win.innerWidth;
    }
    sync();
  };
  const queueViewport=()=>{if(!frame)frame=win.requestAnimationFrame(checkViewport);};
  const react=state=>{
    if(!state||state.responding||!allowed()||!state.visible)return;
    state.responding=true;state.host.classList.add('mascot-responding');
    state.timer=win.setTimeout(()=>finish(state),800);
  };
  const onClick=event=>react(states.get(event.target.closest('.mascot-host')));
  const onKey=event=>{
    const state=states.get(event.target.closest('.mascot-host'));
    // Native home buttons already synthesize clicks for Enter and Space.
    if(!state||!state.customButton||!state.interactive||event.repeat||!['Enter',' '].includes(event.key))return;
    event.preventDefault();react(state);
  };
  const detach=state=>{
    finish(state);observer?.unobserve(state.host);
    state.host.classList.remove('mascot-host','mascot-visual');delete state.host.dataset.mascotActive;
    if(state.customButton)restoreAttributes(state);
    if(state.wrapper?.isConnected){state.wrapper.replaceWith(...state.wrapper.childNodes);}
  };
  const refresh=()=>{
    if(destroyed)return;
    for(const [host,state] of states)if(!root.contains(host)){detach(state);states.delete(host);}
    for(const host of root.querySelectorAll(HOSTS)) {
      if(states.has(host))continue;
      const nativeButton=host.tagName==='BUTTON';
      let wrapper=null;
      if(nativeButton){
        const art=host.querySelector('.bear-art,.mood-sprite');if(!art)continue;
        wrapper=doc.createElement('span');wrapper.className='mascot-body mascot-visual';
        art.before(wrapper);wrapper.append(art);
      }else host.classList.add('mascot-visual');
      const originalAttributes=['role','tabindex','aria-label'].map(name=>[name,host.getAttribute(name)]);
      host.classList.add('mascot-host');host.dataset.mascotActive='false';
      const state={host,wrapper,visible:false,responding:false,timer:0,customButton:!nativeButton,interactive:null,originalAttributes};
      states.set(host,state);observer?.observe(host);
    }
    // Read only the bounded companion set once, so the first paint is lively even
    // before IntersectionObserver delivers its initial asynchronous observation.
    checkViewport();
  };
  const prefsObserver=new win.MutationObserver(sync);
  prefsObserver.observe(doc.documentElement,{attributes:true,attributeFilter:['data-mascot-motion','data-reduced-motion']});
  const modalObserver=new win.MutationObserver(sync);
  modalObserver.observe(doc.body,{subtree:true,attributes:true,attributeFilter:['open']});
  root.addEventListener('click',onClick);root.addEventListener('keydown',onKey);
  doc.addEventListener('visibilitychange',sync);
  if(media.addEventListener)media.addEventListener('change',sync);else media.addListener(sync);
  if(!observer){win.addEventListener('scroll',queueViewport,{passive:true});win.addEventListener('resize',queueViewport,{passive:true});}
  refresh();
  return {refresh,destroy(){
    if(destroyed)return;destroyed=true;
    observer?.disconnect();prefsObserver.disconnect();modalObserver.disconnect();
    root.removeEventListener('click',onClick);root.removeEventListener('keydown',onKey);
    doc.removeEventListener('visibilitychange',sync);
    if(media.removeEventListener)media.removeEventListener('change',sync);else media.removeListener(sync);
    if(!observer){win.removeEventListener('scroll',queueViewport);win.removeEventListener('resize',queueViewport);}
    if(frame)win.cancelAnimationFrame(frame);
    for(const state of states.values())detach(state);states.clear();
  }};
}
