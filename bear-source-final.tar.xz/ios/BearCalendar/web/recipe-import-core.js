const ingredientHeading=/^(?:食材|用料|配料|材料|主料|辅料|原料)(?:清单|准备|表)?[：:]?\s*(.*)$/;
const stepHeading=/^(?:做法|步骤|制作步骤|烹饪步骤|详细步骤|制作方法|制作过程)[：:]?\s*(.*)$/;
const numbered=/^(?:步骤\s*)?(?:[一二三四五六七八九十\d]+[、.．)）:：]|第[一二三四五六七八九十\d]+步)/;
export function parseRecipeImage(raw){
 const original=String(raw||'').replace(/\r/g,''),lines=original.split('\n').map(line=>line.trim()).filter(Boolean);
 let title='',mode='',ingredients=[],steps=[],unassigned=[];
 for(const line of lines){
  const compact=line.replace(/([\u4e00-\u9fff])\s+(?=[\u4e00-\u9fff])/g,'$1');
  const ingredient=compact.match(ingredientHeading),step=compact.match(stepHeading);
  if(ingredient){mode='ingredients';if(ingredient[1])ingredients.push(ingredient[1]);continue;}
  if(step){mode='steps';if(step[1])steps.push(step[1]);continue;}
  if(numbered.test(compact)){mode='steps';steps.push(compact);continue;}
  if(mode==='ingredients'){ingredients.push(compact);continue;}
  if(mode==='steps'){steps.push(compact);continue;}
  if(!title&&compact.length>=2&&compact.length<=60&&!/^(?:小红书|关注|点赞|收藏|评论|分享|返回|菜谱截图|图片录入|食谱大全|\d{1,2}:\d{2})/.test(compact)){title=compact.replace(/^(?:菜名|名称)[：:]\s*/, '');continue;}
  unassigned.push(compact);
 }
 const warnings=[];
 if(!title)warnings.push('没有识别出菜名，请补充。');
 if(!ingredients.length)warnings.push('没有找到明确的食材区，可对照原图补充。');
 if(!steps.length)warnings.push('没有找到明确的做法区，可对照原图补充。');
 if(unassigned.length)warnings.push('部分文字未能归类，已保留在识别原文中。');
 const text=title+' '+ingredients.join(' ');
 let category='其他';
 if(/虾|蟹|鱼|贝|鱿鱼|海鲜/.test(text))category='海鲜';else if(/面条|拌面|面|饺|馄饨/.test(title))category='面食';else if(/汤|羹|粥/.test(title))category='汤羹';else if(/蛋糕|甜|酸奶|布丁|饼干/.test(title))category='甜品';else if(/牛肉|猪肉|鸡|鸭|排骨|羊肉/.test(text))category='肉菜';else if(/蔬|菜|豆腐|茄|笋|瓜/.test(text))category='素菜';
 return {title,ingredients:ingredients.join('\n'),steps:steps.join('\n'),category,raw:original,warnings};
}
