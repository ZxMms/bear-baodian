import {shareDateParts} from './share-core.js?v=38';

export function wrapShareText(ctx,text,width) {
  const result=[];
  for(const paragraph of String(text||'').split('\n')) {
    let line='';
    for(const character of paragraph){if(line&&ctx.measureText(line+character).width>width){result.push(line);line='';}line+=character;}
    result.push(line);
  }
  return result;
}
function rounded(ctx,x,y,width,height,radius) {
  const right=x+width,bottom=y+height;
  ctx.beginPath();ctx.moveTo(x+radius,y);ctx.lineTo(right-radius,y);ctx.quadraticCurveTo(right,y,right,y+radius);ctx.lineTo(right,bottom-radius);ctx.quadraticCurveTo(right,bottom,right-radius,bottom);ctx.lineTo(x+radius,bottom);ctx.quadraticCurveTo(x,bottom,x,bottom-radius);ctx.lineTo(x,y+radius);ctx.quadraticCurveTo(x,y,x+radius,y);ctx.closePath();
}
export function drawShareHeading(ctx,content,bears,art,{width=720,pad=46}={}) {
  const date=content.mode==='day'?shareDateParts(content.date):null;
  ctx.fillStyle='#94745c';ctx.font='18px sans-serif';
  ctx.fillText(date?`${date.year}年  ·  一二布布的日常手账`:'一二布布的日常手账',pad,56);
  ctx.drawImage(bears,art.x*bears.width/4,art.y*bears.height/3,bears.width/4,bears.height/3,width-166,39,126,112);
  let y;
  if(date) {
    ctx.fillStyle='#583d30';ctx.font='bold 40px sans-serif';ctx.fillText(date.dayLabel,pad,117);
    const x=pad+ctx.measureText(date.dayLabel).width+18;
    ctx.font='bold 24px sans-serif';const badgeWidth=ctx.measureText(date.weekday).width+28;
    rounded(ctx,x,82,badgeWidth,44,22);ctx.fillStyle='#f0e2d0';ctx.fill();
    ctx.fillStyle='#855b3c';ctx.fillText(date.weekday,x+14,113);
    y=155;
  } else {
    ctx.fillStyle='#583d30';ctx.font='bold 32px sans-serif';y=105;
    for(const line of wrapShareText(ctx,content.title,width-230)){ctx.fillText(line,pad,y);y+=42;}
  }
  ctx.font='17px sans-serif';ctx.fillStyle='#94745c';
  for(const line of wrapShareText(ctx,content.subtitle,width-2*pad)){ctx.fillText(line,pad,y);y+=27;}
  return y+10;
}
export function drawShareWeather(ctx,report,symbol,top,{width=720,pad=46}={}) {
  if(!report)return top;
  const inner=width-2*pad-40,left=pad+20;
  ctx.font='18px sans-serif';const places=wrapShareText(ctx,report.location,inner);
  const rowTop=top+22+places.length*25+8,temp=report.temperature||'';
  ctx.font='bold 40px sans-serif';const temperatureWidth=temp?ctx.measureText(temp).width:0;
  const textX=left+76,conditionX=textX+(temp?temperatureWidth+16:0);
  ctx.font='20px sans-serif';const conditions=report.condition?wrapShareText(ctx,report.condition,width-pad-20-conditionX):[];
  const mainHeight=Math.max(62,conditions.length*28+10),windTop=rowTop+mainHeight+12;
  ctx.font='18px sans-serif';const winds=report.wind?wrapShareText(ctx,report.wind,inner-29):[];
  const height=windTop-top+(winds.length?19+winds.length*27:0)+12;
  rounded(ctx,pad,top,width-2*pad,height,24);ctx.fillStyle='#fffdf8';ctx.fill();ctx.strokeStyle='#e9dfd2';ctx.lineWidth=1.2;ctx.stroke();
  ctx.fillStyle='#8d7662';ctx.font='18px sans-serif';places.forEach((line,index)=>ctx.fillText(line,left,top+28+index*25));
  ctx.fillStyle='#f7edda';rounded(ctx,left,rowTop,56,56,18);ctx.fill();
  if(symbol)ctx.drawImage(symbol,left+9,rowTop+9,38,38);
  ctx.fillStyle='#584332';ctx.font='bold 40px sans-serif';if(temp)ctx.fillText(temp,textX,rowTop+43);
  ctx.font='20px sans-serif';ctx.fillStyle='#806951';conditions.forEach((line,index)=>ctx.fillText(line,conditionX,rowTop+36+index*28));
  if(winds.length) {
    ctx.strokeStyle='#eee5d9';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(left,windTop);ctx.lineTo(width-pad-20,windTop);ctx.stroke();
    const x=left,y=windTop+24;ctx.strokeStyle='#a48b70';ctx.lineWidth=1.8;ctx.lineCap='round';
    ctx.beginPath();ctx.moveTo(x,y-5);ctx.lineTo(x+13,y-5);ctx.quadraticCurveTo(x+20,y-5,x+17,y-10);ctx.moveTo(x,y+1);ctx.lineTo(x+17,y+1);ctx.quadraticCurveTo(x+25,y+1,x+22,y+7);ctx.moveTo(x,y+7);ctx.lineTo(x+10,y+7);ctx.stroke();
    ctx.font='18px sans-serif';ctx.fillStyle='#806951';winds.forEach((line,index)=>ctx.fillText(line,left+29,windTop+31+index*27));
  }
  return top+height+22;
}
