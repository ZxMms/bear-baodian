import {getSetting,putSetting,dateKey} from './model.js?v=38';
import {bearArt} from './illustrations.js?v=38';
import {icon} from './icons.js?v=38';
import {HAPPY_BOX_KEY,safeHappyPhoto,happySources,normalizeHappyBox,makeHappySnapshot,upsertHappyItem,removeHappyItem,chooseHappyItem} from './happy-box-core.js?v=38';

let ui,box=normalizeHappyBox(),saveTail=Promise.resolve(),lastShown='',pickerQuery='',pickerLimit=30,editor=null;
const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uid=()=>globalThis.crypto?.randomUUID?.()||`happy-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
const sourceRows=()=>happySources(ui.getEntries?.()||[]);
const photo=(src,css,alt)=>safeHappyPhoto(src)?`<img src="${esc(src)}" class="${css}" alt="${esc(alt)}" loading="lazy">`:'';
const names={life:'生活',meal:'美食',memo:'备注'};
const itemById=id=>box.items.find(item=>item.id===id);
function leave(next){if(ui.confirmLeave)ui.confirmLeave(next);else next();}
function show(title,content,view){ui.open(title,`<div class="happy-box">${content}</div>`);ui.sheet.dataset.view=view;}
function back(action='home',label='返回开心盒'){return `<button type="button" class="text-button happy-back" data-happy-action="${action}">${icon('back')}${label}</button>`;}
async function commit(update) {
  const task=saveTail.then(async()=>{const next=update(box);const stored=await putSetting(HAPPY_BOX_KEY,next);box=normalizeHappyBox(stored||next);return box;});
  saveTail=task.catch(()=>{});return task;
}
export async function initHappyBox(callbacks){ui=callbacks;await refreshHappyBox();}
export async function refreshHappyBox(){await saveTail;box=normalizeHappyBox(await getSetting(HAPPY_BOX_KEY));return box.items.length;}
export function openHappyBox(){
  editor=null;
  show('熊熊开心盒',`<section class="happy-hero">${bearArt('moments',dateKey(),'happy-bears',0)}<p class="eyebrow">只收好你亲自挑选的开心</p><h3>给自己留一点甜</h3><p>${box.items.length?`已经收好 ${box.items.length} 份小幸福。想看时，熊熊替你翻一张。`:'一顿好吃的饭、一张喜欢的照片、一句想记住的话，都可以放进来。'}</p></section><div class="happy-main-actions">${box.items.length?`<button type="button" class="primary" data-happy-action="surprise">${icon('heart')}给我一点开心</button>`:''}<button type="button" class="${box.items.length?'secondary':'primary'}" data-happy-action="pick">${icon('plus')}从生活记录里挑一份</button></div>${box.items.length?`<div class="section-title"><h3>我收好的开心</h3><span>${box.items.length} 份</span></div><div class="happy-list">${box.items.map(item=>card(item)).join('')}</div>`:'<div class="happy-empty">开心盒还空着，慢慢收集就好。<br>这里只有你选中的内容，不会自动挑选或推测心情。</div>'}<p class="photo-hint happy-footnote">内容保存在本机，可随完整备份一起带走。收进来的文字和照片会保留一份快照，原记录修改或删除都不会影响它。</p>`,'happy-box');
}
function card(item){return `<button type="button" class="happy-card" data-happy-action="detail" data-happy-id="${esc(item.id)}">${item.photos.length?photo(item.photos[0],'happy-thumb',item.title):`<span class="happy-card-symbol">${icon('heart')}</span>`}<span><strong>${esc(item.title)}</strong><small>${esc(item.note||[item.date,names[item.sourceKind]].filter(Boolean).join(' · '))}</small></span><span class="happy-chevron" aria-hidden="true">›</span></button>`;}
export function openHappyBoxPicker(entryId=''){
  if(entryId){const old=box.items.find(item=>item.sourceId===entryId);if(old){openDetail(old.id);ui.announce('这份开心已经收好，可以继续编辑');return;}const source=sourceRows().find(row=>row.id===entryId);if(source){openEditor(source);return;}ui.announce('请从现有的生活、美食或备注记录里挑一份');}
  editor=null;pickerQuery='';pickerLimit=30;renderPicker();
}
function renderPicker(){
  const rows=happySources(ui.getEntries?.()||[],pickerQuery),selected=new Set(box.items.map(item=>item.sourceId));
  show('挑一份小开心',`${back()}<p class="happy-picker-intro">从生活、美食和备注里选一条，再决定留下哪些文字和照片。</p><form data-form="happy-box-search" class="happy-search"><label class="visually-hidden" for="happy-query">搜索生活记录</label><input id="happy-query" name="happyQuery" value="${esc(pickerQuery)}" placeholder="搜标题、文字或日期" maxlength="100"><button type="submit" class="secondary" aria-label="搜索生活记录">${icon('search')}</button><p class="form-error" role="alert"></p></form><p class="photo-hint">${rows.length} 条可选记录 · 时光胶囊与最近删除不会出现在这里</p><div class="happy-list">${rows.slice(0,pickerLimit).map(row=>`<button type="button" class="happy-card" data-happy-action="select" data-happy-source="${esc(row.id)}">${row.photos.length?photo(row.photos[0],'happy-thumb',row.title):`<span class="happy-card-symbol">${icon(row.kind==='meal'?'recipes':'journal')}</span>`}<span><strong>${esc(row.title)}</strong><small>${esc([row.date,names[row.kind],selected.has(row.id)?'已经收好':''].filter(Boolean).join(' · '))}</small><small>${esc(row.note.slice(0,70))}</small></span><span class="happy-chevron" aria-hidden="true">›</span></button>`).join('')||'<div class="happy-empty">还没有找到合适的记录。可以换个词搜搜，或先在日历里记下一件小事。</div>'}</div>${rows.length>pickerLimit?'<button type="button" class="secondary" data-happy-action="more">再看看前面的记录</button>':''}`,'happy-box-picker');
}
function openEditor(source,existing=null){
  // The editor holds the visible photo list, so later edits to the source cannot silently change a selection.
  editor={source:{...source,photos:[...source.photos]},existing:existing?{...existing}:null,id:existing?.id||uid()};
  show(existing?'编辑这份小开心':'把这份开心收好',`${back(existing?'detail':'pick',existing?'返回这份开心':'重新挑选')}<form data-form="happy-box-save" data-id="${esc(editor.id)}"><p class="happy-source-label">${icon('journal')}来自 ${esc(source.date||'生活记录')} · ${esc(names[source.kind])}</p><label for="happy-title">开心的名字</label><input id="happy-title" name="happyTitle" value="${esc(existing?.title||source.title)}" maxlength="80" required><label for="happy-note">想留下的话 <small>可删改摘录</small></label><textarea id="happy-note" name="happyNote" maxlength="1000" rows="4" placeholder="只留一句话也很好">${esc((existing?.note??source.note).slice(0,1000))}</textarea>${source.photos.length?`<div class="section-title"><h3>想留下的照片</h3><span data-happy-photo-count>${source.photos.length} / ${source.photos.length}</span></div><p class="photo-hint">点选保留，也可以只收藏文字。</p><div class="happy-photo-picker">${source.photos.map((src,index)=>`<label class="happy-photo-choice"><input type="checkbox" name="happyPhoto" value="${index}" checked aria-label="收好第 ${index+1} 张照片"><span>${photo(src,'happy-pick-image',`第 ${index+1} 张生活照片`)}</span></label>`).join('')}</div>`:''}<p class="photo-hint">只修改开心盒里的摘录，原生活记录不会改变。${existing?'':'保存后会保留所选文字和照片的快照。'}</p><p class="form-error" role="alert"></p><button type="submit" class="primary">${icon('heart')}${existing?'保存这份开心':'收好选中的内容'}</button></form>`,'happy-box-edit');
  ui.sheet.dataset.happyId=existing?.id||'';ui.setDraft?.();
}
function openDetail(id,surprise=false){
  const item=itemById(id);if(!item){openHappyBox();return;}
  editor=null;const source=sourceRows().find(row=>row.id===item.sourceId);
  show(surprise?'给你一点小开心':item.title,`${back()}${surprise?`<div class="happy-reveal"><span class="happy-spark happy-spark-one" aria-hidden="true">✦</span>${bearArt('daily',id,'happy-reveal-bears',10)}<span class="happy-spark happy-spark-two" aria-hidden="true">♡</span><p>这份开心，一直好好地收着</p></div>`:''}<article class="happy-detail ${surprise?'happy-detail-reveal':''}"><p class="eyebrow">${esc([item.date,names[item.sourceKind]].filter(Boolean).join(' · '))}</p><h3>${esc(item.title)}</h3>${item.note?`<p class="happy-note">${esc(item.note)}</p>`:''}${item.photos.length?`<div class="happy-detail-photos ${item.photos.length===1?'one-photo':''}">${item.photos.map((src,index)=>`<button type="button" data-happy-action="photo" data-happy-id="${esc(item.id)}" data-happy-index="${index}" aria-label="查看第 ${index+1} 张照片">${photo(src,'happy-detail-photo',`${item.title}，照片 ${index+1}`)}</button>`).join('')}</div>`:''}</article><p class="photo-hint">${source?'这里是当时收好的快照，和原记录各自保存。':'原记录已不在当前列表，这份文字和照片仍然为你保留。'}</p><div class="happy-main-actions">${surprise&&box.items.length>1?'<button type="button" class="primary" data-happy-action="surprise">再给我一份开心</button>':''}${source?`<button type="button" class="secondary" data-happy-action="source" data-happy-id="${esc(item.id)}">${icon('journal')}看看原来的那一天</button>`:''}</div><div class="happy-management"><button type="button" class="text-button" data-happy-action="edit" data-happy-id="${esc(item.id)}">${icon('draft')}编辑摘录</button><button type="button" class="text-button danger" data-happy-action="remove" data-happy-id="${esc(item.id)}">移出开心盒</button></div>`,'happy-box-detail');
  ui.sheet.dataset.happyId=item.id;
}
export async function happyBoxSubmitted(form){
  if(form.dataset.form==='happy-box-search'){pickerQuery=String(new FormData(form).get('happyQuery')||'').trim().slice(0,100);pickerLimit=30;renderPicker();return true;}
  if(form.dataset.form!=='happy-box-save')return false;
  if(!editor||form.dataset.id!==editor.id)throw new Error('这份摘录已变化，请重新打开后保存');
  const active=editor,values=new FormData(form),selection={title:values.get('happyTitle'),note:values.get('happyNote'),photoIndices:values.getAll('happyPhoto')};
  const snapshot=makeHappySnapshot(active.source,selection,active.existing,Date.now(),active.id);
  await commit(current=>upsertHappyItem(current,snapshot));
  if(editor===active&&ui.sheet.dataset.view==='happy-box-edit')openDetail(box.items.find(item=>item.sourceId===snapshot.sourceId)?.id||snapshot.id);
  ui.announce(active.existing?'开心摘录已保存':'熊熊把这份开心收好啦');
  return true;
}
export function happyBoxChanged(input){
  if(input.name==='happyPhoto'){
    const counter=ui.sheet.querySelector('[data-happy-photo-count]');if(counter)counter.textContent=`${ui.sheet.querySelectorAll('[name="happyPhoto"]:checked').length} / ${editor?.source.photos.length||0}`;return true;
  }
  return ['happyTitle','happyNote','happyQuery'].includes(input.name);
}
export async function happyBoxClicked(data){
  const action=data.happyAction;if(!action)return false;
  if(action==='home')leave(openHappyBox);
  else if(action==='pick')leave(()=>openHappyBoxPicker());
  else if(action==='more'){const scroll=ui.sheet.querySelector('.sheet-content')?.scrollTop||0;pickerLimit+=30;renderPicker();const panel=ui.sheet.querySelector('.sheet-content');if(panel)panel.scrollTop=scroll;}
  else if(action==='select'){const source=sourceRows().find(row=>row.id===data.happySource),old=box.items.find(item=>item.sourceId===data.happySource);if(old)openDetail(old.id);else if(source)openEditor(source);else ui.announce('这条记录已经不在当前列表');}
  else if(action==='detail'){const id=data.happyId||ui.sheet.dataset.happyId;leave(()=>openDetail(id));}
  else if(action==='surprise'){const item=chooseHappyItem(box,lastShown);if(item){lastShown=item.id;openDetail(item.id,true);}else openHappyBox();}
  else if(action==='edit'){const item=itemById(data.happyId);if(item)openEditor({id:item.sourceId||item.id,kind:item.sourceKind,date:item.date,title:item.title,note:item.note,photos:item.photos},item);}
  else if(action==='source'){const item=itemById(data.happyId),source=item&&sourceRows().find(row=>row.id===item.sourceId);if(source)ui.showEntry?.(source.id,source.date);else ui.announce('原记录已经不在当前列表，开心盒快照仍然保留');}
  else if(action==='photo'){const item=itemById(data.happyId),index=Number(data.happyIndex);if(item&&Number.isInteger(index)&&index>=0&&index<item.photos.length)ui.showPhotos?.(item.photos,index,item.title);}
  else if(action==='remove'){const item=itemById(data.happyId);if(item){show('把这份开心移出盒子？',`<section class="happy-remove">${icon('heart')}<h3>${esc(item.title)}</h3><p>移出后，盒子里的这份快照不再保留；原生活记录不会改变。</p></section><div class="happy-main-actions"><button type="button" class="primary" data-happy-action="detail" data-happy-id="${esc(item.id)}">继续收好</button><button type="button" class="secondary danger" data-happy-action="remove-confirm" data-happy-id="${esc(item.id)}">移出开心盒</button></div>`,'happy-box-remove');ui.sheet.dataset.happyId=item.id;}}
  else if(action==='remove-confirm'){await commit(current=>removeHappyItem(current,data.happyId));openHappyBox();ui.announce('已移出开心盒，原记录保留');}
  return true;
}
export function happyBoxBack(){
  const view=ui.sheet.dataset.view;
  if(view==='happy-box-edit'){leave(()=>editor?.existing?openDetail(editor.existing.id):openHappyBoxPicker());return true;}
  if(view==='happy-box-remove'){openDetail(ui.sheet.dataset.happyId);return true;}
  if(view==='happy-box-picker'||view==='happy-box-detail'){openHappyBox();return true;}
  return false;
}
