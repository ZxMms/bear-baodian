export function isXhsHost(host){
  const value=String(host||'').toLowerCase();
  return ['xiaohongshu.com','xhslink.com','xhslink.cn'].some(domain=>value===domain||value.endsWith('.'+domain));
}
export function xhsLink(input){
  const text=String(input||'').trim();if(!text)return '';
  // Accept the whole share message; domain changes must not block saving a recipe.
  const candidates=text.match(/https?:\/\/[^\s<>"'“”‘’，。；！【】\u4e00-\u9fff]+/gi)||[];
  if(!candidates.length){const bare=text.match(/(?:^|[\s（(【])((?:www\.)?(?:xhslink\.(?:cn|com)|xiaohongshu\.com)\/[^\s<>"'“”‘’，。；！【】\u4e00-\u9fff]+)/i);if(bare)candidates.push('https://'+bare[1]);}
  const links=[];
  for(const candidate of candidates){
    try{
      const url=new URL(candidate.replace(/[),.;!?）〉》\]}]+$/g,''));
      if(!['https:','http:'].includes(url.protocol)||!url.hostname||url.username||url.password)continue;
      links.push(url);
    }catch{}
  }
  return (links.find(url=>isXhsHost(url.hostname))||links[0])?.href||'';
}
export function recipeFromMeal(entry,details,id){
  const xhsText=String(details.xhsText||details.xhsUrl||'').trim();
  return {id,title:entry.title,category:details.category||'其他',photos:details.cover?[details.cover]:[],ingredients:String(details.ingredients||'').trim(),steps:String(details.steps||'').trim(),xhsText,xhsUrl:xhsLink(xhsText),starter:false,created:Date.now()};
}

// Seasonal food inspiration, not nutrition or health advice. Regions and tastes vary.
export const seasonalFoods={
  立春:{hint:'春卷、嫩芽和时蔬',words:['春卷','春饼','豆芽','韭菜','菠菜'],categories:['素菜']},
  雨水:{hint:'一碗热粥或清汤',words:['粥','汤','山药','菌菇'],categories:['汤羹']},
  惊蛰:{hint:'清爽时蔬，换换口味',words:['春笋','芦笋','荠菜','豌豆'],categories:['素菜']},
  春分:{hint:'把春日蔬菜端上桌',words:['香椿','春笋','菠菜','荠菜'],categories:['素菜']},
  清明:{hint:'青团与春日鲜味',words:['青团','艾草','笋','荠菜'],categories:['素菜','甜品']},
  谷雨:{hint:'嫩笋、豌豆与清蒸鲜味',words:['笋','豌豆','香椿','清蒸'],categories:['素菜','海鲜']},
  立夏:{hint:'清爽凉面，简单吃好',words:['拌面','凉面','黄瓜','番茄'],categories:['面食','素菜']},
  小满:{hint:'清爽蔬菜和家常小炒',words:['黄瓜','苦瓜','莴笋','清炒'],categories:['素菜']},
  芒种:{hint:'清爽拌菜与时令瓜果',words:['黄瓜','凉拌','冬瓜','丝瓜'],categories:['素菜','汤羹']},
  夏至:{hint:'来一碗清爽的面',words:['凉面','拌面','面条','黄瓜'],categories:['面食']},
  小暑:{hint:'瓜类菜肴和清汤',words:['丝瓜','冬瓜','绿豆','凉拌'],categories:['素菜','汤羹']},
  大暑:{hint:'清爽、简单的家常菜',words:['冬瓜','丝瓜','黄瓜','绿豆'],categories:['素菜','汤羹']},
  立秋:{hint:'南瓜、玉米与初秋家常味',words:['南瓜','玉米','茄子','莲藕'],categories:['素菜']},
  处暑:{hint:'莲藕与柔和汤羹',words:['莲藕','银耳','鸭','百合'],categories:['汤羹']},
  白露:{hint:'梨、银耳与温热汤羹',words:['梨','银耳','莲藕','百合'],categories:['汤羹','甜品']},
  秋分:{hint:'秋日菌菇和南瓜',words:['菌菇','香菇','南瓜','莲藕'],categories:['素菜','汤羹']},
  寒露:{hint:'热汤、山药与秋日小菜',words:['山药','汤','板栗','南瓜'],categories:['汤羹']},
  霜降:{hint:'炖菜和一锅热汤',words:['炖','汤','萝卜','牛肉'],categories:['汤羹','肉菜']},
  立冬:{hint:'饺子、热汤与炖菜',words:['饺','汤','炖','萝卜'],categories:['汤羹','面食']},
  小雪:{hint:'热汤面和温热家常菜',words:['汤','炖','面','白菜'],categories:['汤羹','面食']},
  大雪:{hint:'热炖菜与冬日汤羹',words:['炖','汤','萝卜','羊肉'],categories:['汤羹','肉菜']},
  冬至:{hint:'饺子、汤圆，各有家乡味',words:['饺','汤圆','馄饨','羊肉'],categories:['面食','汤羹']},
  小寒:{hint:'砂锅、热粥与炖菜',words:['砂锅','粥','炖','汤'],categories:['汤羹','肉菜']},
  大寒:{hint:'热腾腾的年味家常菜',words:['饺','炖','汤','年糕'],categories:['汤羹','面食']},
};
const termCache=new Map();
export function seasonalContext(date){
  if(typeof date!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(date))return null;
  if(termCache.has(date))return termCache.get(date);
  const year=Number(date.slice(0,4));
  if(!globalThis.Solar||year<1900||year>2100)return null;
  try{
    const [y,m,d]=date.split('-').map(Number),day=Date.UTC(y,m-1,d);
    if(new Date(day).toISOString().slice(0,10)!==date)return null;
    const lunar=globalThis.Solar.fromYmd(y,m,d).getLunar();
    // Food inspiration follows calendar days, including the whole solar-term day.
    // Showing the complete span prevents a term that lasts ~15 days looking stale.
    const current=lunar.getPrevJieQi(true),next=lunar.getNextJieQi(true);
    if(!current||!next)return null;
    const name=current.getName(),startDate=current.getSolar().toYmd(),nextDate=next.getSolar().toYmd();
    const recipe=seasonalFoods[name];if(!recipe)return null;
    const nextDay=Date.parse(nextDate+'T00:00:00Z');
    const result={name,...recipe,date,startDate,endDate:new Date(nextDay-86400000).toISOString().slice(0,10),nextName:next.getName(),nextDate,daysUntilNext:Math.round((nextDay-day)/86400000),isTermDay:startDate===date};
    // Keep browsing many distant dates from retaining an unbounded cache.
    if(termCache.size>=512)termCache.delete(termCache.keys().next().value);
    termCache.set(date,result);return result;
  }catch{return null;}
}
export function seasonalMatch(recipe,season){
  if(!season)return {score:0,reason:''};
  const text=recipe.title+' '+(recipe.ingredients||'');
  const keyword=season.words.find(word=>text.includes(word));
  if(keyword)return {score:50,reason:`${season.name}灵感 · ${keyword}类菜肴`};
  if(season.categories.includes(recipe.category))return {score:25,reason:`${season.name}灵感 · ${season.hint}`};
  return {score:0,reason:''};
}
