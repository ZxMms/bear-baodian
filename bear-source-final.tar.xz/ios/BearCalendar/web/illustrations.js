export const bearScenes = {
  daily: ["一起写手账","合个影吧","热饮和一本书","给绿植浇水","同撑一把伞","围巾和初雪","春日野餐","一起看月亮","累了抱一抱","难过也陪你","开心的气球","安静地依偎"],
  kitchen: ["一起做面条","尝一口热汤","洗洗小蔬菜","包一盘饺子","做个小蛋糕","葱姜蒸鱼","提篮买菜","早餐三明治","鲜虾上桌","草莓小甜点","翻开菜谱","一起吃晚饭"],
  moments: ["存下小幸福","一起记账","整理小票","计划小预算","为你备礼物","圈起纪念日","带你去旅行","生日快乐","送你一束花","翻翻相册","分享小日子","完成小目标"],
};
export function artIndex(key, count = 12) { let hash=0; for(const char of String(key)) hash=(hash*31+char.charCodeAt(0))>>>0; return hash%count; }
export function artMeta(group, key, fixed = null) {
  const index = fixed ?? artIndex(key);
  return { group, index, name:bearScenes[group][index], src:`assets/bears-${group}.webp`, x:index%4, y:Math.floor(index/4) };
}
export function bearArt(group, key, css = "", fixed = null) {
  const art=artMeta(group,key,fixed);
  return `<span class="bear-art bear-art-${group} ${css}" role="img" aria-label="一二布布 · ${art.name}" style="background-position:${art.x*100/3}% ${art.y*50}%"></span>`;
}
export function moodArt(mood, date) {
  const choices={happy:[1,3,6,10],calm:[0,2,7,11],hopeful:[6,10],tired:[8,11],sad:[9]};
  if(!choices[mood]) return `<span class="mood-sprite mood-${mood}" role="img" aria-label="一二布布生气的表情"></span>`;
  const group=choices[mood]; return bearArt("daily",date,"",group[artIndex(date,group.length)]);
}
