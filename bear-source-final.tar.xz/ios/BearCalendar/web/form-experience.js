// Shared feedback for all sheet forms. No dependency or network request required.
function fieldLabel(field) {
  return field.labels?.[0]?.textContent.trim().replace(/\s+/g, ' ') || field.getAttribute('aria-label') || '这一项';
}

function errorText(field) {
  const validity = field.validity, label = fieldLabel(field);
  if (validity.valueMissing) return field.type === 'checkbox' ? `请先确认：${label}` : `请填写${label}`;
  if (validity.rangeUnderflow) return `${label}不能小于 ${field.min}`;
  if (validity.rangeOverflow) return `${label}不能大于 ${field.max}`;
  if (validity.tooLong) return `${label}最多填写 ${field.maxLength} 个字`;
  return field.validationMessage || `请检查${label}的格式`;
}

function reveal(target) {
  for (let parent = target.parentElement; parent; parent = parent.parentElement) {
    if (parent.tagName === 'DETAILS') parent.open = true;
  }
  target.focus({preventScroll: true});
  target.scrollIntoView({block: 'center', behavior: 'auto'});
}

function clearFieldError(field) {
  const id = field.dataset.uiError;
  if (!id) return;
  field.ownerDocument.getElementById(id)?.remove();
  const descriptions = (field.getAttribute('aria-describedby') || '').split(/\s+/).filter(value => value && value !== id);
  if (descriptions.length) field.setAttribute('aria-describedby', descriptions.join(' '));
  else field.removeAttribute('aria-describedby');
  field.removeAttribute('aria-invalid');
  delete field.dataset.uiError;
}

export function clearFormErrors(form) {
  for (const field of form.querySelectorAll('[data-ui-error]')) clearFieldError(field);
  const notice = form.querySelector('.form-error');
  if (notice) notice.textContent = '';
}

export function reportFormError(form, message) {
  if (!form.isConnected) return false;
  const notice = form.querySelector('.form-error');
  if (!notice) return false;
  notice.textContent = message;
  notice.setAttribute('role', 'alert');
  notice.tabIndex = -1;
  reveal(notice);
  return true;
}

export function initSheetExperience(sheet) {
  const win = sheet.ownerDocument.defaultView;
  let errorId = 0, firstInvalid = null, header = null, frame = 0;
  const updateSize = () => {
    frame = 0;
    const content = sheet.querySelector('.sheet-content');
    if (!content) return;
    const height = header?.getBoundingClientRect().height || 88;
    content.style.setProperty('--sheet-header-height', `${Math.ceil(height)}px`);
    if (win.visualViewport) content.style.setProperty('--sheet-visible-height', `${Math.max(160, Math.floor(win.visualViewport.height - 12))}px`);
  };
  const scheduleSize = () => { if (!frame) frame = win.requestAnimationFrame(updateSize); };
  const resize = typeof win.ResizeObserver === 'function' ? new win.ResizeObserver(scheduleSize) : null;
  const contentChanged = () => {
    const next = sheet.querySelector('.sheet-header');
    if (next !== header) {
      resize?.disconnect(); header = next;
      if (header) resize?.observe(header);
    }
    scheduleSize();
  };
  const observer = new win.MutationObserver(contentChanged);
  observer.observe(sheet, {childList: true});
  win.visualViewport?.addEventListener('resize', scheduleSize);
  win.addEventListener('resize', scheduleSize);

  const invalid = event => {
    const field = event.target;
    if (!field.form || !field.willValidate) return;
    event.preventDefault();
    clearFieldError(field);
    const note = sheet.ownerDocument.createElement('p');
    note.className = 'field-error';
    note.id = `field-error-${++errorId}`;
    note.textContent = errorText(field);
    const wrapper = field.closest('label');
    (wrapper || field).insertAdjacentElement('afterend', note);
    field.dataset.uiError = note.id;
    field.setAttribute('aria-invalid', 'true');
    field.setAttribute('aria-describedby', [field.getAttribute('aria-describedby'), note.id].filter(Boolean).join(' '));
    if (!firstInvalid) {
      firstInvalid = field;
      queueMicrotask(() => {
        const target = firstInvalid; firstInvalid = null;
        if (target?.isConnected) reveal(target);
      });
    }
  };
  const edited = event => { if (event.target.validity?.valid) clearFieldError(event.target); };
  sheet.addEventListener('invalid', invalid, true);
  sheet.addEventListener('input', edited);
  sheet.addEventListener('change', edited);
  contentChanged();
  return {destroy() {
    observer.disconnect(); resize?.disconnect(); win.cancelAnimationFrame(frame);
    win.removeEventListener('resize', scheduleSize);
    win.visualViewport?.removeEventListener('resize', scheduleSize);
    sheet.removeEventListener('invalid', invalid, true);
    sheet.removeEventListener('input', edited); sheet.removeEventListener('change', edited);
  }};
}
