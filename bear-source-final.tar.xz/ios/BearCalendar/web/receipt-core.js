// Conservative suggestions, never a posted transaction. The user must confirm every import.
export function parseReceipt(raw, fallbackDate) {
  const text=String(raw||'').normalize('NFKC').replace(/(?<=[\u3400-\u9fff])[ \t]+(?=[\u3400-\u9fff])/g,'');
  const lines=text.split(/\r?\n/).map(line=>line.trim()).filter(Boolean);
  const candidates=[];
  for(let i=0;i<lines.length;i++) {
    const line=lines[i], previous=lines[i-1]||'', context=line+' '+previous;
    if(/余额|优惠|减免|折扣|积分|订单号|商户单号|交易单号|手机号|银行卡|原价|商品金额|运费|手续费/.test(line)) continue;
    const labelled=/实付|实付款|付款金额|支付金额|交易金额|收款金额|到账金额|退款金额|实际支付|合计|总计/.test(context);
    const pattern=/(?:[¥￥]\s*|[+\-]\s*)(\d[\d,]*(?:\.\d{1,2})?)|(\d[\d,]*\.\d{2})(?:\s*元)?/g;
    const amountLine=line.replace(/20\d{2}\s*[年/.-]\s*\d{1,2}\s*[月/.-]\s*\d{1,2}日?/g,'').replace(/\b\d{1,2}:\d{2}(?::\d{2})?\b/g,'');
    const matches=[...amountLine.matchAll(pattern)];
    if(!matches.length&&labelled&&/^\d{1,7}(?:元)?$/.test(line)) matches.push([line,line.replace('元','')]);
    for(const match of matches) {
      const value=(match[1]||match[2]).replaceAll(',','');
      if(!/^\d{1,7}(?:\.\d{1,2})?$/.test(value))continue;
      const [whole,decimal='']=value.split('.'),cents=Number(whole)*100+Number(decimal.padEnd(2,'0'));
      if(cents<=0||cents>999999999)continue;
      let score=labelled?100:0;
      if(/[¥￥+\-]/.test(match[0]))score+=35;
      if(/成功|已支付|完成/.test(context))score+=15;
      if(i<6)score+=10;
      if(/余额|优惠|减免|原价|积分/.test(previous)&&!labelled)score-=100;
      if(score>=0)candidates.push({cents,score,context:line});
    }
  }
  const amounts=new Map();
  for(const candidate of candidates.sort((a,b)=>b.score-a.score)) if(!amounts.has(candidate.cents))amounts.set(candidate.cents,candidate);
  const unique=[...amounts.values()];
  const dateMatch=text.match(/(20\d{2})\s*[年/.-]\s*(\d{1,2})\s*[月/.-]\s*(\d{1,2})/);
  let date=fallbackDate,dateFound=false;
  if(dateMatch){const proposed=`${dateMatch[1]}-${dateMatch[2].padStart(2,'0')}-${dateMatch[3].padStart(2,'0')}`,d=new Date(proposed+'T12:00:00');if(!Number.isNaN(d.valueOf())&&d.getFullYear()===+dateMatch[1]&&d.getMonth()+1===+dateMatch[2]&&d.getDate()===+dateMatch[3]){date=proposed;dateFound=true;}}
  const type=/收款成功|收入|到账金额|已收款|退款成功|已退款/.test(text)?'income':'expense';
  let merchant='';
  for(let i=0;i<lines.length;i++) {
    const match=lines[i].match(/^(?:商家|商户全称|商户名称|收款方|商品说明|交易对方|付款方)\s*[:：]?\s*(.*)/);
    if(match){merchant=(match[1]||lines[i+1]||'').slice(0,60);break;}
  }
  const categories=[[/超市|生鲜|菜场|买菜|水果|蔬菜/,'category-1'],[/餐饮|餐厅|饭店|咖啡|奶茶|外卖|面馆|小吃|早餐/,'category-0'],[/地铁|公交|打车|出租车|滴滴|停车|加油/,'category-2'],[/电费|水费|燃气|房租|物业/,'category-4'],[/药房|医院|挂号|诊所/,'category-6'],[/电影|游戏|门票/,'category-5'],[/淘宝|京东|拼多多|商城|购物/,'category-3']];
  const category=type==='income'?(/工资|薪资/.test(text)?'category-8':'category-11'):(categories.find(([pattern])=>pattern.test(merchant||text))?.[1]||'category-7');
  const warnings=[];
  if(!unique.length)warnings.push('未确定交易金额，请手动填写。');
  else if(unique.length>1)warnings.push('发现多个金额，请核对实际收支金额。');
  if(!dateFound)warnings.push('未识别到完整交易日期，暂填今天，请核对。');
  if(/待支付|未支付|已关闭|退款中|处理中|交易失败/.test(text))warnings.push('截图可能不是已完成交易，请确认是否需要记账。');
  if(/[\$€£]|USD|HKD|港币|美元|欧元/.test(text))warnings.push('截图可能含外币；账本使用人民币，请换算后手动填写。');
  return {cents:unique[0]?.cents||null,candidates:unique.slice(0,6),date,dateFound,type,category,merchant,warnings};
}
