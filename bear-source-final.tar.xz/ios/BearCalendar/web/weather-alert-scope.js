// Publication area matching, not an assertion that an alert covers a GPS point.
const municipalities = new Set(['北京市', '天津市', '上海市', '重庆市']);
const clean = value => typeof value === 'string' && /^[\u3400-\u9fff·]{2,40}$/.test(value) ? value : '';
const suffix = /(?:自治州|地区|市|区|县|盟)$/;
const normalized = value => value.replace(suffix, '');
function forms(value) {
  const name = clean(value); if (!name) return [];
  return suffix.test(name) ? [name, normalized(name)] : [name+'市',name+'区',name+'县',name+'地区',name+'盟',name];
}
function exact(region, name) { return forms(name).includes(region); }
function childOf(region, name) {
  return forms(name).filter(part => suffix.test(part)).some(part => region.startsWith(part) && region.length > part.length);
}
export function areaForPlace(place, province) {
  if (!place || place.countryCode !== 'CN' || !clean(province)) return null;
  const supplied = place.alertArea;
  if (place.source === 'location' && ['geocoder','district-boundary'].includes(supplied?.source) && supplied.province === province) {
    const city = clean(supplied.city), district = clean(supplied.district);
    if (city || district) return {province,city,district,districtUnique:supplied.districtUnique === true,selected:'',mode:district?'district':'city',label:district || city};
  }
  if (place.source === 'city') {
    if (place.alertNameAmbiguous === true) return null;
    const selected = clean(place.name);
    if (selected) return {province,city:municipalities.has(province) && exact(selected,province)?province:'',district:'',selected,mode:'selected',label:selected};
  }
  return null;
}
export function placeScopeKey(place, province) {
  const area = areaForPlace(place, province);
  return area ? JSON.stringify([area.province,area.city,area.district,area.districtUnique,area.selected,area.mode]) : province || '';
}
function publisher(row, area) {
  if (!area || typeof row?.title !== 'string' || !row.title.startsWith(area.province)) return null;
  const rest = row.title.slice(area.province.length);
  const match = /^([\u3400-\u9fff·]{0,65}?)(?:气象台|气象局)(?=.{0,12}(?:发布|更新|解除|变更|继续))/.exec(rest);
  return match ? match[1] : null;
}
export function classifyAlert(row, area) {
  const region = publisher(row,area);
  if (region === null) return 'unknown';
  if (!region) return municipalities.has(area.province) ? 'local' : 'parent';
  const {city,district,selected} = area;
  if (district) {
    if (exact(region,district)) return area.districtUnique || municipalities.has(area.province) ? 'local' : 'unknown';
    if (city && forms(city).some(part => suffix.test(part) && region.startsWith(part) && exact(region.slice(part.length),district))) return 'local';
    if (city && exact(region,city)) return 'local';
    return 'other';
  }
  if (city) {
    if (city === area.province || exact(region,city) || childOf(region,city)) return 'local';
    // A bare county title gives no verified parent city.
    return /(?:县|区)$/.test(region) && !/(?:市|自治州|地区|盟).+(?:县|区)$/.test(region) ? 'unknown' : 'other';
  }
  if (selected) {
    if (exact(region,selected) || childOf(region,selected)) return 'local';
    // Explicitly selected counties can appear after a named parent city.
    if (forms(selected).some(part => region.endsWith(part) && suffix.test(region.slice(0,-part.length)))) return 'local';
    return 'unknown';
  }
  return 'unknown';
}
export function buildAlertView(rows, area) {
  const groups = {local:[],parent:[],other:[],unknown:[]};
  const seen = new Set();
  for (const row of Array.isArray(rows) ? rows : []) {
    if (!row || typeof row !== 'object') continue;
    const identity = row.id || row.url;
    if (identity && seen.has(identity)) continue;
    if (identity) seen.add(identity);
    groups[classifyAlert(row,area)].push(row);
  }
  const rank = {red:4,orange:3,yellow:2,blue:1};
  const severity = row => Object.prototype.hasOwnProperty.call(rank,row.level) ? rank[row.level] : 0;
  for (const group of Object.values(groups)) group.sort((a,b) => severity(b)-severity(a) || b.issuedAt-a.issuedAt || String(a.id||'').localeCompare(String(b.id||'')));
  return groups;
}
