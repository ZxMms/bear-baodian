import {wishCents,wishMoney,wishDate,MAX_CENTS} from './wishes-core.js?v=37';

export const GOLD_KEY='feature:gold-goals';
const MAX_MG=999999999;
const copy=value=>JSON.parse(JSON.stringify(value));
const text=(value,length)=>String(value??'').trim().slice(0,length);
const valid=(value,max)=>Number.isSafeInteger(value)&&value>0&&value<=max;
export const goldMoney=wishMoney;
export function goldMilligrams(value){
  const input=String(value??'').trim();
  if(!/^(?:0|[1-9]\d{0,5})(?:\.\d{1,3})?$/.test(input))throw new Error('克重请填写正数，最多三位小数');
  const [whole,fraction='']=input.split('.'),mg=Number(whole)*1000+Number(fraction.padEnd(3,'0'));
  if(!valid(mg,MAX_MG))throw new Error('克重需在 0.001–999,999.999 克之间');
  return mg;
}
export const goldGrams=mg=>(mg/1000).toLocaleString('zh-CN',{maximumFractionDigits:3});
export function goldProgress(goal){
  const purchases=(goal?.purchases||[]).filter(row=>!row.removedAt),mg=purchases.reduce((s,r)=>s+r.mg,0),cents=purchases.reduce((s,r)=>s+r.cents,0),target=goal?.targetMg||0;
  return {mg,cents,count:purchases.length,remaining:Math.max(0,target-mg),extra:Math.max(0,mg-target),percent:target?Math.min(100,mg/target*100):0,ready:target>0&&mg>=target,averageCents:mg?Math.round(cents*1000/mg):null};
}
export function normalizeGold(value){
  const ids=new Set();
  const goals=(Array.isArray(value?.goals)?value.goals:[]).filter(g=>g&&typeof g.id==='string'&&g.id&&g.id.length<200&&!ids.has(g.id)&&(ids.add(g.id),true)&&valid(g.targetMg,MAX_MG)).map(g=>{
    const seen=new Set();let mg=0,cents=0;
    const purchases=(Array.isArray(g.purchases)?g.purchases:[]).filter(r=>{
      if(!r||typeof r.id!=='string'||!r.id||r.id.length>200||seen.has(r.id)||!valid(r.mg,MAX_MG)||!valid(r.cents,MAX_CENTS)||!wishDate(r.date))return false;
      if(!r.removedAt&&(mg+r.mg>MAX_MG||cents+r.cents>MAX_CENTS))return false;
      seen.add(r.id);if(!r.removedAt){mg+=r.mg;cents+=r.cents;}return true;
    }).map(r=>({...r,brand:text(r.brand,40),note:text(r.note,240),feeCents:Number.isSafeInteger(r.feeCents)&&r.feeCents>=0&&r.feeCents<=r.cents?r.feeCents:null,ledgerId:text(r.ledgerId,250),removedAt:Number(r.removedAt)||0}));
    return {id:g.id,title:text(g.title,40)||'我的买金小目标',targetMg:g.targetMg,note:text(g.note,240),purchases,created:Number(g.created)||0,updated:Number(g.updated)||0,archivedAt:Number(g.archivedAt)||0};
  });
  return {version:1,goals};
}

// A purchase and its optional bill commit together. IDs remain stable across edits,
// retries and re-linking. Gold records never represent a payment or a live quote.
export function createGoldStore({read,atomic,loadLedger,loadCategories,now=()=>Date.now(),id=()=>crypto.randomUUID()}){
  let state={version:1,goals:[]},tail=Promise.resolve();
  const enqueue=fn=>{const next=tail.then(fn);tail=next.catch(()=>{});return next;};
  const get=(next,goalId)=>{const goal=next.goals.find(g=>g.id===goalId);if(!goal)throw new Error('找不到这个买金目标');return goal;};
  const mutate=fn=>enqueue(async()=>{
    // Refresh before mutation so a restored backup or another screen is respected.
    const next=normalizeGold(await read(GOLD_KEY)),writes=[];
    const result=await fn(next,writes);
    writes.push({store:'settings',key:GOLD_KEY,value:next});
    await atomic(writes);state=normalizeGold(next);return result;
  });
  return {
    load:()=>enqueue(async()=>{state=normalizeGold(await read(GOLD_KEY));return copy(state.goals);}),
    list:()=>copy(state.goals),
    saveGoal:input=>mutate(next=>{
      const existing=input.id?get(next,input.id):null;
      if(!existing&&next.goals.length>=100)throw new Error('最多保存 100 个买金目标');
      const title=text(input.title,40);if(!title)throw new Error('给小目标起个名字吧');
      const goal={...existing,id:existing?.id||id(),title,targetMg:goldMilligrams(input.target),note:text(input.note,240),purchases:existing?.purchases||[],created:existing?.created||now(),updated:now(),archivedAt:existing?.archivedAt||0};
      next.goals=[...next.goals.filter(g=>g.id!==goal.id),goal];return goal.id;
    }),
    savePurchase:(goalId,input)=>mutate(async(next,writes)=>{
      const goal=get(next,goalId);if(goal.archivedAt)throw new Error('请先恢复这个目标，再记录购入');
      const existing=goal.purchases.find(r=>r.id===input.id);
      if(existing?.removedAt)throw new Error('这笔购入记录已经移除');
      if(!existing&&goal.purchases.length>=1000)throw new Error('这个目标已有 1000 条记录，请新建一个目标');
      if(!wishDate(input.date))throw new Error('请选择正确的购入日期');
      const mg=goldMilligrams(input.grams),cents=wishCents(input.amount),rawFee=String(input.fee??'').trim();
      let feeCents;
      try{feeCents=rawFee===''?null:/^0(?:\.0{1,2})?$/.test(rawFee)?0:wishCents(rawFee);}catch{throw new Error('工费请填写 0 或正数金额，最多两位小数');}
      if(feeCents>cents)throw new Error('工费已经包含在实付金额中，不能高于实付金额');
      const progress=goldProgress(goal);
      if(progress.mg-(existing?.mg||0)+mg>MAX_MG||progress.cents-(existing?.cents||0)+cents>MAX_CENTS)throw new Error('累计克重或金额超出可记录范围');
      const purchaseId=existing?.id||input.id||id();
      if(!/^[\w-]{1,200}$/.test(purchaseId))throw new Error('记录标识无效，请重新打开');
      const row={...existing,id:purchaseId,date:input.date,mg,cents,feeCents,brand:text(input.brand,40),note:text(input.note,240),created:existing?.created||now(),updated:now(),removedAt:0,ledgerId:existing?.ledgerId||`gold-bill-${purchaseId}`};
      const ledger=await loadLedger(),bill=ledger.find(r=>r.id===row.ledgerId);
      if(bill&&(bill.goldGoalId!==goalId||bill.goldPurchaseId!==purchaseId))throw new Error('关联账单发生变化，请重新打开后核对');
      if(input.syncLedger){
        const categories=await loadCategories(),category=categories.find(c=>c.id===bill?.category&&c.type==='expense')||categories.find(c=>c.name==='买金'&&c.type==='expense');
        const categoryId=category?.id||'category-gold';
        if(!category){if(categories.some(c=>c.id===categoryId))throw new Error('买金分类标识已被使用，请检查分类');writes.push({store:'ledgerCategories',value:{id:categoryId,type:'expense',name:'买金',icon:'◇'}});}
        writes.push({store:'ledger',value:{...bill,id:row.ledgerId,type:'expense',category:categoryId,date:row.date,cents:row.cents,note:`买金 · ${row.brand?row.brand+' · ':''}${goldGrams(mg)} 克${row.note?' · '+row.note:''}`.slice(0,200),photos:bill?.photos||[],created:bill?.created||now(),goldGoalId:goalId,goldPurchaseId:purchaseId,_deletedAt:0,_deleteExpiresAt:0}});
      }else if(bill&&!bill._deletedAt){
        // Opting out removes only the bill from current totals; the purchase stays.
        const removedAt=now();writes.push({store:'ledger',value:{...bill,_deletedAt:removedAt,_deleteExpiresAt:removedAt+30*86400000}});
      }
      goal.purchases=[...goal.purchases.filter(r=>r.id!==row.id),row];goal.updated=now();return row.id;
    }),
    removePurchase:(goalId,purchaseId)=>mutate(async(next,writes)=>{
      const goal=get(next,goalId),row=goal.purchases.find(r=>r.id===purchaseId);
      if(!row||row.removedAt)throw new Error('这笔购入已经移除');
      row.removedAt=now();goal.updated=now();
      // Preserve actual expense history and turn it into an ordinary bill.
      const bill=(await loadLedger()).find(r=>r.id===row.ledgerId&&r.goldGoalId===goalId&&r.goldPurchaseId===purchaseId);
      if(bill)writes.push({store:'ledger',value:{...bill,goldGoalId:'',goldPurchaseId:''}});
      return goalId;
    }),
    archive:(goalId,archived)=>mutate(next=>{const goal=get(next,goalId);goal.archivedAt=archived?now():0;goal.updated=now();return goalId;})
  };
}
