import Foundation

/// Only fixed, anonymous public quotes. No stored responses or app/account information.
final class GoldQuotes: NSObject, URLSessionDataDelegate, URLSessionTaskDelegate {
    private struct Job { let id: String; let kind: String; var data = Data() }
    private var jobs = [Int: Job]()
    private var tasks = [Int: URLSessionDataTask]()
    private var session: URLSession!
    private let result: (String, [String: Any]) -> Void
    init(result: @escaping (String, [String: Any]) -> Void) {
        self.result = result; super.init()
        let config = URLSessionConfiguration.ephemeral
        config.urlCache = nil; config.httpCookieStorage = nil; config.requestCachePolicy = .reloadIgnoringLocalCacheData
        config.timeoutIntervalForRequest = 8; config.timeoutIntervalForResource = 12
        session = URLSession(configuration: config, delegate: self, delegateQueue: .main)
    }
    func cancel() { tasks.values.forEach { $0.cancel() }; tasks.removeAll(); jobs.removeAll() }
    func stop() { cancel(); session.invalidateAndCancel() }
    func request(_ id: String, kind: String) {
        guard id.range(of: "^[0-9]{1,12}$", options: .regularExpression) != nil, ["quote","history","brands"].contains(kind) else { return }
        // UI calls cancel before a new batch. IDs also guard obsolete callbacks.
        let brands = kind == "brands"
        let url = brands ? "https://precious.smm.cn/gold-price" : "https://ms.jr.jd.com/gw2/generic/ugActs/h5/m/" + (kind == "quote" ? "queryStockData" : "queryStockKLine")
        var request = URLRequest(url: URL(string: url)!, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 8)
        request.setValue("no-cache, no-store", forHTTPHeaderField: "Cache-Control")
        request.setValue("BearBaodian/2.2.18", forHTTPHeaderField: "User-Agent")
        if !brands {
            request.httpMethod = "POST"; request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            var params = ["stockCode": "SGE-Au99.99"]; if kind == "history" { params["kType"] = "day" }
            request.httpBody = try? JSONSerialization.data(withJSONObject: ["paramMap":params])
        }
        let task = session.dataTask(with: request); jobs[task.taskIdentifier] = Job(id: id, kind: kind); tasks[task.taskIdentifier] = task; task.resume()
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse, completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        completionHandler((response as? HTTPURLResponse)?.statusCode == 200 && response.expectedContentLength <= 1500000 ? .allow : .cancel)
    }
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        guard var job = jobs[dataTask.taskIdentifier] else { dataTask.cancel(); return }
        guard job.data.count + data.count <= 1500000 else { dataTask.cancel(); return }
        job.data.append(data); jobs[dataTask.taskIdentifier] = job
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        tasks.removeValue(forKey: task.taskIdentifier)
        guard let job = jobs.removeValue(forKey: task.taskIdentifier) else { return }
        if error == nil, let body = String(data: job.data, encoding: .utf8) { result(job.id,["ok":true,"body":body]) }
        else { result(job.id,["ok":false,"error":"连接暂时没有成功，请检查网络后重试"]) }
    }
}
