import UIKit
import WebKit
import PhotosUI
import Photos
import UniformTypeIdentifiers
import ImageIO
import AVFoundation

final class BearViewController: UIViewController, WKScriptMessageHandler, WKUIDelegate, WKNavigationDelegate, PHPickerViewControllerDelegate, UIDocumentPickerDelegate {
    let store: Store, backup: Backup
    let reminders = Reminders(), weather = Weather()
    lazy var alerts = Alerts(weather:weather)
    lazy var gold = GoldQuotes { [weak self] id, result in self?.emit("bearGoldResult",[id,result]) }
    var audio: AVAudioPlayer?
    private var web: WKWebView!
    private var pickLimit = 5, photoRequest = 0
    private var shares = [String:[URL]](), exportURL: URL?
    private var loaded = false
    private var dark = false
    override var preferredStatusBarStyle:UIStatusBarStyle { dark ? .lightContent : .darkContent }
    init(store: Store) { self.store = store; backup = Backup(store:store); super.init(nibName:nil,bundle:nil) }
    required init?(coder:NSCoder) { fatalError("Use init()") }
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red:1,green:0.98,blue:0.95,alpha:1)
        let config = WKWebViewConfiguration()
        config.defaultWebpagePreferences.allowsContentJavaScript = true
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.setURLSchemeHandler(AssetHandler(root:Bundle.main.bundleURL.appendingPathComponent("web"),media:store.root),forURLScheme:"bearapp")
        config.userContentController.add(self,name:"bear")
        if let url = Bundle.main.url(forResource:"bridge",withExtension:"js"), let script = try? String(contentsOf:url,encoding:.utf8) { config.userContentController.addUserScript(WKUserScript(source:script,injectionTime:.atDocumentStart,forMainFrameOnly:true)) }
        web = WKWebView(frame:.zero,configuration:config); web.navigationDelegate = self; web.uiDelegate = self
        web.isOpaque = false; web.backgroundColor = view.backgroundColor; web.scrollView.backgroundColor = view.backgroundColor; web.scrollView.contentInsetAdjustmentBehavior = .never
        web.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(web)
        NSLayoutConstraint.activate([web.topAnchor.constraint(equalTo:view.safeAreaLayoutGuide.topAnchor),web.bottomAnchor.constraint(equalTo:view.safeAreaLayoutGuide.bottomAnchor),web.leadingAnchor.constraint(equalTo:view.safeAreaLayoutGuide.leadingAnchor),web.trailingAnchor.constraint(equalTo:view.safeAreaLayoutGuide.trailingAnchor)])
        weather.changed = { [weak self] state in self?.emit("bearWeatherChanged",[JSON.string(state)]) }
        weather.citiesChanged = { [weak self] state in self?.emit("bearWeatherCities",[JSON.string(state)]) }
        alerts.changed = { [weak self] state in self?.emit("bearWeatherAlertsChanged",[JSON.string(state)]) }
        web.load(URLRequest(url:URL(string:"bearapp://app/index.html")!))
    }
    nonisolated func emit(_ name:String,_ args:[Any]) {
        DispatchQueue.main.async { [weak self] in
            guard let self, self.web != nil else { return }
            self.web.evaluateJavaScript("window.\(name)?.(\(args.map(JSON.string).joined(separator:",")))",completionHandler:nil)
        }
    }
    private func trusted(_ frame:WKFrameInfo) -> Bool { frame.isMainFrame && frame.request.url?.scheme == "bearapp" && frame.request.url?.host == "app" }
    func becameActive() {
        guard loaded else { return }
        weather.refresh(); alerts.refresh(); reminders.rebuild { _ in }; emit("bearIOSResume",[])
    }
    func webView(_ webView:WKWebView,didFinish navigation:WKNavigation!) { loaded = true; becameActive() }
    func webViewWebContentProcessDidTerminate(_ webView:WKWebView) { loaded = false; webView.reload() }
    func webView(_ webView:WKWebView,decidePolicyFor navigationAction:WKNavigationAction,decisionHandler:@escaping (WKNavigationActionPolicy)->Void) {
        if navigationAction.request.url?.scheme == "bearapp", navigationAction.request.url?.host == "app" { decisionHandler(.allow); return }
        decisionHandler(.cancel)
        if navigationAction.navigationType == .linkActivated, let url = navigationAction.request.url { _ = openExternal(url.absoluteString) }
    }
    func webView(_ webView:WKWebView,createWebViewWith configuration:WKWebViewConfiguration,for navigationAction:WKNavigationAction,windowFeatures:WKWindowFeatures) -> WKWebView? {
        if let url = navigationAction.request.url { _ = openExternal(url.absoluteString) }; return nil
    }
    func userContentController(_ userContentController:WKUserContentController,didReceive message:WKScriptMessage) {
        guard trusted(message.frameInfo), let body = message.body as? [String:Any] else { return }
        if body["type"] as? String == "appearance" {
            dark = body["dark"] as? Bool == true
            view.backgroundColor = dark ? UIColor(red:0.145,green:0.118,blue:0.11,alpha:1) : UIColor(red:1,green:0.98,blue:0.95,alpha:1)
            web.backgroundColor = view.backgroundColor; web.scrollView.backgroundColor = view.backgroundColor; setNeedsStatusBarAppearanceUpdate(); return
        }
        if body["type"] as? String == "photos", let id = body["id"] as? Int {
            guard presentedViewController == nil else { emit("bearIOSPhotos",[id,[],"请先关闭当前系统窗口"]); return }
            photoRequest = id; var config = PHPickerConfiguration(photoLibrary:.shared()); config.filter = .images; config.selectionLimit = body["multiple"] as? Bool == true ? max(1,min(5,pickLimit)) : 1; config.selection = .ordered
            let picker = PHPickerViewController(configuration:config); picker.delegate = self; present(picker,animated:true); return
        }
        guard body["type"] as? String == "store", let id = body["id"] as? String, id.range(of:"^[0-9]{1,12}$",options:.regularExpression) != nil, let input = body["input"] as? String, input.utf8.count <= 60 * 1024 * 1024 else { return }
        store.queue.async { [weak self] in
            guard let self else { return }
            do {
                guard let request = try JSON.parse(input) as? [String:Any] else { throw BearError.message("存储请求无效") }
                let value: Any = request["op"] as? String == "restore-confirm" ? try self.backup.merge(request["token"] as? String ?? "") : try self.store.request(request)
                self.emit("bearStoreResult",[id,["ok":true,"value":value]])
            } catch { self.emit("bearStoreResult",[id,["ok":false,"error":error.localizedDescription]]) }
        }
    }
    func webView(_ webView:WKWebView,runJavaScriptTextInputPanelWithPrompt prompt:String,defaultText:String?,initiatedByFrame frame:WKFrameInfo,completionHandler:@escaping (String?)->Void) {
        guard trusted(frame), prompt.hasPrefix("__BEAR_IOS__"), prompt.utf8.count <= 60 * 1024 * 1024, let request = try? JSON.parse(String(prompt.dropFirst(12))) as? [String:Any] else { completionHandler(nil); return }
        let reply:(Any)->Void = { value in DispatchQueue.main.async { completionHandler(JSON.string(["ok":true,"value":value])) } }
        let fail:(Error)->Void = { error in DispatchQueue.main.async { completionHandler(JSON.string(["ok":false,"error":error.localizedDescription])) } }
        do { try handle(request,reply:reply,fail:fail) } catch { fail(error) }
    }
    private func handle(_ request:[String:Any],reply:@escaping (Any)->Void,fail:@escaping (Error)->Void) throws {
        let service = request["service"] as? String ?? "", method = request["method"] as? String ?? "", args = request["args"] as? [Any] ?? []
        func string(_ index:Int) -> String { index < args.count ? args[index] as? String ?? "" : "" }
        func number(_ index:Int) -> Double { index < args.count ? args[index] as? Double ?? 0 : 0 }
        func later(_ action:@escaping ()->Void) { reply(true); DispatchQueue.main.async(execute:action) }
        switch service + "." + method {
        case "BearGold.request": let id = string(0), kind = string(1); later { self.gold.request(id,kind:kind) }
        case "BearGold.cancel": gold.cancel(); reply(true)
        case "BearApp.info": reply(["version":"2.2.18-ios.38","build":38,"platform":"ios"])
        case "BearApp.setImagePickLimit": pickLimit = max(1,min(5,Int(number(0)))); reply(true)
        case "BearApp.consumeWidgetAction": reply("null")
        case "BearApp.refreshInterface": later { self.web.reload() }
        case "BearApp.openRecipeLink": reply(openExternal(string(0)))
        case "BearCalendarAudio.stop": audio?.stop(); reply(true)
        case "BearCalendarAudio.play", "BearCalendarAudio.playAtVolume":
            let name = string(0); guard ["tap","saved","recommend"].contains(name), let url = Bundle.main.url(forResource:name,withExtension:"wav",subdirectory:"web/assets") else { reply(false); return }
            try AVAudioSession.sharedInstance().setCategory(.ambient,mode:.default); try AVAudioSession.sharedInstance().setActive(true)
            audio?.stop(); audio = try AVAudioPlayer(contentsOf:url); audio?.volume = method == "playAtVolume" ? Float(max(0,min(1,number(1)))) : 0.45; reply(audio?.play() ?? false)
        case "BearStore.exportBackup": later { self.exportBackup() }
        case "BearStore.chooseBackup": later { let picker = UIDocumentPickerViewController(forOpeningContentTypes:[.zip],asCopy:true); picker.delegate = self; self.present(picker,animated:true) }
        case "BearShare.canSaveToAlbum": reply(true)
        case "BearShare.copy": UIPasteboard.general.string = string(0); reply(true)
        case "BearShare.prepare":
            guard let pages = try JSON.parse(string(0)) as? [String], (1...9).contains(pages.count) else { throw BearError.message("分享内容无效") }
            let token = UUID().uuidString, folder = FileManager.default.temporaryDirectory.appendingPathComponent("share-"+token)
            try FileManager.default.createDirectory(at:folder,withIntermediateDirectories:true)
            var urls = [URL]()
            do {
                for (index,page) in pages.enumerated() {
                    guard page.hasPrefix("data:image/png;base64,"), let data = Data(base64Encoded:String(page.dropFirst(22))), data.count <= 10 * 1024 * 1024, let image = UIImage(data:data), let jpg = image.jpegData(compressionQuality:0.94) else { throw BearError.message("分享图片无效") }
                    let url = folder.appendingPathComponent("熊熊分享-\(index+1).jpg"); try jpg.write(to:url,options:.atomic); urls.append(url)
                }
            } catch { try? FileManager.default.removeItem(at:folder); throw error }
            if shares.count >= 3, let old = shares.keys.first, let folder = shares[old]?.first?.deletingLastPathComponent() { try? FileManager.default.removeItem(at:folder); shares.removeValue(forKey:old) }
            shares[token] = urls; reply(["ok":true,"token":token])
        case "BearShare.share", "BearShare.save", "BearShare.saveToAlbum":
            guard let urls = shares[string(0)] else { throw BearError.message("分享预览已过期，请重新生成") }
            let index = Int(number(1)); guard urls.indices.contains(index) else { throw BearError.message("分享页码无效") }
            if method == "share" { later { let sheet = UIActivityViewController(activityItems:urls,applicationActivities:nil); sheet.popoverPresentationController?.sourceView = self.view; sheet.popoverPresentationController?.sourceRect = CGRect(x:self.view.bounds.midX,y:self.view.bounds.maxY-40,width:1,height:1); self.present(sheet,animated:true) } }
            else if method == "save" { later { let picker = UIDocumentPickerViewController(forExporting:[urls[index]],asCopy:true); self.present(picker,animated:true) } }
            else { later { self.savePhoto(urls[index]) } }
        case "BearReminders.status": reminders.settings(reply)
        case "BearReminders.sync": guard let rows = try JSON.parse(string(0)) as? [[String:Any]], rows.count <= 10000 else { throw BearError.message("提醒内容无效") }; reminders.sync(rows,completion:reply)
        case "BearReminders.consumeOpenEntry": let entry = reminders.openEntry; reminders.openEntry = nil; reply(JSON.string(entry ?? [:]))
        case "BearReminders.requestPermission": later { self.reminders.requestPermission { allowed in self.emit("bearShareResult",[allowed ? "通知已开启" : "通知未开启，可到系统设置中允许"]) } }
        case "BearReminders.test": later { self.reminders.timer("__reminder_test__",title:"熊熊提醒测试",seconds:3) { result in self.emit("bearShareResult",[result["ok"] as? Bool == true ? "3 秒后发送测试通知" : result["message"] ?? "未能设置测试通知"]) } }
        case "BearReminders.settings", "BearReminders.exactSettings", "BearApp.cookingNotificationSettings", "BearWeather.settings", "BearWeather.locationSettings": later { UIApplication.shared.open(URL(string:UIApplication.openSettingsURLString)!) }
        case "BearApp.startCookingTimer": reminders.timer(string(0),title:string(1),seconds:number(2),completion:reply)
        case "BearApp.testCookingRinging": reminders.timer("__bear_ring_test__",title:"熊熊 5 秒试响",seconds:5,completion:reply)
        case "BearApp.cookingTimerStatus": reminders.timerStatus(string(0),completion:reply)
        case "BearApp.cookingRingingStatus": reminders.ringHealth(completion:reply)
        case "BearApp.cancelCookingTimer": reminders.cancel(string(0)); reply(true)
        case "BearApp.cancelCookingRingingTest": reminders.cancel("__bear_ring_test__"); reply(true)
        case "BearApp.stopCookingTimerRinging": reminders.center.removeDeliveredNotifications(withIdentifiers:["timer:"+string(0)]); reply(true)
        case "BearApp.chooseCookingRingtone": later { self.chooseSound() }
        case "BearWeather.state": reply(weather.state)
        case "BearWeather.refresh", "BearWeather.refreshNow": later { self.weather.refresh() }
        case "BearWeather.refreshSavedPlace": later { self.weather.refresh(saved:true) }
        case "BearWeather.locate", "BearWeather.locatePrecise": later { self.weather.locate() }
        case "BearWeather.cancelLocate": weather.cancelLocation(); reply(true)
        case "BearWeather.disable": weather.disable(); reply(true)
        case "BearWeather.select": guard let place = try JSON.parse(string(0)) as? [String:Any] else { throw BearError.message("地区无效") }; later { self.weather.select(place) }
        case "BearWeather.search": let query = string(0); later { self.weather.search(query) }
        case "BearWeatherAlerts.state": reply(alerts.state)
        case "BearWeatherAlerts.selectProvince": let province = string(0); later { self.alerts.select(province) }
        case "BearWeatherAlerts.disable": alerts.select(""); reply(true)
        case "BearWeatherAlerts.refresh", "BearWeatherAlerts.refreshIfNeeded": later { self.alerts.refresh() }
        default: throw BearError.message("此 iPhone 版本暂不支持这项系统操作")
        }
    }
    private func openExternal(_ text:String) -> Bool {
        guard let detector = try? NSDataDetector(types:NSTextCheckingResult.CheckingType.link.rawValue), let match = detector.firstMatch(in:text,range:NSRange(text.startIndex...,in:text)), let url = match.url, ["https","http"].contains(url.scheme?.lowercased() ?? ""), url.user == nil, url.password == nil else { return false }
        UIApplication.shared.open(url); return true
    }
    private func chooseSound() {
        let sheet = UIAlertController(title:"计时提醒声音",message:"iPhone 不提供系统铃声列表给第三方应用。可选默认通知声音或随 App 自带的熊熊短音效。",preferredStyle:.actionSheet)
        for (key,title) in [("system","iPhone 默认通知声音"),("bear","熊熊短提示音")] { sheet.addAction(UIAlertAction(title:title,style:.default) { _ in UserDefaults.standard.set(key,forKey:"timerSound"); self.emit("bearShareResult",["声音已选择，对下次计时生效"]) }) }
        sheet.addAction(UIAlertAction(title:"取消",style:.cancel)); sheet.popoverPresentationController?.sourceView = view; sheet.popoverPresentationController?.sourceRect = CGRect(x:view.bounds.midX,y:view.bounds.maxY-40,width:1,height:1); present(sheet,animated:true)
    }
    private func savePhoto(_ url:URL) {
        PHPhotoLibrary.requestAuthorization(for:.addOnly) { status in
            guard status == .authorized || status == .limited else { self.emit("bearShareResult",["尚未允许保存到相册，可在系统设置中开启添加照片权限"]); return }
            PHPhotoLibrary.shared().performChanges({ PHAssetChangeRequest.creationRequestForAssetFromImage(atFileURL:url) }) { saved,_ in self.emit("bearShareResult",[saved ? "已保存到相册" : "未能保存，请检查相册权限或空间"]) }
        }
    }
    func picker(_ picker:PHPickerViewController,didFinishPicking results:[PHPickerResult]) {
        picker.dismiss(animated:true); let request = photoRequest
        guard !results.isEmpty else { emit("bearIOSPhotos",[request,[],NSNull()]); return }
        let group = DispatchGroup(), lock = NSLock(); var images = [Int:String](), failed = false
        for (index,result) in results.prefix(5).enumerated() {
            group.enter(); result.itemProvider.loadFileRepresentation(forTypeIdentifier:UTType.image.identifier) { url,_ in
                defer { group.leave() }
                var output:Data?
                if let url, let source = CGImageSourceCreateWithURL(url as CFURL,nil), let image = CGImageSourceCreateThumbnailAtIndex(source,0,[kCGImageSourceCreateThumbnailFromImageAlways:true,kCGImageSourceCreateThumbnailWithTransform:true,kCGImageSourceThumbnailMaxPixelSize:2400] as CFDictionary) {
                    let data = NSMutableData()
                    if let destination = CGImageDestinationCreateWithData(data as CFMutableData,UTType.jpeg.identifier as CFString,1,nil) { CGImageDestinationAddImage(destination,image,[kCGImageDestinationLossyCompressionQuality:0.86] as CFDictionary); if CGImageDestinationFinalize(destination) { output = data as Data } }
                }
                lock.lock(); if let output { images[index] = output.base64EncodedString() } else { failed = true }; lock.unlock()
            }
        }
        group.notify(queue:.main) { self.emit("bearIOSPhotos",[request,failed ? [] : images.keys.sorted().map { ["data":images[$0]!] },failed ? "有照片未能读取，请确认 iCloud 原图已下载后重试" : NSNull()]) }
    }
    private func exportBackup() {
        store.queue.async { do { let url = try self.backup.export(); DispatchQueue.main.async { self.exportURL = url; let picker = UIDocumentPickerViewController(forExporting:[url],asCopy:true); picker.delegate = self; self.present(picker,animated:true) } } catch { self.emit("bearBackupResult",[["type":"error","message":error.localizedDescription]]) } }
    }
    func documentPickerWasCancelled(_ controller:UIDocumentPickerViewController) { if let exportURL { try? FileManager.default.removeItem(at:exportURL.deletingLastPathComponent()) }; exportURL = nil; emit("bearBackupResult",[["type":"cancelled","message":"已取消，本机数据保留"]]) }
    func documentPicker(_ controller:UIDocumentPickerViewController,didPickDocumentsAt urls:[URL]) {
        if let exported = exportURL {
            exportURL = nil; store.queue.async { defer { try? FileManager.default.removeItem(at:exported.deletingLastPathComponent()) }; do { try self.store.setMeta("lastBackup",String(JSON.now)); self.emit("bearBackupResult",[["type":"exported","message":"完整备份已保存"]]) } catch { self.emit("bearBackupResult",[["type":"error","message":"文件已导出，但未能记录备份时间"]]) } }; return
        }
        guard let url = urls.first else { return }
        store.queue.async { let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }; do { self.emit("bearBackupResult",[try self.backup.inspect(url)]) } catch { self.emit("bearBackupResult",[["type":"error","message":"未恢复：\(error.localizedDescription)。原记录保留。"]]) } }
    }
}
