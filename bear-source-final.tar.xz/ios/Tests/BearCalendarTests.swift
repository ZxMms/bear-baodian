import XCTest
@testable import BearCalendar

final class BearCalendarTests: XCTestCase {
    func withStore(_ block:(Store)throws->Void) throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at:root) }
        let seed = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".json")
        try Data("[]".utf8).write(to:seed); defer { try? FileManager.default.removeItem(at:seed) }
        let store = try Store(root:root,seed:seed); try block(store)
    }
    func testAtomicFailureDoesNotPartiallySave() throws {
        try withStore { store in
            let rows:[[String:Any]] = [["store":"entries","key":"one","value":["id":"one","title":"第一条"]],["store":"recipes","key":"bad","value":["id":"different"]]]
            XCTAssertThrowsError(try store.request(["op":"put-batch","rows":rows]))
            XCTAssertEqual(try store.counts()["entries"],0)
        }
    }
    func testMoodCanOnlyBeAddedOnce() throws {
        try withStore { store in
            let row:[String:Any] = ["op":"put","store":"moods","key":"2026-11-19","value":["date":"2026-11-19","mood":"happy"],"add":true]
            _ = try store.request(row); XCTAssertThrowsError(try store.request(row)); XCTAssertEqual(try store.counts()["moods"],1)
        }
    }
    func testSQLiteSurvivesReopenAndTrashCanRestore() throws {
        try withStore { store in
            _ = try store.request(["op":"put","store":"entries","key":"one","value":["id":"one","title":"中文用户名的手账"]])
            _ = try store.request(["op":"soft-delete","store":"entries","key":"one"])
            let second = try Store(root:store.root,seed:nil)
            let deleted = try second.request(["op":"get","store":"entries","key":"one"]) as! [String:Any]
            XCTAssertNotNil((deleted["value"] as? [String:Any])?["_deletedAt"])
            let restored = try second.request(["op":"restore","store":"entries","key":"one"]) as! [String:Any]
            XCTAssertNil((restored["value"] as? [String:Any])?["_deletedAt"])
            XCTAssertEqual((restored["value"] as? [String:Any])?["title"] as? String,"中文用户名的手账")
        }
    }
    func testMediaPathTraversalIsRejected() {
        XCTAssertFalse(Store.validMedia("media/../bear.sqlite"))
        XCTAssertFalse(Store.validMedia("media/" + String(repeating:"a",count:64) + ".jpg/../../bear.sqlite"))
        XCTAssertTrue(Store.validMedia("media/" + String(repeating:"a",count:64) + ".jpg"))
    }
    func testBackupRoundTripKeepsExistingRecords() throws {
        try withStore { first in
            _ = try first.request(["op":"put","store":"entries","key":"one","value":["id":"one","title":"旧标题"]])
            let url = try Backup(store:first).export()
            defer { try? FileManager.default.removeItem(at:url.deletingLastPathComponent()) }
            try withStore { second in
                _ = try second.request(["op":"put","store":"entries","key":"one","value":["id":"one","title":"本机新标题"]])
                let backup = Backup(store:second), preview = try backup.inspect(url)
                let result = try backup.merge(preview["token"] as! String)
                XCTAssertEqual(result["kept"],1)
                let row = try second.request(["op":"get","store":"entries","key":"one"]) as! [String:Any]
                XCTAssertEqual((row["value"] as! [String:Any])["title"] as? String,"本机新标题")
            }
        }
    }
    func testReminderMonthEndAndOfficialWorkdays() {
        var cal = Calendar(identifier:.gregorian); cal.timeZone = TimeZone(identifier:"Asia/Shanghai")!
        let now = ISO8601DateFormatter().date(from:"2026-02-01T00:00:00Z")!
        let rows:[[String:Any]] = [
            ["id":"month","title":"月末","date":"2026-01-01","recurrence":"monthly","monthDay":31,"overflow":"last","time":"09:00","days":0],
            ["id":"salary","title":"发薪","date":"1900-01-01","recurrence":"last-workday","workMode":"official","workDates":["2026-02-28"],"time":"09:00","days":1]]
        let schedule = ReminderSchedule.upcoming(rows,now:now,calendar:cal)
        XCTAssertEqual(schedule.first { $0.recordID == "month" }?.entryDate,"2026-02-28")
        let salary = schedule.filter { $0.recordID == "salary" }; XCTAssertEqual(salary.count,1)
        XCTAssertEqual(cal.component(.day,from:salary[0].fire),27)
    }
    func testLeapDayReminderDoesNotBecomeMarchFirst() {
        let now = ISO8601DateFormatter().date(from:"2026-01-01T00:00:00Z")!
        let rows:[[String:Any]] = [["id":"leap","date":"2024-02-29","annual":true,"time":"09:00"]]
        XCTAssertTrue(ReminderSchedule.upcoming(rows,now:now).isEmpty)
    }
}
