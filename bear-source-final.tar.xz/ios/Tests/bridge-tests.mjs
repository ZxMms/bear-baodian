import fs from 'node:fs';
import assert from 'node:assert/strict';
import {JSDOM} from '../../tools/ui-test-runtime/node_modules/jsdom/lib/api.js';
const source=fs.readFileSync(new URL('../BearCalendar/bridge.js',import.meta.url),'utf8');
function setup(url='bearapp://app/index.html') {
 const dom=new JSDOM('<!doctype html><html><head></head><body><input type="file" accept="image/*" multiple></body></html>',{url,runScripts:'outside-only'}),w=dom.window, calls=[],posts=[];
 w.webkit={messageHandlers:{bear:{postMessage:body=>posts.push(body)}}};
 w.prompt=value=>{const request=JSON.parse(value.slice(12));calls.push(request);const result=request.method==='info'?{version:'2.2.18-ios.38',platform:'ios'}:request.method==='prepare'?{ok:true,token:'photos'}:true;return JSON.stringify({ok:true,value:result});};
 w.eval(source);return {dom,w,calls,posts};
}
let tests=0;
const {dom,w,calls,posts}=setup();
assert.equal(JSON.parse(w.BearApp.info()).platform,'ios');tests++;
assert.equal(w.BearCalendarAudio.playAtVolume('tap',0.5),true);assert.deepEqual(calls.at(-1),{service:'BearCalendarAudio',method:'playAtVolume',args:['tap',0.5]});tests++;
assert.equal(JSON.parse(w.BearShare.prepare('["image"]')).token,'photos');assert.equal(calls.filter(c=>['save','saveToAlbum','share'].includes(c.method)).length,0);tests++;
w.BearStore.request(8,'{"op":"status"}');assert.equal(posts.at(-1).id,'8');assert.equal(posts.at(-1).type,'store');tests++;
w.BearApp.setImagePickLimit(4);const input=w.document.querySelector('input');input.click();assert.equal(posts.at(-1).type,'photos');assert.equal(posts.at(-1).multiple,true);tests++;
const photoId=posts.at(-1).id;w.bearIOSPhotos(photoId,[],null);input.click();assert.equal(posts.at(-1).id,photoId+1);tests++;
let resumes=0,opened=0;w.document.addEventListener('visibilitychange',()=>resumes++);w.bearOpenNotification=()=>opened++;w.bearIOSResume();assert.equal(resumes,1);assert.equal(opened,1);tests++;
w.prompt=()=>JSON.stringify({ok:false,error:'磁盘空间不足'});assert.throws(()=>w.BearShare.prepare('[]'),/磁盘空间不足/);tests++;
assert.equal(w.BearApp.pinWidget,undefined);tests++;
for(const url of ['https://untrusted.example/','bearapp://evil/index.html']) {const other=setup(url);assert.equal(other.w.BearStore,undefined);assert.equal(other.w.BearShare,undefined);other.dom.window.close();tests++;}
dom.window.close();console.log(`PASS ${tests} iOS JS bridge contract checks (mock native runtime, not device tests)`);
