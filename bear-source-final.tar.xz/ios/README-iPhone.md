# 熊熊宝典 · iPhone 工程初版

基于 Android v2.2.14 的页面和功能，新增 Swift + WKWebView 的 iOS 应用工程。最低 iOS 16，支持 iPhone 和 iPad。不是网页快捷方式，也不是 APK 改后缀。

**当前交付是开发工程，不是可安装 IPA。** 已完成下面的适配代码和非苹果环境验证；尚未在 Xcode 中编译、运行原生测试、签名或在 iPhone 实测。首次 Mac 构建仍可能发现 iOS SDK 类型兼容问题，需解决后才能分发。没有生成安装链接或 TestFlight 邀请。

## 这次迁移的内容

| 功能 | iOS 工程中的实现 | 当前验证范围 |
|---|---|---|
| 手账、心情、农历日历、倒计时、美食与菜谱、冰箱、周菜单、记账与图表 | 复用现有页面和业务逻辑，一二布布素材与轻动画保留 | 共享业务测试；待 WKWebView 真机测试 |
| 本地保存 | 原生 SQLite；附件按 SHA-256 存于应用私有目录；关联记录事务保存 | Swift 语法解析；XCTest 已提供，尚未运行 |
| 选照片 | PHPicker 系统相册网格，按剩余容量限制最多 5 张；照片方向修正、缩小长边至 2400 像素 | JS 桥协议测试；待真机验证 iCloud 照片 |
| 分享 | 保留周几和可选天气卡，系统分享面板；保存相册须单独点击并申请添加权限 | 分享卡回归测试；微信接收效果待真机验证 |
| 备份 | 导出 ZIP 到“文件”；兼容现有 format-1 备份，校验数量、SHA-256、路径与体积后合并 | 恢复测试代码已提供，尚未跑原生 ZIP 库 |
| 天气 | Core Location 新位置 + 苹果地理解析；中央气象台站点，失败回退 Open-Meteo；每次请求不写天气磁盘缓存 | 逻辑审查；网络、区县定位待国内真机验证 |
| 气象预警 | 中央气象台最多 5 页发布，复用现有所在区县筛选逻辑；不完整查询明确提示 | 代码适配；待在线验证 |
| 日程和做菜计时 | 本地通知；按月、每年、最后工作日计算；5 秒试响；默认通知声音/内置短提示音 | 排期测试已提供；后台/锁屏送达待真机验证 |
| 桌面小组件 | 暂未迁移 WidgetKit，在本版隐藏安卓组件入口 | 后续独立适配 |

当前音效复用原包，内置通知短音频为 0.56 秒。没有新增音频导入。iOS 不开放完整的系统铃声选择列表；通知受静音、音量与专注模式影响，清除已送达通知也不代表可以控制系统正在播放的声音。未申请绕过静音的特殊提醒权限。

相册选择默认使用系统相册，不读取完整照片库。当前没有单独原生相机入口。截图记账、图片录入菜谱继续使用已有 OCR 模块，需真机验证 WKWebView 的 Worker/WASM 支持。

## 在 Mac 上打开

1. 安装支持所用 iPhone 系统的 Xcode，首次启动完成组件安装。建议 Xcode 16 或更新。
2. 解压，打开 `BearCalendar.xcodeproj`。若拿到完整双平台源码，位于 `bear-calendar/ios/`。
3. 等待 Swift Package Manager 下载固定版本 **ZIPFoundation 0.9.20**。这是唯一额外的原生依赖，无需 CocoaPods、Node 或 XcodeGen。
4. 选中 BearCalendar target → Signing & Capabilities，开启 Automatically manage signing，选择你自己的 Team。
5. 将 Bundle Identifier 改成你账号下唯一的编号，例如 `com.yourname.bearcalendar`；不需要更换备份格式里的 Android 标识。
6. iPhone 连到 Mac 并信任电脑，按系统提示开启开发者模式；在 Xcode 选择该设备，点 Run。

工程不包含证书、私钥、苹果账号或付费团队配置。使用普通 Apple Account 的 Personal Team 可在自己的设备测试，签名有效期较短，需要定期重新安装；TestFlight 分发需要 Apple Developer Program 和 App Store Connect 配置。

苹果官方说明：https://developer.apple.com/help/account/basics/about-your-developer-account

## 编译与测试

```bash
cd ios # 单独 iOS 工程包则进入解压后的项目根目录
bash scripts/check_on_mac.sh
# 列出可用模拟器：xcrun simctl list devices available
bash scripts/check_on_mac.sh 'platform=iOS Simulator,id=你的模拟器UDID'
```

脚本先刷新资源（完整工程）或使用随包资源（独立 iOS 包），再构建模拟器。提供模拟器参数时执行 XCTest。不要将本机语法解析结果当作 Xcode 编译通过。

`scripts/make_project.py` 可以重新生成工程；生成前如已手动更改签名或标识，请先记录这些设置。

## 安卓数据转到 iPhone

在安卓“设置 → 数据与备份”导出完整 ZIP，传到 iPhone“文件”，再在 iPhone 版选择备份恢复。先展示数量与时间，点击确认后才合并。同编号的用户记录和已有设置保留本机版本。照片随 ZIP 迁移，禁止单独复制 SQLite 文件。原安卓应用和数据不受这个工程影响。

## 数据、天气和隐私

- 记录与照片由本 App 保存在本机，不新增账户或自建服务器，也不增加情侣双人功能。系统整机备份是否包含应用数据由 iOS 和用户设置决定。
- 只有你启用天气定位后才请求位置权限。查询天气需要将坐标发送给天气服务；地区名称解析使用 Apple 地理服务。没有广告、统计或位置历史上传逻辑。
- 保存的是用户选择的地区，不保存天气查询结果。查询期间可以保留当前画面，失败会明确标记，不把旧结果当成刷新成功。
- 天气来源：中央气象台 https://www.nmc.cn/；备用模型资料 Open-Meteo https://open-meteo.com/，署名 CC BY 4.0。预警是近期发布信息，不等于实时有效预警全集。
- 已加入权限用途文案和隐私清单初稿。若以后公开发布，需要按最终使用的服务核对 App Store 隐私问卷，以及现有一二布布素材、音效的公开发行授权。

## 上机验收重点

首次启动、离线重开、记录保存/撤销/最近删除；5 张照片及 iCloud 原图；Android 备份转入且无覆盖；当天分享周几和天气；首次定位授权、拒绝、精确/大致、区县与跨区移动；计时后台/锁屏/静音/专注模式；月底发薪、闰年、时区；微信分享及用户手动保存；小屏/大字/夜间/减少动态；截图与菜谱 OCR。

原生测试通过和真机验收完成前，请作为开发预览工程使用。
