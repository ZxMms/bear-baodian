"""Fail a release when its APK ships stale or missing web resources."""
from pathlib import Path
import json
import re
import xml.etree.ElementTree as ET
import zipfile

root = Path(__file__).resolve().parents[1]
manifest = ET.parse(root / 'android/AndroidManifest.xml').getroot()
android = '{http://schemas.android.com/apk/res/android}'
version, build = manifest.get(android + 'versionName'), manifest.get(android + 'versionCode')
assert json.loads((root / 'package.json').read_text())['version'] == version
app = (root / 'web/app.js').read_text()
assert re.search(r'const APP_VERSION = "' + re.escape(version) + '";', app)
assert re.search(r'const APP_BUILD = ' + build + ';', app)
for filename in ['index.html', 'app.js', 'model.js']:
    refs = re.findall(r'(?:src|href)="[^\"]+\?v=(\d+)"|from "[^\"]+\?v=(\d+)"', (root / 'web' / filename).read_text())
    assert refs and all((a or b) == build for a,b in refs), filename
with zipfile.ZipFile(root / 'android/build/bear-calendar.apk') as apk:
    files = [p for p in (root / 'web').rglob('*') if p.is_file()]
    assert set(n for n in apk.namelist() if n.startswith('assets/') and not n.endswith('/')) == {'assets/' + str(p.relative_to(root / 'web')) for p in files}
    for p in files:
        assert apk.read('assets/' + str(p.relative_to(root / 'web'))) == p.read_bytes(), p
    assert apk.getinfo('classes.dex').file_size > 0
print(f'Passed: v{version} build {build}, all {len(files)} web assets match the APK exactly.')
