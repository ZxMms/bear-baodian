"""Generate small original soft foley-style cues; these are NOT character voices."""
import math
import random
import struct
import wave
from pathlib import Path

RATE = 22050
OUTPUT = Path(__file__).resolve().parents[1] / 'web' / 'assets'

def render(name, length, taps=(), paper=False):
    rng = random.Random({'tap': 18, 'saved': 23, 'recommend': 42}[name])
    filtered = 0.0
    samples = []
    for index in range(round(length * RATE)):
        t = index / RATE
        noise = rng.uniform(-1, 1)
        filtered += 0.16 * (noise - filtered)
        value = 0.0
        for onset, strength in taps:
            age = t - onset
            if age >= 0:
                attack = min(1, age / 0.003)
                # Damped, inharmonic wooden resonance; no melody or electronic chirp.
                value += strength * attack * math.exp(-age * 48) * (
                    0.47 * math.sin(2 * math.pi * 340 * age)
                    + 0.22 * math.sin(2 * math.pi * 807 * age)
                    + 0.12 * math.sin(2 * math.pi * 1331 * age))
                if age < 0.035:
                    value += strength * 0.3 * filtered * (1-age/0.035)**2
        if paper:
            envelope = math.sin(math.pi * min(1,t/length))**2
            value += filtered * 0.52 * envelope * (0.68 + 0.32*math.sin(t*105))
        samples.append(struct.pack('<h', round(max(-0.95,min(0.95,value))*32767)))
    with wave.open(str(OUTPUT / f'{name}.wav'), 'wb') as sound:
        sound.setparams((1,2,RATE,0,'NONE','not compressed'))
        sound.writeframes(b''.join(samples))

render('tap', .20, [(0, .55)])
render('saved', .40, [(0, .43), (.14, .56)])
render('recommend', .35, paper=True)
