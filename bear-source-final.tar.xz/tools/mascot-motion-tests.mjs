import assert from 'node:assert/strict';
import {initMascotMotion,mascotMotionAllowed} from '../web/mascot-motion.js';

class List {
  values=new Set();add(...xs){xs.forEach(x=>this.values.add(x));}remove(...xs){xs.forEach(x=>this.values.delete(x));}contains(x){return this.values.has(x);}
}
class Target {
  listeners=new Map();
  addEventListener(type,fn){this.listeners.set(type,fn);}
  removeEventListener(type,fn){if(this.listeners.get(type)===fn)this.listeners.delete(type);}
  emit(type,event={}){this.listeners.get(type)?.(event);}
}
class Element extends Target {
  constructor(doc,tag='SPAN') {super();this.ownerDocument=doc;this.tagName=tag;this.classList=new List();this.dataset={};this.attrs=new Map();this.isConnected=true;this.childNodes=[];this.rect={top:0,left:0,bottom:100,right:100};}
  set className(value){this.classList.values=new Set(value.split(' '));}
  getAttribute(name){return this.attrs.get(name)??null;}
  setAttribute(name,value){this.attrs.set(name,value);}
  removeAttribute(name){this.attrs.delete(name);}
  getBoundingClientRect(){return this.rect;}
  querySelector(){return this.art||null;}
  before(other){this.inserted=other;}
  append(child){this.childNodes.push(child);}
  replaceWith(...children){this.restored=children;this.isConnected=false;}
  closest(){return this.host||this;}
}
function fixture({intersection=true}={}) {
  const mutations=[],intersections=[],timers=new Map(),doc=new Target(),win=new Target();let timer=0;
  const media=new Target();media.matches=false;
  Object.assign(win,{innerHeight:800,innerWidth:360,matchMedia:()=>media,
    setTimeout:fn=>{timers.set(++timer,fn);return timer;},clearTimeout:id=>timers.delete(id),
    requestAnimationFrame:fn=>{fn();return 1;},cancelAnimationFrame(){},
    MutationObserver:class{constructor(fn){this.fn=fn;mutations.push(this);}observe(){}disconnect(){this.disconnected=true;}},
  });
  if(intersection)win.IntersectionObserver=class {
    constructor(fn){this.fn=fn;this.observed=new Set();intersections.push(this);}observe(el){this.observed.add(el);}unobserve(el){this.observed.delete(el);}disconnect(){this.disconnected=true;}
  };
  doc.defaultView=win;doc.documentElement=new Element(doc);doc.body=new Element(doc);doc.hidden=false;doc.modal=false;
  doc.createElement=tag=>new Element(doc,tag.toUpperCase());doc.querySelector=()=>doc.modal?{}:null;
  const root=new Element(doc,'MAIN');root.hosts=[];root.contains=el=>root.hosts.includes(el)&&el.isConnected;
  // Honor the shipped direct-child selectors instead of blindly returning all images.
  root.querySelectorAll=selector=>root.hosts.filter(host=>selector.split(',').some(part=>{
    const match=part.trim().match(/^\.([\w-]+)\s*>\s*\.([\w-]+)$/);
    assert(match,`Unexpected companion selector: ${part}`);
    return host.parentClasses?.has(match[1])&&host.classList.contains(match[2]);
  }));
  const native=new Element(doc,'BUTTON');native.art=new Element(doc);native.art.host=native;native.setAttribute('aria-label','让熊熊回应一下');native.className='mood-companion';native.parentClasses=new Set(['compact-hero','page-hero']);
  const decorative=new Element(doc);decorative.setAttribute('role','img');decorative.setAttribute('aria-label','一二布布 · 翻开菜谱');decorative.className='bear-art kitchen-bears';decorative.parentClasses=new Set(['kitchen-hero','page-hero']);
  const journal=new Element(doc);journal.className='bear-art journal-bears';journal.parentClasses=new Set(['journal-intro','page-hero']);
  const ledger=new Element(doc);ledger.className='bear-art ledger-bear';ledger.parentClasses=new Set(['ledger-overview','page-hero','ledger-page-hero']);
  const recordPhoto=new Element(doc);recordPhoto.className='ledger-bear';recordPhoto.parentClasses=new Set(['ledger-row']);
  root.hosts=[native,decorative,journal,ledger,recordPhoto];
  return {root,doc,win,media,mutations,intersections,timers,native,decorative,journal,ledger,recordPhoto,flushTimers(){for(const fn of [...timers.values()])fn();timers.clear();}};
}
let passed=0;
const test=(name,fn)=>{fn();passed++;};
test('motion has one permission gate',()=>{
  assert.equal(mascotMotionAllowed(),true);
  for(const value of [{enabled:false},{reduced:true},{systemReduced:true},{hidden:true},{modal:true}])assert.equal(mascotMotionAllowed(value),false);
});
test('absent page is a safe no-op',()=>{initMascotMotion(null).refresh();initMascotMotion(null).destroy();});
test('only discovered companions are enhanced, native button keeps its semantics',()=>{
  const f=fixture(),control=initMascotMotion(f.root);
  assert.equal(f.native.getAttribute('role'),null);
  assert.equal(f.native.getAttribute('aria-label'),'让熊熊回应一下');
  assert.equal(f.native.art.inserted.childNodes[0],f.native.art);
  assert.equal(f.decorative.getAttribute('role'),'button');assert.equal(f.decorative.getAttribute('tabindex'),'0');
  assert.equal(f.native.dataset.mascotActive,'true');assert.equal(f.decorative.dataset.mascotActive,'true');
  control.destroy();
});
test('all four page companions respond while a similarly named record image stays inert',()=>{
  const f=fixture(),control=initMascotMotion(f.root);
  for(const host of [f.native,f.decorative,f.journal,f.ledger]){
    assert.equal(host.classList.contains('mascot-host'),true);assert.equal(host.dataset.mascotActive,'true');
  }
  assert.equal(f.ledger.getAttribute('role'),'button');assert.equal(f.ledger.getAttribute('tabindex'),'0');
  f.root.emit('click',{target:f.ledger});assert.equal(f.ledger.classList.contains('mascot-responding'),true);
  assert.equal(f.recordPhoto.classList.contains('mascot-host'),false);assert.equal(f.recordPhoto.getAttribute('role'),null);
  f.root.emit('click',{target:f.recordPhoto});assert.equal(f.timers.size,1,'ordinary record images cannot start another animation');
  control.destroy();assert.equal(f.ledger.getAttribute('role'),null);assert.equal(f.ledger.getAttribute('tabindex'),null);
});
test('refresh is idempotent and render replacement releases old elements',()=>{
  const f=fixture(),control=initMascotMotion(f.root),wrapper=f.native.art.inserted;
  control.refresh();assert.equal(f.native.art.inserted,wrapper);
  f.root.hosts=[f.decorative];control.refresh();
  assert.equal(f.native.classList.contains('mascot-host'),false);assert.equal(f.intersections[0].observed.has(f.native),false);
  control.destroy();
});
test('offscreen companions pause, intersecting companions resume',()=>{
  const f=fixture(),control=initMascotMotion(f.root);
  f.intersections[0].fn([{target:f.decorative,isIntersecting:false,intersectionRatio:0}]);
  assert.equal(f.decorative.dataset.mascotActive,'false');
  f.intersections[0].fn([{target:f.decorative,isIntersecting:true,intersectionRatio:1}]);
  assert.equal(f.decorative.dataset.mascotActive,'true');control.destroy();
});
test('background pauses motion and pending tap response',()=>{
  const f=fixture(),control=initMascotMotion(f.root);f.root.emit('click',{target:f.native});
  assert.equal(f.timers.size,1);f.doc.hidden=true;f.doc.emit('visibilitychange');
  assert.equal(f.native.dataset.mascotActive,'false');assert.equal(f.timers.size,0);
  f.doc.hidden=false;f.doc.emit('visibilitychange');assert.equal(f.native.dataset.mascotActive,'true');control.destroy();
});
test('open editor pauses the background; closing it resumes',()=>{
  const f=fixture(),control=initMascotMotion(f.root);f.doc.modal=true;f.mutations[1].fn();
  assert.equal(f.native.dataset.mascotActive,'false');f.doc.modal=false;f.mutations[1].fn();
  assert.equal(f.native.dataset.mascotActive,'true');control.destroy();
});
test('user toggle, reduced motion and system motion updates all apply immediately',()=>{
  const f=fixture(),control=initMascotMotion(f.root);
  f.doc.documentElement.dataset.mascotMotion='false';f.mutations[0].fn();assert.equal(f.native.dataset.mascotActive,'false');
  f.doc.documentElement.dataset.mascotMotion='true';f.doc.documentElement.dataset.reducedMotion='true';f.mutations[0].fn();assert.equal(f.native.dataset.mascotActive,'false');
  f.doc.documentElement.dataset.reducedMotion='false';f.mutations[0].fn();assert.equal(f.native.dataset.mascotActive,'true');
  f.media.matches=true;f.media.emit('change');assert.equal(f.native.dataset.mascotActive,'false');control.destroy();
});
test('repeated taps produce a single bounded reaction',()=>{
  const f=fixture(),control=initMascotMotion(f.root);
  f.root.emit('click',{target:f.decorative});f.root.emit('click',{target:f.decorative});
  assert.equal(f.timers.size,1);assert.equal(f.decorative.classList.contains('mascot-responding'),true);
  f.flushTimers();assert.equal(f.decorative.classList.contains('mascot-responding'),false);
  f.root.emit('click',{target:f.decorative});assert.equal(f.timers.size,1);control.destroy();
});
test('decorative companions respond to keyboard without repeated key pulses',()=>{
  const f=fixture(),control=initMascotMotion(f.root);let prevented=0;
  f.root.emit('keydown',{target:f.decorative,key:' ',preventDefault(){prevented++;}});
  assert.equal(prevented,1);assert.equal(f.timers.size,1);f.flushTimers();
  f.root.emit('keydown',{target:f.decorative,key:'Enter',repeat:true,preventDefault(){prevented++;}});
  assert.equal(f.timers.size,0);control.destroy();
});
test('native buttons do not double-trigger on key plus synthesized click',()=>{
  const f=fixture(),control=initMascotMotion(f.root);
  f.root.emit('keydown',{target:f.native,key:'Enter',preventDefault(){throw Error('native event must pass');}});
  assert.equal(f.timers.size,0);f.root.emit('click',{target:f.native});assert.equal(f.timers.size,1);control.destroy();
});
test('disabled motion ignores tap animation',()=>{
  const f=fixture();f.doc.documentElement.dataset.mascotMotion='false';const control=initMascotMotion(f.root);
  f.root.emit('click',{target:f.native});assert.equal(f.timers.size,0);control.destroy();
});
test('disabled preferences expose original images instead of inert keyboard buttons',()=>{
  for(const mode of ['mascotMotion','reducedMotion','system']){
    const f=fixture();
    if(mode==='system')f.media.matches=true;
    else f.doc.documentElement.dataset[mode]=mode==='mascotMotion'?'false':'true';
    f.decorative.setAttribute('tabindex','-1');
    const control=initMascotMotion(f.root);
    assert.equal(f.decorative.getAttribute('role'),'img');
    assert.equal(f.decorative.getAttribute('aria-label'),'一二布布 · 翻开菜谱');
    assert.equal(f.decorative.getAttribute('tabindex'),'-1');
    for(const host of [f.journal,f.ledger]){
      assert.equal(host.getAttribute('role'),null);assert.equal(host.getAttribute('tabindex'),null);
      assert.equal(host.getAttribute('aria-label'),null);
    }
    f.root.emit('keydown',{target:f.decorative,key:' ',preventDefault(){throw Error('static image must not consume Space');}});
    f.root.emit('click',{target:f.decorative});assert.equal(f.timers.size,0);
    assert.equal(f.native.tagName,'BUTTON');assert.equal(f.native.getAttribute('aria-label'),'让熊熊回应一下');
    control.destroy();
  }
});
test('turning motion off cancels a response and re-enabling restores one keyboard action',()=>{
  const f=fixture(),control=initMascotMotion(f.root);
  f.root.emit('click',{target:f.decorative});assert.equal(f.timers.size,1);
  f.doc.documentElement.dataset.mascotMotion='false';f.mutations[0].fn();
  assert.equal(f.timers.size,0);assert.equal(f.decorative.classList.contains('mascot-responding'),false);
  assert.equal(f.decorative.getAttribute('role'),'img');assert.equal(f.decorative.getAttribute('tabindex'),null);
  f.doc.documentElement.dataset.mascotMotion='true';f.mutations[0].fn();f.mutations[0].fn();
  assert.equal(f.decorative.getAttribute('role'),'button');assert.equal(f.decorative.getAttribute('tabindex'),'0');
  assert.equal(f.decorative.getAttribute('aria-label'),'一二布布 · 翻开菜谱，轻点回应');
  for(const key of ['Enter',' ']){
    let prevented=0;f.root.emit('keydown',{target:f.decorative,key,preventDefault(){prevented++;}});
    assert.equal(prevented,1);assert.equal(f.timers.size,1);f.flushTimers();
  }
  control.destroy();assert.equal(f.decorative.getAttribute('role'),'img');
});
test('live reduced-motion changes restore image semantics without changing temporary pause semantics',()=>{
  const f=fixture(),control=initMascotMotion(f.root);
  f.doc.modal=true;f.mutations[1].fn();assert.equal(f.decorative.getAttribute('role'),'button');
  f.doc.modal=false;f.mutations[1].fn();
  f.doc.documentElement.dataset.reducedMotion='true';f.mutations[0].fn();assert.equal(f.decorative.getAttribute('role'),'img');
  f.doc.documentElement.dataset.reducedMotion='false';f.mutations[0].fn();assert.equal(f.decorative.getAttribute('role'),'button');
  f.media.matches=true;f.media.emit('change');assert.equal(f.decorative.getAttribute('role'),'img');
  f.media.matches=false;f.media.emit('change');assert.equal(f.decorative.getAttribute('role'),'button');
  assert.equal(f.native.getAttribute('role'),null);assert.equal(f.native.getAttribute('aria-label'),'让熊熊回应一下');
  control.destroy();
});
test('fallback bounds checking pauses an offscreen companion without an observer',()=>{
  const f=fixture({intersection:false});f.decorative.rect={top:1000,bottom:1100,left:0,right:100};const control=initMascotMotion(f.root);
  assert.equal(f.decorative.dataset.mascotActive,'false');assert.equal(f.native.dataset.mascotActive,'true');
  assert.equal(f.win.listeners.has('scroll'),true);control.destroy();assert.equal(f.win.listeners.size,0);
});
test('destroy restores decorative semantics and removes every subscription',()=>{
  const f=fixture(),control=initMascotMotion(f.root);f.root.emit('click',{target:f.native});control.destroy();control.destroy();
  assert.equal(f.decorative.getAttribute('role'),'img');assert.equal(f.decorative.getAttribute('tabindex'),null);
  assert.equal(f.decorative.getAttribute('aria-label'),'一二布布 · 翻开菜谱');
  assert.equal(f.root.listeners.size,0);assert.equal(f.doc.listeners.size,0);assert.equal(f.media.listeners.size,0);assert.equal(f.timers.size,0);
  assert.ok(f.mutations.every(x=>x.disconnected));assert.equal(f.intersections[0].disconnected,true);
  control.refresh();assert.equal(f.native.classList.contains('mascot-host'),false);
});
console.log(`Passed ${passed} mascot motion regressions: visibility, accessibility, preferences, bounded reactions and lifecycle cleanup.`);
