import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const deps=process.env.BEAR_UI_TEST_DEPS?path.resolve(process.env.BEAR_UI_TEST_DEPS):new URL('./ui-test-runtime/node_modules/',import.meta.url).pathname;
const [{JSDOM,VirtualConsole},{indexedDB}]=await Promise.all([import(pathToFileURL(path.join(deps,'jsdom/lib/api.js'))),import(pathToFileURL(path.join(deps,'fake-indexeddb/build/esm/index.js')))]);
const web=new URL('../web/',import.meta.url),html=fs.readFileSync(new URL('index.html',web),'utf8'),version=/app\.js\?v=(\d+)/.exec(html)[1];
const errors=[],vc=new VirtualConsole();vc.on('jsdomError',error=>errors.push(error.message));
const dom=new JSDOM(html,{url:'https://ledger.test/',pretendToBeVisual:true,runScripts:'outside-only',virtualConsole:vc}),w=dom.window;
for(const name of ['window','document','navigator','localStorage','FormData','MutationObserver','Event','CustomEvent','Image','Audio','HTMLElement','HTMLInputElement'])Object.defineProperty(globalThis,name,{value:name==='window'?w:w[name],configurable:true});
w.matchMedia=query=>({matches:false,media:query,addEventListener(){},removeEventListener(){}});globalThis.matchMedia=w.matchMedia;
w.scrollTo=()=>{};w.HTMLElement.prototype.scrollIntoView=function(){};w.HTMLElement.prototype.animate=()=>({finished:Promise.resolve(),cancel(){}});
w.HTMLDialogElement.prototype.showModal=function(){this.open=true;};w.HTMLDialogElement.prototype.close=function(){this.open=false;this.dispatchEvent(new w.Event('close'));};
w.HTMLMediaElement.prototype.pause=function(){};w.HTMLMediaElement.prototype.play=async function(){};
globalThis.requestAnimationFrame=w.requestAnimationFrame.bind(w);globalThis.cancelAnimationFrame=w.cancelAnimationFrame.bind(w);
globalThis.indexedDB=w.indexedDB=indexedDB;globalThis.CSS=w.CSS={escape:s=>String(s).replace(/[^\w-]/g,c=>'\\'+c)};
w.eval(fs.readFileSync(new URL('lunar.js',web),'utf8'));globalThis.Solar=w.Solar;globalThis.Lunar=w.Lunar;
for(const match of html.matchAll(/rel="stylesheet" href="([^?]+)\?/g)){const style=w.document.createElement('style');style.textContent=fs.readFileSync(new URL(match[1],web),'utf8');w.document.head.append(style);assert.ok(style.sheet?.cssRules.length);}
const moduleURL=name=>new URL(name+'?v='+version,web).href;
const model=await import(moduleURL('model.js'));await model.openStore();await model.setSound(false);
const fixture=[
 ['before','2026-12-30',900,'category-0','expense'],['first','2026-12-31',1000,'category-0','expense'],
 ['middle','2027-01-01',1500,'category-1','expense'],['last','2027-01-02',703,'category-0','expense'],
 ['after','2027-01-03',900,'category-0','expense'],['salary','2027-01-01',120000,'category-8','income'],
 ['bonus','2027-01-03',500,'category-9','income'],['previous','2026-07-02',2000,'category-2','expense'],
 ['old-income','2026-12-01',100000,'category-8','income'],['leap','2028-02-29',100,'category-0','expense'],
];
for(const [id,date,cents,category,type] of fixture)await model.saveItem('ledger',{id,date,cents,category,type,photos:[],note:id,created:1});
await model.saveItem('ledger',{id:'deleted',date:'2027-01-01',cents:99999,type:'expense',category:'category-0',_deletedAt:Date.now()});
await import(moduleURL('app.js'));
const pause=()=>new Promise(resolve=>setTimeout(resolve,35));
for(let i=0;i<60&&!w.document.querySelector('.tabs,.initial-error');i++)await pause();
assert.equal(w.document.querySelector('.initial-error'),null);
const $=selector=>w.document.querySelector(selector);
async function click(selector){const node=$(selector);assert.ok(node,selector);node.dispatchEvent(new w.MouseEvent('click',{bubbles:true}));await pause();await pause();}
function set(name,value){const input=$(`#sheet [name="${name}"]`);assert.ok(input,name);input.value=value;input.dispatchEvent(new w.Event('input',{bubbles:true}));input.dispatchEvent(new w.Event('change',{bubbles:true}));}
async function submit(){const form=$('#sheet form');form.requestSubmit();await pause();await pause();assert.ok(!form.isConnected||!form.getAttribute('aria-busy'));}
async function selectPeriod(mode,anchor,start,end){await click('[data-ledger-action="period-picker"]');set('periodMode',mode);if(mode==='custom'){set('periodStart',start);set('periodEnd',end);}else set('periodAnchor',anchor);await submit();assert.equal($('#sheet').open,false);}
const total=type=>$(`[data-ledger-total="${type}"]`).textContent;
await click('[data-page="ledger"]');await click('[data-ledger-section="analysis"]');
await selectPeriod('custom',null,'2026-12-31','2027-01-02');
assert.equal(total('expense'),'¥32.03');assert.equal(total('income'),'¥1,200.00');assert.equal(total('net'),'¥1,167.97');
assert.equal(w.document.querySelectorAll('.ledger-pie-slice').length,2);assert.match($('.ledger-ranking').textContent,/餐饮/);assert.match($('.ledger-ranking').textContent,/53.2%/);
assert.match($('.ledger-period-date').textContent,/2026-12-31 — 2027-01-02/);
const color=$('[data-ledger-slice="category-0"]').getAttribute('fill');
await click('[data-ledger-slice="category-0"]');
assert.equal(w.document.querySelectorAll('.ledger-row').length,2);assert.ok($('[data-ledger-id="first"]'));assert.ok($('[data-ledger-id="last"]'));assert.equal($('[data-ledger-id="before"]'),null);
assert.equal(w.document.activeElement,$('.ledger-filter-tag'));assert.match($('.ledger-day-group h3').textContent,/2027年/);
await click('.ledger-back-analysis');await click('[data-ledger-analysis="income"]');
assert.equal(w.document.querySelectorAll('.ledger-pie-slice').length,1);assert.equal($('.ledger-pie-slice').tagName,'circle');assert.match($('.ledger-ranking').textContent,/收入从哪里来/);assert.match($('.ledger-insight').textContent,/收入对比/);
$('.ledger-pie-slice').dispatchEvent(new w.KeyboardEvent('keydown',{key:'Enter',bubbles:true}));await pause();assert.equal(w.document.querySelectorAll('.ledger-row').length,1);assert.ok($('[data-ledger-id="salary"]'));
await click('.ledger-back-analysis');await click('[data-ledger-analysis="expense"]');assert.equal($('[data-ledger-slice="category-0"]').getAttribute('fill'),color);
await click('[data-ledger-action="period-picker"]');set('periodStart','2027-01-05');set('periodEnd','2027-01-01');await submit();
assert.equal($('#sheet').open,true);assert.match($('#sheet .form-error').textContent,/不能早于/);assert.equal(w.document.activeElement,$('#sheet .form-error'));assert.equal(total('expense'),'¥32.03');
await click('#sheet [data-action="close"]');assert.ok($('.exit-confirm[open]'));w.bearCalendarBack();await pause();assert.equal($('[name="periodStart"]').value,'2027-01-05');
set('periodStart','2027-01-02');set('periodEnd','2027-01-02');await submit();assert.equal(total('expense'),'¥7.03');assert.equal($('.ledger-pie-slice').tagName,'circle');assert.ok(!$('.ledger-trend').innerHTML.includes('NaN'));assert.match($('.ledger-trend').textContent,/1 个统计点/);
await selectPeriod('week','2027-01-01');assert.equal(total('expense'),'¥50.03');assert.match($('.ledger-period-date').textContent,/2026-12-28 — 2027-01-03/);
await click('[data-ledger-action="next"]');assert.match($('.ledger-period-date').textContent,/2027-01-04 — 2027-01-10/);assert.ok($('.ledger-pie-empty'));
await click('[data-ledger-action="prev"]');assert.equal(total('expense'),'¥50.03');
await selectPeriod('month','2027-01-01');assert.equal(total('expense'),'¥31.03');assert.ok($('.ledger-budget-empty'));
await selectPeriod('quarter','2026-12-31');assert.equal(total('expense'),'¥19.00');assert.match($('.ledger-period-date').textContent,/第4季度/);assert.match($('.ledger-trend').textContent,/3 个统计点/);assert.match($('.ledger-insight').textContent,/少 ¥1.00/);assert.equal($('.ledger-budget-empty'),null);
await click('[data-ledger-period="year"]');assert.equal(total('expense'),'¥39.00');assert.match($('.ledger-trend').textContent,/12 个统计点/);
await selectPeriod('custom',null,'2030-01-01','2030-01-01');assert.ok($('.ledger-pie-empty'));assert.equal(w.document.querySelectorAll('.ledger-pie-slice').length,0);assert.equal(total('expense'),'¥0.00');
await selectPeriod('month','2028-02-29');assert.equal(total('expense'),'¥1.00');assert.match($('.ledger-period-date').textContent,/2028-02-01 — 2028-02-29/);
assert.equal((await model.loadAll('ledger')).length,fixture.length,'range changes never rewrite bills');
assert.deepEqual(errors,[]);
console.log('Passed ledger statistics UI: actual form routing, inclusive cross-year totals, clickable/keyboard pie drill-down, income/expense, stable category colors, validation and cancel, period navigation, zero/single-category charts, leap month, budget scope and CSS parsing.');
dom.window.close();process.exit(0);
