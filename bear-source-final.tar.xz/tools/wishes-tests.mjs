import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createWishStore,wishCents,wishMoney,wishProgress,normalizeWishes,wishDate,WISHES_KEY,MAX_CENTS} from '../web/wishes-core.js';

for(const [value,cents] of [['0.01',1],['0.10',10],['1.01',101],['99999999.99',MAX_CENTS],[' 12.3 ',1230]])assert.equal(wishCents(value),cents);
for(const value of ['',0,-1,'1.001','1e3','Infinity','1,000','+1','01','100000000','NaN'])assert.throws(()=>wishCents(value));
assert.equal(wishMoney(101),'1.01');assert.equal(wishMoney(123456),'1,234.56');
for(const date of ['2024-02-29','1900-01-01','9999-12-31'])assert.equal(wishDate(date),true);
for(const date of ['2026-02-29','2026-13-01','2026-4-1','1899-12-31',''])assert.equal(wishDate(date),false);
let saved,failWrite=false,failAtomic=false,sequence=0,timestamp=1000,atomicCount=0;
const entries=new Map(),storage={read:async()=>structuredClone(saved),write:async(key,value)=>{assert.equal(key,WISHES_KEY);if(failWrite)throw new Error('disk full');saved=structuredClone(value);return structuredClone(saved);},atomic:async rows=>{if(failAtomic)throw new Error('atomic failure');atomicCount++;assert.deepEqual(rows.map(row=>row.store),['entries','settings']);const next=structuredClone(rows);entries.set(next[0].value.id,next[0].value);saved=next[1].value;},now:()=>++timestamp,id:()=>`test-${++sequence}`};
const store=createWishStore(storage);await store.load();assert.deepEqual(store.list(),[]);
const wishId=await store.save({title:'去看演唱会',target:'0.30',photos:['data:image/png;base64,AAAA'],coverFocus:{x:0,y:100}});
assert.deepEqual(store.list()[0].coverFocus,{x:0,y:100});assert.equal(entries.size,0,'creating a wish creates no journal or ledger');
await Promise.all([store.contribute(wishId,{amount:'0.10',date:'2026-11-18'}),store.contribute(wishId,{amount:'0.20',date:'2026-11-18'})]);
assert.equal(wishProgress(store.list()[0]).saved,30,'decimal contributions use exact integer cents and concurrent writes serialize');assert.equal(wishProgress(store.list()[0]).ready,true);
const original=store.list();failWrite=true;await assert.rejects(store.contribute(wishId,{amount:'1',date:'2026-11-18'}),/disk full/);assert.deepEqual(store.list(),original,'failed write never updates visible progress');failWrite=false;
const contributionId=store.list()[0].contributions[0].id;await store.contributionState(wishId,contributionId,true);assert.equal(wishProgress(store.list()[0]).saved,20);await assert.rejects(store.complete(wishId,{date:'2026-11-18',createJournal:true}),/攒到/);assert.equal(entries.size,0);
await store.contributionState(wishId,contributionId,false);assert.equal(wishProgress(store.list()[0]).saved,30);
failAtomic=true;const beforeFailure=store.list();await assert.rejects(store.complete(wishId,{date:'2026-11-18',createJournal:true}),/atomic failure/);assert.deepEqual(store.list(),beforeFailure);assert.equal(entries.size,0);failAtomic=false;
const results=await Promise.all([store.complete(wishId,{date:'2026-11-18',createJournal:true,note:'终于看见喜欢的舞台'}),store.complete(wishId,{date:'2026-11-18',createJournal:true})]);
assert.equal(atomicCount,1,'rapid double completion commits one atomic journal');assert.equal(entries.size,1);assert.deepEqual(results.map(result=>result.created),[true,false]);
const journal=[...entries.values()][0];assert.equal(journal.note,'终于看见喜欢的舞台');assert.deepEqual(journal.photos,store.list()[0].photos);assert.equal(journal.kind,'life');assert.equal(journal.date,'2026-11-18');assert.equal(journal.ledgerId,undefined);assert.doesNotMatch(journal.note,/0\.30/,'amount is not automatically exposed in journal');
await assert.rejects(store.contribute(wishId,{amount:'1',date:'2026-11-18'}),/重新开启/);
await store.reopen(wishId);await store.complete(wishId,{date:'2026-11-19',createJournal:true});assert.equal(atomicCount,1);assert.equal(entries.size,1,'reopening and recompleting preserves the one original journal');
await store.archive(wishId,true);await assert.rejects(store.reopen(wishId),/归档恢复/);await store.archive(wishId,false);await store.reopen(wishId);
await store.save({...store.list()[0],target:'0.20'});assert.equal(wishProgress(store.list()[0]).extra,10,'lowering target retains contributions and reports surplus');
await store.complete(wishId,{date:'2026-11-19',createJournal:false});const reload=createWishStore(storage);await reload.load();assert.deepEqual(reload.list(),store.list(),'cover, notes, counters and journal link survive reload');
const detached=reload.list();detached[0].title='mutated';assert.notEqual(reload.list()[0].title,'mutated','list snapshots cannot mutate repository state');
const second=await reload.save({title:'周末的小旅行',target:'100'});await reload.contribute(second,{amount:'100',date:'2026-11-18'});await reload.complete(second,{date:'2026-11-18',createJournal:false});assert.equal(entries.size,1,'unchecked journal option only changes wish status');
assert.equal(normalizeWishes({wishes:[{id:'bad',targetCents:NaN}]}).wishes.length,0);

// Exercise the production UI module through the actual model/native bridge boundary.
const tables={settings:new Map(),entries:new Map()},lifecycle=[];let failNative=false,failBatch=false,batchCount=0;
globalThis.window={BearStore:{request(id,raw){const request=JSON.parse(raw);try{let result;if(request.op==='status')result={ready:true};else if(request.op==='get')result={value:tables[request.store]?.get(request.key)};else if(request.op==='put'){if(failNative)throw new Error('本机空间不足');tables[request.store].set(request.key,structuredClone(request.value));result={value:request.value};}else if(request.op==='put-batch'){if(failBatch)throw new Error('关联保存失败');batchCount++;for(const row of request.rows)tables[row.store].set(row.key,structuredClone(row.value));result={rows:request.rows};}else throw new Error(`Unexpected operation ${request.op}`);queueMicrotask(()=>window.bearStoreResult(id,{ok:true,value:structuredClone(result)}));}catch(error){queueMicrotask(()=>window.bearStoreResult(id,{ok:false,error:error.message}));}}}};
const source=await readFile(new URL('../web/wishes.js',import.meta.url),'utf8'),specifier=source.match(/from ['"]([^'"]*model\.js[^'"]*)['"]/)[1];
const model=await import(new URL('../web/'+specifier.slice(2),import.meta.url));await model.openStore();const module=await import('../web/wishes.js');
const OriginalFormData=globalThis.FormData;globalThis.FormData=class{constructor(form){this.values=new Map(Object.entries(form.values));}get(name){return this.values.get(name)??null;}has(name){return this.values.has(name);}};
let html='',activeForm=null,notice='',photos=[],savedCalls=0,viewer=null,refreshFails=false;
const ui={open(title,body){html=body;lifecycle.push(title);activeForm=null;},sheet:{dataset:{},querySelector(selector){return selector==='form'?activeForm:null;}},announce(message){notice=message;},setDraft(){},confirmLeave(next){next();},photoFields:()=>'<section class="photo-field"></section>',initPhotos(value){photos=value;},getPhotos:()=>photos,getCoverFocus:()=>({x:0,y:100}),getEntries:()=>[...tables.entries.values()],showPhotos(value){viewer=value;},onSaved(){savedCalls++;},async refreshData(){if(refreshFails)throw new Error('refresh failed');}};
await module.initWishes(ui);
const form=(kind,values,id='')=>{const error={textContent:'',setAttribute(){},focus(){},scrollIntoView(){}},button={disabled:false};const result={isConnected:true,dataset:{form:kind,id},values,querySelector:()=>error,querySelectorAll:()=>[button],error,button};activeForm=result;return result;};
try{
  module.openWishes();assert.match(html,/先放进一个/);assert.match(html,/不会转账/);
  await module.wishesClicked({wishAction:'new'});assert.equal(ui.sheet.dataset.view,'wish-edit');
  photos=['data:image/png;base64,AAAA'];failNative=true;const failed=form('wish',{wishTitle:'一张<演唱会>门票',wishTarget:'1.01',wishNote:'喜欢的舞台'});await module.wishesSubmitted(failed);assert.match(failed.error.textContent,/空间不足/);assert.equal(savedCalls,0);assert.equal(tables.settings.size,0);assert.equal(failed.button.disabled,false);failNative=false;
  await module.wishesSubmitted(failed);assert.equal(savedCalls,1);let wish=tables.settings.get(WISHES_KEY).wishes[0];assert.equal(wish.targetCents,101);assert.match(html,/愿望封面/);assert.match(html,/object-position:0% 100%/);assert.equal(ui.sheet.dataset.view,'wish-detail');assert.deepEqual(wish.coverFocus,{x:0,y:100});
  await module.wishesClicked({wishAction:'contribute',wishId:wish.id});assert.match(html,/不会移动资金/);await module.wishesSubmitted(form('wish-contribution',{wishAmount:'1.01',wishDate:'2026-11-18'},wish.id));wish=tables.settings.get(WISHES_KEY).wishes[0];assert.equal(wishProgress(wish).saved,101);assert.match(html,/愿望实现啦/);
  await module.wishesClicked({wishAction:'photo',wishId:wish.id});assert.deepEqual(viewer,['data:image/png;base64,AAAA']);
  await module.wishesClicked({wishAction:'complete',wishId:wish.id});assert.match(html,/name="wishJournal" type="checkbox">/,'journal creation is explicitly opt-in');
  const failedCompletion=form('wish-complete',{wishDate:'2026-11-18',wishJournal:'on'},wish.id);failBatch=true;await module.wishesSubmitted(failedCompletion);assert.match(failedCompletion.error.textContent,/关联保存失败/);assert.equal(tables.entries.size,0);assert.equal(tables.settings.get(WISHES_KEY).wishes[0].completedAt,0);failBatch=false;refreshFails=true;
  await module.wishesSubmitted(failedCompletion);assert.equal(batchCount,1);assert.equal(tables.entries.size,1);assert.match(notice,/手账已保存/,'post-commit refresh failure is not reported as a failed write');assert.equal(ui.sheet.dataset.view,'wish-detail');
  await module.refreshWishes();module.openWishes('completed');assert.match(html,/已经实现/);assert.match(html,/&lt;演唱会&gt;/,'user titles are escaped in markup');
  await module.wishesClicked({wishAction:'archive',wishId:wish.id});assert.match(html,/恢复这个愿望/);await module.wishesClicked({wishAction:'restore',wishId:wish.id});assert.match(html,/愿望已实现/);
}finally{globalThis.FormData=OriginalFormData;}
console.log('Passed wishes: exact cents, concurrent writes, contribution undo/restore, target changes, cover focus, archive/reopen, atomic opt-in journal and idempotency, storage failure and committed-save UI recovery.');
