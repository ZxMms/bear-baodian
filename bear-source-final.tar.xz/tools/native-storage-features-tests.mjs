import assert from 'node:assert/strict';

const stores=['entries','recipes','moods','ledger','ledgerCategories','settings'];
const tables=Object.fromEntries(stores.map(name=>[name,new Map()]));
const calls=[],retention=30*86400000;
const image='data:image/png;base64,iVBORwECAwQ=';
const media='media/normalized-test.jpg';
function normalize(value){
  if(!value||typeof value!=='object')return value;
  if(Array.isArray(value))return value.map(normalize);
  return Object.fromEntries(Object.entries(value).map(([name,child])=>[name,name==='photos'&&Array.isArray(child)?child.map(()=>media):['foodRecipeCover','receipt','photo'].includes(name)&&child===image?media:normalize(child)]));
}
function respond(req){
  const table=tables[req.store];
  if(req.op==='status')return {ready:true};
  if(req.op==='all')return {value:[...table.values()]};
  if(req.op==='get')return {value:table.get(req.key)??null};
  if(req.op==='put'){const value=normalize(req.value);table.set(req.key,value);return {value};}
  if(req.op==='put-batch'){const rows=req.rows.map(row=>({...row,value:normalize(row.value)}));for(const row of rows)tables[row.store].set(row.key,row.value);return {rows};}
  if(req.op==='remove'){table.delete(req.key);return {};}
  if(req.op==='soft-delete'){let value=table.get(req.key);if(value&&!value._deletedAt){value={...value,_deletedAt:req.now,_deleteExpiresAt:req.now+retention};table.set(req.key,value);}return {value:value??null};}
  if(req.op==='restore'){const value={...table.get(req.key)};if(!value._deletedAt)throw new Error('missing deleted row');delete value._deletedAt;delete value._deleteExpiresAt;table.set(req.key,value);return {value};}
  if(req.op==='purge-trash-item'){if(table.get(req.key)&&!table.get(req.key)._deletedAt)throw new Error('active row');table.delete(req.key);return {};}
  if(req.op==='purge-trash'){let removed=0;for(const name of ['entries','recipes','ledger'])for(const [key,row] of tables[name])if(row._deletedAt&&(!req.expiredOnly||row._deleteExpiresAt<=req.now)){tables[name].delete(key);removed++;}return {removed};}
  throw new Error(`Unexpected op ${req.op}`);
}
globalThis.window={BearStore:{request(id,input){
  const req=JSON.parse(input);calls.push(req);
  queueMicrotask(()=>{try{window.bearStoreResult(id,{ok:true,value:structuredClone(respond(req))});}catch(error){window.bearStoreResult(id,{ok:false,error:error.message});}});
}}};
globalThis.indexedDB={open(){throw new Error('ready native backend must not open IndexedDB');}};
const model=await import('../web/model.js');await model.openStore();
const fakeText='media/'+('0'.repeat(64))+'.jpg';
const draft=await model.saveDraft('entry',{photos:[image],foodRecipeCover:image,fields:[{name:'note',value:fakeText}],context:{receipt:image}});
assert.deepEqual(draft.photos,[media]);assert.equal(draft.foodRecipeCover,media);assert.equal(draft.context.receipt,media);assert.equal(draft.fields[0].value,fakeText);
assert.equal(calls.at(-1).key,'draft:entry');assert.equal(draft.draftId,'entry');assert(draft.savedAt>0);
assert.deepEqual(await model.loadDraft('entry'),draft);
await model.putSetting('kitchen-cooking',{recipeId:'recipe',step:2});await model.putSetting('sound',false);
assert.equal(await model.getSetting('sound'),false);assert.equal((await model.listDrafts()).length,1);
await model.clearDraft('entry');assert.equal(await model.loadDraft('entry'),undefined);assert.equal((await model.listDrafts()).length,0);
assert.throws(()=>model.saveDraft('',{}));assert.throws(()=>model.saveDraft('entry',[]));
const memory={id:'memory',kind:'life',photos:[image],ledgerId:'bill'},bill={id:'bill',date:'2026-11-17',type:'expense',cents:3500,photos:[image],entryId:'memory'};
await model.saveItemsAtomically([{store:'ledger',key:'bill',value:bill},{store:'entries',key:'memory',value:memory}]);
assert.equal(calls.at(-1).op,'put-batch');assert.deepEqual(calls.at(-1).rows.map(row=>[row.store,row.key]),[['ledger','bill'],['entries','memory']]);
assert.deepEqual(memory.photos,[media]);assert.deepEqual(bill.photos,[media]);
const before=calls.length;
await assert.rejects(model.saveItemsAtomically([{store:'entries',value:memory},{store:'entries',value:memory}]),/重复/);
await assert.rejects(model.saveItemsAtomically([{store:'entries',key:'different',value:memory}]),/格式/);
assert.equal(calls.length,before,'invalid batch must not cross native bridge');
const deleted=await model.removeItem('ledger','bill');assert.equal(calls.at(-1).op,'soft-delete');assert.equal(deleted._deleteExpiresAt-deleted._deletedAt,retention);
assert.equal((await model.loadAll('ledger')).length,0);assert.equal((await model.loadAll('ledger',{includeDeleted:true})).length,1);assert.equal((await model.loadAll('entries')).length,1);
const trash=await model.loadTrash(deleted._deleteExpiresAt+1);assert.equal(trash.length,1);assert.equal(trash[0].store,'ledger');assert(trash[0].expired);assert.equal(trash[0].remainingDays,0);
assert.equal(tables.ledger.size,1,'reading expired trash never purges');
const restored=await model.restoreItem('ledger','bill');assert.equal(calls.at(-1).op,'restore');assert.equal(restored.cents,3500);assert(!restored._deletedAt);
assert.equal((await model.loadAll('ledger')).length,1);assert.equal((await model.loadTrash()).length,0);
await assert.rejects(model.purgeTrashItem('ledger','bill'),/active/);
await model.removeItem('entries','memory');assert.deepEqual(await model.purgeTrash(),{removed:0});assert.equal(calls.at(-1).expiredOnly,true);
assert.deepEqual(await model.purgeTrash({expiredOnly:false}),{removed:1});assert.equal(tables.ledger.size,1);
assert.equal(model.kinds.capsule.name,'时光胶囊');
console.log('Passed native model contracts: durable draft metadata and image refs, settings, single atomic bridge batch, in-place normalization, trash filtering/restore and explicit purge.');
