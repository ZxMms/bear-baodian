import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
import {mascotMotionAllowed} from '../web/mascot-motion.js';
import {moods,onDate} from '../web/model.js';

// Run the shipped controller code, while controlling dates, persistence and DOM edges.
// These tests make no browser or network calls.
const appSource=await readFile(new URL('../web/app.js',import.meta.url),'utf8');
const workbenchSource=(await readFile(new URL('../web/workbench.js',import.meta.url),'utf8'))
  .replace(/^import .*;\r?\n/gm,'').replace(/^export /gm,'');
function appHelper(name,values){
  const start=new RegExp(`^function ${name}\\(`,'m').exec(appSource);
  assert(start,`Missing app helper ${name}`);
  const rest=appSource.slice(start.index),end=/\n\}/.exec(rest);
  assert(end,`Missing end of app helper ${name}`);
  const ctx=vm.createContext(values);vm.runInContext(rest.slice(0,end.index+2),ctx);return ctx;
}
const plain=value=>JSON.parse(JSON.stringify(value));
let passed=0;const failures=[];
async function test(name,run){try{await run();passed++;}catch(error){failures.push(`${name}: ${error.stack||error.message}`);}}

function dayContext(overrides={}){
  let rendered=0;
  const ctx=appHelper('refreshDay',{today:()=> '2026-11-22',lastToday:'2026-11-21',chosen:'2026-11-21',month:'2026-11',recipeDate:'2026-11-21',recommendationOffset:3,sheet:{open:false},render(){rendered++;},...overrides});
  return {ctx,get rendered(){return rendered;}};
}
await test('A recipe following today rolls into the new solar-term day',()=>{
  const run=dayContext();run.ctx.refreshDay();
  assert.equal(run.ctx.recipeDate,'2026-11-22');assert.equal(run.ctx.recommendationOffset,0);
  assert.equal(run.ctx.chosen,'2026-11-22');assert.equal(run.ctx.lastToday,'2026-11-22');assert.equal(run.rendered,1);
});
await test('A manually selected recommendation date survives a midnight rollover',()=>{
  const run=dayContext({recipeDate:'2026-12-25',recommendationOffset:2});run.ctx.refreshDay();
  assert.equal(run.ctx.recipeDate,'2026-12-25');assert.equal(run.ctx.recommendationOffset,2);assert.equal(run.ctx.chosen,'2026-11-22');
});
await test('A historical calendar selection does not prevent today-based recipe refresh',()=>{
  const run=dayContext({chosen:'2026-10-01',month:'2026-10'});run.ctx.refreshDay();
  assert.equal(run.ctx.chosen,'2026-10-01');assert.equal(run.ctx.month,'2026-10');assert.equal(run.ctx.recipeDate,'2026-11-22');
});
await test('Year rollover follows today without keeping last year in either view',()=>{
  const run=dayContext({today:()=> '2027-01-01',lastToday:'2026-12-31',chosen:'2026-12-31',month:'2026-12',recipeDate:'2026-12-31'});run.ctx.refreshDay();
  assert.equal(run.ctx.chosen,'2027-01-01');assert.equal(run.ctx.month,'2027-01');assert.equal(run.ctx.recipeDate,'2027-01-01');
});
await test('Open editors defer date refresh and refresh once after they close',()=>{
  const run=dayContext({sheet:{open:true}});run.ctx.refreshDay();assert.equal(run.rendered,0);assert.equal(run.ctx.lastToday,'2026-11-21');
  run.ctx.sheet.open=false;run.ctx.refreshDay();run.ctx.refreshDay();assert.equal(run.rendered,1);assert.equal(run.ctx.recipeDate,'2026-11-22');
});

class FormDataDouble{
  constructor(form){this.values=new Map(form.values);}
  get(name){return this.values.get(name)??null;}
  has(name){return this.values.has(name);}
  [Symbol.iterator](){return this.values[Symbol.iterator]();}
}
const preferenceForm=values=>({dataset:{form:'preferences'},values:Object.entries({theme:'day',pinnedCountdownId:'',...values})});
async function settingsContext(stored={},display={}){
  const events=[],writes=[],dataset={},meta={},sheet={dataset:{}},markup=[];
  let save=async()=>{};
  const ctx=vm.createContext({
    FormData:FormDataDouble,document:{documentElement:{dataset},querySelector:selector=>selector.startsWith('meta')?{setAttribute:(name,value)=>{meta[name]=value;}}:null},
    matchMedia:()=>({matches:true,addEventListener(){}}),getSetting:async()=>stored,
    putSetting:async(key,value)=>{events.push('write');writes.push({key,value:plain(value)});await save(key,value);events.push('committed');},
    listDrafts:async()=>[],loadTrash:async()=>[],icon:()=>'',dateKey:()=> '2026-11-17',lunarLabel:()=>({full:'农历丙午年 十月初九',term:''}),daysBetween:()=>1,
    seasonalContext:()=>({name:'立冬',isTermDay:false}),moods,onDate,
  });
  vm.runInContext(workbenchSource,ctx);
  await ctx.initWorkbench({version:'test',sheet,getCountdowns:()=>display.cards||[],getEntries:()=>display.entries||[],getMoods:()=>display.moods||[],open:(title,html)=>{markup.push({title,html});events.push('open');},setDraft:()=>events.push('baseline'),render:()=>events.push('render'),syncWidgets:()=>events.push('widget'),announce:()=>events.push('announce')});
  return {ctx,dataset,meta,sheet,markup,events,writes,prefs:()=>plain(vm.runInContext('getPreferences()',ctx)),setSave:fn=>{save=fn;}};
}
await test('Opening display settings establishes an unsaved-edit baseline',async()=>{
  const run=await settingsContext();await run.ctx.openSettings();
  assert.deepEqual(run.events,['open','baseline']);assert.equal(run.sheet.dataset.view,'settings');assert(run.markup[0].html.includes('data-form="preferences"'));
});
await test('Failed preference persistence leaves active styling, widget and baseline unchanged',async()=>{
  const run=await settingsContext({theme:'night',widgetTheme:'mint',mascotMotion:true});
  const before=run.prefs(),themeBefore={...run.dataset};run.setSave(async()=>{throw new Error('disk full');});
  await assert.rejects(run.ctx.workbenchSubmitted(preferenceForm({theme:'day',largeText:'on',reducedMotion:'on'})),/disk full/);
  assert.deepEqual(run.prefs(),before);assert.deepEqual(run.dataset,themeBefore);assert.deepEqual(run.events,['write']);
});
await test('Pending preference writes do not preview or announce uncommitted settings',async()=>{
  const run=await settingsContext({theme:'night',widgetTheme:'peach',mascotMotion:true});
  let release;run.setSave(()=>new Promise(resolve=>{release=resolve;}));
  const pending=run.ctx.workbenchSubmitted(preferenceForm({theme:'day'}));
  assert.equal(run.prefs().theme,'night');assert.equal(run.dataset.theme,'night');assert.deepEqual(run.events,['write']);
  release();await pending;assert.equal(run.dataset.theme,'day');assert.deepEqual(run.events,['write','committed','render','widget','baseline','announce']);
});
await test('Saving display settings preserves the independent widget palette and stores motion controls',async()=>{
  const run=await settingsContext({theme:'night',widgetTheme:'mint',mascotMotion:true});
  assert.equal(await run.ctx.workbenchSubmitted(preferenceForm({largeText:'on',reducedMotion:'on',pinnedCountdownId:'birthday'})),true);
  assert.equal(run.prefs().widgetTheme,'mint');assert.equal(run.writes[0].value.widgetTheme,'mint');
  assert.equal(run.prefs().mascotMotion,false);assert.equal(run.prefs().reducedMotion,true);assert.equal(run.prefs().largeText,true);
  assert.equal(run.dataset.mascotMotion,'false');assert.equal(run.dataset.reducedMotion,'true');assert.equal(run.dataset.theme,'day');
  assert.equal(run.prefs().pinnedCountdownId,'birthday');
});
await test('Enabling mascot motion again persists independently of large text and widget color',async()=>{
  const run=await settingsContext({widgetTheme:'peach',mascotMotion:false,largeText:true,reducedMotion:true});
  await run.ctx.workbenchSubmitted(preferenceForm({mascotMotion:'on'}));
  assert.equal(run.prefs().mascotMotion,true);assert.equal(run.dataset.mascotMotion,'true');
  assert.equal(run.prefs().largeText,false);assert.equal(run.prefs().reducedMotion,false);assert.equal(run.prefs().widgetTheme,'peach');
});
await test('Older preference records use cream widgets and enabled mascot motion by default',async()=>{
  const run=await settingsContext({theme:'night'});
  assert.equal(run.prefs().widgetTheme,'cream');assert.equal(run.prefs().mascotMotion,true);assert.equal(run.dataset.mascotMotion,'true');
});
await test('Widget palette changes save before refreshing and retain all display preferences',async()=>{
  const run=await settingsContext({theme:'night',largeText:true,mascotMotion:false,reducedMotion:true});
  await run.ctx.workbenchClicked({workWidgetTheme:'peach'});
  assert.equal(run.prefs().widgetTheme,'peach');assert.equal(run.prefs().theme,'night');assert.equal(run.prefs().mascotMotion,false);assert.equal(run.prefs().largeText,true);
  assert.deepEqual(run.events,['write','committed','widget','open','announce']);
});
await test('Failed widget color persistence keeps the previously chosen color',async()=>{
  const run=await settingsContext({widgetTheme:'mint'});run.setSave(async()=>{throw new Error('write failed');});
  await assert.rejects(run.ctx.workbenchClicked({workWidgetTheme:'peach'}),/write failed/);
  assert.equal(run.prefs().widgetTheme,'mint');assert.deepEqual(run.events,['write']);
});
await test('Unknown widget palettes cannot replace an existing choice',async()=>{
  const run=await settingsContext({widgetTheme:'mint'});await run.ctx.workbenchClicked({workWidgetTheme:'black'});
  assert.equal(run.prefs().widgetTheme,'mint');assert.equal(run.writes.length,0);assert.equal(run.events.length,0);
});
await test('Widget preview uses recurring events and current mood without exposing capsule text',async()=>{
  const run=await settingsContext({widgetTheme:'mint'},{entries:[
    {id:'capsule',kind:'capsule',date:'2026-11-17',time:'23:59',title:'未开启的私密标题',note:'私密正文',photos:['data:image/jpeg;base64,privatephoto']},
    {id:'annual',kind:'anniversary',date:'2020-11-17',title:'每年都会重逢',recurrence:{type:'yearly'}},
    {id:'tomorrow',kind:'life',date:'2026-11-18',title:'明天记录不可混进今天'},
  ],moods:[{date:'2026-11-17',mood:'happy',note:'不应展示心情正文'}]});
  run.ctx.openWidgets();const markup=run.markup.at(-1).html;
  assert(markup.includes('今日心情 · '+moods.happy.name));assert(markup.includes('2 条记录'));
  assert(markup.includes('立冬时节'));assert(markup.includes('时光胶囊到时间啦'));assert(markup.includes('每年都会重逢'));
  for(const hidden of ['未开启的私密标题','私密正文','privatephoto','明天记录不可混进今天','不应展示心情正文'])assert(!markup.includes(hidden),hidden);
});
await test('Widget preview escapes agenda titles before rendering them',async()=>{
  const run=await settingsContext({}, {entries:[{id:'unsafe',kind:'life',date:'2026-11-17',title:'<img src=x onerror=bad()> & 一件小事'}]});
  run.ctx.openWidgets();const markup=run.markup.at(-1).html;
  assert(!markup.includes('<img src=x'));assert(markup.includes('&lt;img src=x onerror=bad()&gt; &amp; 一件小事'));
});

function renderContext({oldLabel='菜谱分类',nextLabel='菜谱分类',oldScroll=176}={}){
  const before={scrollLeft:oldScroll,getAttribute:()=>oldLabel},after=nextLabel?{scrollLeft:0,getAttribute:()=>nextLabel}:null;
  let current=before,refreshes=0;
  const app={querySelector:()=>current,set innerHTML(_html){current=after;}};
  const ctx=appHelper('render',{app,page:'recipes',head:()=>'',navigation:()=>'',calendarMarkup:()=>'',journalMarkup:()=>'',recipeMarkup:()=>'',ledgerMarkup:()=>'',paintWeather(){},mascotMotion:{refresh(){refreshes++;}}});
  return {ctx,after,get refreshes(){return refreshes;}};
}
await test('Selecting a later recipe category preserves the horizontal chip position',()=>{
  const run=renderContext();run.ctx.render();assert.equal(run.after.scrollLeft,176);assert.equal(run.refreshes,1);
});
await test('Journal filtering also preserves its own chip position',()=>{
  const run=renderContext({oldLabel:'记录分类',nextLabel:'记录分类',oldScroll:224});run.ctx.page='journal';run.ctx.render();assert.equal(run.after.scrollLeft,224);
});
await test('Changing sections never copies recipe scroll into unrelated journal filters',()=>{
  const run=renderContext({nextLabel:'记录分类'});run.ctx.page='journal';run.ctx.render();assert.equal(run.after.scrollLeft,0);
});
await test('Rendering a section without filters remains safe',()=>{
  const run=renderContext({nextLabel:null});run.ctx.page='calendar';run.ctx.render();assert.equal(run.refreshes,1);
});
await test('Mascot animation respects the separate toggle, reduced motion and hidden/modal state',()=>{
  assert.equal(mascotMotionAllowed(),true);
  for(const flag of ['reduced','systemReduced','hidden','modal'])assert.equal(mascotMotionAllowed({[flag]:true}),false,flag);
  assert.equal(mascotMotionAllowed({enabled:false}),false);
});

if(failures.length){console.error(`Failed ${failures.length} UI polish regressions (${passed} passed):\n${failures.map(x=>' - '+x).join('\n')}`);process.exitCode=1;}
else console.log(`Passed ${passed} UI polish regressions: day rollover, preference durability, widget colors, chip scroll and motion.`);
