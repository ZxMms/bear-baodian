import assert from "node:assert/strict";
import vm from "node:vm";
import { readFileSync } from "node:fs";
import { lastWorkday, nextPayday, nextHoliday, dayPolicy, daysBetween, countdownParts, lunarLabel } from "../web/calendar-tools.js";
import { weatherLook, isWeatherStale } from "../web/weather.js";
import { nextScheduledDate, monthOccurrence, knownWorkDates } from "../web/calendar-tools.js";
import { onDate, nextOccurrence } from "../web/model.js";

const monthly31 = { type: "monthly", day: 31, overflow: "last" };
assert.equal(nextScheduledDate("2026-01-31", monthly31, "2026-02-01"), "2026-02-28");
assert.equal(nextScheduledDate("2026-01-31", monthly31, "2026-03-01"), "2026-03-31");
assert.equal(nextScheduledDate("2026-01-31", {...monthly31, overflow:"skip"}, "2026-02-01"), "2026-03-31");
assert.equal(nextScheduledDate("2026-01-31", monthly31, "2028-02-01"), "2028-02-29");
assert.equal(nextScheduledDate("2026-11-26", {type:"monthly",day:25}, "2026-11-16"), "2026-12-25");
assert.equal(nextScheduledDate("2026-01-01", {type:"monthly",day:25}, "2026-11-25"), "2026-11-25");
assert.equal(nextScheduledDate("2026-01-01", {type:"monthly",day:25}, "2026-11-26"), "2026-12-25");
assert.equal(nextScheduledDate("2024-02-29", {type:"yearly"}, "2097-01-01"), "2104-02-29");
assert.equal(nextScheduledDate("2026-01-01", {type:"last-workday",workMode:"official"}, "2027-01-01"), "2027-01-31");
assert.equal(nextScheduledDate("2026-01-01", {type:"last-workday",workMode:"five-day"}, "2027-01-01"), "2027-01-29");
assert.equal(nextScheduledDate("2026-01-01", {type:"last-workday",workMode:"official"}, "2028-01-01"), null);
assert.equal(nextScheduledDate("2026-01-01", {type:"last-workday",workMode:"weekdays"}, "2028-01-01"), "2028-01-31");
assert.equal(monthOccurrence(2026, 2, {type:"monthly", day:32}), null);
const recurring = {kind:"event",date:"2026-01-31",recurrence:monthly31};
assert.equal(onDate(recurring,"2026-02-28"), true);
assert.equal(onDate(recurring,"2026-03-28"), false);
assert.equal(onDate(recurring,"2025-12-31"), false);
assert.equal(onDate({kind:"anniversary", date:"2024-11-16",repeat:true},"2026-11-16"), true);
assert.equal(nextOccurrence({kind:"anniversary",date:"2024-11-16",repeat:false},"2026-11-16"), null);
assert.equal(knownWorkDates("2027-01-01", "official").length, 12);
assert.equal(knownWorkDates("2027-01-01", "official")[0], "2027-01-31");

// Public holiday edge cases: the last working day is sometimes a Sunday.
assert.equal(lastWorkday(2027, 1), "2027-01-31");
assert.equal(lastWorkday(2027, 1, "five-day"), "2027-01-29");
assert.equal(lastWorkday(2026, 2), "2026-02-28");
assert.equal(lastWorkday(2026, 2, "weekdays"), "2026-02-27");
assert.equal(lastWorkday(2028, 1), null);
assert.equal(lastWorkday(2028, 1, "weekdays"), "2028-01-31");
assert.equal(nextPayday("2026-11-30"), "2026-11-30");
assert.equal(nextPayday("2026-01-31"), "2026-02-28");
assert.equal(nextPayday("2027-12-31"), "2027-12-31");
assert.equal(nextPayday("2028-01-01"), null);
assert.equal(nextHoliday("2026-11-16").start, "2027-01-01");
assert.equal(nextHoliday("2027-02-13").name, "春节");
assert.equal(nextHoliday("2027-02-14").name, "清明节");
assert.equal(nextHoliday("2028-01-01"), null);
assert.equal(dayPolicy("2027-01-31").work, true);
assert.equal(dayPolicy("2027-02-06").holiday.name, "春节");
assert.equal(daysBetween("2026-11-16", "2027-01-01"), 46);
assert.equal(daysBetween("2027-03-14", "2027-03-15"), 1);
const clock = new Date("2026-11-16T12:00:00").getTime();
assert.deepEqual(countdownParts("2026-11-17", "13:02", clock), {days:1, hours:1, minutes:2, seconds:0, done:false, target:clock+90120000});
assert.equal(countdownParts("2026-11-16", "12:00", clock).done, true);
assert.equal(countdownParts("2026-11-15", "12:00", clock).seconds, 0);
assert.equal(countdownParts("invalid", "12:00", clock), null);

// Offline lunar library in the same classic-script mode as Android WebView.
const context = vm.createContext({});
vm.runInContext(readFileSync(new URL("../web/lunar.js", import.meta.url), "utf8"), context);
globalThis.Solar = context.Solar;
assert.match(lunarLabel("2027-02-06").full, /正月初一/); // HKO 2027 conversion table
assert.match(lunarLabel("2026-02-17").full, /正月初一/);
assert.equal(lunarLabel("2026-11-16").short, "初八");
assert.equal(lunarLabel("2026-11-22").term, "小雪");
assert.equal(lunarLabel("2101-01-01").short, "");

assert.equal(weatherLook(0, false).icon, "☾");
assert.equal(weatherLook(0, true).icon, "☀");
for (const code of [51, 57, 65, 67, 82, 95, 99]) assert.equal(weatherLook(code).kind, "rain");
for (const code of [71, 73, 75, 77, 85, 86]) assert.equal(weatherLook(code).kind, "snow");
assert.equal(weatherLook(48).kind, "fog");
assert.equal(weatherLook(999).kind, "unknown");
assert.equal(isWeatherStale({updatedAt:clock}, clock+3600000), false);
assert.equal(isWeatherStale({updatedAt:clock}, clock+7200001), true);
assert.equal(isWeatherStale({updatedAt:clock+600000}, clock), true);
console.log("Passed: holiday/workday rules, unknown years, countdown boundaries, lunar conversions, weather and cache states.");
