import assert from 'node:assert/strict';
import {normalizeCoverFocus,coverStyle,movePhoto,fittedSize,clampPan,zoomAt,swipeStep,focusAfterDrag,outputSize,validPhotoSource,headerDimensions} from '../web/photo-experience-core.js';

// Reordering must retain every photo and leave an unsaved draft's old snapshot untouched.
const photos=['one','two','three','four','five'];
assert.deepEqual(movePhoto(photos,0,4),['two','three','four','five','one']);
assert.deepEqual(movePhoto(photos,4,1),['one','five','two','three','four']);
assert.deepEqual(photos,['one','two','three','four','five']);
for(const [from,to] of [[-1,0],[1,5],[1.5,2],[0,NaN]])assert.deepEqual(movePhoto(photos,from,to),photos);

// A tall screenshot fits completely; zooming keeps its content under the finger and clamps edges.
assert.deepEqual(fittedSize(1080,6000,390,600),{width:108,height:600});
assert.deepEqual(fittedSize(0,6000,390,600),{width:0,height:0});
const initial={scale:1,x:0,y:0},point={x:40,y:-70},zoomed=zoomAt(initial,3,point);
assert.equal((point.x-zoomed.x)/zoomed.scale,(point.x-initial.x)/initial.scale);
assert.equal((point.y-zoomed.y)/zoomed.scale,(point.y-initial.y)/initial.scale);
assert.deepEqual(clampPan(100,999,3,108,600,390,600),{x:0,y:600});
assert.deepEqual(clampPan(-999,-999,3,390,260,390,600),{x:-390,y:-90});
assert.equal(zoomAt(initial,99).scale,6);
assert.equal(zoomAt(initial,.2).scale,1);
assert.equal(swipeStep(-100,20,390),1);
assert.equal(swipeStep(100,20,390),-1);
assert.equal(swipeStep(50,3,390),0);
assert.equal(swipeStep(100,95,390),0);

// Crop focus cannot move along a dimension that does not overflow the frame.
assert.deepEqual(normalizeCoverFocus(),{x:50,y:50});
assert.deepEqual(normalizeCoverFocus({x:-1,y:999}),{x:0,y:100});
assert.equal(coverStyle({x:20,y:70}),'object-position:20% 70%');
assert.deepEqual(focusAfterDrag({x:50,y:50},25,-25,100,0),{x:25,y:50});
assert.deepEqual(focusAfterDrag({x:50,y:50},0,-999,0,100),{x:50,y:100});

// Text mode retains more detail but respects both edge and pixel caps; do not upscale.
assert.deepEqual(outputSize(3000,6000),{width:600,height:1200,quality:.8});
assert.deepEqual(outputSize(1080,6000,'clear'),{width:720,height:4000,quality:.92});
assert.deepEqual(outputSize(600,800,'clear'),{width:600,height:800,quality:.92});
for(const [width,height] of [[5000,5000],[3333,6666],[6000,6500],[8000,3000],[1,40000000]]){
  const result=outputSize(width,height,'clear');
  assert.ok(result.width*result.height<=8000000);
  assert.ok(Math.max(result.width,result.height)<=4000);
}
for(const [width,height] of [[0,10],[10000,10000],[NaN,20]])assert.throws(()=>outputSize(width,height));

// Only locally persisted image sources may enter the full-screen viewer.
assert.ok(validPhotoSource('data:image/jpeg;base64,/9j/AA=='));
assert.ok(validPhotoSource(`media/${'a'.repeat(64)}.jpg`));
for(const source of ['https://example.com/x.jpg','javascript:alert(1)','media/../../private','data:image/svg+xml;base64,PHN2Zz4=','data:image/jpeg;base64,AA==" onerror="x'])assert.equal(validPhotoSource(source),false);

// Read common image headers before allocating full decoded images.
const png=new Uint8Array(24),pngView=new DataView(png.buffer);png.set([137,80,78,71]);pngView.setUint32(16,9000);pngView.setUint32(20,8000);
assert.deepEqual(headerDimensions(png),{width:9000,height:8000});
assert.throws(()=>{const size=headerDimensions(png);outputSize(size.width,size.height,'clear');});
const gif=new Uint8Array([71,73,70,56,57,97,0x80,0x02,0xe0,0x01]);
assert.deepEqual(headerDimensions(gif),{width:640,height:480});
const jpeg=new Uint8Array([255,216,255,224,0,4,0,0,255,192,0,7,8,0x04,0x38,0x07,0x80,255,217]);
assert.deepEqual(headerDimensions(jpeg),{width:1920,height:1080});
assert.equal(headerDimensions(jpeg.subarray(0,14)),null);
const webp=new Uint8Array(30);webp.set([82,73,70,70],0);webp.set([87,69,66,80],8);webp.set([86,80,56,88],12);webp.set([255,3,0],24);webp.set([255,1,0],27);
assert.deepEqual(headerDimensions(webp),{width:1024,height:512});
for(const bytes of [new Uint8Array(),new Uint8Array([255,216]),new Uint8Array(5)])assert.equal(headerDimensions(bytes),null);

console.log('Photo experience: reorder, zoom bounds, swipe intent, cover focus, quality limits, source validation, and header checks passed.');
