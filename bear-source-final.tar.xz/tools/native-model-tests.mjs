import assert from 'node:assert/strict';
const calls=[];
globalThis.window={BearStore:{request(id,input){const req=JSON.parse(input);calls.push(req);const normalize=value=>({...value,photos:(value.photos||[]).map(()=> 'media/test.jpg')});queueMicrotask(()=>window.bearStoreResult(id,{ok:true,value:req.op==='status'?{ready:true}:req.op==='get'?{value:false}:req.op==='put-batch'?{rows:req.rows.map(row=>({...row,value:normalize(row.value)}))}:{value:normalize(req.value)}}));}}};
globalThis.indexedDB={open(){throw new Error('should not reopen legacy DB');}};
const model=await import('../web/model.js?v=34');await model.openStore();
assert.equal(await model.getSound(),false);
const item={id:'entry',kind:'meal',photos:['data:image/png;base64,AA==']};await model.saveItem('entries',item);assert.deepEqual(item.photos,['media/test.jpg']);
const recipe={id:'recipe',photos:['data:image/png;base64,AA==']};await model.saveMealWithRecipe(item,recipe);assert.equal(item.recipeId,'recipe');assert.deepEqual(recipe.photos,['media/test.jpg']);assert.equal(calls.filter(r=>r.op==='put-batch').length,1);
console.log('Passed: ready SQLite skips legacy DB, false settings preserved, normalized file refs update UI state, food+recipe saved as one batch.');
