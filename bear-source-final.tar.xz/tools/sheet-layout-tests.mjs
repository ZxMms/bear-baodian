import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';

// Check the whole shipped cascade, not just the first stylesheet. This catches
// the later workbench override that previously left content above the header.
// These are layout contracts, not a substitute for Android visual verification.
const web=new URL('../web/',import.meta.url);
const html=await readFile(new URL('index.html',web),'utf8');
const files=[...html.matchAll(/<link\b[^>]*rel="stylesheet"[^>]*href="([^"?]+)/g)].map(match=>match[1]);
assert(files.length>1,'test the actual stylesheet loading order');
const rules=[];
for(const file of files){
  const css=(await readFile(new URL(file,web),'utf8')).replace(/\/\*[\s\S]*?\*\//g,'');
  for(const match of css.matchAll(/([^{}]+)\{([^{}]*)\}/g)){
    const declarations=Object.fromEntries(match[2].split(';').map(text=>text.trim()).filter(Boolean).map(text=>{const colon=text.indexOf(':');return [text.slice(0,colon).trim(),text.slice(colon+1).trim()];}));
    for(const selector of match[1].split(','))rules.push({file,selector:selector.trim(),declarations});
  }
}
const forSelector=selector=>rules.filter(rule=>rule.selector===selector);
const cascade=selector=>Object.assign({},...forSelector(selector).map(rule=>rule.declarations));
const header=cascade('.sheet-header'),content=cascade('.sheet-content'),grabber=cascade('.sheet-grabber'),dialog=cascade('dialog#sheet');
const headerPositions=rules.filter(rule=>/(?:^|\s)\.sheet-header$/.test(rule.selector)&&('top' in rule.declarations||'position' in rule.declarations));
assert.equal(headerPositions.length,1,'one shared header positioning rule prevents negative-offset overrides');
assert.equal(header.position,'sticky');assert.equal(header.top,'0');
assert.equal(header.background,'var(--card)','the header uses an opaque surface in every theme');
assert.equal(Number(header['z-index'])>=7,true);
assert.equal(header.opacity,undefined);assert.equal(header['backdrop-filter'],undefined,'readability does not depend on translucent blur');
assert.equal(content.padding.split(/\s+/)[0],'0','the scrolling viewport has no uncovered top inset');
assert.equal(content['overflow-y'],'auto');assert.equal(content['overflow-x'],'hidden');
assert.equal(dialog.overflow,'hidden','the dialog clips rounded corners without creating a second scroller');
assert.match(content['max-height'],/90dvh/,'the scroll viewport follows the available screen height');
assert.match(content.padding,/safe-area-inset-bottom/,'the bottom system gesture inset is preserved');

const sideInset=parseFloat(content.padding.split(/\s+/)[1]);
const margins=header.margin.split(/\s+/),sideMargin=parseFloat(margins[1]);
assert.equal(sideInset+sideMargin,0,'the opaque header extends across both content gutters');
assert.equal(margins[0],'0','the first header starts at the scrollport top');
assert.equal(header.height,undefined);assert.equal(header['max-height'],undefined,'long titles can expand without clipping');
assert.equal(grabber.position,'absolute');assert.equal(grabber.margin,'0');
assert.equal(grabber.left,'50%');assert.equal(grabber.transform,'translateX(-50%)');
assert.equal(parseFloat(grabber.top)+parseFloat(grabber.height)<parseFloat(header.padding),true,'the drag handle fits above the title controls');
for(const rule of rules.filter(rule=>rule.declarations['--card']))assert.match(rule.declarations['--card'],/^#[\da-f]{6}$/i,`${rule.file}: header surfaces must remain opaque`);

const app=await readFile(new URL('app.js',web),'utf8');
assert.match(app,/<section class="sheet-content"><div class="sheet-header"><div class="sheet-grabber" aria-hidden="true"><\/div>/,'the sticky header is the first flow child and owns its drag handle');
assert.match(app,/\.closest\('\.sheet-header,\.sheet-grabber'\)/,'existing drag-to-close hit targets stay attached');
console.log(`Passed sheet layout contracts across ${files.length} shipped stylesheets: full-width opaque first-child header, zero top gap, one scroll owner, safe area and adaptive title height.`);
