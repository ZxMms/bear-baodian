import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
const deps=process.env.BEAR_UI_TEST_DEPS ? path.resolve(process.env.BEAR_UI_TEST_DEPS) : new URL('./ui-test-runtime/node_modules/',import.meta.url).pathname;
const [{JSDOM,VirtualConsole},{indexedDB,IDBKeyRange}]=await Promise.all([import(pathToFileURL(path.join(deps,'jsdom/lib/api.js'))),import(pathToFileURL(path.join(deps,'fake-indexeddb/build/esm/index.js')))]);
import assert from 'node:assert/strict';

const root=new URL('../web/',import.meta.url).pathname;
const errors=[];
const vc=new VirtualConsole();
vc.on('jsdomError',e=>{ if(!/Not implemented: (HTMLCanvasElement|navigation)/.test(e.message)) errors.push(e.message); });
const dom=new JSDOM(fs.readFileSync(path.join(root,'index.html'),'utf8'),{url:'https://bear.test/',pretendToBeVisual:true,runScripts:'outside-only',virtualConsole:vc});
const w=dom.window;
for(const name of ['window','document','navigator','localStorage','FormData','MutationObserver','Element','HTMLElement','HTMLInputElement','HTMLTextAreaElement','HTMLSelectElement','Event','CustomEvent','MouseEvent','Image','Audio','getComputedStyle']) {
  Object.defineProperty(globalThis,name,{value:name==='window'?w:(typeof w[name]==='function'&&name==='getComputedStyle'?w[name].bind(w):w[name]),configurable:true});
}
w.matchMedia=query=>({matches:false,media:query,addEventListener(){},removeEventListener(){},addListener(){},removeListener(){}});
w.scrollTo=()=>{};
w.HTMLElement.prototype.scrollIntoView=function(){};
w.HTMLElement.prototype.animate=function(){return {finished:Promise.resolve(),cancel(){}};};
w.HTMLDialogElement.prototype.showModal=function(){this.setAttribute('open','');};
w.HTMLDialogElement.prototype.close=function(){this.removeAttribute('open');this.dispatchEvent(new w.Event('close'));};
w.HTMLMediaElement.prototype.play=async function(){};
w.HTMLMediaElement.prototype.pause=function(){};
globalThis.matchMedia=w.matchMedia;
globalThis.requestAnimationFrame=w.requestAnimationFrame.bind(w);
globalThis.cancelAnimationFrame=w.cancelAnimationFrame.bind(w);
globalThis.indexedDB=w.indexedDB=indexedDB;
globalThis.IDBKeyRange=IDBKeyRange;
globalThis.CSS=w.CSS={escape:s=>String(s).replace(/[^a-zA-Z0-9_-]/g,c=>'\\'+c)};
w.eval(fs.readFileSync(path.join(root,'lunar.js'),'utf8'));
globalThis.Solar=w.Solar;globalThis.Lunar=w.Lunar;
const version=/app\.js\?v=(\d+)/.exec(fs.readFileSync(path.join(root,'index.html'),'utf8'))[1];
const moduleURL=name=>pathToFileURL(path.join(root,name)).href+'?v='+version;
const model=await import(moduleURL('model.js'));
await model.openStore();
await model.setSound(false);
const photo='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aC9sAAAAASUVORK5CYII=';
const populated=process.argv.includes('--populated');
if(populated){
 await model.saveItem('entries',{id:'fixture-life',kind:'life',date:model.dateKey(),title:'照片与长文本测试'.repeat(6),note:'长文本换行\n'.repeat(60),photos:Array(5).fill(photo),recurrence:{type:'none'}});
 await model.saveItem('ledger',{id:'fixture-ledger',date:model.dateKey(),type:'expense',cents:12345,category:'category-0',merchant:'店铺名称'.repeat(10),note:'账单记录'.repeat(60),photos:Array(5).fill(photo)});
}
await import(moduleURL('app.js'));
const pause=()=>new Promise(r=>setTimeout(r,40));
for(let i=0;i<50&&!w.document.querySelector('.tabs,.initial-error');i++)await pause();
if(w.document.querySelector('.initial-error'))throw Error(w.document.querySelector('.initial-error').textContent);
const findings=[];
function audit(name){
 const dialog=[...w.document.querySelectorAll('dialog[open]')].at(-1);
 const scope=dialog?.querySelector('.sheet-content')||dialog||w.document.querySelector('#app');
 const ids=[...scope.querySelectorAll('[id]')].map(x=>x.id);
 const unlabeled=[...scope.querySelectorAll('input:not([type=hidden]):not([type=submit]):not([type=button]),select,textarea')].filter(x=>!x.closest('[hidden]')&&!x.labels?.length&&!x.getAttribute('aria-label')&&!x.getAttribute('aria-labelledby')).map(x=>x.name||x.id||x.type);
 const unnamed=[...scope.querySelectorAll('button')].filter(x=>!x.textContent.trim()&&!x.getAttribute('aria-label')).map(x=>x.outerHTML.slice(0,160));
 findings.push({name,title:scope.querySelector('h2')?.textContent,controls:scope.querySelectorAll('button,input,select,textarea').length,unlabeled,unnamed,duplicateIds:ids.filter((id,i)=>ids.indexOf(id)!==i)});
}
async function click(selector){const el=w.document.querySelector(selector);if(!el)throw Error('Missing '+selector);el.click();await pause();await pause();}
async function close(){if(w.document.querySelector('#sheet[open]'))await click('#sheet [data-action="close"]');}
const set=(name,value)=>{const el=w.document.querySelector(`#sheet [name="${name}"]`);assert.ok(el,name);if(el.type==='checkbox')el.checked=Boolean(value);else el.value=value;el.dispatchEvent(new w.Event('input',{bubbles:true}));el.dispatchEvent(new w.Event('change',{bubbles:true}));};
async function submit(){w.document.querySelector('#sheet form').requestSubmit();await pause();await pause();await pause();}
audit('首页');
for(const page of ['journal','recipes','ledger','calendar']){await click('[data-page="'+page+'"]');audit(page);}
if(populated){
 await click('[data-action="open-today"]');audit('五图日期预览');
 await click('[data-entry="fixture-life"]');audit('五图长手账详情');
 assert.equal(w.document.querySelectorAll('.photo-gallery .gallery-photo').length,5);
 await click('[data-photo-entry="fixture-life"]');audit('照片查看器');
 await click('[data-photo-ux="next"]');assert.equal(w.document.querySelector('.photo-lightbox-count').textContent,'2 / 5');
 await click('[data-photo-ux="close"]');assert.ok(w.document.querySelector('#sheet[open] .record-detail'));await close();
}
await click('[data-work-action="settings"]');audit('设置');await close();
await click('[data-work-action="tools"]');audit('工具入口');
const routes=[...w.document.querySelectorAll('#sheet [data-work-action]')].map(x=>x.dataset.workAction);
await close();
const work=await import(moduleURL('workbench.js'));
// Xiaomi hardware must not be presented as platform publication approval.
for(const reviewBuild of [false,true]){
 w.BearApp={widgetPlatformInfo:()=>JSON.stringify({xiaomi:true,reviewBuild})};
 await work.workbenchClicked({workAction:'widgets'});await pause();
 const note=w.document.querySelector('.widget-xiaomi-note');assert.ok(note);
 assert.match(note.textContent,/需要小米审核收录/);
 assert.equal(/适配测试版/.test(note.textContent),reviewBuild);
 assert.equal(w.document.querySelectorAll('[data-work-action="widget-small"],[data-work-action="widget-large"]').length,2);
 audit(reviewBuild?'小米提测入口说明':'小米正式包入口说明');await close();
}
delete w.BearApp;
for(const route of [...new Set([...routes,'search','drafts','trash','widgets','backup','reminders','audio','about'])]){
 try{await work.workbenchClicked({workAction:route});await pause();audit(route);await close();}catch(e){errors.push(route+': '+e.stack);}
}
// Real event handlers and real IndexedDB API, with isolated test data only.
for(const kind of ['life','meal','memo','anniversary','event','capsule']){
 await click('[data-action="choose-kind"]');await click(`[data-kind="${kind}"]`);audit('新增-'+kind);await close();
}
await click('[data-action="choose-kind"]');await click('[data-kind="memo"]');
await submit();audit('必填错误');
assert.equal(w.document.activeElement.name,'title');
assert.ok(w.document.querySelector('[name=title][aria-invalid=true]'));
set('title','测试备注：长标题与换行');set('note','第一行\n第二行\n'+'长内容'.repeat(100));
assert.equal(w.document.querySelector('[name=title]').hasAttribute('aria-invalid'),false);
await submit();audit('保存记录详情');
assert.ok((await model.loadAll('entries')).some(x=>x.title==='测试备注：长标题与换行'));
assert.equal(w.document.querySelector('#toast').parentElement.id,'sheet','success toast stays in dialog top layer');
await close();assert.equal(w.document.querySelector('#toast').parentElement,w.document.body);
await click('[data-action="open-today"]');audit('有记录日期详情');
await click('[data-share-day]');audit('日期分享内容选择');
assert.equal(w.document.querySelector('[name=shareLedger]')?.checked||false,false);await close();
await click('[data-action="choose-mood"]');audit('心情选择');await close();
await click('[data-action="dates"]');audit('重要日子');
await click('[data-action="date-settings"]');audit('发薪日设置');await close();
await click('[data-page="recipes"]');await click('[data-action="add-recipe"]');audit('新增菜谱');
set('title','测试菜谱');await click('#sheet [data-action="close"]');
assert.ok(w.document.querySelector('.exit-confirm[open]'),'unsaved recipe is guarded');
audit('退出确认');
const exit=await import(moduleURL('exit-confirm.js'));
exit.exitConfirmationBack();await pause();assert.equal(w.document.querySelector('[name=title]').value,'测试菜谱');
set('ingredients','番茄、鸡蛋');set('steps','第一步\n第二步');await submit();audit('菜谱详情');await close();
await click('[data-recipe="sample-noodle"]');audit('示例菜谱详情');
await click('[data-share-recipe]');audit('菜谱分享内容选择');
await click('[data-action="sheet-back"]');assert.equal(w.document.querySelector('#sheet-title').textContent,'番茄鸡蛋面');
await click('[data-kitchen-cook]');audit('跟熊熊做饭');
await click('[data-kitchen-action="step-next"]');assert.ok(w.document.querySelector('.kitchen-step'));audit('做饭下一步');await close();
await work.workbenchClicked({workAction:'planner'});await pause();
await click('[data-kitchen-action="plan-add"]');audit('一周菜单编辑');await close();
const kitchen=await import(moduleURL('kitchen.js'));
await work.workbenchClicked({workAction:'planner'});await kitchen.kitchenClicked({kitchenAction:'shopping'});audit('采购清单');
await click('[data-kitchen-action="shopping-add"]');audit('采购编辑');
set('text','西红柿 2 个');await click('[data-kitchen-action="shopping"]');
assert.ok(w.document.querySelector('.exit-confirm[open]'),'shopping return is guarded');exit.exitConfirmationBack();await pause();
assert.equal(w.document.querySelector('[name=text]').value,'西红柿 2 个');await submit();audit('采购保存结果');await close();
await work.workbenchClicked({workAction:'pantry'});await click('[data-pantry-action="add"]');audit('食材编辑');await close();
await work.workbenchClicked({workAction:'wishes'});await click('[data-wish-action="new"]');audit('愿望编辑');
set('wishTitle','测试愿望');set('wishTarget','10');await submit();audit('愿望详情');
assert.equal(w.document.querySelector('#toast').parentElement.id,'sheet','toast also survives announce-before-navigation');
await click('[data-wish-action="contribute"]');audit('愿望攒钱编辑');set('wishAmount','10');await submit();
await click('[data-wish-action="complete"]');audit('愿望完成选择');await submit();audit('愿望完成详情');await close();
await work.workbenchClicked({workAction:'happy-box'});await click('[data-happy-action="pick"]');audit('开心盒挑选记录');await close();
await click('[data-page="ledger"]');const ledger=await import(moduleURL('ledger.js'));
await ledger.ledgerClick({ledgerAction:'add'});audit('账单编辑');await close();
await ledger.ledgerClick({ledgerAction:'budget'});audit('预算编辑');await close();
await ledger.ledgerClick({ledgerAction:'categories'});audit('账单分类');
await ledger.ledgerClick({ledgerNewCategory:'expense'});audit('分类编辑');await close();
await ledger.ledgerClick({ledgerAction:'receipt'});audit('截图记账入口');await close();
await ledger.ledgerClick({ledgerSection:'analysis'});audit(populated?'账本图表有数据':'账本分析空状态');
if(populated){await ledger.openLedger('fixture-ledger');audit('五图账单详情');await close();}
const weather=await import(moduleURL('weather.js'));
await weather.weatherClick({weatherAction:'open'});await pause();audit('天气入口');
await click('[data-weather-alert-action="regions"]');audit('预警地区选择');await click('[data-action="sheet-back"]');
for(let i=0;i<3;i++){
 await click('[data-weather-action="cities"]');audit('城市区县选择'+i);
 await click('[data-weather-action="open"]');
 assert.equal(w.document.querySelector('#sheet-title').textContent,'今日天气');
 assert.equal(w.document.querySelector('#sheet [data-action="sheet-back"]'),null,'weather city roundtrip must not duplicate history');
}
w.bearWeatherChanged(JSON.stringify({native:true,loading:true,phase:'正在等待定位',locationStatus:{phase:'locating',status:'waiting',permission:'precise',serviceEnabled:true,detail:'测试等待状态'}}));audit('天气定位中');
w.bearWeatherChanged(JSON.stringify({native:true,loading:false,error:'测试：网络暂时不可用',errorCode:'NETWORK',locationStatus:{phase:'failed',status:'timeout',permission:'precise',serviceEnabled:true}}));audit('天气失败恢复');await close();
await work.openSettings();set('theme','night');set('largeText',true);set('reducedMotion',true);await submit();
assert.equal(w.document.documentElement.dataset.theme,'night');assert.equal(w.document.documentElement.dataset.largeText,'true');assert.equal(w.document.documentElement.dataset.reducedMotion,'true');
audit('夜间大字设置结果');await close();await click('[data-page="calendar"]');
await click('[data-action="choose-kind"]');await click('[data-kind="life"]');audit('夜间大字表单');await close();
// Error feedback preserves existing help and exposes invalid fields inside details.
const forms=await import(moduleURL('form-experience.js'));
const testSheet=w.document.createElement('dialog');w.document.body.append(testSheet);
testSheet.innerHTML='<section class="sheet-content"><div class="sheet-header">标题</div><form><details><summary>选填信息</summary><label for="test-required">名称</label><input id="test-required" name="title" required aria-describedby="test-help"><p id="test-help">已有说明</p></details><p class="form-error"></p><button type="submit">保存</button></form></section>';
const clean=forms.initSheetExperience(testSheet);testSheet.showModal();const testForm=testSheet.querySelector('form'),field=testForm.elements.title;
testForm.addEventListener('submit',e=>e.preventDefault());testForm.requestSubmit();await pause();
assert.equal(testSheet.querySelector('details').open,true);assert.equal(w.document.activeElement,field);
assert.match(field.getAttribute('aria-describedby'),/^test-help field-error-/);
field.value='已有内容';field.dispatchEvent(new w.Event('input',{bubbles:true}));assert.equal(field.getAttribute('aria-describedby'),'test-help');
assert.equal(forms.reportFormError(testForm,'测试：本机写入失败'),true);assert.equal(w.document.activeElement,testForm.querySelector('.form-error'));
clean.destroy();testSheet.remove();
const photos=await import(moduleURL('photo-experience.js'));let savedFocus;
photos.openCoverFocusEditor({src:photo,focus:{x:10,y:70},onSave:value=>savedFocus=value});audit('菜谱封面位置调整');
await click('[data-focus-action="reset"]');await click('[data-focus-action="save"]');assert.deepEqual(savedFocus,{x:50,y:50});
console.log(JSON.stringify({mode:populated?'populated':'empty',findings,errors},null,2));
for(const finding of findings){assert.deepEqual(finding.unlabeled,[],finding.name+' unlabeled');assert.deepEqual(finding.unnamed,[],finding.name+' unnamed');assert.deepEqual(finding.duplicateIds,[],finding.name+' duplicate IDs');}
dom.window.close();
process.exit(errors.length?1:0);
