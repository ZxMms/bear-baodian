import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
import {holidays,holidaySources,nextScheduledDate} from '../web/calendar-tools.js';
import {dateKey,fromKey} from '../web/model.js';
import {upcomingHolidays,holidayPickerMarkup,applyHolidayChoice,setHolidayMode,syncHolidayPicker,savedHolidayId} from '../web/holiday-picker.js';

// Exercise real picker logic and app integration helpers at a small DOM boundary.
// Controlled dates keep these checks valid after the actual clock crosses a year.
const source=await readFile(new URL('../web/app.js',import.meta.url),'utf8');
const floor='2026-01-01';
const holiday=holidays.find(row=>row.name==='劳动节'&&row.start.startsWith('2026-'));
assert(holiday&&holidaySources[2026],'the 2026 verified fixture must remain available');
const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function node(extra={}){return {hidden:false,textContent:'',innerHTML:'',dataset:{},attributes:{},classList:{toggle(){}},setAttribute(name,value){this.attributes[name]=String(value);},...extra};}
function makeForm(overrides={}){
  const fields={title:'朋友聚会',date:'2026-03-12',time:'18:30',repeatType:'monthly',monthDay:'12',monthOverflow:'last',workMode:'official',note:'这段文字不要丢',reminderDays:'3',reminderTime:'09:30',countdownSource:'custom',holidayId:'',...overrides};
  const elements={};for(const [name,value]of Object.entries(fields))elements[name]={name,value,type:'text'};
  elements.countdown={name:'countdown',value:'on',type:'checkbox',checked:false};
  elements.time.required=false;
  Object.defineProperty(elements,Symbol.iterator,{value:function*(){yield* Object.values(this);}});
  const nodes=new Map(),modes=['custom','holiday'].map(mode=>node({dataset:{holidayMode:mode}})),choices=holidays.map(row=>node({dataset:{holidayPick:row.id}}));
  const form={dataset:{form:'entry',kind:'event',id:''},elements,attributes:{},setAttribute(key,value){this.attributes[key]=value;},removeAttribute(key){delete this.attributes[key];},
    querySelector(selector){
      if(selector==='[data-form="entry"]'||selector==='form')return form;
      if(selector.startsWith('[name="'))return elements[selector.slice(7,-2)]||null;
      if(!nodes.has(selector))nodes.set(selector,node());return nodes.get(selector);
    },
    querySelectorAll(selector){if(selector.includes('data-holiday-mode'))return modes;if(selector.includes('data-holiday-pick'))return choices;if(selector.startsWith('[name="')){const field=elements[selector.slice(7,-2)];return field?[field]:[];}return [];}
  };
  for(const field of Object.values(elements))field.form=form;
  return {form,nodes,modes,choices};
}
class FormValues {
  constructor(form){this.rows=[...form.elements].filter(field=>!field.disabled&&(!['checkbox','radio'].includes(field.type)||field.checked)).map(field=>[field.name,field.value]);}
  [Symbol.iterator](){return this.rows[Symbol.iterator]();}
  get(name){return this.rows.find(([key])=>key===name)?.[1]??null;}
  has(name){return this.rows.some(([key])=>key===name);}
}
function functionSource(name){const start=new RegExp(`^(?:async )?function ${name}\\(`,'m').exec(source);assert(start,`Missing actual helper ${name}`);const rest=source.slice(start.index),line=rest.split('\n')[0];if(line.endsWith('}'))return line;const end=/^}/m.exec(rest);assert(end);return rest.slice(0,end.index+1);}
function context(names,values={}){const ctx=vm.createContext({html:escape,icon:()=>'',today:()=>floor,...values});for(const name of names)vm.runInContext(functionSource(name),ctx);return ctx;}
let count=0;const failures=[];
async function test(name,run){try{await run();count++;}catch(error){failures.push(`${name}: ${error.stack}`);}}

await test('Upcoming holidays are ordered across years and require a known official year',()=>{
  const rows=[{id:'later',name:'后面的假期',start:'2027-02-05',end:'2027-02-13'},{id:'ongoing',name:'进行中',start:'2026-12-25',end:'2027-01-03'},{id:'today',name:'当天开始',start:'2026-12-31',end:'2027-01-01'},{id:'unknown',name:'未知年份',start:'2028-01-01',end:'2028-01-03'},{id:'next',name:'次年第一天',start:'2027-01-01',end:'2027-01-03'}];
  const sources={2026:holidaySources[2026],2027:holidaySources[2026]};
  assert.deepEqual(upcomingHolidays('2026-12-31',rows,sources).map(row=>row.id),['today','next','later']);
  assert.deepEqual(upcomingHolidays('2028-01-01',rows,sources),[]);
});
await test('Holiday starts today are selectable while an already-started holiday is excluded',()=>{
  assert(upcomingHolidays(holiday.start).some(row=>row.id===holiday.id));
  const following=new Date(`${holiday.start}T12:00:00Z`);following.setUTCDate(following.getUTCDate()+1);
  assert(!upcomingHolidays(following.toISOString().slice(0,10)).some(row=>row.id===holiday.id));
});
await test('Malformed dates and unverified years cannot become selectable holiday dates',()=>{
  for(const from of ['2026-02-30','2026-13-01','not-a-date','',null])assert.deepEqual(upcomingHolidays(from),[]);
  const valid={id:'valid',name:'已核对日期',start:'2026-05-01',end:'2026-05-05'};
  const rows=[{...valid,id:'bad-day',start:'2026-02-30'},{...valid,id:'end-before-start',end:'2026-04-30'},{...valid,id:'unverified',start:'2028-01-01',end:'2028-01-03'},valid,{...valid}];
  assert.deepEqual(upcomingHolidays(floor,rows,{2026:holidaySources[2026]}).map(row=>row.id),['valid']);
});
await test('Picker remains an inline form section and exposes future choices',()=>{
  const markup=holidayPickerMarkup(null,floor);
  assert.doesNotMatch(markup,/<form\b/i);
  assert.match(markup,/法定节假日/);assert.match(markup,/自定义/);
  assert.match(markup,/name="countdownSource"/);assert.match(markup,/name="holidayId"/);
});
await test('Selecting a holiday fills one dated countdown while preserving notes and reminder choices',()=>{
  const {form}=makeForm();const note=form.elements.note.value,reminder=[form.elements.reminderDays.value,form.elements.reminderTime.value];
  const picked=applyHolidayChoice(form,holiday.id,floor);
  assert.equal(picked.id,holiday.id);assert.equal(form.elements.title.value,`${holiday.name}假期`);assert.equal(form.elements.date.value,holiday.start);assert.equal(form.elements.time.value,'00:00');assert.equal(form.elements.countdown.checked,true);assert.equal(form.elements.time.required,true);assert.equal(form.elements.repeatType.value,'none');
  assert.equal(form.elements.note.value,note);assert.deepEqual([form.elements.reminderDays.value,form.elements.reminderTime.value],reminder);
  assert.equal(form.elements.countdownSource.value,'holiday');assert.equal(form.elements.holidayId.value,holiday.id);assert.equal(savedHolidayId(form),holiday.id);
});
await test('Invalid and already-past selections leave existing form values untouched',()=>{
  for(const [id,from]of [['unknown-id',floor],[holiday.id,'2027-01-01']]){
    const {form}=makeForm(),before=JSON.stringify([...new FormValues(form)]);
    assert.equal(applyHolidayChoice(form,id,from),null);assert.equal(JSON.stringify([...new FormValues(form)]),before);
  }
});
await test('Switching back to custom preserves entered details but clears holiday attribution',()=>{
  const {form}=makeForm();applyHolidayChoice(form,holiday.id,floor);
  const date=form.elements.date.value,title=form.elements.title.value,note=form.elements.note.value;
  assert.equal(setHolidayMode(form,'custom',floor),true);
  assert.equal(form.elements.date.value,date);assert.equal(form.elements.title.value,title);assert.equal(form.elements.note.value,note);assert.equal(form.elements.holidayId.value,'');assert.equal(savedHolidayId(form),'');
});
await test('Manual date, repeat-rule or countdown changes invalidate official holiday metadata',()=>{
  for(const change of [form=>{form.elements.date.value='2026-06-10';},form=>{form.elements.repeatType.value='yearly';},form=>{form.elements.countdown.checked=false;}]){
    const {form}=makeForm();applyHolidayChoice(form,holiday.id,floor);change(form);syncHolidayPicker(form,floor);
    assert.equal(form.elements.holidayId.value,'');assert.equal(form.elements.countdownSource.value,'custom');assert.equal(savedHolidayId(form),'');
  }
});
await test('A user-edited title or time keeps the selected holiday date valid',()=>{
  const {form}=makeForm();applyHolidayChoice(form,holiday.id,floor);form.elements.title.value='终于放假啦';form.elements.time.value='18:00';syncHolidayPicker(form,floor);
  assert.equal(form.elements.title.value,'终于放假啦');assert.equal(form.elements.time.value,'18:00');assert.equal(savedHolidayId(form),holiday.id);
});
await test('Programmatic holiday selection is detected as an unsaved durable edit, including photos',()=>{
  const {form}=makeForm();const sheet={querySelector:selector=>selector.includes('[data-form="entry"]')?form:null};
  const photos=['media/kept-photo.jpg'];
  const ctx=context(['draftSnapshot','hasDraftChanges'],{sheet,durableForm:()=>form,durableKey:()=> 'entry:new',FormData:FormValues,formPhotos:photos,foodRecipeCover:'',formCoverFocus:{x:50,y:50},initialDraft:null});
  ctx.initialDraft=ctx.draftSnapshot();applyHolidayChoice(form,holiday.id,floor);assert.equal(ctx.hasDraftChanges(),true);assert.deepEqual(ctx.formPhotos,photos);
});

await test('The real delegated click applies the holiday without replacing the editing form',async()=>{
  const {form}=makeForm(),messages=[];let click,scheduled=0,focused=null;
  const ctx=context(['readRule','updateRulePreview','updateEntryDateContext','updateCountdownFields'],{
    nextScheduledDate,dateKey,fromKey,busy:false,uploadTask:null,setHolidayMode,applyHolidayChoice,syncHolidayPicker,
    document:{addEventListener:(name,handler)=>{if(name==='click')click=handler;}},sheet:{querySelector:selector=>selector==='[data-form="entry"][data-kind="event"]'?form:null},
    focusSheetTarget:target=>{focused=target;},announce:message=>messages.push(message),durableForm:()=>form,scheduleDraft:()=>{scheduled++;},
  });
  const start=source.indexOf('document.addEventListener("click", async (event) => {'),end=source.indexOf('\nsheet.addEventListener("click"',start);assert(start>=0&&end>start);vm.runInContext(source.slice(start,end),ctx);
  await click({target:{closest:()=>({dataset:{holidayPick:holiday.id}})}});
  assert.equal(form.elements.date.value,holiday.start);assert.equal(form.elements.repeatType.value,'none');
  assert.equal(form.querySelector('[data-rule-monthly]').hidden,true);assert.equal(form.querySelector('[data-rule-workday]').hidden,true);
  assert.match(form.querySelector('[data-rule-preview]').textContent,new RegExp(holiday.start.replaceAll('-','/')));
  assert.match(form.querySelector('.entry-date-context').innerHTML,new RegExp(holiday.start));
  assert.equal(form.querySelector('label[for="time"] small').textContent,'倒计时必填');assert.equal(form.querySelector('[type="submit"]').textContent,'保存倒计时');
  assert.equal(focused,form.querySelector('[data-holiday-choice-summary]'));assert(scheduled>0);assert(messages.some(message=>message.includes(holiday.start)));assert.equal(ctx.busy,false);
});

await test('Restoring a durable draft restores holiday mode, date context and time validation',async()=>{
  const {form}=makeForm();applyHolidayChoice(form,holiday.id,floor);
  const photos=['media/kept-photo.jpg'];let restored=0;
  const ctx=context(['readRule','updateRulePreview','updateEntryDateContext','updateCountdownFields','captureDurableDraft','restoreDurableDraft','draftSnapshot'],{
    nextScheduledDate,dateKey,fromKey,syncHolidayPicker,FormData:FormValues,CSS:{escape:value=>value},
    sheet:{querySelector:selector=>selector.includes('[data-form="entry"]')?form:null},durableForm:()=>form,durableKey:()=> 'entry:holiday-draft',
    formPhotos:photos,foodRecipeCover:'',formCoverFocus:{x:50,y:50},photoQualityMode:'standard',recipeImportContext:null,getPhotoQualityMode:()=> 'standard',
    getLedgerDraftContext:()=>null,editEntry:()=>{restored++;},showPhotoFields(){},updateFoodRecipeFields(){},refreshLedgerForm(){},updateEntryLinkFields(){},announce(){},restoringDraft:false,initialDraft:null,
  });
  const draft=ctx.captureDurableDraft();draft.draftId='entry:holiday-draft';
  for(const field of Object.values(form.elements)){field.value='';if(field.type==='checkbox')field.checked=false;}
  form.elements.time.required=false;ctx.formPhotos=[];
  await ctx.restoreDurableDraft(draft);
  assert.equal(restored,1);assert.equal(form.elements.holidayId.value,holiday.id);assert.equal(form.elements.countdownSource.value,'holiday');assert.equal(form.querySelector('[data-holiday-panel]').hidden,false);
  assert.equal(form.elements.date.value,holiday.start);assert.equal(form.elements.time.value,'00:00');assert.equal(form.elements.time.required,true);assert.equal(form.elements.countdown.checked,true);
  assert.match(form.querySelector('.entry-date-context').innerHTML,new RegExp(holiday.start));assert.equal(form.querySelector('[type="submit"]').textContent,'保存倒计时');
  assert.deepEqual([...ctx.formPhotos],photos);assert.equal(form.elements.note.value,'这段文字不要丢');assert.equal(form.elements.reminderDays.value,'3');assert(ctx.initialDraft);assert.equal(ctx.restoringDraft,false);
});

await test('The real change listener clears stale holiday attribution after a manual date edit',async()=>{
  const {form}=makeForm();applyHolidayChoice(form,holiday.id,floor);let changed;
  const ctx=context(['readRule','updateRulePreview','updateEntryDateContext','updateCountdownFields'],{
    nextScheduledDate,dateKey,fromKey,syncHolidayPicker,sheet:{addEventListener:(name,handler)=>{if(name==='change')changed=handler;}},
    kitchenChanged:()=>false,pantryChanged:()=>false,happyBoxChanged:()=>false,wishesChanged:()=>false,memoriesChanged:()=>false,photoExperienceChanged:()=>false,ledgerChange:()=>false,
    announce:message=>{throw new Error(message);},
  });
  const start=source.indexOf('sheet.addEventListener("change", async (event) => {'),end=source.indexOf('\nsheet.addEventListener("submit"',start);assert(start>=0&&end>start);vm.runInContext(source.slice(start,end),ctx);
  form.elements.date.value='2026-06-10';await changed({target:form.elements.date});
  assert.equal(savedHolidayId(form),'');assert.equal(form.elements.countdownSource.value,'custom');assert.equal(form.querySelector('[data-holiday-panel]').hidden,true);assert.match(form.querySelector('.entry-date-context').innerHTML,/2026-06-10/);
});

await test('The actual save handler stores the chosen holiday as a one-off event with its original photos',async()=>{
  const {form}=makeForm();applyHolidayChoice(form,holiday.id,floor);form.elements.reminderDays.value='off';
  const photos=['media/kept-photo.jpg'],writes=[],messages=[];let submit;
  const ctx=context(['readRule'],{
    busy:false,uploadTask:null,FormData:FormValues,dateKey,fromKey,savedHolidayId,formPhotos:photos,reminderKinds:['memo','event','anniversary','capsule'],
    sheet:{addEventListener:(name,handler)=>{if(name==='submit')submit=handler;}},
    clearFormErrors:form=>{form.querySelector('.form-error').textContent='';},reportFormError:()=>false,
    workbenchSubmitted:async()=>false,kitchenSubmitted:async()=>false,pantrySubmitted:async()=>false,happyBoxSubmitted:async()=>false,wishesSubmitted:async()=>false,memoriesSubmitted:async()=>false,
    newId:()=> 'holiday-entry-test',entryById:id=>writes.flatMap(batch=>batch).find(row=>row.value?.id===id)?.value,
    getLedgerRows:()=>[],saveItemsAtomically:async rows=>{assert.equal(form.attributes['aria-busy'],'true');assert.equal(form.querySelector('[type="submit"]').textContent,'正在保存…');writes.push(JSON.parse(JSON.stringify(rows)));},entries:[],recipes:[],
    reloadLedger:async()=>{},nextOccurrence:item=>item.date,clearCurrentDraft:async()=>{},syncReminders:()=>({native:false}),syncWidgets(){},close(){},render(){},showEntry(){},celebrate(){},play(){},announce:message=>messages.push(message),
  });
  const start=source.indexOf('sheet.addEventListener("submit", async (event) => {'),end=source.indexOf('\nwindow.bearCalendarBack',start);assert(start>=0&&end>start);vm.runInContext(source.slice(start,end),ctx);
  await submit({preventDefault(){},target:form});
  assert.equal(writes.length,1);assert.equal(writes[0].length,1);const row=writes[0][0];assert.equal(row.store,'entries');assert.equal(row.value.holidayId,holiday.id);assert.equal(row.value.date,holiday.start);assert.equal(row.value.title,`${holiday.name}假期`);assert.equal(row.value.time,'00:00');assert.equal(row.value.countdown,true);assert.equal(row.value.repeat,false);assert.equal(row.value.recurrence.type,'none');assert.deepEqual(row.value.photos,photos);assert.equal(row.value.note,'这段文字不要丢');assert.equal(ctx.busy,false);assert.equal(form.querySelector('.form-error').textContent,'');assert(messages.length>0);
});

if(failures.length){console.error(failures.join('\n'));process.exitCode=1;}else console.log(`Passed ${count} holiday picker regressions: upcoming date boundaries, one-off selections, metadata invalidation, real click routing and durable draft restoration.`);
