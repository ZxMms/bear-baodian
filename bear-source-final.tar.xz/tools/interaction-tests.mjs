import assert from 'node:assert/strict';
import { swipeAxis, swipeMonth } from '../web/calendar-swipe.js';
import { parseAmount, amountText, monthShift, ledgerSummary, categorySummary, dailyTotals, budgetSummary } from '../web/ledger-core.js';
import { selectShareContent, shareText } from '../web/share-core.js';
import { artIndex, artMeta, bearScenes } from '../web/illustrations.js';

// Tap jitter, vertical scroll, diagonal rejection and both horizontal directions.
assert.equal(swipeAxis(4, 5), 'pending');
assert.equal(swipeAxis(12, 45), 'vertical');
assert.equal(swipeAxis(20, 19), 'vertical');
assert.equal(swipeAxis(20, 2), 'horizontal');
assert.equal(swipeMonth(-100, 8, 320), 1);
assert.equal(swipeMonth(100, -10, 393), -1);
assert.equal(swipeMonth(20, 1, 320), 0);
assert.equal(swipeMonth(100, 90, 320), 0);
assert.equal(swipeMonth(-40, 3, 320), 0);

assert.equal(parseAmount('0.10') + parseAmount('0.20'), 30);
assert.equal(parseAmount('1234567.89'), 123456789);
assert.equal(parseAmount('12.5'), 1250);
for(const bad of ['-1','0','0.00','1.234','abc','1e3','1,000','10000000.00','Infinity','']) assert.throws(()=>parseAmount(bad));
assert.equal(amountText(30), '0.30');
assert.equal(amountText(-123456), '−1,234.56');
assert.equal(monthShift('2026-12',1),'2027-01');
assert.equal(monthShift('2027-01',-1),'2026-12');
assert.equal(monthShift('1900-01',-1),'1900-01');
const rows=[{id:'a',date:'2026-11-16',type:'expense',category:'food',cents:10},{id:'b',date:'2026-11-16',type:'expense',category:'food',cents:20},{id:'c',date:'2026-11-17',type:'expense',category:'travel',cents:12345},{id:'d',date:'2026-11-25',type:'income',category:'salary',cents:100000},{id:'e',date:'2026-10-25',type:'expense',category:'food',cents:9999}];
assert.deepEqual(ledgerSummary(rows,'2026-11'),{income:100000,expense:12375,net:87625,count:4});
assert.deepEqual(ledgerSummary(rows,'2027-01'),{income:0,expense:0,net:0,count:0});
assert.deepEqual(categorySummary(rows,'2026-11','expense'),[{id:'travel',cents:12345},{id:'food',cents:30}]);
assert.equal(ledgerSummary(rows.filter(r=>r.id!=='c'),'2026-11').expense,30);
assert.equal(ledgerSummary(rows.map(r=>r.id==='c'?{...r,cents:2500}:r),'2026-11').expense,2530);

const series = dailyTotals(rows,'2026-11');
assert.equal(series.length,30);
assert.equal(series[15].cents,30);
assert.equal(series[16].cents,12345);
assert.equal(series.reduce((sum,d)=>sum+d.cents,0),12375);
assert.equal(dailyTotals(rows,'2024-02').length,29);
assert.equal(dailyTotals(rows,'2026-02').length,28);
assert.equal(dailyTotals(rows,'2026-11','income')[24].cents,100000);
assert.deepEqual(budgetSummary(6000,10000),{remaining:4000,used:60,over:false});
assert.deepEqual(budgetSummary(12000,10000),{remaining:-2000,used:120,over:true});
assert.equal(budgetSummary(6000,0),null);
assert.equal(budgetSummary(0,10000).used,0);

const source={title:'2026-11-16',subtitle:'分享测试',mood:{name:'开心',copy:'今天很好'},entries:[{id:'one',label:'生活',title:'一条记录',note:'完整正文',photos:['1','2','3','4','5']},{id:'two',label:'做菜',title:'番茄面',note:'很好吃',recipe:{ingredients:'番茄 面条',steps:'煮熟'}}],ledger:[{title:'工资 100000',text:'私密工资备注'}]};
const ordinary=selectShareContent(source,{ids:['one'],photos:true,mood:true});
assert.equal(ordinary.sections.length,2);
assert.equal(ordinary.sections[1].photos.length,5);
assert.equal(shareText(ordinary).includes('私密工资备注'),false);
assert.equal(shareText(ordinary).includes('番茄面'),false);
assert.equal(shareText(selectShareContent(source,{ids:['two'],recipes:true})).includes('番茄 面条'),true);
assert.equal(shareText(selectShareContent(source,{ids:[],ledger:true})).includes('私密工资备注'),true);
assert.deepEqual(selectShareContent(source,{ids:['one'],photos:false}).sections[0].photos,[]);
assert.equal(selectShareContent(source,{}).sections.length,0);
assert.equal(Object.values(bearScenes).flat().length,36);
assert.equal(new Set(Object.values(bearScenes).flat()).size,36);
assert.equal(artIndex('2026-11-16'),artIndex('2026-11-16'));
for(const group of Object.keys(bearScenes)) for(let i=0;i<12;i++) {const a=artMeta(group,'',i);assert.equal(a.x,i%4);assert.equal(a.y,Math.floor(i/4));}
console.log('Passed: swipe intent, integer money/aggregation/edit/delete recalculation, month boundaries, opt-in sharing with 5 photos, and 36 illustration mappings.');
