import assert from 'node:assert/strict';
import {parseRecipeImage} from '../web/recipe-import-core.js';
const raw='椒盐皮皮虾\n食材\n皮皮虾 500 克\n蒜 5 瓣\n椒盐 1 勺\n做法\n1. 皮皮虾洗净并沥干。\n2. 热锅放油，炸至外壳酥脆。\n3. 撒入椒盐和蒜末翻炒。';
const p=parseRecipeImage(raw);assert.equal(p.title,'椒盐皮皮虾');assert.equal(p.category,'海鲜');assert.match(p.ingredients,/皮皮虾 500 克/);assert.match(p.steps,/3\./);assert.equal(p.raw,raw);assert.equal(p.warnings.length,0);
const q=parseRecipeImage('番茄鸡蛋面\n用 料：番茄 2 个\n鸡蛋 2 个\n步 骤：炒熟鸡蛋\n2、加入面条');assert.equal(q.title,'番茄鸡蛋面');assert.match(q.ingredients,/番茄/);assert.match(q.steps,/炒熟/);
const empty=parseRecipeImage('');assert.equal(empty.title,'');assert.equal(empty.warnings.length,3);
const missing=parseRecipeImage('好吃的菜\n一段没有分区的文字');assert(missing.warnings.length>0);assert(missing.raw.includes('没有分区'));
console.log('Passed: recipe screenshot sections, title, category, numbered steps, spaced headings, empty results and full source preservation.');
