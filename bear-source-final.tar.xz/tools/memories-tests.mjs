import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
import vm from "node:vm";
import {capsuleDue,capsuleIsHidden,memoryDateKey,validMemoryDate,memoryReferenceDate,memoryRows,magazineMonthData,defaultMagazineSelection,normalizeMagazineSelection,magazineSections} from "../web/memories-core.js";

assert.equal(memoryDateKey(new Date(2026,10,17,8)),"2026-11-17");
assert.equal(validMemoryDate("2028-02-29"),true);
assert.equal(validMemoryDate("2026-02-29"),false);
assert.equal(validMemoryDate("2026-13-01"),false);
assert.equal(validMemoryDate("1899-12-31"),false);
assert.equal(memoryReferenceDate("2026-11-17"),"2025-11-17");
assert.equal(memoryReferenceDate("2026-11-17","quarter"),"2026-08-17");
assert.equal(memoryReferenceDate("2026-01-17","quarter"),"2025-10-17");
assert.equal(memoryReferenceDate("2028-02-29"),"");
assert.equal(memoryReferenceDate("2026-05-31","quarter"),"");
assert.equal(memoryReferenceDate("1900-01-17","quarter"),"");

const capsule={id:"future",kind:"capsule",date:"2026-11-17",time:"09:00",note:"PRIVATE LETTER",photos:["PRIVATE PHOTO"]};
assert.equal(capsuleDue(capsule,new Date("2026-11-17T08:59:59")),false);
assert.equal(capsuleDue(capsule,new Date("2026-11-17T09:00:00")),true);
assert.equal(capsuleDue({...capsule,time:"29:00"}),false);
assert.equal(capsuleDue({...capsule,date:"2026-02-30"}),false);
assert.equal(capsuleIsHidden(capsule,new Date("2026-11-17T08:00:00")),true);
assert.equal(capsuleIsHidden({...capsule,kind:"life"},new Date("2026-11-17T08:00:00")),false);
assert.equal(capsuleDue({...capsule,time:undefined},new Date("2026-11-17T08:59:59")),false);
assert.equal(capsuleDue({...capsule,time:undefined},new Date("2026-11-17T09:00:00")),true);

const historical=[
  {id:"year",kind:"life",date:"2025-11-17",created:2},
  {id:"quarter",kind:"meal",date:"2026-08-17",created:3},
  {...capsule,id:"old-capsule",date:"2025-11-17"},
  {id:"trash",kind:"life",date:"2025-11-17",_deletedAt:99},
];
assert.deepEqual(memoryRows(historical,"2026-11-17").rows.map(row=>row.id),["year"]);
assert.deepEqual(memoryRows(historical,"2026-11-17","quarter").rows.map(row=>row.id),["quarter"]);

const data=magazineMonthData({
  entries:[
    {id:"a",kind:"life",title:"散步",date:"2026-11-01",note:"秋天的叶子",photos:["shared","walk"]},
    {id:"b",kind:"meal",title:"今日午饭",recipeId:"recipe",date:"2026-11-17",note:"暖暖的",photos:["shared","soup"]},
    {id:"c",kind:"meal",title:"南瓜汤",date:"2026-11-16",photos:[]},
    {id:"past",kind:"life",date:"2026-10-30",photos:["past"]},
    {id:"later",kind:"event",date:"2026-11-25",photos:["future"]},
    {id:"trash",kind:"life",date:"2026-11-08",photos:["deleted"],_deletedAt:99},
    capsule,
  ],
  recipes:[{id:"recipe",title:"南瓜汤"},{id:"unused-recipe",title:"未做过的蛋糕"}],
  moods:[{date:"2026-11-01",mood:"happy"},{date:"2026-11-17",mood:"happy"},{date:"2026-11-16",mood:"calm"},{date:"2026-11-18",mood:"sad"}],
  ledger:[
    {id:"expense",date:"2026-11-02",type:"expense",cents:12678,category:"food",photos:["shared","receipt"]},
    {id:"expense2",date:"2026-11-03",type:"expense",cents:4321,category:"missing"},
    {id:"income",date:"2026-11-04",type:"income",cents:30200,category:"salary"},
    {id:"later-bill",date:"2026-11-18",type:"expense",cents:99},
    {id:"bad-bill",date:"2026-11-01",type:"expense",cents:1.99},
    {id:"zero-bill",date:"2026-11-01",type:"expense",cents:0},
    {id:"deleted-bill",date:"2026-11-01",type:"expense",cents:10000,_deletedAt:99},
  ],categories:[{id:"food",name:"餐饮"}],
},"2026-11","2026-11-17");
assert.deepEqual(data.entries.map(row=>row.id),["b","c","a"]);
assert.equal(data.days,3);
assert.equal(data.meals.length,2);
assert.deepEqual(data.dishes,[{name:"南瓜汤",count:2}]);
assert.deepEqual(data.moodCounts,{happy:2,calm:1});
assert.equal(data.expense,16999);
assert.equal(data.income,30200);
assert.deepEqual(data.spending.map(row=>row.name),["餐饮","未分类"]);
assert.equal(data.spending.reduce((sum,row)=>sum+row.ratio,0),1);
assert.equal(data.photos.filter(row=>row.src==="shared").length,1);
assert.equal(data.photos.length,4);
assert.deepEqual(data.photos.filter(row=>row.store==="ledger").map(row=>row.src),["receipt"]);
const defaults=defaultMagazineSelection(data);
assert.equal(defaults.includeLedger,false);
assert.equal(defaults.photoKeys.some(key=>key.startsWith("ledger:")),false);
const cleaned=normalizeMagazineSelection(data,{entryIds:["a","gone","a"],photoKeys:["entry:a:1","removed","entry:a:1"],excerpts:{a:"自选摘录",gone:"不要包含"},title:"   ",includeLedger:"yes"});
assert.deepEqual(cleaned.entryIds,["a"]);
assert.deepEqual(cleaned.photoKeys,["entry:a:1"]);
assert.deepEqual(cleaned.excerpts,{a:"自选摘录"});
assert.equal(cleaned.title,"11 月的熊熊月刊");
assert.equal(cleaned.includeLedger,false);
const privateContent=magazineSections(data,defaults,{happy:"开心",calm:"平静"});
assert.doesNotMatch(JSON.stringify(privateContent),/169\.99|302\.00|PRIVATE|receipt|未做过的蛋糕/);
assert.match(JSON.stringify(privateContent),/开心 2 天/);
const publicContent=magazineSections(data,{...defaults,includeLedger:true,excerpts:{a:"用户改写的摘录"}});
assert.match(JSON.stringify(publicContent),/169\.99/);
assert.match(JSON.stringify(publicContent),/302\.00/);
assert.match(JSON.stringify(publicContent),/用户改写的摘录/);
assert.deepEqual(publicContent.sections.filter(row=>/月\d+日 ·/.test(row.title)).map(row=>row.title),["11月01日 · 散步","11月16日 · 南瓜汤","11月17日 · 今日午饭"]);
const noMoodOrFood=magazineSections(data,{...defaults,includeMood:false,includeMeals:false,entryIds:[],photoKeys:[]});
assert.doesNotMatch(JSON.stringify(noMoodOrFood),/心情|南瓜汤|美食|169\.99/);
const empty=magazineMonthData({},"2026-10","2026-11-17");
assert.equal(empty.days,0);
assert.match(JSON.stringify(magazineSections(empty,{})),/还没有心情记录/);
assert.throws(()=>magazineMonthData({},"2026-12","2026-11-17"),/今天或以前/);
assert.throws(()=>magazineMonthData({},"2026-13","2026-11-17"),/今天或以前/);
assert.throws(()=>magazineMonthData({ledger:[{date:"2026-11-01",type:"expense",cents:Number.MAX_SAFE_INTEGER},{date:"2026-11-01",type:"expense",cents:1}]},"2026-11","2026-11-17"),/累计金额/);
// Exercise the actual view handlers with local data and storage callbacks. No browser or network is used.
const uiRows=[{...capsule,id:"locked",title:"给未来",date:"2099-11-17"},{...capsule,id:"ready",title:"旧日来信",date:"2000-11-17"}],settings=new Map();
let rendered="",refreshed=0,photoDraft=[],failRefresh=false,shownPhotos=null;const savedForms=[];
const sheet={dataset:{},querySelector:()=>null};
const context=vm.createContext({
  console,Date,Math,Map,Set,JSON,Promise,Number,String,Array,Object,Error,
  capsuleDue,capsuleIsHidden,validMemoryDate,memoryRows,magazineMonthData,normalizeMagazineSelection,magazineSections,
  dateKey:memoryDateKey,moods:{happy:{name:"开心"}},amountText:cents=>(cents/100).toFixed(2),monthShift:()=>"2026-10",
  bearArt:()=>'<span class="bear-art"></span>',artMeta:()=>({src:"bear.webp",x:0,y:0}),window:{},
  saveItem:async(store,item)=>{assert.equal(store,"entries");const index=uiRows.findIndex(row=>row.id===item.id);if(index<0)uiRows.push(item);else uiRows[index]=item;},
  removeItem:async(store,id)=>{const index=uiRows.findIndex(row=>row.id===id);if(index>=0)uiRows.splice(index,1);},
  getSetting:async key=>settings.get(key),putSetting:async(key,value)=>settings.set(key,value),
  FormData:class{constructor(form){this.values=new Map(form.values||[]);}get(key){return this.values.get(key)??null;}getAll(key){const value=this.values.get(key);return value===undefined?[]:Array.isArray(value)?value:[value];}has(key){return this.values.has(key);}},
});
const moduleText=readFileSync(new URL("../web/memories.js",import.meta.url),"utf8").replace(/^import .*;\n/gm,"").replace(/^export \{[^}]+\};\n/gm,"").replace(/export (async )?function /g,"$1function ");
vm.runInContext(moduleText,context);
context.initMemories({
  sheet,getEntries:()=>uiRows,getMoods:()=>[],getRecipes:()=>[],getLedger:()=>[],
  open:(title,body)=>{rendered=body;sheet.dataset.view="";},announce:()=>{},
  photoFields:()=>'<input name="photos" type="file">',initPhotos:photos=>{photoDraft=[...photos];},getPhotos:()=>photoDraft,
  refreshData:async()=>{refreshed++;if(failRefresh)throw new Error("refresh unavailable");},setDraft:()=>{},
  onSaved:form=>savedForms.push(form),showPhotos:(photos,index,title)=>{shownPhotos={photos,index,title};},
});
context.openCapsule("locked");
assert.doesNotMatch(rendered,/PRIVATE LETTER|PRIVATE PHOTO/);
assert.match(rendered,/编辑原信/);
await context.memoriesClicked({memoryAction:"capsule-open",memoryId:"locked"});
assert.equal(uiRows.find(row=>row.id==="locked").capsuleOpenedAt,undefined);
context.openCapsule("ready");
assert.doesNotMatch(rendered,/PRIVATE LETTER/);
await context.memoriesClicked({memoryAction:"capsule-open",memoryId:"ready"});
assert.match(rendered,/PRIVATE LETTER/);
assert.ok(uiRows.find(row=>row.id==="ready").capsuleOpenedAt);
assert.equal(refreshed,1);
const capsulePage=rendered;
await context.memoriesClicked({memoryAction:"capsule-photo",memoryId:"ready",memoryIndex:"0"});
assert.equal(rendered,capsulePage);
assert.equal(sheet.dataset.view,"capsule");
assert.equal(shownPhotos.index,0);
assert.equal(shownPhotos.title,"旧日来信");
context.editCapsule(uiRows.find(row=>row.id==="locked"));
assert.match(rendered,/PRIVATE LETTER/);
assert.deepEqual(photoDraft,["PRIVATE PHOTO"]);
photoDraft=[];
await context.memoriesSubmitted({dataset:{form:"capsule",id:""},values:[["capsuleTitle","一封新信"],["capsuleDate","2099-12-25"],["capsuleTime","08:30"],["capsuleNote","我的心愿"],["capsuleReminder","on"]]});
const saved=uiRows.find(row=>row.title==="一封新信");
assert.equal(saved.kind,"capsule");assert.equal(saved.date,"2099-12-25");assert.equal(saved.reminder.time,"08:30");assert.equal(saved.recurrence.type,"none");
assert.equal(savedForms.length,1);
assert.doesNotMatch(rendered,/我的心愿/);
assert.equal(context.memoriesBack(),true);
assert.equal(sheet.dataset.view,"capsules");
failRefresh=true;
await context.memoriesSubmitted({dataset:{form:"capsule",id:""},values:[["capsuleTitle","刷新失败也已保存"],["capsuleDate","2099-12-25"],["capsuleTime","08:30"]]});
assert.equal(sheet.dataset.view,"capsule-saved");
assert.match(rendered,/无需再保存一遍/);
assert.doesNotMatch(rendered,/<form/);
assert.equal(savedForms.length,2);
const savedDespiteRefresh=uiRows.filter(row=>row.title==="刷新失败也已保存");
assert.equal(savedDespiteRefresh.length,1);
failRefresh=false;
await context.memoriesClicked({memoryAction:"capsule-refresh",memoryId:savedDespiteRefresh[0].id});
assert.equal(sheet.dataset.view,"capsule");
await context.openMagazine("2026-10");
assert.match(rendered,/金额默认隐藏/);
assert.doesNotMatch(rendered,/name="magazineLedger" checked/);
assert.equal(await context.memoriesChanged({name:"unrelated"}),false);
assert.equal(await context.memoriesSubmitted({dataset:{form:"unrelated"}}),false);
assert.equal(await context.memoriesClicked({action:"unrelated"}),false);
console.log("Passed: local-time capsule opening, exact historical dates, actual-record monthly statistics, deleted/future/private exclusions, photo deduplication, editable selections, opt-in money exports, locked/opened/editable capsule views and saved reminder fields.");
