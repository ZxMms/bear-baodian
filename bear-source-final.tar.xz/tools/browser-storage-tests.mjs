import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {readFile,mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join,resolve,extname} from 'node:path';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';

// Runs the browser fallback against Chromium's real IndexedDB, including aborts.
const project=resolve(fileURLToPath(new URL('..',import.meta.url)));
const page=(await readFile(new URL('./storage-verification.html',import.meta.url),'utf8')).replace("import('./model.js')","import('/web/model.js')");
const server=createServer(async(req,res)=>{
  try {
    const pathname=new URL(req.url,'http://localhost').pathname;
    if(pathname==='/'){res.setHeader('Content-Type','text/html; charset=utf-8');res.end(page);return;}
    const path=resolve(project,'.'+pathname);
    if(!path.startsWith(project+'/')){res.writeHead(403).end();return;}
    res.setHeader('Content-Type',extname(path)==='.js'?'text/javascript; charset=utf-8':'text/plain');res.end(await readFile(path));
  } catch {res.writeHead(404).end();}
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const profile=await mkdtemp(join(tmpdir(),'bear-storage-browser-'));
try {
  const output=await new Promise((resolve,reject)=>{
    const process=spawn(processEnvChromium(),['--headless','--no-sandbox','--disable-gpu','--disable-background-networking',`--user-data-dir=${profile}`,'--virtual-time-budget=12000','--dump-dom',`http://127.0.0.1:${server.address().port}/`]);
    let out='',err='';const timer=setTimeout(()=>{process.kill('SIGKILL');reject(new Error('Chromium storage test timed out'));},30000);
    process.stdout.on('data',data=>out+=data);process.stderr.on('data',data=>err+=data);process.on('error',reject);process.on('close',code=>{clearTimeout(timer);code===0?resolve(out):reject(new Error(err));});
  });
  const resultText=output.match(/<pre id="result">([^<]+)<\/pre>/)?.[1];
  assert(resultText&&resultText!=='running',`Browser test did not complete: ${output.slice(0,500)}`);
  const result=JSON.parse(resultText.replaceAll('&quot;','"').replaceAll('&amp;','&').replaceAll('&gt;','>').replaceAll('&lt;','<'));
  assert(result.ok,result.error);console.log(`Passed ${result.checks} real IndexedDB assertions: drafts, settings, atomic linked saves and rollback, trash filtering/undo and explicit purge.`);
} finally {server.close();await rm(profile,{recursive:true,force:true});}
function processEnvChromium(){return process.env.CHROMIUM_PATH||'/usr/bin/chromium';}
