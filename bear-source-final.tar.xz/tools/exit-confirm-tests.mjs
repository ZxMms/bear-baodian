import assert from 'node:assert/strict';
import {
  showExitConfirmation, exitConfirmationOpen, exitConfirmationBack, destroyExitConfirmation,
} from '../web/exit-confirm.js';

// Run the real dialog controller. The DOM double deliberately leaves the editor
// mounted so these tests can detect focus/scroll loss and stale async callbacks.
const flush = () => new Promise(resolve => setImmediate(resolve));
const deferred = () => {
  let resolve, reject;
  const promise = new Promise((yes, no) => { resolve = yes; reject = no; });
  return {promise, resolve, reject};
};
class ClassList {
  values = new Set();
  add(...values) { values.forEach(value => this.values.add(value)); }
  remove(...values) { values.forEach(value => this.values.delete(value)); }
  contains(value) { return this.values.has(value); }
}
class Element {
  constructor(doc) {
    this.doc = doc;
    this.isConnected = true;
    this.disabled = false;
    this.classList = new ClassList();
    this.dataset = {};
  }
  focus(options) { this.doc.activeElement = this; this.focusOptions = options; }
  setSelectionRange(...selection) { this.restoredSelection = selection; }
  closest(selector) { return selector === '[data-exit-choice]' && this.dataset.exitChoice ? this : null; }
}
class Dialog extends Element {
  constructor(doc) {
    super(doc);
    this.isConnected = false;
    this.attributes = new Map();
    this.listeners = new Map();
    this.buttons = [];
    this.open = false;
    this.status = new Element(doc);
    this.status.hidden = true;
    this.animations = [];
  }
  set innerHTML(html) {
    this.html = html;
    this.buttons = [...html.matchAll(/data-exit-choice="([^"]+)"/g)].map(([,choice]) => {
      const button = new Element(this.doc);
      button.dataset.exitChoice = choice;
      return button;
    });
  }
  querySelector(selector) {
    if (selector === '.exit-confirm-status') return this.status;
    const choice = selector.match(/data-exit-choice="([^"]+)"/)?.[1];
    return this.buttons.find(button => button.dataset.exitChoice === choice) || null;
  }
  querySelectorAll(selector) { return selector === 'button' ? this.buttons : []; }
  setAttribute(name, value) { this.attributes.set(name, value); }
  addEventListener(type, fn) {
    const handlers = this.listeners.get(type) || [];
    handlers.push(fn);
    this.listeners.set(type, handlers);
  }
  dispatch(type, overrides = {}) {
    const event = {
      target: this, clientX: 50, clientY: 50, prevented: false, stopped: false,
      preventDefault() { this.prevented = true; },
      stopPropagation() { this.stopped = true; }, ...overrides,
    };
    for (const handler of this.listeners.get(type) || []) handler(event);
    return event;
  }
  click(choice) {
    const target = this.buttons.find(button => button.dataset.exitChoice === choice);
    assert.ok(target, `Expected visible ${choice} button`);
    return this.dispatch('click', {target});
  }
  showModal() { this.open = true; }
  close() { this.open = false; this.dispatch('close'); }
  remove() {
    this.isConnected = false;
    this.doc.dialogs = this.doc.dialogs.filter(dialog => dialog !== this);
  }
  getBoundingClientRect() { return {left: 10, top: 20, right: 310, bottom: 420}; }
  animate(keyframes, options) {
    const animation = {keyframes, options, ...deferred()};
    animation.finished = animation.promise;
    this.animations.push(animation);
    return animation;
  }
}
function setup({reducedMotion = true, systemReducedMotion = false} = {}) {
  destroyExitConfirmation();
  const doc = {
    dialogs: [], documentElement: {dataset: {reducedMotion: String(reducedMotion)}},
    createElement(tag) { assert.equal(tag, 'dialog'); return new Dialog(this); },
    body: {append(dialog) { dialog.isConnected = true; doc.dialogs.push(dialog); }},
  };
  globalThis.document = doc;
  globalThis.matchMedia = () => ({matches: systemReducedMotion});
  const editor = new Element(doc);
  editor.selectionStart = 2;
  editor.selectionEnd = 7;
  editor.selectionDirection = 'backward';
  doc.activeElement = editor;
  const region = {isConnected: true, scrollTop: 321};
  const calls = {save: 0, discard: 0, exits: []};
  const options = {
    focusTarget: editor, region, canSaveDraft: true,
    saveDraft: () => { calls.save++; return true; },
    discard: () => { calls.discard++; },
    onExit: choice => calls.exits.push(choice),
  };
  const show = overrides => {
    showExitConfirmation({...options, ...overrides});
    return doc.dialogs.at(-1);
  };
  return {doc, editor, region, calls, show};
}
let passed = 0;
const failures = [];
async function test(name, run) {
  try { await run(); passed++; }
  catch (error) { failures.push({name, error}); }
  finally { destroyExitConfirmation(); }
}

await test('Persistent editors expose three choices and cannot stack confirmations', async () => {
  const env = setup(), dialog = env.show();
  assert.equal(exitConfirmationOpen(), true);
  assert.deepEqual(dialog.buttons.map(button => button.dataset.exitChoice), ['continue', 'draft', 'discard']);
  assert.equal(dialog.attributes.get('role'), 'alertdialog');
  assert.equal(dialog.attributes.get('aria-labelledby'), 'exit-confirm-title');
  assert.equal(dialog.attributes.get('aria-describedby'), 'exit-confirm-description');
  assert.equal(env.doc.activeElement, dialog.buttons[0]);
  env.show();
  assert.equal(env.doc.dialogs.length, 1);
  assert.equal(env.doc.dialogs[0], dialog);
});

await test('Non-durable settings expose only continue and discard with existing-value copy', async () => {
  const env = setup(), dialog = env.show({canSaveDraft: false, editingExisting: true});
  assert.deepEqual(dialog.buttons.map(button => button.dataset.exitChoice), ['continue', 'discard']);
  assert.match(dialog.html, /原来的内容会保留/);
  assert.match(dialog.html, /放弃本次修改/);
});

await test('Continue preserves the editor and restores exact selection and scroll', async () => {
  const env = setup(), dialog = env.show();
  env.region.scrollTop = 9;
  assert.equal(dialog.click('continue').stopped, true);
  await flush();
  assert.equal(exitConfirmationOpen(), false);
  assert.equal(env.editor.isConnected, true);
  assert.equal(env.doc.activeElement, env.editor);
  assert.deepEqual(env.editor.focusOptions, {preventScroll: true});
  assert.deepEqual(env.editor.restoredSelection, [2, 7, 'backward']);
  assert.equal(env.region.scrollTop, 321);
  assert.deepEqual(env.calls, {save: 0, discard: 0, exits: []});
});

await test('Android Back consumes only the confirmation and returns false when none is open', async () => {
  const env = setup(); env.show();
  assert.equal(exitConfirmationBack(), true);
  await flush();
  assert.equal(exitConfirmationBack(), false);
  assert.equal(env.editor.isConnected, true);
  assert.equal(env.doc.activeElement, env.editor);
  assert.deepEqual(env.calls.exits, []);
});

await test('Escape and native cancel stop propagation and preserve the underlying editor', async () => {
  for (const type of ['keydown', 'cancel']) {
    const env = setup(), dialog = env.show();
    const event = dialog.dispatch(type, {key: 'Escape'});
    assert.equal(event.prevented, true);
    assert.equal(event.stopped, true);
    await flush();
    assert.equal(exitConfirmationOpen(), false);
    assert.equal(env.doc.activeElement, env.editor);
    assert.deepEqual(env.calls.exits, []);
  }
});

await test('Clicks inside the card stay open and backdrop clicks resume editing', async () => {
  const env = setup(), dialog = env.show();
  dialog.dispatch('click', {clientX: 100, clientY: 100});
  assert.equal(exitConfirmationOpen(), true);
  const event = dialog.dispatch('click', {clientX: 9, clientY: 100});
  assert.equal(event.stopped, true);
  await flush();
  assert.equal(exitConfirmationOpen(), false);
  assert.deepEqual(env.calls.exits, []);
});

await test('Saving awaits persistence, disables all choices and deduplicates rapid taps and Back', async () => {
  const env = setup(), pending = deferred();
  const dialog = env.show({saveDraft: () => { env.calls.save++; return pending.promise; }});
  dialog.click('draft');
  dialog.click('draft');
  dialog.click('discard');
  dialog.click('continue');
  assert.equal(exitConfirmationBack(), true);
  assert.equal(exitConfirmationOpen(), true);
  assert.equal(env.calls.save, 1);
  assert.equal(env.calls.discard, 0);
  assert.equal(dialog.attributes.get('aria-busy'), 'true');
  assert.ok(dialog.buttons.every(button => button.disabled));
  assert.deepEqual(env.calls.exits, []);
  pending.resolve(true); await flush();
  assert.equal(exitConfirmationOpen(), false);
  assert.deepEqual(env.calls.exits, ['draft']);
});

await test('A false save result keeps the form, reports failure and permits a successful retry', async () => {
  const env = setup(); let attempt = 0;
  const dialog = env.show({saveDraft: () => ++attempt > 1});
  dialog.click('draft'); await flush();
  assert.equal(exitConfirmationOpen(), true);
  assert.equal(dialog.status.hidden, false);
  assert.equal(dialog.status.classList.contains('is-error'), true);
  assert.match(dialog.status.textContent, /填写内容还在/);
  assert.equal(dialog.attributes.get('aria-busy'), 'false');
  assert.ok(dialog.buttons.every(button => !button.disabled));
  assert.deepEqual(env.calls.exits, []);
  assert.equal(env.editor.isConnected, true);
  dialog.click('draft'); await flush();
  assert.equal(attempt, 2);
  assert.equal(exitConfirmationOpen(), false);
  assert.deepEqual(env.calls.exits, ['draft']);
});

await test('Rejected persistence and discard promises keep the confirmation and permit continue', async () => {
  for (const choice of ['draft', 'discard']) {
    const env = setup();
    const dialog = env.show({[choice === 'draft' ? 'saveDraft' : 'discard']: async () => { throw new Error('disk full'); }});
    dialog.click(choice); await flush();
    assert.equal(exitConfirmationOpen(), true);
    assert.equal(dialog.status.textContent, 'disk full');
    assert.equal(env.doc.activeElement, dialog.buttons[0]);
    assert.deepEqual(env.calls.exits, []);
    dialog.click('continue'); await flush();
    assert.equal(env.doc.activeElement, env.editor);
    assert.equal(exitConfirmationOpen(), false);
  }
});

await test('Discard waits for cleanup and exits only once after successful cleanup', async () => {
  const env = setup(), pending = deferred();
  const dialog = env.show({discard: () => { env.calls.discard++; return pending.promise; }});
  dialog.click('discard'); dialog.click('discard');
  assert.equal(env.calls.discard, 1);
  assert.deepEqual(env.calls.exits, []);
  pending.resolve(); await flush();
  assert.equal(exitConfirmationOpen(), false);
  assert.deepEqual(env.calls.exits, ['discard']);
  assert.equal(env.editor.restoredSelection, undefined);
});

await test('Destroying a pending dialog suppresses its eventual exit and does not focus the old editor', async () => {
  const env = setup(), pending = deferred();
  const dialog = env.show({saveDraft: () => pending.promise});
  dialog.click('draft');
  destroyExitConfirmation();
  assert.equal(exitConfirmationOpen(), false);
  assert.equal(env.editor.restoredSelection, undefined);
  pending.resolve(true); await flush();
  assert.deepEqual(env.calls.exits, []);
  assert.equal(env.editor.restoredSelection, undefined);
});

await test('An obsolete save cannot dismiss or report errors into a replacement confirmation', async () => {
  for (const outcome of ['resolve', 'reject']) {
    const env = setup(), pending = deferred();
    const obsolete = env.show({saveDraft: () => pending.promise});
    obsolete.click('draft'); destroyExitConfirmation();
    const replacement = env.show();
    pending[outcome](outcome === 'resolve' ? true : new Error('old failure'));
    await flush();
    assert.equal(exitConfirmationOpen(), true);
    assert.deepEqual(env.doc.dialogs, [replacement]);
    assert.equal(replacement.status.hidden, true);
    assert.equal(env.doc.activeElement, replacement.buttons[0]);
    assert.deepEqual(env.calls.exits, []);
  }
});

await test('Destroying during an exit animation suppresses callbacks and protects the next dialog', async () => {
  const env = setup({reducedMotion: false}), dialog = env.show();
  dialog.click('discard'); await flush();
  assert.equal(dialog.animations.length, 1);
  assert.equal(exitConfirmationBack(), true);
  assert.equal(dialog.animations.length, 1);
  destroyExitConfirmation();
  const replacement = env.show();
  dialog.animations[0].resolve(); await flush();
  assert.deepEqual(env.calls.exits, []);
  assert.deepEqual(env.doc.dialogs, [replacement]);
});

await test('Motion preference bypasses animation and regular animation restores only after it ends', async () => {
  for (const preferences of [{reducedMotion: true}, {reducedMotion: false, systemReducedMotion: true}]) {
    const env = setup(preferences), dialog = env.show();
    dialog.click('continue'); await flush();
    assert.equal(dialog.animations.length, 0);
    assert.equal(exitConfirmationOpen(), false);
  }
  const env = setup({reducedMotion: false}), dialog = env.show();
  dialog.click('continue');
  assert.equal(exitConfirmationOpen(), true);
  assert.equal(env.editor.restoredSelection, undefined);
  dialog.animations[0].resolve(); await flush();
  assert.equal(exitConfirmationOpen(), false);
  assert.deepEqual(env.editor.restoredSelection, [2, 7, 'backward']);
});

await test('External native close restores the editor and makes a later save callback inert', async () => {
  const env = setup(), pending = deferred();
  const dialog = env.show({saveDraft: () => pending.promise});
  dialog.click('draft'); dialog.close();
  assert.equal(exitConfirmationOpen(), false);
  assert.equal(env.doc.activeElement, env.editor);
  pending.resolve(true); await flush();
  assert.deepEqual(env.calls.exits, []);
});

for (const {name, error} of failures) console.error(`FAIL ${name}\n${error.stack}`);
if (failures.length) process.exitCode = 1;
console.log(`Passed ${passed} exit-confirm regressions${failures.length ? `; failed ${failures.length}` : ''}: editor preservation, async failure safety, navigation and motion.`);
