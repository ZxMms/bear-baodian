import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const deps=process.env.BEAR_UI_TEST_DEPS?path.resolve(process.env.BEAR_UI_TEST_DEPS):new URL('./ui-test-runtime/node_modules/',import.meta.url).pathname;
const [{JSDOM,VirtualConsole},{indexedDB}]=await Promise.all([import(pathToFileURL(path.join(deps,'jsdom/lib/api.js'))),import(pathToFileURL(path.join(deps,'fake-indexeddb/build/esm/index.js')))]);
const web=new URL('../web/',import.meta.url),html=fs.readFileSync(new URL('index.html',web),'utf8'),version=/app\.js\?v=(\d+)/.exec(html)[1];
const errors=[],vc=new VirtualConsole();vc.on('jsdomError',error=>errors.push(error.message));
const dom=new JSDOM(html,{url:'https://ledger.test/',pretendToBeVisual:true,runScripts:'outside-only',virtualConsole:vc}),w=dom.window;
for(const name of ['window','document','navigator','localStorage','FormData','MutationObserver','Event','CustomEvent','Image','Audio','HTMLElement','HTMLInputElement'])Object.defineProperty(globalThis,name,{value:name==='window'?w:w[name],configurable:true});
w.matchMedia=query=>({matches:false,media:query,addEventListener(){},removeEventListener(){}});globalThis.matchMedia=w.matchMedia;
w.scrollTo=()=>{};w.HTMLElement.prototype.scrollIntoView=function(){};w.HTMLElement.prototype.animate=()=>({finished:Promise.resolve(),cancel(){}});
w.HTMLDialogElement.prototype.showModal=function(){this.open=true;};w.HTMLDialogElement.prototype.close=function(){this.open=false;this.dispatchEvent(new w.Event('close'));};
w.HTMLMediaElement.prototype.pause=function(){};w.HTMLMediaElement.prototype.play=async function(){};
globalThis.requestAnimationFrame=w.requestAnimationFrame.bind(w);globalThis.cancelAnimationFrame=w.cancelAnimationFrame.bind(w);
globalThis.indexedDB=w.indexedDB=indexedDB;globalThis.CSS=w.CSS={escape:s=>String(s).replace(/[^\w-]/g,c=>'\\'+c)};
w.eval(fs.readFileSync(new URL('lunar.js',web),'utf8'));globalThis.Solar=w.Solar;globalThis.Lunar=w.Lunar;
for(const match of html.matchAll(/rel="stylesheet" href="([^?]+)\?/g)){const style=w.document.createElement('style');style.textContent=fs.readFileSync(new URL(match[1],web),'utf8');w.document.head.append(style);assert.ok(style.sheet?.cssRules.length);}
const moduleURL=name=>new URL(name+'?v='+version,web).href;
const model=await import(moduleURL('model.js'));await model.openStore();await model.setSound(false);
await import(moduleURL('app.js'));
const pause=()=>new Promise(resolve=>setTimeout(resolve,35));
for(let i=0;i<60&&!w.document.querySelector('.tabs,.initial-error');i++)await pause();
assert.equal(w.document.querySelector('.initial-error'),null);
const $=selector=>w.document.querySelector(selector);
async function click(selector){const node=$(selector);assert.ok(node,selector);node.dispatchEvent(new w.MouseEvent('click',{bubbles:true}));await pause();await pause();}
function set(name,value){const input=$(`#sheet [name="${name}"]`);assert.ok(input,name);input.value=value;input.dispatchEvent(new w.Event('input',{bubbles:true}));input.dispatchEvent(new w.Event('change',{bubbles:true}));}
async function submit(){const form=$('#sheet form');form.requestSubmit();await pause();await pause();assert.ok(!form.isConnected||!form.getAttribute('aria-busy'));}
const saved=async()=>await model.getSetting('feature:gold-goals');

const requests=[];let phase='normal';
const wrap=data=>JSON.stringify({success:true,resultCode:0,resultData:{data}});
const today=new Date(Date.now()+8*3600000).toISOString().slice(0,10);
const quote=wrap({stockCode:'Au99.99',currentPrice:'800.12',currentTime:Date.now(),closedYesterday:'799',open:'801',minPrice:'797',maxPrice:'802'});
const points=Array.from({length:96},(_,i)=>({date:new Date(Date.parse(today+'T00:00:00Z')-(95-i)*86400000).toISOString().slice(0,10),close:String(780+i)}));
const brands='<table><tr><td>测试金店 &lt;标签&gt;</td><td>首饰黄金</td><td>1100</td><td>'+today+'</td></tr><tr><td>旧金店</td><td>首饰黄金</td><td>1090</td><td>2020-01-01</td></tr><tr><td>测试金店</td><td>投资金条</td><td>820</td><td>'+today+'</td></tr></table>';
w.BearGold={cancel(){},request(id,kind){requests.push({id,kind});if(phase==='hold')return;setTimeout(()=>w.bearGoldResult(id,phase==='fail'&&kind==='quote'?{ok:false,error:'网络已断开'}:{ok:true,body:kind==='quote'?quote:kind==='history'?wrap({kLineDtoList:points}):brands}),15);}};
await click('[data-page="ledger"]');assert.ok($('[data-market-action="open"]'));
await click('[data-market-action="open"]');assert.equal($('#sheet').dataset.view,'gold-prices');assert.match($('.market-price').textContent,/800.12/);assert.match($('.market-timestamp').textContent,/报价时间.*北京时间/);assert.equal(requests.length,3);
await click('[data-market-tab="brands"]');assert.equal($('.market-brand b').textContent,'1100.00');assert.match($('.market-brands').textContent,/旧报价/);assert.equal($('#sheet script'),null);
await click('[data-market-type="bar"]');assert.match($('.market-brands').textContent,/投资金条/);assert.equal($('.market-brand b').textContent,'820.00');
await click('[data-market-tab="history"]');assert.ok($('.market-line'));assert.equal($('#market-point').options.length,30);
await click('[data-market-days="7"]');assert.equal($('#market-point').options.length,7);await click('[data-market-days="90"]');assert.equal($('#market-point').options.length,90);
$('#market-point').selectedIndex=8;const selected=$('#market-point').value;$('#market-point').dispatchEvent(new w.Event('change',{bubbles:true}));assert.match($('.market-selected').textContent,new RegExp(selected));
await click('[data-market-tab="quote"]');phase='fail';await click('[data-market-action="refresh"]');assert.match($('#market-content').textContent,/网络已断开/);assert.equal($('.market-price'),null,'failed refresh must not display an old price as latest');
await click('[data-market-tab="brands"]');assert.ok($('.market-brand'),'one failed source does not hide other results');
phase='hold';await click('[data-market-action="refresh"]');const obsolete=requests.at(-3);await click('#sheet [data-action="close"]');assert.equal($('#sheet').open,false);
phase='normal';await click('[data-market-action="open"]');w.bearGoldResult(obsolete.id,{ok:true,body:wrap({stockCode:'Au99.99',currentPrice:'100',currentTime:Date.now()})});assert.match($('.market-price').textContent,/800.12/);
await click('.market-goals');assert.equal($('#sheet').dataset.view,'gold-list');w.bearCalendarBack();await pause();assert.equal($('#sheet').dataset.view,'gold-prices');assert.ok($('.market-price'),'return from goal repaints current price');
await click('#sheet [data-action="close"]');delete w.BearGold;await click('[data-market-action="open"]');assert.match($('#market-content').textContent,/新版手机 App/);
assert.deepEqual(errors,[]);console.log('PASS gold price UI: real app entry, independent sources, tabs, 7/30/90-day chart, selected trading day, partial errors, refresh, stale callbacks, goal back navigation and unsupported-browser fallback.');
dom.window.close();process.exit(0);
