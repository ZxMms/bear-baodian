import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';

// Execute the actual app helpers/event handlers with small DOM boundaries. This
// checks cross-feature routing and asynchronous navigation without a browser.
const source=await readFile(new URL('../web/app.js',import.meta.url),'utf8');
const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function functionSource(name){const start=new RegExp(`^(?:async )?function ${name}\\(`,'m').exec(source);assert(start,`Missing integration helper ${name}`);const rest=source.slice(start.index),line=rest.split('\n')[0];if(line.endsWith('}'))return line;const end=/^}/m.exec(rest);assert(end,`Missing closing boundary for ${name}`);return rest.slice(0,end.index+1);}
function context(names,values={}){const ctx=vm.createContext({html:escape,document:{body:{append(){}}},toast:{classList:{contains:()=>false}},...values});for(const name of names)vm.runInContext(functionSource(name),ctx);return ctx;}
function deferred(){let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return {promise,resolve,reject};}
let count=0;const failures=[];
async function test(name,run){try{await run();count++;}catch(error){failures.push(`${name}: ${error.stack}`);}}

await test('A late daily-menu response cannot write into a detached day sheet',async()=>{
  const task=deferred(),target={isConnected:true,dataset:{dayMealPlan:'2026-11-18'},innerHTML:'loading'};
  const ctx=context(['loadDayMealPlan'],{getMealPlan:()=>task.promise});
  const loading=ctx.loadDayMealPlan(target,'2026-11-18');target.isConnected=false;
  task.resolve({plans:[{id:'old',mealName:'午餐',title:'旧日菜单'}]});await loading;
  assert.equal(target.innerHTML,'loading');
});
await test('A response for an older date cannot overwrite a reused day section',async()=>{
  const task=deferred(),target={isConnected:true,dataset:{dayMealPlan:'2026-11-18'},innerHTML:'loading'};
  const ctx=context(['loadDayMealPlan'],{getMealPlan:()=>task.promise});
  const loading=ctx.loadDayMealPlan(target,'2026-11-18');target.dataset.dayMealPlan='2026-11-19';target.innerHTML='new date';
  task.resolve({plans:[{id:'old',title:'旧日菜单'}]});await loading;
  assert.equal(target.innerHTML,'new date');
});
await test('Calendar manual meals log to their day and never expose a broken cook action',async()=>{
  const target={isConnected:true,dataset:{dayMealPlan:'2026-12-05'},innerHTML:''};
  const ctx=context(['loadDayMealPlan'],{getMealPlan:async()=>({plans:[{id:'manual-1',title:'妈妈的饭 <晚餐>',mealName:'晚餐'}]})});
  await ctx.loadDayMealPlan(target,'2026-12-05');
  assert.match(target.innerHTML,/data-kitchen-plan-log="manual-1" data-kitchen-date="2026-12-05"/);
  assert.doesNotMatch(target.innerHTML,/data-kitchen-plan-cook=/);
  assert.match(target.innerHTML,/妈妈的饭 &lt;晚餐&gt;/);assert.doesNotMatch(target.innerHTML,/<晚餐>/);
});
await test('A daily-menu read failure presents a retry for the same date',async()=>{
  const target={isConnected:true,dataset:{dayMealPlan:'2026-12-05'},innerHTML:''};
  const ctx=context(['loadDayMealPlan'],{getMealPlan:async()=>{throw new Error('disk read');}});
  await ctx.loadDayMealPlan(target,'2026-12-05');assert.match(target.innerHTML,/data-day-plan-retry="2026-12-05"/);
});
await test('All new editing forms protect text and checkbox changes on close',()=>{
  for(const kind of ['pantry-item','pantry-intake','pantry-plan-date','pantry-missing','happy-box-save','wish','wish-contribution','wish-complete']){
    const form={dataset:{form:kind},values:[['title','before']]};
    const sheet={querySelector:selector=>selector.includes(`[data-form="${kind}"]`)?form:null};
    const ctx=context(['draftSnapshot','hasDraftChanges'],{sheet,durableForm:()=>null,FormData:class{constructor(f){return f.values;}},formPhotos:[],foodRecipeCover:'',formCoverFocus:{x:50,y:50},initialDraft:null});
    ctx.initialDraft=ctx.draftSnapshot();assert(ctx.initialDraft,`${kind} needs an exit snapshot`);
    form.values=[['title','after'],['selectedPhoto','0']];assert.equal(ctx.hasDraftChanges(),true,`${kind} changes must be protected`);
  }
});
await test('Changing only a wish cover or crop counts as an unsaved edit',()=>{
  const form={dataset:{form:'wish'},values:[['wishTitle','旅行'],['wishTarget','3000']]};
  const ctx=context(['draftSnapshot','hasDraftChanges'],{sheet:{querySelector:selector=>selector.includes('[data-form="wish"]')?form:null},durableForm:()=>null,FormData:class{constructor(f){return f.values;}},formPhotos:['media/original.jpg'],foodRecipeCover:'',formCoverFocus:{x:50,y:50},initialDraft:null});
  ctx.initialDraft=ctx.draftSnapshot();ctx.formPhotos=['media/new.jpg'];assert.equal(ctx.hasDraftChanges(),true);
  ctx.formPhotos=['media/original.jpg'];ctx.formCoverFocus={x:10,y:80};assert.equal(ctx.hasDraftChanges(),true);
});
function clickContext(values={}){
  let click;const ctx=vm.createContext({document:{addEventListener:(name,handler)=>{if(name==='click')click=handler;}},busy:false,uploadTask:null,
    sheet:{querySelector:()=>null,dataset:{}},photoExperienceClicked:()=>false,weatherClick:()=>false,durableForm:()=>null,scheduleDraft(){},announce(){},...values});
  const start=source.indexOf('document.addEventListener("click", async (event) => {'),end=source.indexOf('\nsheet.addEventListener("click"',start);assert(start>=0&&end>start);vm.runInContext(source.slice(start,end),ctx);
  return {ctx,click:data=>click({target:{closest:()=>({dataset:data})}})};
}
await test('Recipe logging uses the date on the recipe detail, not stale global selection',async()=>{
  const calls=[],{click}=clickContext({recipeDate:'2026-11-18',editEntry:(...args)=>calls.push(args)});
  await click({logMeal:'recipe-1',recordDate:'2026-12-05'});
  assert.deepEqual(calls,[['meal',null,'recipe-1',false,'2026-12-05']]);
});
await test('Feature clicks hold the global lock during writes and release it on errors',async()=>{
  for(const [key,name] of [['pantryAction','pantryClicked'],['happyAction','happyBoxClicked'],['wishAction','wishesClicked']]){
    const task=deferred(),messages=[];let calls=0;
    const {ctx,click}=clickContext({[name]:async()=>{calls++;await task.promise;},announce:text=>messages.push(text)});
    const active=click({[key]:'save'});assert.equal(ctx.busy,true);await click({[key]:'save'});assert.equal(calls,1);
    task.reject(new Error('保存失败，请重试'));await active;assert.equal(ctx.busy,false);assert.match(messages[0],/保存失败/);
  }
});
await test('Widget shortcuts never claim a non-durable feature editor was saved as a draft',async()=>{
  let closed=0,prompted=0,routed=0,flushed=0;const messages=[];
  const ctx=context(['widgetAction'],{appReady:true,busy:false,uploadTask:null,hasDraftChanges:()=>true,durableForm:()=>null,flushDurableDraft:async()=>{flushed++;return true;},
    requestClose(){prompted++;},close(){closed++;},announce:message=>messages.push(message),today:()=> '2026-11-18',editEntry(){routed++;},audioHasChanges:()=>false});
  await ctx.widgetAction({type:'entry'});
  assert.equal(closed,0);assert.equal(routed,0);assert.equal(flushed,0);assert.equal(prompted,1);assert(!messages.some(message=>message.includes('已保存')));
});

await test('Returning to a day overview reloads its async meal list instead of leaving a frozen loading state',()=>{
  const target={isConnected:true,dataset:{dayMealPlan:'2026-12-05'},innerHTML:'loading'},content={scrollTop:0},calls=[];
  const sheet={dataset:{view:'entry'},innerHTML:'entry detail',querySelector:selector=>selector==='.sheet-content'?content:selector==='[data-day-meal-plan]'?target:null};
  const ctx=context(['restorePreviousSheet','goBackInSheet'],{sheet,sheetHistory:[{html:'day overview',data:{view:'day'},scroll:124,baseline:null}],initialDraft:null,
    exitConfirmationBack:()=>false,photoExperienceBack:()=>false,hasDraftChanges:()=>false,audioHasChanges:()=>false,returningSheet:false,lastEditorFocus:null,
    sheetFocusTarget:()=>null,focusSheetTarget:()=>false,loadDayMealPlan:(...args)=>calls.push(args)});
  ctx.goBackInSheet();assert.equal(sheet.dataset.view,'day');assert.equal(content.scrollTop,124);assert.equal(calls.length,1);assert.equal(calls[0][0],target);assert.equal(calls[0][1],'2026-12-05');
});

function notificationContext({changed=true,busy=false,uploadTask=null}={}){
  let consumed=0,closed=0,confirmation=null;const routed=[],scheduled=[],form={dataset:{form:'wish'}},entry={id:'event-original',date:'2026-12-05'};
  const ctx=context(['requestClose','openNotificationTarget'],{busy,uploadTask,appReady:true,window:{BearReminders:{consumeOpenEntry(){consumed++;return JSON.stringify({id:entry.id,date:'2026-12-06'});}}},
    hasDraftChanges:()=>changed,audioHasChanges:()=>false,durableForm:()=>null,lastEditorFocus:null,bearArt:()=>'',sheet:{querySelector:selector=>selector==='form'?form:null,contains:()=>false},
    showExitConfirmation:options=>{confirmation=options;},flushDurableDraft:async()=>true,clearCurrentDraft:async()=>{},close(){closed++;},initialDraft:{},announce(){},
    entryById:id=>id===entry.id?entry:null,render(){},showEntry:(...args)=>routed.push(args),setTimeout:(fn,delay)=>scheduled.push({fn,delay}),
    ledgerReminderTarget:()=>null,holidays:[],today:()=> '2026-11-18'});
  const start=source.indexOf('window.bearOpenNotification = () => {'),end=source.indexOf('\nfunction openNotificationTarget',start);assert(start>=0&&end>start);vm.runInContext(source.slice(start,end),ctx);
  return {ctx,routed,scheduled,get consumed(){return consumed;},get closed(){return closed;},get confirmation(){return confirmation;}};
}
await test('A notification preserves a feature editor until explicit exit and keeps the already-consumed destination',async()=>{
  const run=notificationContext();run.ctx.window.bearOpenNotification();
  assert.equal(run.consumed,1);assert.equal(run.closed,0);assert.equal(run.routed.length,0);assert(run.confirmation);assert.equal(run.confirmation.canSaveDraft,false);
  // Continuing simply leaves this independent confirmation without invoking onExit.
  assert.equal(run.ctx.sheet.querySelector('form').dataset.form,'wish');assert.equal(run.routed.length,0);
  run.confirmation.onExit('discard');await Promise.resolve();
  assert.equal(run.routed.length,1);assert.equal(run.routed[0][0].id,'event-original');assert.equal(run.routed[0][1],'2026-12-06');assert.equal(run.consumed,1);
});
await test('Notifications wait for an in-flight write or image conversion without closing the editor',()=>{
  for(const waiting of [{busy:true},{uploadTask:{pending:true}}]){
    const run=notificationContext({changed:false,...waiting});run.ctx.window.bearOpenNotification();
    assert.equal(run.consumed,1);assert.equal(run.closed,0);assert.equal(run.routed.length,0);assert.equal(run.scheduled.length,1);assert.equal(run.scheduled[0].delay,250);
    run.ctx.busy=false;run.ctx.uploadTask=null;run.scheduled[0].fn();
    assert.equal(run.consumed,1);assert.equal(run.closed,1);assert.equal(run.routed.length,1);assert.equal(run.routed[0][0].id,'event-original');
  }
});
await test('Widget shortcuts wait for writes and image conversion while preserving the requested action',async()=>{
  for(const waiting of [{busy:true,uploadTask:null},{busy:false,uploadTask:{pending:true}}]){
    const scheduled=[],calls=[];let closed=0;
    const ctx=context(['widgetAction'],{appReady:true,...waiting,hasDraftChanges:()=>false,setTimeout:(fn,delay)=>scheduled.push({fn,delay}),close(){closed++;},today:()=> '2026-11-18',editLedger:(...args)=>calls.push(args)});
    await ctx.widgetAction(JSON.stringify({type:'ledger'}));assert.equal(closed,0);assert.equal(calls.length,0);assert.equal(scheduled.length,1);assert.equal(scheduled[0].delay,250);
    ctx.busy=false;ctx.uploadTask=null;await scheduled[0].fn();assert.equal(closed,1);assert.deepEqual(calls,[[null,'2026-11-18']]);
  }
});

if(failures.length){console.error(failures.join('\n\n'));process.exitCode=1;}
else console.log(`Passed ${count} feature integration checks: asynchronous day menus, explicit dates, feature exit protection, cover edits and click locking.`);
