import assert from 'node:assert/strict';
import {ledgerPeriod,shiftLedgerPeriod,periodDays,periodRows,periodSummary,periodCategories,periodTrend,pieSlices,percentageText} from '../web/ledger-periods.js';

const range=(mode,anchor,custom)=>ledgerPeriod(mode,anchor,custom);
const bounds=period=>[period.start,period.end];
assert.deepEqual(bounds(range('week','2026-11-19')),['2026-11-16','2026-11-22']);
assert.deepEqual(bounds(range('week','2027-01-01')),['2026-12-28','2027-01-03']);
assert.deepEqual(bounds(range('month','2028-02-29')),['2028-02-01','2028-02-29']);
assert.deepEqual(bounds(range('quarter','2026-12-31')),['2026-10-01','2026-12-31']);
assert.deepEqual(bounds(range('quarter','2026-04-01')),['2026-04-01','2026-06-30']);
assert.deepEqual(bounds(range('year','2028-03-10')),['2028-01-01','2028-12-31']);
assert.equal(periodDays(range('year','2028-03-10')),366);
assert.deepEqual(bounds(shiftLedgerPeriod(range('quarter','2026-02-01'),-1)),['2025-10-01','2025-12-31']);
assert.deepEqual(bounds(shiftLedgerPeriod(range('year','2026-02-01'),1)),['2027-01-01','2027-12-31']);
const custom=range('custom',null,{start:'2026-12-31',end:'2027-01-02'});
assert.equal(periodDays(custom),3);
assert.deepEqual(bounds(shiftLedgerPeriod(custom,-1)),['2026-12-28','2026-12-30']);
assert.deepEqual(bounds(shiftLedgerPeriod(custom,1)),['2027-01-03','2027-01-05']);
for(const mode of ['month','quarter','year','week']){
 assert.equal(shiftLedgerPeriod(range(mode,'1900-01-01'),-1),null);
 assert.equal(shiftLedgerPeriod(range(mode,'9999-12-31'),1),null);
}
assert.deepEqual(bounds(shiftLedgerPeriod(range('week','9999-12-20'),1)),['9999-12-27','9999-12-31']);
assert.throws(()=>range('custom',null,{start:'2026-11-20',end:'2026-11-19'}),/不能早于/);
for(const invalid of ['2026-02-29','2026-04-31','1899-12-31','10000-01-01','2026-1-01',''])assert.throws(()=>range('month',invalid));
assert.throws(()=>range('__proto__','2026-11-19'));

const bill=(date,cents,category='food',type='expense',extra={})=>({date,cents,category,type,...extra});
const rows=[bill('2026-12-30',900),bill('2026-12-31',101),bill('2027-01-01',202,'travel'),bill('2027-01-02',303),bill('2027-01-03',999),bill('2027-01-01',100000,'salary','income'),bill('2027-01-02',777,'food','expense',{_deletedAt:1}),bill('2027-01-01',-10),bill('2027-01-01',0),bill('2027-01-01',NaN),bill('2027-01-01',1.5),bill('2027-01-01',1,'food','unknown'),bill('2027-02-31',50)];
assert.equal(periodRows(rows,custom).length,4);
assert.deepEqual(periodSummary(rows,custom),{income:100000,expense:606,net:99394,count:4});
assert.deepEqual(periodCategories(rows,custom,'expense'),[{id:'food',cents:404,count:2},{id:'travel',cents:202,count:1}]);
assert.deepEqual(periodCategories(rows,custom,'income'),[{id:'salary',cents:100000,count:1}]);
assert.deepEqual(periodSummary([],custom),{income:0,expense:0,net:0,count:0});
assert.equal(periodSummary(rows.filter(row=>row.cents!==202),custom).expense,404);
assert.equal(periodSummary(rows.map(row=>row.cents===202?{...row,cents:300}:row),custom).expense,704);
assert.throws(()=>periodSummary([bill(custom.start,Number.MAX_SAFE_INTEGER),bill(custom.end,1)],custom),/超出/);

for(const period of [custom,range('week','2027-01-01'),range('month','2027-01-10'),range('quarter','2027-02-01'),range('year','2027-01-01'),range('custom',null,{start:'1900-01-01',end:'9999-12-31'})]){
 for(const type of ['income','expense']){
  const trend=periodTrend(rows,period,type);
  assert.ok(trend.points.length>0&&trend.points.length<=62);
  assert.equal(trend.points[0].start,period.start);assert.equal(trend.points.at(-1).end,period.end);
  assert.equal(trend.points.reduce((sum,point)=>sum+point.cents,0),periodSummary(rows,period)[type]);
  for(let i=1;i<trend.points.length;i++)assert.equal(Date.parse(trend.points[i].start)-Date.parse(trend.points[i-1].end),86400000);
 }
}
assert.equal(periodTrend(rows,range('quarter','2027-02-01'),'expense').points.length,3);
assert.equal(periodTrend(rows,range('year','2027-01-01'),'income').points.length,12);
const partial=range('custom',null,{start:'2026-12-31',end:'2027-04-01'});
assert.equal(periodTrend(rows,partial,'expense').points[0].cents,101,'partial first month excludes earlier bills');
const single=range('custom',null,{start:'2027-01-01',end:'2027-01-01'});
assert.equal(periodTrend(rows,single,'expense').points.length,1);
const slices=pieSlices(periodCategories(rows,custom,'expense'));
assert.equal(slices.length,2);assert.ok(Math.abs(slices.reduce((sum,x)=>sum+x.share,0)-1)<1e-12);assert.equal(slices[0].percent,'66.7%');
assert.equal(pieSlices([{id:'only',cents:100,count:1}])[0].full,true);
assert.deepEqual(pieSlices([]),[]);assert.deepEqual(pieSlices([{cents:0}]),[]);
assert.equal(percentageText(1,100000),'不足 0.1%');
assert.ok(slices.every(slice=>!/[Nn]a[Nn]|Infinity/.test(slice.path)));
console.log('Passed ledger periods: week/month/quarter/year/custom, inclusive boundaries, leap days, cross-year shifts, deleted/invalid data, exact money, category shares, bounded trends and pie geometry.');
