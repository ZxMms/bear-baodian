import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const deps=process.env.BEAR_UI_TEST_DEPS?path.resolve(process.env.BEAR_UI_TEST_DEPS):new URL('./ui-test-runtime/node_modules/',import.meta.url).pathname;
const canvasDeps=process.env.BEAR_CANVAS_DEPS?path.resolve(process.env.BEAR_CANVAS_DEPS):deps;
const [{JSDOM,VirtualConsole},{indexedDB},canvas]=await Promise.all([import(pathToFileURL(path.join(deps,'jsdom/lib/api.js'))),import(pathToFileURL(path.join(deps,'fake-indexeddb/build/esm/index.js'))),import(pathToFileURL(path.join(canvasDeps,'@napi-rs/canvas/index.js')))]);
const web=new URL('../web/',import.meta.url),html=fs.readFileSync(new URL('index.html',web),'utf8'),version=/app\.js\?v=(\d+)/.exec(html)[1];
const errors=[],vc=new VirtualConsole();vc.on('jsdomError',error=>errors.push(error.message));
const dom=new JSDOM(html,{url:'https://sharing.test/',pretendToBeVisual:true,runScripts:'outside-only',virtualConsole:vc}),w=dom.window;
for(const name of ['window','document','navigator','localStorage','FormData','MutationObserver','Event','CustomEvent','Image','Audio','HTMLElement','HTMLInputElement'])Object.defineProperty(globalThis,name,{value:name==='window'?w:w[name],configurable:true});
w.matchMedia=query=>({matches:false,media:query,addEventListener(){},removeEventListener(){}});globalThis.matchMedia=w.matchMedia;
w.scrollTo=()=>{};w.HTMLElement.prototype.scrollIntoView=function(){};w.HTMLElement.prototype.animate=()=>({finished:Promise.resolve(),cancel(){}});
w.HTMLDialogElement.prototype.showModal=function(){this.open=true;};w.HTMLDialogElement.prototype.close=function(){this.open=false;this.dispatchEvent(new w.Event('close'));};
w.HTMLMediaElement.prototype.pause=function(){};w.HTMLMediaElement.prototype.play=async function(){};
globalThis.requestAnimationFrame=w.requestAnimationFrame.bind(w);globalThis.cancelAnimationFrame=w.cancelAnimationFrame.bind(w);
globalThis.indexedDB=w.indexedDB=indexedDB;globalThis.CSS=w.CSS={escape:s=>String(s).replace(/[^\w-]/g,c=>'\\'+c)};
w.eval(fs.readFileSync(new URL('lunar.js',web),'utf8'));globalThis.Solar=w.Solar;globalThis.Lunar=w.Lunar;
for(const match of html.matchAll(/rel="stylesheet" href="([^?]+)\?/g)){const style=w.document.createElement('style');style.textContent=fs.readFileSync(new URL(match[1],web),'utf8');w.document.head.append(style);assert.ok(style.sheet?.cssRules.length);}
class FileImage extends canvas.Image { set src(value){super.src=value.startsWith('data:')?value:fs.readFileSync(new URL(value,web));} }
Object.defineProperty(globalThis,'Image',{value:FileImage,configurable:true});
const drawn=[],photoPositions=[];
w.HTMLCanvasElement.prototype.getContext=function(){
 const host=this;
 if(!this.realCanvas){this.realCanvas=canvas.createCanvas(this.width,this.height);const real=this.realCanvas.getContext('2d');this.realContext=new Proxy(real,{get(target,key){if(key==='drawImage')return (image,...args)=>{if(image.width===160&&image.height===220&&args.length===4)photoPositions.push({x:args[0],y:args[1],width:args[2],height:args[3]});return target.drawImage(image.realCanvas||image,...args);};if(key==='fillText')return (text,x,y)=>{const measured=target.measureText(text),right=target.textAlign==='right'?x:x+measured.width;drawn.push({text,x,y,right,width:host.width,font:target.font});return target.fillText(text,x,y);};const v=Reflect.get(target,key,target);return typeof v==='function'?v.bind(target):v;},set(target,key,value){target[key]=value;return true;}});}
 return this.realContext;
};
w.HTMLCanvasElement.prototype.toDataURL=function(){return this.realCanvas.toDataURL('image/png');};
const captured={pages:[],sent:[],copied:[],albums:[],saved:[],refresh:0};
w.BearShare={prepare(value){captured.pages=JSON.parse(value);return JSON.stringify({ok:true,token:'test-only-token'});},share(token){captured.sent.push(token);},copy(text){captured.copied.push(text);},saveToAlbum(token,index){captured.albums.push({token,index});},save(token,index){captured.saved.push({token,index});}};
let forecast={native:true,place:{name:'丰台',displayName:'北京市 · 丰台区',source:'city',countryCode:'CN',admin1:'北京市',nmcCode:'TEST'},weather:{provider:'nmc',temperature:7,conditionText:'多云',code:2,isDay:true,observedAt:Date.now(),updatedAt:Date.now(),windDirectionText:'西北风',windPower:'3级'},loading:false,error:''};
function emit(patch){forecast={...forecast,...patch};w.bearWeatherChanged(JSON.stringify(forecast));}
w.BearWeather={state:()=>JSON.stringify(forecast),refreshNow(){captured.refresh++;emit({loading:true});}};
const moduleURL=name=>new URL(name+'?v='+version,web).href;
const model=await import(moduleURL('model.js'));await model.openStore();await model.setSound(false);
const date=model.dateKey();
await model.saveItem('entries',{id:'share-fixture',kind:'life',date,title:'测试卡片：小日常',note:'测试内容：今天一起去公园散步。',photos:[],recurrence:{type:'none'}});
await model.saveItem('ledger',{id:'private-money',date,type:'income',cents:1000000,category:'category-8',note:'私密工资备注',photos:[]});
await import(moduleURL('app.js'));
const pause=()=>new Promise(r=>setTimeout(r,30));
for(let i=0;i<60&&!w.document.querySelector('.tabs,.initial-error');i++)await pause();
assert.equal(w.document.querySelector('.initial-error'),null);
const $=selector=>w.document.querySelector(selector);
async function click(selector){const el=$(selector);assert.ok(el,selector);el.click();await pause();await pause();}
async function submit(){const form=$('#sheet form');form.requestSubmit();for(let i=0;i<120&&$('#sheet').dataset.view!=='share-preview';i++)await pause();assert.equal($('#sheet').dataset.view,'share-preview',form.querySelector('.form-error')?.textContent);}
await click('[data-action="open-today"]');await click('[data-share-day]');
assert.match($('.share-weekday').textContent,/^星期[日一二三四五六]$/);assert.equal(captured.refresh,1);assert.ok($('[name=shareWeather]').checked);assert.match($('[data-share-weather-status]').textContent,/查询中/);
$('[name=shareLedger]').checked=false;emit({loading:false});assert.match($('[data-share-weather-status]').textContent,/丰台区[\s\S]*西北风[\s\S]*3级/);
await submit();assert.ok(captured.pages[0].startsWith('data:image/png;base64,'));
assert.match($('.share-preview-date .share-weekday').textContent,/^星期[日一二三四五六]$/);
assert.match($('.share-text pre').textContent,/星期[\s\S]*丰台区[\s\S]*西北风[\s\S]*3级/);assert.doesNotMatch($('.share-text pre').textContent,/私密工资/);
assert.ok(drawn.some(p=>p.text.includes('星期')));assert.ok(drawn.some(p=>p.text.includes('风力 3级')));
assert.deepEqual(captured.albums,[],'preview must never save to the album');assert.deepEqual(captured.sent,[],'preview must not send');
if(process.env.BEAR_SHARE_PREVIEW){fs.writeFileSync(process.env.BEAR_SHARE_PREVIEW,Buffer.from(captured.pages[0].split(',')[1],'base64'));}
await click('[data-share-action="send"]');assert.deepEqual(captured.sent,['test-only-token']);assert.deepEqual(captured.albums,[],'ordinary sharing never saves to the album');
await click('[data-share-action="album"]');assert.deepEqual(captured.albums,[{token:'test-only-token',index:0}]);
await click('[data-share-action="copy"]');assert.equal(captured.copied[0],$('.share-text pre').textContent);
await click('[data-share-action="options"]');$('[name=shareWeather]').checked=false;emit({loading:false});assert.equal($('[name=shareWeather]').checked,false,'live weather update preserves explicit opt-out');const noWeatherStart=drawn.length;await submit();assert.doesNotMatch($('.share-text pre').textContent,/丰台|风力|中央气象台/);assert.ok(drawn.slice(noWeatherStart).some(p=>/^星期/.test(p.text)),'weekday is independent of weather');
if(process.env.BEAR_SHARE_PREVIEW)fs.writeFileSync(path.join(path.dirname(process.env.BEAR_SHARE_PREVIEW),'test-share-no-weather.png'),Buffer.from(captured.pages[0].split(',')[1],'base64'));
await click('[data-share-action="options"]');$('[name=shareWeather]').checked=true;emit({loading:false,error:'测试断网'});await submit();assert.match($('.share-preview-note').textContent,/未附天气/);assert.doesNotMatch($('.share-text pre').textContent,/丰台|中央气象台/);
await click('[data-share-action="options"]');await click('[data-share-action="weather-refresh"]');emit({loading:false,error:''});await submit();assert.match($('.share-text pre').textContent,/丰台/);
const sharing=await import(moduleURL('share.js'));
sharing.showShareOptions({mode:'day',title:'2026-01-01 · 这一天',subtitle:'测试历史日期',entries:[{id:'past',label:'生活',title:'过去的一天',note:'测试内容',photos:[]}],ledger:[]});
const before=captured.refresh;assert.match($('[data-share-weather-status]').textContent,/没有留存/);await submit();assert.equal(captured.refresh,before);assert.doesNotMatch($('.share-text pre').textContent,/丰台|风力/);
assert.match($('.share-preview-date').textContent,/2026-01-01星期四/);assert.match($('.share-text pre').textContent,/2026-01-01 · 星期四/);
const multiStart=drawn.length;
sharing.showShareOptions({mode:'day',date,title:'旧标题没有星期',subtitle:'测试多页',entries:[{id:'long',label:'生活',title:'测试长手账',note:'测试多页分页内容\n'.repeat(75),photos:[]}],ledger:[]});emit({loading:false,error:''});await submit();assert.ok(captured.pages.length>1);assert.ok(captured.pages.length<=9);
assert.equal(drawn.slice(multiStart).filter(p=>/^星期[日一二三四五六]$/.test(p.text)).length,captured.pages.length,'weekday is painted independently on every exported page');
await click('[data-share-action="next"]');await click('[data-share-action="album"]');assert.equal(captured.albums.at(-1).index,1,'gallery saves only explicitly chosen current page');
sharing.showShareOptions({mode:'recipe',title:'测试菜谱',subtitle:'食谱',entries:[{id:'recipe',label:'菜谱',title:'番茄面',note:'测试做法',photos:[]}],ledger:[]});assert.equal($('[name=shareWeather]'),null);assert.equal($('.share-weekday'),null);await submit();assert.doesNotMatch($('.share-text pre').textContent,/天气|风力|丰台/);
const photoCanvas=canvas.createCanvas(160,220),photoContext=photoCanvas.getContext('2d');photoContext.fillStyle='#d5e3d1';photoContext.fillRect(0,0,160,220);const photo=photoCanvas.toDataURL('image/png'),albumCount=captured.albums.length;
const photoStart=drawn.length;sharing.showShareOptions({mode:'day',date,title:'照片分页测试',subtitle:'测试内容',entries:[{id:'five-photos',label:'生活',title:'五图长记录',note:'用于分页的测试文字\n'.repeat(33),photos:Array(5).fill(photo)}],ledger:[]});emit({loading:false,error:''});await submit();
assert.equal(photoPositions.length,5);assert.ok(photoPositions.every(p=>p.x>=46&&p.x+p.width<=674&&p.y>0&&p.y+p.height<1650),'all five photos fit above the footer');assert.equal(drawn.slice(photoStart).filter(p=>/^星期/.test(p.text)).length,captured.pages.length);assert.equal(captured.albums.length,albumCount,'five-photo preview does not save automatically');
for(const sample of [
 {name:'night',weather:{provider:'open-meteo',temperature:-3,conditionText:'',code:0,isDay:false,windDirection:315,windSpeed:3.2,windGust:5.8}},
 {name:'rain',weather:{provider:'nmc',temperature:16,conditionText:'小雨',code:61,isDay:true,windDirectionText:'东南风',windPower:'3—4级'}},
 {name:'long',weather:{provider:'nmc',temperature:-12,conditionText:'测试较长天气描述'.repeat(6),code:3,isDay:true,windDirectionText:'西北风',windPower:'3—4级，短时阵风较强（测试）'.repeat(4),stationName:'测试站点名称'.repeat(9)},place:{...forecast.place,displayName:'测试省 · 测试自治州 · 测试长地区名称'.repeat(3)}}
]){
 const start=drawn.length;sharing.showShareOptions({mode:'day',date,title:'任意旧标题',subtitle:'测试天气排版',entries:[{id:'sample',label:'生活',title:'排版测试',note:'这是隔离的测试资料，不是真实天气。',photos:[]}],ledger:[]});
 emit({...(sample.place?{place:sample.place}:{}),weather:{...sample.weather,updatedAt:Date.now(),observedAt:Date.now()},loading:false,error:''});await submit();
 const text=drawn.slice(start);assert.ok(text.some(p=>/^星期/.test(p.text)));assert.ok(text.every(p=>p.right<=720&&p.y<1800));
 if(process.env.BEAR_SHARE_PREVIEW)fs.writeFileSync(path.join(path.dirname(process.env.BEAR_SHARE_PREVIEW),`test-share-${sample.name}.png`),Buffer.from(captured.pages[0].split(',')[1],'base64'));
}
assert.deepEqual(errors,[]);assert.equal((await model.loadAll('ledger')).length,1,'sharing never changes bills');
assert.ok(drawn.every(p=>p.x>=0&&p.right<=720&&p.y>0&&p.y<1800),'drawn text stays within card bounds');
console.log('Passed sharing UI and real Canvas: weekday/weather text and pixels, opt-out, asynchronous refresh, errors/history, multi-page current-image save, copy, recipe isolation, and no automatic gallery save or send.');
dom.window.close();process.exit(0);
