import assert from 'node:assert/strict';
import {migrateLegacy} from '../web/native-store.js?v=34';
const names=['entries','recipes','moods','ledger','ledgerCategories','settings'];
globalThis.localStorage={setItem(){},removeItem(){}};
function fakeDatabase(){
 const tables=Object.fromEntries(names.map(n=>[n,new Map()]));tables.entries.set('entry',{id:'entry',title:'中文🙂',photos:['data:image/png;base64,AA==']});tables.settings.set('sound',false);
 return {tables,transaction(name){const tx={objectStore:()=>({getAllKeys:()=>read([...tables[name].keys()]),get:key=>read(tables[name].get(key))})};function read(value){const req={result:structuredClone(value)};queueMicrotask(()=>tx.oncomplete());return req;}return tx;}};
}
const db=fakeDatabase(),ops=[];
const reply=async req=>{ops.push(req);return req.op==='migration-finish'?{counts:Object.fromEntries(names.map(n=>[n,db.tables[n].size]))}:{};};
await migrateLegacy(db,reply);assert.equal(ops.at(-1).op,'migration-finish');assert.equal(ops.find(r=>r.key==='sound').value,false);assert.equal(db.tables.entries.size,1);
const changed=fakeDatabase(),changedOps=[];
await assert.rejects(migrateLegacy(changed,async req=>{changedOps.push(req.op);if(req.op==='migration-row')changed.tables.entries.get('entry').title='并发修改';return {};}),/内容发生变化/);assert(!changedOps.includes('migration-finish'));
const interrupted=fakeDatabase();await assert.rejects(migrateLegacy(interrupted,async req=>{if(req.op==='migration-row')throw new Error('storage full');return {};}),/storage full/);assert.equal(interrupted.tables.entries.size,1);
console.log('Passed: migration keeps original data, preserves false settings, checks same-key edits and aborts safely on write failure.');
