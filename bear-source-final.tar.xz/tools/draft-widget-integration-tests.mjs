import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
import {dateKey,fromKey,onDate,nextOccurrence,moods} from '../web/model.js';
import {recurrenceFor,nextScheduledDate,lunarLabel} from '../web/calendar-tools.js';
import {seasonalContext} from '../web/food-core.js';

// Execute the app's real integration helpers with controlled DOM/native boundaries.
// These checks protect user-visible persistence and widget behavior, not source spelling.
const source=await readFile(new URL('../web/app.js',import.meta.url),'utf8');
vm.runInThisContext(await readFile(new URL('../web/lunar.js',import.meta.url),'utf8'));
function functionSource(name){
  const start=new RegExp(`^(?:async )?function ${name}\\(`,'m').exec(source);
  assert(start,`Missing integration helper ${name}`);
  const rest=source.slice(start.index),next=/\n(?:async )?function \w+\(/.exec(rest);
  return next?rest.slice(0,next.index):rest;
}
function context(names,values){
  const focusHelpers=['focusSheetTarget','captureSheetFocus','sheetFocusTarget'];
  const required=names.some(name=>['open','close','sheetSnapshot','goBackInSheet'].includes(name))?[...focusHelpers,'restorePreviousSheet',...names]:names;
  const document=values.document||{activeElement:null};document.body??={append(){}};
  const ctx=vm.createContext({toast:{classList:{contains:()=>false}},app:{contains:()=>false,querySelector:()=>null},sheetOpener:null,lastEditorFocus:null,...values,document});
  for(const name of new Set(required))vm.runInContext(functionSource(name),ctx);return ctx;
}
let passed=0;const failures=[];
async function test(name,run){try{await run();passed++;}catch(error){failures.push(`${name}: ${error.message}`);}}

await test('Capsule edits participate in durable draft detection',()=>{
  const form={dataset:{form:'capsule'},values:[['capsuleTitle','给未来的自己']]};
  const ctx=context(['durableForm','durableKey','draftSnapshot'],{sheet:{querySelector:selector=>selector.includes('[data-form="capsule"]')?form:null},newId:()=> 'draft-test',FormData:class{constructor(f){return f.values;}},formPhotos:[],foodRecipeCover:'',formCoverFocus:{x:50,y:50},photoQualityMode:'standard',getPhotoQualityMode:()=> 'standard'});
  assert(ctx.draftSnapshot(),'capsule content must produce a comparison snapshot');
});
await test('Changing only the cover focal point counts as an unsaved edit',()=>{
  const form={dataset:{form:'recipe'},values:[['title','面条']]};
  const ctx=context(['durableForm','durableKey','draftSnapshot'],{sheet:{querySelector:()=>form},newId:()=> 'draft-test',FormData:class{constructor(f){return f.values;}},formPhotos:['media/original.jpg'],foodRecipeCover:'',formCoverFocus:{x:50,y:50},photoQualityMode:'standard',getPhotoQualityMode:()=> 'standard'});
  const before=JSON.stringify(ctx.draftSnapshot());ctx.formCoverFocus={x:20,y:80};
  assert.notEqual(JSON.stringify(ctx.draftSnapshot()),before,'cover crop changes must be saved and protected on close');
});
await test('Draft identity survives a new record receiving its saved ID',()=>{
  const form={dataset:{form:'ledger',id:''}};
  const ctx=context(['durableForm','durableKey'],{sheet:{querySelector:()=>form},newId:()=> 'new-draft-identity'});
  const before=ctx.durableKey(form);form.dataset.id='committed-bill-id';assert.equal(ctx.durableKey(form),before,'draft cleanup must target the original draft after commit');
});
await test('Back preserves unsaved preferences, settings, budgets and audio edits through an independent confirmation',()=>{
  for(const formType of ['preferences','date-settings','ledger-budget','audio-settings']){
    const form={dataset:{form:formType},values:[['value','before']]},content={scrollTop:120,isConnected:true},field={isConnected:true};
    let confirmation=null,closed=0,prompts=0,dismissed=0;
    const sheet={dataset:{view:formType},innerHTML:'current editing page',contains:node=>node===field,querySelector(selector){
      if(selector==='form'||selector.includes(`[data-form="${formType}"]`))return form;
      if(selector==='.sheet-content')return content;
      return null;
    }};
    const ctx=context(['durableForm','durableKey','draftSnapshot','hasDraftChanges','requestClose','goBackInSheet'],{
      sheet,sheetHistory:[{html:'previous page',data:{view:'settings'},scroll:10}],initialDraft:null,returningSheet:false,lastEditorFocus:field,
      FormData:class{constructor(f){return f.values;}},formPhotos:[],foodRecipeCover:'',formCoverFocus:{x:50,y:50},
      photoExperienceBack:()=>false,audioHasChanges:()=>formType==='audio-settings',memoriesBack:()=>false,ledgerBack:()=>false,close(){closed++;},
      showExitConfirmation(options){if(!confirmation){confirmation=options;prompts++;}},exitConfirmationBack(){if(!confirmation)return false;confirmation=null;dismissed++;return true;},
      bearArt:()=>'',flushDurableDraft:async()=>true,clearCurrentDraft:async()=>{},newId:()=> 'unused',announce(){}
    });
    ctx.initialDraft=ctx.draftSnapshot();form.values=[['value','unsaved change']];
    ctx.goBackInSheet();
    assert.equal(sheet.innerHTML,'current editing page',`${formType}: Back must not replace the editor`);
    assert.equal(ctx.sheetHistory.length,1,`${formType}: history remains untouched until the decision`);
    assert.equal(closed,0);assert.equal(prompts,1);assert.equal(confirmation.canSaveDraft,false);
    assert.equal(confirmation.focusTarget,field);assert.equal(confirmation.region,content);assert.equal(content.scrollTop,120);
    assert.equal(form.values[0][1],'unsaved change');
    ctx.requestClose();assert.equal(prompts,1,`${formType}: repeated close cannot stack confirmations`);
    ctx.goBackInSheet();assert.equal(dismissed,1,`${formType}: Back dismisses only the confirmation`);
    assert.equal(ctx.sheetHistory.length,1);assert.equal(closed,0);assert.equal(form.values[0][1],'unsaved change');
  }
});
await test('Unchanged forms close without asking and persistent editors offer a draft',()=>{
  const form={dataset:{form:'entry',id:'existing-entry'}},content={scrollTop:45};let changed=false,closed=0,confirmation=null;
  const ctx=context(['requestClose'],{hasDraftChanges:()=>changed,audioHasChanges:()=>false,close(){closed++;},sheet:{querySelector:q=>q==='form'?form:q==='.sheet-content'?content:null,contains:()=>false},durableForm:()=>form,lastEditorFocus:null,bearArt:()=>'',showExitConfirmation:options=>confirmation=options,flushDurableDraft:async()=>true,clearCurrentDraft:async()=>{},announce(){},initialDraft:{}});
  ctx.requestClose();assert.equal(closed,1);assert.equal(confirmation,null);
  changed=true;ctx.requestClose();assert.equal(closed,1);assert.equal(confirmation.canSaveDraft,true);assert.equal(confirmation.editingExisting,true);
});
await test('Returning from a settings subpage restores the original edit baseline',()=>{
  const form={dataset:{form:'preferences'},values:[['theme','night']]},content={scrollTop:75};let prompted=0;
  const sheet={dataset:{view:'settings'},innerHTML:'settings markup',querySelector(selector){
    if(selector==='.sheet-content')return content;
    return this.dataset.view==='settings'&&selector.includes('[data-form="preferences"]')?form:null;
  },querySelectorAll:()=>[],cloneNode(){return {innerHTML:this.innerHTML,querySelectorAll:()=>[]};}};
  const ctx=context(['durableForm','draftSnapshot','hasDraftChanges','sheetSnapshot','goBackInSheet'],{
    sheet,initialDraft:null,sheetHistory:[],returningSheet:false,FormData:class{constructor(f){return f.values;}},formPhotos:[],foodRecipeCover:'',formCoverFocus:{x:50,y:50},
    exitConfirmationBack:()=>false,photoExperienceBack:()=>false,audioHasChanges:()=>false,requestClose(){prompted++;},memoriesBack:()=>false,ledgerBack:()=>false,
  });
  ctx.initialDraft=ctx.draftSnapshot();const baseline=ctx.initialDraft,snapshot=ctx.sheetSnapshot();
  assert.notEqual(snapshot.baseline,baseline,'history owns an independent baseline');
  ctx.sheetHistory.push(snapshot);sheet.dataset.view='widgets';sheet.innerHTML='widget subpage';ctx.initialDraft=null;
  ctx.goBackInSheet();assert.equal(sheet.dataset.view,'settings');assert.equal(content.scrollTop,75);
  assert.deepEqual(JSON.parse(JSON.stringify(ctx.initialDraft)),JSON.parse(JSON.stringify(baseline)));assert.equal(ctx.hasDraftChanges(),false);
  form.values=[['theme','day']];assert.equal(ctx.hasDraftChanges(),true);ctx.goBackInSheet();assert.equal(prompted,1);
});
await test('Navigating from edited preferences waits for an explicit discard decision',async()=>{
  let click,confirmation,closed=0;const routes=[],form={dataset:{form:'preferences'}};
  const sheet={querySelector:selector=>selector==='form'||selector.includes('[data-form="preferences"]')?form:null,contains:()=>false};
  const ctx=context(['requestClose'],{document:{addEventListener:(name,callback)=>{click=callback;}},busy:false,uploadTask:null,
    sheet,hasDraftChanges:()=>true,audioHasChanges:()=>false,durableForm:()=>null,lastEditorFocus:null,bearArt:()=>'',
    showExitConfirmation:options=>{confirmation=options;},close(){closed++;},flushDurableDraft:async()=>true,clearCurrentDraft:async()=>{},initialDraft:{},
    workbenchClicked:async data=>routes.push(data.workAction),announce(){},scheduleDraft(){},
  });
  const start=source.indexOf('document.addEventListener("click", async (event) => {'),end=source.indexOf('\nsheet.addEventListener("click"',start);
  assert(start>=0&&end>start);vm.runInContext(source.slice(start,end),ctx);
  await click({target:{closest:()=>({dataset:{workAction:'widgets'}})}});
  assert.equal(closed,0);assert.deepEqual(routes,[]);assert(confirmation);assert.equal(confirmation.canSaveDraft,false);
  // Continuing has no exit callback; the destination must remain unopened.
  assert.equal(sheet.querySelector('form'),form);assert.equal(ctx.busy,false);
  confirmation.onExit('discard');await Promise.resolve();assert.equal(closed,1);assert.deepEqual(routes,['widgets']);
});
await test('Completed destructive confirmations never return through sheet history',()=>{
  for(const title of ['删除这份草稿？','永久删除？','删除这条记录？','删除这道菜谱？','删除这笔账？','把这封信移到最近删除？']){
    const content={scrollTop:0};let closed=0;
    const sheet={open:false,dataset:{},innerHTML:'',querySelector(selector){
      if(selector==='#sheet-title'){const title=this.innerHTML.match(/<h2 id="sheet-title"[^>]*>([^<]*)<\/h2>/)?.[1];return title===undefined?null:{textContent:title};}
      return selector==='.sheet-content'?content:null;
    },querySelectorAll:()=>[],cloneNode(){return {innerHTML:this.innerHTML,querySelectorAll:()=>[]};},setAttribute(){},showModal(){this.open=true;}};
    const ctx=context(['sheetSnapshot','open','goBackInSheet'],{
      sheet,sheetHistory:[],returningSheet:false,initialDraft:null,lastEditorFocus:null,countdownTimer:null,clearInterval(){},flushDurableDraft:()=>Promise.resolve(true),destroyExitConfirmation(){},exitConfirmationBack:()=>false,
      durableForm:()=>null,html:value=>value,icon:()=>'',photoExperienceBack:()=>false,hasDraftChanges:()=>false,audioHasChanges:()=>false,
      memoriesBack:()=>false,ledgerBack:()=>false,requestClose(){closed++;}
    });
    ctx.open('原始列表','<p>待处理记录</p>');sheet.dataset.view='list';
    ctx.open(title,'<button data-confirm-operation="record">确认操作</button>');
    assert.equal(sheet.dataset.view,'confirmation',`${title}: confirmation receives its transient view state`);
    // The operation has finished; its normal handler now opens the updated result.
    ctx.open('处理完成','<p>操作已完成</p>');sheet.dataset.view='result';
    assert.equal(ctx.sheetHistory.length,1,`${title}: history contains only the list, not the executed confirmation`);
    ctx.goBackInSheet();
    assert.equal(sheet.querySelector('#sheet-title').textContent,'原始列表');assert.equal(sheet.dataset.view,'list');
    assert(!sheet.innerHTML.includes('data-confirm-operation'),`${title}: Back cannot expose the old executable confirmation`);
    ctx.goBackInSheet();assert.equal(closed,1,`${title}: the next Back exits instead of replaying the action page`);
  }
});
function navigationFocusFixture(){
  // Model the browser's node replacement/focus boundary, while executing the
  // actual open/snapshot/back/close helpers above. No app routing is duplicated.
  const document={activeElement:null},focusLog=[];let ctx,markup='';
  const node=(tag,attributes={})=>({tagName:tag,isConnected:true,disabled:false,children:[],parentElement:null,scrollTop:0,scrollLeft:0,...attributes,
    contains(target){for(let p=target;p;p=p.parentElement)if(p===this)return true;return false;},
    closest(){for(let p=this;p;p=p.parentElement)if(p.hidden||p.inert)return p;return null;},
    getClientRects(){return this.hidden?[]:[{}];},
    focus(options){document.activeElement=this;focusLog.push({node:this,options});if(['INPUT','TEXTAREA','SELECT'].includes(this.tagName)&&ctx)ctx.lastEditorFocus=this;},
    setAttribute(name,value){this[name]=value;},removeAttribute(name){delete this[name];},
    setSelectionRange(start,end,direction){this.selectionStart=start;this.selectionEnd=end;this.selectionDirection=direction;sheet.content.scrollTop=999;},
  });
  const append=(parent,...children)=>{parent.children.push(...children);for(const child of children)child.parentElement=parent;};
  const body=node('BODY'),app=node('MAIN'),opener=node('BUTTON'),tab=node('BUTTON');append(body,app);append(app,opener,tab);document.activeElement=body;
  app.querySelector=selector=>selector==='.tabs [aria-current]'?tab:null;
  const sheet=node('DIALOG',{open:false,dataset:{}});append(body,sheet);
  const disconnect=parent=>{for(const child of parent.children){disconnect(child);child.isConnected=false;}parent.children=[];};
  Object.defineProperty(sheet,'innerHTML',{get:()=>markup,set(value){
    if(sheet.contains(document.activeElement))document.activeElement=body;
    disconnect(sheet);markup=value;sheet.content=node('SECTION');sheet.header=node('DIV');
    sheet.title=node('H2',{textContent:value.match(/<h2 id="sheet-title"[^>]*>([^<]*)<\/h2>/)?.[1],tabIndex:-1});
    append(sheet,sheet.content);append(sheet.content,sheet.header);append(sheet.header,sheet.title);
    sheet.fields=[];sheet.targets=new Map();
    for(const match of value.matchAll(/<(button|input|textarea|select)\b[^>]*data-focus-key="([^"]+)"[^>]*>/g)){
      const child=node(match[1].toUpperCase(),{focusKey:match[2],value:'原来的文字内容',checked:false});
      append(sheet.content,child);sheet.targets.set(match[2],child);
      if(child.tagName!=='BUTTON')sheet.fields.push(child);
    }
  }});
  sheet.querySelector=selector=>selector==='#sheet-title'?sheet.title:selector==='.sheet-content'?sheet.content:null;
  sheet.querySelectorAll=()=>sheet.fields||[];
  sheet.cloneNode=()=>({innerHTML:markup,querySelectorAll:()=>(sheet.fields||[]).map(field=>({...field}))});
  sheet.showModal=()=>{sheet.open=true;};sheet.close=()=>{sheet.open=false;document.activeElement=body;};
  sheet.replaceChildren=()=>{disconnect(sheet);markup='';};
  ctx=context(['sheetSnapshot','open','close','requestClose','goBackInSheet'],{
    document,app,sheet,sheetHistory:[],sheetOpener:null,returningSheet:false,initialDraft:null,lastEditorFocus:null,countdownTimer:null,changed:false,
    clearInterval(){},flushDurableDraft:()=>Promise.resolve(true),destroyExitConfirmation(){},exitConfirmationBack:()=>false,
    durableForm:()=>null,html:value=>value,icon:()=>'',photoExperienceBack:()=>false,hasDraftChanges:()=>ctx.changed,audioHasChanges:()=>false,
    memoriesBack:()=>false,ledgerBack:()=>false,stopAudio(){},cancelReceipt(){},cancelRecipeImport(){},bearArt:()=>'',clearCurrentDraft:async()=>{},announce(){},
    showExitConfirmation(options){ctx.confirmation=options;},
  });
  return {ctx,document,app,sheet,opener,tab,focusLog,target:key=>sheet.targets.get(key)};
}
await test('Confirming Back returns one level with its focus and scroll; Close still exits the entire sheet',()=>{
  for(const choice of ['draft','discard']){
    const f=navigationFocusFixture();
    f.ctx.open('日期记录','<button data-focus-key="write">写记录</button>');
    f.sheet.content.scrollTop=88;f.target('write').focus();
    f.ctx.open('写手账','<textarea data-focus-key="note"></textarea>');
    f.ctx.changed=true;f.ctx.durableForm=()=>({dataset:{form:'entry'}});
    f.ctx.goBackInSheet();assert.ok(f.ctx.confirmation.canSaveDraft);
    f.ctx.confirmation.onExit(choice);assert.ok(f.sheet.open);
    assert.equal(f.sheet.title.textContent,'日期记录');assert.equal(f.sheet.content.scrollTop,88);
    assert.equal(f.document.activeElement,f.target('write'));assert.equal(f.ctx.sheetHistory.length,0);
    f.ctx.open('写手账','<textarea data-focus-key="note"></textarea>');
    f.ctx.requestClose();f.ctx.confirmation.onExit(choice);assert.equal(f.sheet.open,false);
  }
});
await test('Meal-plan form changes in inactive tabs still require an exit decision',()=>{
  const titleInput={name:'planTitle',value:'',disabled:true},form={dataset:{form:'kitchen-plan'},elements:[{name:'planSource',value:'recipe',checked:true},titleInput]};
  const ctx=context(['draftSnapshot','hasDraftChanges'],{sheet:{querySelector:()=>form},initialDraft:null});
  ctx.initialDraft=ctx.draftSnapshot();assert.equal(ctx.hasDraftChanges(),false);
  titleInput.value='写完后切回了菜谱页';assert.equal(ctx.hasDraftChanges(),true,'hidden manual text remains protected even when its fieldset is disabled');
});
await test('Saving or returning from a meal editor replaces its old planner history',()=>{
  for(const saved of [true,false]){
    const f=navigationFocusFixture();f.ctx.open('工具箱','<p>工具</p>');f.sheet.dataset.view='workbench';
    f.ctx.open('一周吃什么','<p>保存前的菜单</p>');f.sheet.dataset.view='kitchen-planner';
    f.ctx.open('安排一道菜',`<form data-form="kitchen-plan" ${saved?'data-saved="true"':''}><input data-focus-key="dish"></form>`);f.sheet.dataset.view='kitchen-plan-edit';
    assert.equal(f.ctx.sheetHistory.length,2);
    f.ctx.open('一周吃什么',`<p>${saved?'保存后的红烧肉':'未修改直接返回'}</p>`);f.sheet.dataset.view='kitchen-planner';
    assert.equal(f.ctx.sheetHistory.length,1,'the original planner snapshot is replaced, and the editor is not pushed');
    assert.equal(f.ctx.sheetHistory[0].data.view,'workbench');
    f.ctx.goBackInSheet();assert.equal(f.sheet.dataset.view,'workbench');assert.doesNotMatch(f.sheet.innerHTML,/data-form="kitchen-plan"|保存前的菜单/,'Back cannot reopen a submitted editor or stale menu');
  }
});
await test('Continue editing retains a meal draft; discarding returns to a fresh planner',()=>{
  const f=navigationFocusFixture();
  const planner=()=>{f.ctx.open('一周吃什么','<p>已保存的菜单</p>');f.sheet.dataset.view='kitchen-planner';};
  planner();f.ctx.open('安排一道菜','<input data-focus-key="dish">');f.sheet.dataset.view='kitchen-plan-edit';
  const editor=f.sheet.innerHTML;f.target('dish').value='没保存的菜名';f.ctx.changed=true;
  f.ctx.requestClose(planner);assert.ok(f.ctx.confirmation);assert.equal(f.ctx.confirmation.canSaveDraft,false);assert.equal(f.sheet.dataset.view,'kitchen-plan-edit');
  // Back on the existing exit confirmation is the same continue-editing branch.
  f.ctx.exitConfirmationBack=()=>{if(!f.ctx.confirmation)return false;f.ctx.confirmation=null;return true;};
  f.ctx.goBackInSheet();assert.equal(f.sheet.innerHTML,editor);assert.equal(f.target('dish').value,'没保存的菜名');assert.equal(f.sheet.open,true);
  f.ctx.requestClose(planner);f.ctx.confirmation.onExit('discard');f.ctx.changed=false;f.ctx.confirmation=null;
  assert.equal(f.sheet.dataset.view,'kitchen-planner');assert.equal(f.ctx.sheetHistory.length,0);
  f.ctx.open('安排一道菜','<input data-focus-key="fresh-dish">');f.sheet.dataset.view='kitchen-plan-edit';
  assert.doesNotMatch(f.sheet.innerHTML,/没保存的菜名|data-saved/);assert.equal(f.ctx.sheetHistory.length,1);assert.equal(f.ctx.sheetHistory[0].data.view,'kitchen-planner');
});
await test('Opening a nested sheet focuses its new heading without focusing an input',()=>{
  const f=navigationFocusFixture();f.opener.focus();
  f.ctx.open('搜索','<input data-focus-key="query"><button data-focus-key="result">结果</button>');
  assert.equal(f.document.activeElement,f.sheet.title);assert.equal(f.sheet.title.tabIndex,-1);
  f.target('result').focus();f.ctx.open('记录详情','<input data-focus-key="edit-title">');
  assert.equal(f.document.activeElement,f.sheet.title);assert.equal(f.document.activeElement.textContent,'记录详情');
  assert.equal(f.focusLog.filter(event=>event.node.tagName==='INPUT').length,0,'new sheets do not request the input keyboard');
  assert.equal(f.ctx.lastEditorFocus,null);assert.equal(f.ctx.sheetOpener,f.opener);
});
await test('Every opened sheet keeps its grabber inside the first sticky header and its existing scroll owner',()=>{
  const f=navigationFocusFixture();f.ctx.open('跟熊熊做饭','<p data-sheet-body>很长的做菜步骤</p>');
  assert.match(f.sheet.innerHTML,/^<section class="sheet-content"><div class="sheet-header"><div class="sheet-grabber" aria-hidden="true"><\/div>/);
  assert.equal((f.sheet.innerHTML.match(/class="sheet-content"/g)||[]).length,1);
  assert.match(f.sheet.innerHTML,/<button[^>]+data-action="close"[^>]*>[\s\S]*?<\/button><\/div><p data-sheet-body>/,'body content follows the complete opaque header');
  f.sheet.dataset.view='cooking';f.sheet.content.scrollTop=487;
  f.ctx.open('成品日记','<p>成品照片</p>');f.ctx.goBackInSheet();
  assert.equal(f.sheet.dataset.view,'cooking');assert.equal(f.sheet.content.scrollTop,487,'header regrouping preserves cooking scroll restoration');
  assert.equal(f.document.activeElement,f.sheet.title);
});
await test('Back restores the cloned result button, scroll and editor context for exit confirmation',()=>{
  const f=navigationFocusFixture();f.opener.focus();
  f.ctx.open('搜索','<input data-focus-key="query"><button data-focus-key="result">结果</button>');
  const oldField=f.target('query'),oldResult=f.target('result');oldField.focus();oldResult.focus();f.sheet.content.scrollTop=217;
  f.ctx.open('记录详情','<p>正文</p>');assert.equal(oldResult.isConnected,false);
  f.ctx.goBackInSheet();
  assert.equal(f.document.activeElement,f.target('result'));assert.notEqual(f.document.activeElement,oldResult);
  assert.equal(f.sheet.content.scrollTop,217);assert.equal(f.ctx.lastEditorFocus,f.target('query'));
  assert.equal(f.focusLog.at(-1).options.preventScroll,true);
  f.ctx.changed=true;f.ctx.requestClose();assert.equal(f.ctx.confirmation.focusTarget,f.target('query'));
});
await test('Back restores a focused field selection and both field and sheet scroll positions',()=>{
  const f=navigationFocusFixture();f.opener.focus();f.ctx.open('编辑说明','<textarea data-focus-key="note"></textarea>');
  const field=f.target('note');field.focus();field.selectionStart=2;field.selectionEnd=7;field.selectionDirection='backward';field.scrollTop=31;field.scrollLeft=7;f.sheet.content.scrollTop=284;
  f.ctx.open('补充说明','<p>帮助</p>');f.ctx.goBackInSheet();const restored=f.target('note');
  assert.equal(f.document.activeElement,restored);assert.equal(f.ctx.lastEditorFocus,restored);
  assert.deepEqual([restored.selectionStart,restored.selectionEnd,restored.selectionDirection],[2,7,'backward']);
  assert.equal(restored.scrollTop,31);assert.equal(restored.scrollLeft,7);assert.equal(f.sheet.content.scrollTop,284);
});
await test('History falls back to its heading when the original target cannot be resolved',()=>{
  const f=navigationFocusFixture();f.ctx.open('原页','<button data-focus-key="result">结果</button>');f.target('result').focus();f.sheet.content.scrollTop=92;
  f.ctx.open('详情','');f.ctx.sheetHistory[0].focus.path=[99];f.ctx.goBackInSheet();
  assert.equal(f.document.activeElement,f.sheet.title);assert.equal(f.sheet.content.scrollTop,92);
});
await test('Closing returns to the original homepage trigger, with a live tab fallback',()=>{
  for(const state of ['connected','removed','disabled','hidden']){
    const f=navigationFocusFixture();f.opener.focus();f.ctx.open('设置','<button data-focus-key="child">组件</button>');f.target('child').focus();f.ctx.open('组件','');
    if(state==='removed')f.opener.isConnected=false;if(state==='disabled')f.opener.disabled=true;if(state==='hidden')f.opener.hidden=true;
    f.ctx.close();assert.equal(f.document.activeElement,state==='connected'?f.opener:f.tab,state);
    assert.equal(f.ctx.sheetOpener,null);assert.equal(f.ctx.sheetHistory.length,0);assert.equal(f.ctx.lastEditorFocus,null);
    assert.equal(f.focusLog.at(-1).options.preventScroll,true);
  }
});
await test('Choosing a weather region returns to the same sheet without a navigation loop',()=>{
  for (const picker of ['选择天气城市','预警地区']) {
    const f=navigationFocusFixture();
    f.ctx.open('设置','<p>设置</p>');
    f.ctx.open('今日天气','<p>当前城市</p>');
    f.ctx.open(picker,'<p>选择</p>');
    f.ctx.open('今日天气','<p>新城市</p>');
    assert.equal(f.ctx.sheetHistory.length,1);
    f.ctx.goBackInSheet();
    assert.equal(f.sheet.querySelector('#sheet-title').textContent,'设置');
  }
});
await test('The desktop weather shortcut uses the regular weather entry',async()=>{
  const actions=[];
  const ctx=context(['widgetAction'],{appReady:true,busy:false,uploadTask:null,hasDraftChanges:()=>false,close(){},weatherClick:data=>actions.push(data.weatherAction)});
  await ctx.widgetAction({type:'weather'});assert.deepEqual(actions,['open']);
});
await test('Tab switches preserve the recipe date and each page scroll position',()=>{
  const positions=[],window={scrollY:480,scrollTo:(...args)=>positions.push(args)};
  const ctx=context(['switchPage'],{page:'recipes',pageScroll:new Map(),recipeDate:'2027-01-16',window,render(){},getPreferences:()=>({reducedMotion:true})});
  ctx.switchPage('journal');window.scrollY=80;ctx.switchPage('recipes');
  assert.equal(ctx.recipeDate,'2027-01-16');assert.deepEqual(positions.at(-1),[0,480]);
  ctx.switchPage('recipes');assert.equal(positions.at(-1)[0].top,0);
});
await test('Widget shortcut waits for the current draft write before changing forms',async()=>{
  let release;const pending=new Promise(resolve=>release=resolve);let closed=0,opened=0;
  const ctx=context(['widgetAction'],{appReady:true,busy:false,uploadTask:null,hasDraftChanges:()=>true,durableForm:()=>({}),flushDurableDraft:()=>pending,announce(){},close(){closed++;},today:()=> '2026-11-17',editEntry(){opened++;},editLedger(){},chosen:'2026-11-17'});
  const action=ctx.widgetAction({type:'entry'});assert.equal(closed,0,'navigation cannot discard the live form while persistence is pending');release(true);await action;assert.equal(opened,1);
});
await test('Widget shortcut keeps the current form when its draft cannot be written',async()=>{
  let closed=0;
  const ctx=context(['widgetAction'],{appReady:true,busy:false,uploadTask:null,hasDraftChanges:()=>true,durableForm:()=>({}),flushDurableDraft:()=>Promise.resolve(false),announce(){},close(){closed++;},today:()=> '2026-11-17',editEntry(){},editLedger(){},chosen:'2026-11-17'});
  await ctx.widgetAction({type:'entry'});
  assert.equal(closed,0,'a failed write must leave the editable form available');
});
function draftQueueContext(){
  let release;const blocked=new Promise(resolve=>release=resolve),saved=[],removed=[];
  const ctx=context(['flushDurableDraft','clearCurrentDraft'],{clearTimeout(){},draftTimer:null,restoringDraft:false,hasDraftChanges:()=>true,durableForm:()=>({dataset:{draftKey:'draft-a'}}),durableKey:form=>form?.dataset.draftKey||'draft-a',captureDurableDraft:()=>({photos:['media/a.jpg']}),draftGenerations:new Map(),draftQueue:blocked,initialDraft:{},saveDraft:async(key,draft)=>saved.push({key,draft}),clearDraft:async key=>removed.push(key),announce(){}});
  return {ctx,release,saved,removed};
}
await test('Saving another form does not cancel a queued draft for an earlier form',async()=>{
  const run=draftQueueContext(),save=run.ctx.flushDurableDraft(),clear=run.ctx.clearCurrentDraft({dataset:{draftKey:'draft-b'}});
  run.release();await Promise.all([save,clear]);assert.deepEqual(run.saved.map(x=>x.key),['draft-a']);assert.deepEqual(run.removed,['draft-b']);
});
await test('A queued autosave cannot resurrect a draft after that form is saved or discarded',async()=>{
  const run=draftQueueContext(),save=run.ctx.flushDurableDraft(),clear=run.ctx.clearCurrentDraft({dataset:{draftKey:'draft-a'}});
  run.release();await Promise.all([save,clear]);assert.equal(run.saved.length,0);assert.deepEqual(run.removed,['draft-a']);
});
await test('Failed draft cleanup preserves the unsaved-change baseline',async()=>{
  const run=draftQueueContext(),baseline=run.ctx.initialDraft;run.ctx.clearDraft=async()=>{throw new Error('disk full');};
  const clear=run.ctx.clearCurrentDraft({dataset:{draftKey:'draft-a'}});run.release();await assert.rejects(clear,/disk full/);
  assert.equal(run.ctx.initialDraft,baseline,'the live editor must remain protected after cleanup fails');
});
function widgetContext({cards=[],entries=[],pinned='',widgetTheme='cream',moodHistory=[]}={}){
  let snapshot;
  const ctx=context(['syncWidgets'],{appReady:true,window:{BearApp:{updateWidgets(text){snapshot=JSON.parse(text);return '{"ok":true}';}}},dateCards:()=>cards,getPreferences:()=>({pinnedCountdownId:pinned,widgetTheme}),entryById:id=>entries.find(x=>x.id===id),today:()=> '2026-11-17',dateKey,fromKey,entries,moodHistory,moods,lunarLabel,seasonalContext,onDate,nextOccurrence,recurrenceFor,nextScheduledDate,paydayRule:()=>({type:'last-workday',workMode:'official'}),dateSettings:{paydayEnabled:true},holidays:[],announce(){}});
  return {ctx,get snapshot(){return snapshot;}};
}
await test('Widget receives the chosen light palette, day metadata and current mood only',()=>{
  const run=widgetContext({widgetTheme:'mint',moodHistory:[{date:'2026-11-17',mood:'happy',note:'private mood note'}],entries:[{id:'life',kind:'life',title:'一杯热可可',date:'2026-11-17'}]});
  assert.equal(run.ctx.syncWidgets(),true);assert.equal(run.snapshot.widgetTheme,'mint');
  const first=run.snapshot.days[0],tomorrow=run.snapshot.days[1],nextTerm=run.snapshot.days.find(day=>day.date==='2026-11-22');
  assert.equal(first.lunarLabel,'十月初九');assert.equal(first.seasonLabel,'立冬时节');assert.equal(first.recordCount,1);
  assert.equal(first.moodLabel,moods.happy.name);assert.equal(tomorrow.moodLabel,'');assert.equal(nextTerm.seasonLabel,'小雪');
  assert(!JSON.stringify(run.snapshot).includes('private mood note'),'mood text must not leak beyond its display label');
});
await test('Older preferences default to a cream widget even when the app uses night mode',()=>{
  const run=widgetContext();run.ctx.getPreferences=()=>({theme:'night'});
  assert.equal(run.ctx.syncWidgets(),true);assert.equal(run.snapshot.widgetTheme,'cream');
});
await test('Pinned payday has upcoming occurrences after this month ends',()=>{
  const run=widgetContext({cards:[{id:'auto-payday',kind:'payday',title:'发薪日',date:'2026-11-30'}],pinned:'auto-payday'});run.ctx.syncWidgets();
  assert(run.snapshot?.countdowns.some(x=>x.title==='发薪日'&&x.date==='2026-12-31'),'widget must retain next payday without reopening the app');
});
await test('Automatic countdown chooses the nearest day across payday and other events',()=>{
  const run=widgetContext({cards:[{id:'current-holiday',kind:'holiday',title:'正在过的假期',date:'2026-11-16'},{id:'auto-pay-2026-11',kind:'payday',title:'发薪日',date:'2026-11-30'},{id:'tomorrow',kind:'entry',title:'明天纪念日',date:'2026-11-18'}]});run.ctx.syncWidgets();
  assert.equal(run.snapshot.countdown.title,'明天纪念日');assert(run.snapshot.countdowns.some(x=>x.title==='发薪日'&&x.date==='2026-12-31'));
});
await test('Legacy monthly payday pin keeps selecting payday after the month changes',()=>{
  const run=widgetContext({cards:[{id:'other',kind:'entry',title:'明天活动',date:'2026-11-18'},{id:'auto-pay-2026-11',kind:'payday',title:'发薪日',date:'2026-11-30'}],pinned:'auto-pay-2026-10'});run.ctx.syncWidgets();
  assert.equal(run.snapshot.countdown.title,'发薪日');assert.equal(run.snapshot.countdowns.length,12);assert(run.snapshot.countdowns.every(x=>x.title==='发薪日'));
});
await test('Pinned repeating entry retains twelve future occurrences',()=>{
  const entry={id:'anniversary',kind:'anniversary',title:'我们的纪念日',date:'2020-11-18',recurrence:{type:'yearly'}};
  const run=widgetContext({cards:[{id:entry.id,kind:'entry',title:entry.title,date:'2026-11-18'}],entries:[entry],pinned:entry.id});run.ctx.syncWidgets();
  assert.equal(run.snapshot.countdowns.length,12);assert.equal(run.snapshot.countdowns[11].date,'2037-11-18');
});
await test('Automatic countdown candidates are sorted and capped at sixty-four',()=>{
  const cards=Array.from({length:90},(_,i)=>{const date=fromKey('2026-11-17');date.setDate(date.getDate()+90-i);return {id:'event-'+i,kind:'entry',title:'活动 '+i,date:dateKey(date)};});
  const run=widgetContext({cards});run.ctx.syncWidgets();assert.equal(run.snapshot.countdowns.length,64);assert.equal(run.snapshot.countdown.date,'2026-11-18');
  assert(run.snapshot.countdowns.every((x,i,rows)=>!i||rows[i-1].date<=x.date));
});
await test('Widget payload is bounded before crossing the native bridge',()=>{
  const entries=Array.from({length:2500},(_,i)=>({id:'entry-'+i,title:'这是一条有正常长度的生活记录，记录今天值得留住的时刻。'.repeat(2),date:'2026-11-17',kind:'life',photos:[],note:'私人正文不应出现在组件'}));
  const run=widgetContext({entries});run.ctx.syncWidgets();
  assert(run.snapshot,'a display snapshot should be sent');assert(JSON.stringify(run.snapshot).length<=200000,'native rejects snapshots over 200000 characters');
  assert(run.snapshot.days.every(day=>day.items.length<=20),'each day needs a bounded display list');
});
await test('Escaped imported strings cannot exceed the native payload limit',()=>{
  const entries=Array.from({length:800},(_,i)=>{const date=fromKey('2026-11-17');date.setDate(date.getDate()+Math.floor(i/20));return {id:'"'.repeat(95)+i,title:'"'.repeat(60),time:'"'.repeat(8),date:dateKey(date),kind:'life'};});
  const run=widgetContext({entries});assert.equal(run.ctx.syncWidgets(),true);assert(JSON.stringify(run.snapshot).length<=190000);
});
await test('Native widget update rejection is returned to callers',()=>{
  const run=widgetContext();run.ctx.window.BearApp.updateWidgets=()=>'{"ok":false,"message":"not stored"}';assert.equal(run.ctx.syncWidgets(),false);
});
await test('Widget snapshot hides unopened capsule content and all record photos/notes',()=>{
  const run=widgetContext({entries:[{id:'secret',title:'我的私密信封标题',note:'不能外泄的正文',photos:['data:image/png;base64,secret'],kind:'capsule',date:'2026-11-17',time:'23:59'}]});run.ctx.syncWidgets();
  const text=JSON.stringify(run.snapshot);assert(!text.includes('私密信封')&&!text.includes('不能外泄')&&!text.includes('base64'));
});
if(failures.length){console.error(`Failed ${failures.length} integration regressions (${passed} passed):\n${failures.map(x=>' - '+x).join('\n')}`);process.exitCode=1;}
else console.log(`Passed ${passed} integration regressions: durable editing, navigation failure safety, payday rollover, widget size and privacy.`);
