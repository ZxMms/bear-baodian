import assert from 'node:assert/strict';
import {areaForPlace, placeScopeKey, classifyAlert, buildAlertView} from '../web/weather-alert-scope.js';

// Execute the production matcher against ambiguous publication areas; no network or browser.
const province='陕西省', now=Date.parse('2026-11-18T06:00:00Z');
const located={source:'location',countryCode:'CN',admin1:province,name:'长安附近',alertArea:{source:'geocoder',province,city:'西安市',district:'长安区',districtUnique:true}};
const area=areaForPlace(located,province);
const cityArea=areaForPlace({...located,alertArea:{...located.alertArea,district:''}},province);
const row=(title,extra={})=>({id:title,title,issuedAt:now,url:'https://www.nmc.cn/publish/alarm/61010041600000_20261118120000.html',level:'blue',...extra});
const release=(region,extra={})=>row(`${province}${region}气象台发布大风蓝色预警信号`,extra);
let passed=0;const failures=[];
function test(name,run){try{run();passed++;}catch(error){failures.push(`${name}: ${error.stack}`);}}

test('Beijing offline district match limits local releases to Fengtai and the municipality',()=>{
  const place={source:'location',countryCode:'CN',admin1:'北京市',alertArea:{source:'district-boundary',province:'北京市',city:'北京市',district:'丰台区',districtUnique:true}};
  const area=areaForPlace(place,'北京市');assert.equal(area.district,'丰台区');
  assert.equal(classifyAlert(row('北京市丰台区气象台发布大风蓝色预警信号'),area),'local');
  assert.notEqual(classifyAlert(row('北京市昌平区气象台发布大风蓝色预警信号'),area),'local');
});
test('Verified location metadata identifies city and district without using the display name',()=>{
  assert.equal(area.province,province);assert.equal(area.city,'西安市');assert.equal(area.district,'长安区');assert.equal(area.mode,'district');assert.equal(area.label,'长安区');
  assert.equal(areaForPlace({...located,name:'北京附近'},province).label,'长安区');
});
test('Coordinates and an old nearby weather-station label do not invent a local warning area',()=>{
  for(const place of [null,{...located,alertArea:undefined},{...located,alertArea:{...located.alertArea,source:'guess'}},{...located,alertArea:{...located.alertArea,province:'山西省'}},{...located,countryCode:'US'}])assert.equal(areaForPlace(place,province),null);
});
test('Untrusted or incomplete locality strings cannot become markup or a precise district',()=>{
  assert.equal(areaForPlace({...located,alertArea:{...located.alertArea,city:'<svg>',district:'<img>'}},province),null);
  const coarse=areaForPlace({...located,alertArea:{...located.alertArea,district:''}},province);
  assert.equal(coarse.mode,'city');assert.equal(coarse.district,'');
});
test('Explicitly selected cities have a named scope without a guessed parent municipality',()=>{
  const selected=areaForPlace({source:'city',countryCode:'CN',name:'蓝田',admin1:province},province);
  assert.equal(selected.selected,'蓝田');assert.equal(selected.city,'');assert.equal(selected.district,'');
  assert.equal(classifyAlert(release('蓝田县'),selected),'local');
});
test('Scope identity changes on a same-province city or district move',()=>{
  const key=placeScopeKey(located,province);
  assert.notEqual(key,placeScopeKey({...located,alertArea:{...located.alertArea,district:'雁塔区'}},province));
  assert.notEqual(key,placeScopeKey({...located,alertArea:{...located.alertArea,city:'宝鸡市',district:''}},province));
  assert.equal(key,placeScopeKey({...located,latitude:34.1234,longitude:108.1234},province));
});
test('District scope includes its own publisher and its parent city publication',()=>{
  for(const region of ['长安区','西安市长安区','西安市'])assert.equal(classifyAlert(release(region),area),'local',region);
});
test('District scope excludes sibling districts and a different named parent city',()=>{
  for(const region of ['西安市雁塔区','雁塔区','咸阳市','咸阳市长安区'])assert.equal(classifyAlert(release(region),area),'other',region);
});
test('Province-wide publications remain separately available instead of being called local',()=>{
  assert.equal(classifyAlert(release(''),area),'parent');
  assert.equal(classifyAlert(release(''),cityArea),'parent');
});
test('An approximate city scope includes explicitly named subordinate districts',()=>{
  for(const region of ['西安市','西安市长安区','西安市雁塔区'])assert.equal(classifyAlert(release(region),cityArea),'local',region);
});
test('An isolated county name does not imply an unverified parent city',()=>{
  assert.equal(classifyAlert(release('蓝田县'),cityArea),'unknown');
  assert.equal(classifyAlert(release('长安区'),cityArea),'unknown');
  assert.notEqual(classifyAlert(release('西安新区'),cityArea),'local');
});
test('Nearby or similarly named cities cannot match through arbitrary substrings',()=>{
  assert.notEqual(classifyAlert(release('西安市新区以外'),area),'local');
  assert.notEqual(classifyAlert(release('西安新区'),area),'local');
  assert.notEqual(classifyAlert(release('宝鸡市'),cityArea),'local');
});
test('Different provinces and titles with no recognizable publisher stay unconfirmed',()=>{
  for(const value of [row('山西省西安市气象台发布大风蓝色预警'),row('陕西省提醒西安市关注天气'),row('西安市气象台发布大风蓝色预警'),{},null])assert.equal(classifyAlert(value,area),'unknown');
});
test('Location mentioned in alert text does not substitute for its publication area',()=>{
  assert.equal(classifyAlert(row('陕西省宝鸡市气象台发布大风蓝色预警，西安市请留意'),area),'other');
  assert.equal(classifyAlert(row('陕西省气象台发布西安市大风蓝色预警'),area),'parent');
});
test('Changes and cancellations keep their exact official publications available',()=>{
  for(const verb of ['更新','解除','变更','继续发布'])assert.equal(classifyAlert(row(`陕西省西安市气象台${verb}大风黄色预警`),area),'local');
});
test('Official prefecture names are matched as a complete region',()=>{
  const p='贵州省',a=areaForPlace({...located,admin1:p,alertArea:{source:'geocoder',province:p,city:'黔南布依族苗族自治州',district:'瓮安县'}},p);
  assert.equal(classifyAlert(row('贵州省黔南布依族苗族自治州瓮安县气象台发布大风蓝色预警'),a),'local');
  assert.equal(classifyAlert(row('贵州省黔东南苗族侗族自治州瓮安县气象台发布大风蓝色预警'),a),'other');
});
test('Municipality-wide publications remain relevant to a verified municipality district',()=>{
  const p='北京市',a=areaForPlace({...located,admin1:p,alertArea:{source:'geocoder',province:p,city:'北京市',district:'朝阳区'}},p);
  assert.equal(classifyAlert(row('北京市气象台发布大风蓝色预警'),a),'local');
  assert.equal(classifyAlert(row('北京市朝阳区气象台发布大风蓝色预警'),a),'local');
  assert.equal(classifyAlert(row('北京市海淀区气象台发布大风蓝色预警'),a),'other');
});
test('No known area never labels any province feed item as local',()=>{
  const rows=[release(''),release('西安市'),release('长安区')];
  const groups=buildAlertView(rows,null);assert.equal(groups.local.length,0);assert.equal(groups.unknown.length,3);
});
test('Every distinct official publication survives grouping with its original link',()=>{
  const rows=[release('西安市',{id:'city',url:'city-url'}),release('长安区',{id:'district',url:'district-url'}),release('',{id:'province'}),release('雁塔区',{id:'sibling'}),row('不明发布',{id:'unknown'})];
  const groups=buildAlertView(rows,area);assert.equal(Object.values(groups).flat().length,5);
  assert.equal(groups.local.length,2);assert.equal(groups.parent.length,1);assert.equal(groups.other.length,1);assert.equal(groups.unknown.length,1);
  assert.ok(groups.local.some(item=>item.url==='district-url'));assert.ok(groups.local.some(item=>item.url==='city-url'));
});
test('Severity takes priority, then newer issue time, without mutating the supplied array',()=>{
  const rows=[release('西安市',{id:'blue',level:'blue',issuedAt:now}),release('西安市',{id:'old-red',level:'red',issuedAt:now-120000}),release('长安区',{id:'new-red',level:'red',issuedAt:now-60000}),release('西安市',{id:'orange',level:'orange',issuedAt:now})];
  const before=rows.map(item=>item.id);assert.deepEqual(buildAlertView(rows,area).local.map(item=>item.id),['new-red','old-red','orange','blue']);assert.deepEqual(rows.map(item=>item.id),before);
});
test('Duplicate IDs are removed without combining distinct districts or source documents',()=>{
  const a=release('西安市',{id:'same'}),b=release('长安区',{id:'second'});const groups=buildAlertView([a,a,b],area);
  assert.equal(groups.local.length,2);assert.deepEqual(groups.local.map(item=>item.id).sort(),['same','second']);
});
test('Unexpected levels and prototype names cannot outrank genuine severity',()=>{
  const rows=['constructor','toString','__proto__','unknown','<img>'].map((level,i)=>release('西安市',{id:String(i),level}));rows.push(release('长安区',{id:'blue',level:'blue'}));
  assert.equal(buildAlertView(rows,area).local[0].id,'blue');
});
test('A repeated bare district name is not assumed to be the same county without a verified parent',()=>{
  const ambiguous=areaForPlace({...located,alertArea:{...located.alertArea,districtUnique:false}},province);
  assert.equal(classifyAlert(release('长安区'),ambiguous),'unknown');
  assert.equal(classifyAlert(release('西安市长安区'),ambiguous),'local');
  assert.equal(classifyAlert(release('咸阳市长安区'),ambiguous),'other');
});
test('An explicitly ambiguous same-province station name cannot create a local area',()=>{
  assert.equal(areaForPlace({source:'city',countryCode:'CN',admin1:'江苏省',name:'淮安',alertNameAmbiguous:true},'江苏省'),null);
});
test('Missing or malformed collections produce bounded empty groups',()=>{
  for(const rows of [null,undefined,{},'invalid',[null,undefined,42,'text']])assert.equal(Object.values(buildAlertView(rows,area)).flat().length,0);
});

if(failures.length){console.error(failures.join('\n\n'));process.exitCode=1;}
console.log(`Weather alert scope checks passed: ${passed}; failed: ${failures.length}`);
