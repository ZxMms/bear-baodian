import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';

// Exercise the real kitchen/model modules. Only platform boundaries are controlled:
// the native bridge, SQLite request transport, clock and the small DOM surface used here.
const saved=new Map(),nativeTimers=new Map(),nativeCalls=[],announcements=[],listeners={};
const clone=value=>value===undefined?undefined:structuredClone(value);
const TEST_ID='__bear_ring_test__';
let now=Date.parse('2026-11-17T12:00:00Z'),tick,html='',openCount=0,testAllowed=true,cancelTestAllowed=true,stopAllowed=true,statusThrows=false,healthThrows=false;
let health={ok:true,notifications:true,channelSound:true,soundEnabled:true,soundKind:'builtin',soundName:'加加加短铃声',alarmVolume:6,alarmMaxVolume:15,mediaVolume:8,interruptionFilter:1,exact:true,message:'可以试响；音量和通知已开启。'};
const controls={
  preview:{textContent:'',attributes:{},setAttribute(key,value){this.attributes[key]=value;}},
  test:{textContent:''},health:{innerHTML:'',hidden:false},name:{textContent:''},note:{textContent:''},
  counter:{textContent:'',classList:{toggle(){}}},stop:{hidden:true,disabled:false,textContent:''},
  clear:{textContent:''},message:{textContent:''},panel:{scrollTop:0},details:{open:true},
};
Date.now=()=>now;
globalThis.setInterval=callback=>{tick=callback;return 1;};
globalThis.clearInterval=()=>{};
globalThis.document={visibilityState:'visible',activeElement:null,addEventListener(type,callback){listeners[type]=callback;}};
Object.defineProperty(globalThis,'navigator',{value:{},configurable:true});
globalThis.FormData=class {constructor(form){this.values=form.values;}get(key){return this.values[key]??null;}};
const audio=[];
globalThis.Audio=class {constructor(src){this.src=src;this.paused=true;this.events={};audio.push(this);}addEventListener(type,callback){this.events[type]=callback;}play(){this.paused=false;return Promise.resolve();}pause(){this.paused=true;}};
globalThis.window={
  BearStore:{request(id,input){
    const request=JSON.parse(input);let value;
    if(request.op==='status')value={ready:true};
    else if(request.op==='get')value={value:clone(saved.get(request.key))};
    else if(request.op==='put'){saved.set(request.key,clone(request.value));value={value:clone(request.value)};}
    else throw new Error('Unexpected storage operation: '+request.op);
    queueMicrotask(()=>window.bearStoreResult(id,{ok:true,value}));
  }},
  BearApp:{
    startCookingTimer(id,label,seconds){
      nativeCalls.push({kind:'start',id,label,seconds});
      const timer={known:true,active:true,finished:false,endAt:now+seconds*1000+250,scheduled:true,exact:true,deliveryStatus:'pending'};
      nativeTimers.set(id,timer);return JSON.stringify({ok:true,...health,...timer});
    },
    cookingTimerStatus(id){
      nativeCalls.push({kind:'status',id});if(statusThrows)throw new Error('Bridge unavailable');
      const timer=nativeTimers.get(id);
      if(timer?.active&&timer.endAt<=now){timer.active=false;timer.finished=true;timer.deliveryStatus='posted';}
      return JSON.stringify({...health,...(timer||{known:false,active:false})});
    },
    cookingRingingStatus(){nativeCalls.push({kind:'health'});if(healthThrows)throw new Error('Health bridge unavailable');return JSON.stringify(health);},
    chooseCookingRingtone(){nativeCalls.push({kind:'choose'});},
    testCookingRinging(){
      nativeCalls.push({kind:'test',id:TEST_ID});
      if(!testAllowed)return JSON.stringify({ok:false,message:'测试通知暂未安排'});
      const timer={known:true,active:true,finished:false,endAt:now+5000,scheduled:true,deliveryStatus:'pending'};
      nativeTimers.set(TEST_ID,timer);return JSON.stringify({ok:true,...health,...timer});
    },
    cancelCookingRingingTest(){nativeCalls.push({kind:'cancel-test',id:TEST_ID});if(!cancelTestAllowed)return false;nativeTimers.delete(TEST_ID);return true;},
    stopCookingTimerRinging(id){nativeCalls.push({kind:'stop',id});return stopAllowed;},
    cancelCookingTimer(id){nativeCalls.push({kind:'cancel',id});nativeTimers.delete(id);return true;},
    cookingNotificationSettings(){nativeCalls.push({kind:'settings'});},
  },
};
const selectors={
  '.sheet-content':'panel','.kitchen-ingredients':'details',
  '[data-kitchen-action="timer-preview"]':'preview','[data-kitchen-action="timer-ring-test"]':'test',
  '[data-kitchen-ring-health]':'health','[data-kitchen-clock]':'counter','[data-kitchen-ring-stop]':'stop',
  '[data-kitchen-ring-name]':'name','[data-kitchen-ring-note]':'note',
  '[data-kitchen-timer-clear]':'clear','[data-kitchen-timer-message]':'message',
};
const sheet={open:false,dataset:{},addEventListener(type,callback){listeners['sheet-'+type]=callback;},querySelector(selector){return controls[selectors[selector]]||null;}};
const recipe={id:'soup-1',title:'番茄汤',category:'汤羹',ingredients:'番茄 2 个',steps:'1. 小火煮开'};
const moduleUrl=new URL('../web/kitchen.js',import.meta.url);
const moduleSource=await readFile(moduleUrl,'utf8');
const modelPath=moduleSource.match(/from ['"]([^'"]*model\.js[^'"]*)['"]/)[1];
await (await import(new URL(modelPath,moduleUrl))).openStore();
const kitchen=await import(moduleUrl);
const ui={sheet,open(title,markup){openCount++;html=markup;sheet.open=true;},announce:message=>announcements.push(message),getRecipes:()=>[recipe],getEntries:()=>[],recordMeal(){}};
await kitchen.initKitchen(ui);
const flush=()=>new Promise(resolve=>setImmediate(resolve));
const timer=()=>saved.get('kitchen-sessions')[recipe.id].timer;
const dueAnnouncements=()=>announcements.filter(message=>message.includes('的计时到了')).length;
const click=action=>kitchen.kitchenClicked({kitchenAction:action});
const start=async(minutes=1)=>{await kitchen.kitchenSubmitted({dataset:{form:'kitchen-timer'},values:{minutes:String(minutes)}});await flush();};
const step=async(milliseconds=0)=>{now+=milliseconds;tick();await flush();};

await kitchen.openCooking(recipe,'2026-11-17');
assert.match(html,/5 秒试响/);assert.match(controls.health.innerHTML,/闹钟音量 6 \/ 15/);
await start();
assert.equal(timer().endAt,nativeTimers.get(recipe.id).endAt,'native end time is retained when starting');
const initialEnd=timer().endAt;
nativeTimers.get(recipe.id).endAt=initialEnd+9000;
now=initialEnd;
const beforeDue=dueAnnouncements(),beforeStatus=nativeCalls.length;
await step();
assert.ok(nativeCalls.slice(beforeStatus).some(call=>call.kind==='status'&&call.id===recipe.id),'foreground expiry asks native status to deliver a due timer');
assert.equal(timer().endAt,initialEnd+9000,'native monotonic clock can correct an early web expiry');
assert.equal(timer().notified,false);assert.equal(dueAnnouncements(),beforeDue,'a corrected future timer is not announced early');
now=timer().endAt;await step();
assert.equal(timer().notified,true);assert.equal(timer().deliveryStatus,'posted');assert.equal(dueAnnouncements(),beforeDue+1);
await step();await step();assert.equal(dueAnnouncements(),beforeDue+1,'expiry announcement occurs once');
assert.equal(controls.stop.hidden,false);assert.match(controls.message.textContent,/已请求系统提醒/);
const completedEnd=timer().endAt;
stopAllowed=false;await assert.rejects(click('timer-ring-stop'),/暂时没能停止/);
assert.equal(timer().ringStopped,false);assert.equal(controls.stop.disabled,false,'failed stop keeps its retry affordance');
stopAllowed=true;await click('timer-ring-stop');
assert.equal(timer().ringStopped,true);assert.equal(timer().endAt,completedEnd,'stopping sound preserves completed cooking timer');

// A real cooking timer and a test alarm coexist, including failures and cancellation.
await start(3);const realTimer=clone(timer()),realNative=clone(nativeTimers.get(recipe.id));
testAllowed=false;await assert.rejects(click('timer-ring-test'),/测试通知暂未安排/);
assert.equal(controls.test.textContent,'5 秒试响');assert.deepEqual(timer(),realTimer);
testAllowed=true;await click('timer-preview');assert.equal(audio.at(-1).paused,false);
await click('timer-ring-test');
assert.equal(audio.at(-1).paused,true,'test alarm stops media preview to avoid mixed audio');
assert.match(controls.test.textContent,/取消试响.*5 秒/);
assert.ok(nativeTimers.has(TEST_ID));assert.deepEqual(nativeTimers.get(recipe.id),realNative);
assert.deepEqual(timer(),realTimer,'test start never overwrites the saved cooking timer');
cancelTestAllowed=false;await assert.rejects(click('timer-ring-test'),/试响暂未停止/);
assert.match(controls.test.textContent,/取消试响/);assert.ok(nativeTimers.has(TEST_ID),'failed test cancellation keeps its UI and pending test');
cancelTestAllowed=true;await click('timer-ring-test');
assert.equal(controls.test.textContent,'5 秒试响');assert.equal(nativeTimers.has(TEST_ID),false);assert.deepEqual(timer(),realTimer);
await click('timer-ring-test');const beforeTestDue=nativeCalls.length;
await step(5000);
assert.ok(nativeCalls.slice(beforeTestDue).some(call=>call.kind==='status'&&call.id===TEST_ID),'test expiry reconciles the reserved native timer');
assert.equal(controls.test.textContent,'停止试响');assert.equal(timer().notified,false);assert.deepEqual(nativeTimers.get(recipe.id),realNative);
await click('timer-ring-test');assert.equal(controls.test.textContent,'5 秒试响');assert.deepEqual(timer(),realTimer);

// A test notification can fail independently; expose the retry/failure, retaining stop.
await click('timer-ring-test');
Object.assign(nativeTimers.get(TEST_ID),{active:false,finished:true,deliveryStatus:'retrying',deliveryError:'系统通知服务暂时不可用'});
await step(5000);assert.match(controls.health.innerHTML,/试响通知暂未发出，正在重试/);
const beforeRetry=nativeCalls.length;
nativeTimers.get(TEST_ID).deliveryStatus='failed';nativeTimers.get(TEST_ID).deliveryError='试响失败 <img src=x onerror="bad()">';
await step(5000);
assert.ok(nativeCalls.slice(beforeRetry).some(call=>call.kind==='status'&&call.id===TEST_ID),'pending test delivery is polled again after backoff');
assert.match(controls.health.innerHTML,/试响失败 &lt;img/);assert.doesNotMatch(controls.health.innerHTML,/<img/);
assert.equal(controls.test.textContent,'停止试响');assert.deepEqual(timer(),realTimer);
const cancelTest=window.BearApp.cancelCookingRingingTest;delete window.BearApp.cancelCookingRingingTest;
await assert.rejects(click('timer-ring-test'),/试响暂未停止/);
assert.equal(controls.test.textContent,'停止试响','a missing cancellation bridge never reports success');
window.BearApp.cancelCookingRingingTest=cancelTest;await click('timer-ring-test');
assert.equal(controls.test.textContent,'5 秒试响');assert.deepEqual(timer(),realTimer);

// Returning from system settings refreshes the clock and current diagnostics.
nativeTimers.get(recipe.id).endAt=now+70000;
health={...health,notifications:false,soundEnabled:false,alarmVolume:0,interruptionFilter:3,message:'通知未开启，请打开通知设置。'};
document.visibilityState='hidden';listeners.visibilitychange();
document.visibilityState='visible';listeners.visibilitychange();await flush();
assert.equal(timer().endAt,now+70000);assert.equal(timer().notifications,false);assert.equal(timer().alarmVolume,0);
assert.match(controls.health.innerHTML,/通知未开启/);assert.match(controls.health.innerHTML,/闹钟音量 0 \/ 15/);assert.match(controls.health.innerHTML,/勿扰：禁止打扰/);
now=timer().endAt;await step();assert.match(controls.message.textContent,/通知未开启/);
health={...health,notifications:true,soundEnabled:true,channelSound:true,interruptionFilter:1,message:'系统闹钟音量为 0。'};
await click('timer-ring-check');assert.match(controls.message.textContent,/闹钟音量为 0/);
health={...health,alarmVolume:6,interruptionFilter:3,message:'勿扰模式可能阻止响铃。'};
await click('timer-ring-check');assert.match(controls.message.textContent,/勿扰模式可能阻止响铃/);
health={...health,interruptionFilter:4,message:'当前勿扰允许闹钟。'};
await click('timer-ring-check');assert.match(controls.health.innerHTML,/勿扰：允许闹钟/);assert.doesNotMatch(controls.message.textContent,/阻止响铃/);
health={...health,channelSound:false,soundEnabled:false,interruptionFilter:1,message:'计时通知为静音。'};
await click('timer-ring-check');assert.match(controls.message.textContent,/计时通知设为静音/);assert.match(controls.health.innerHTML,/计时通知为静音/);
health={...health,alarmVolume:-1,alarmMaxVolume:-1,mediaVolume:-1};
await click('timer-ring-check');assert.doesNotMatch(controls.health.innerHTML,/闹钟音量 -1|试听媒体音量 -1/,'unknown system volume is not shown as a real negative volume');

// Bridge strings are untrusted display text, including diagnostics and delivery errors.
const untrusted='<img src=x onerror="alert(1)"> & <script>bad()</script>';
health={...health,channelSound:true,soundEnabled:true,message:untrusted};
nativeTimers.get(recipe.id).deliveryStatus='failed';nativeTimers.get(recipe.id).deliveryError=untrusted;
await click('timer-ring-check');
assert.doesNotMatch(controls.health.innerHTML,/<img|<script/);assert.match(controls.health.innerHTML,/&lt;img/);assert.match(controls.health.innerHTML,/&amp;/);
assert.doesNotMatch(html,/<img src=x|<script>bad/);assert.match(html,/&lt;script&gt;bad/);
assert.ok(controls.message.textContent.includes(untrusted),'incremental updates use textContent, never HTML');
assert.equal(timer().deliveryStatus,'failed');assert.match(controls.message.textContent,/可点「检查响铃」查看/);

// A bridge exception never becomes a claim that the alarm successfully rang.
health={...health,message:'可以试响。'};await start();now=timer().endAt;statusThrows=true;
await step();assert.equal(timer().deliveryStatus,'unconfirmed');assert.match(controls.message.textContent,/未能确认系统提醒/);
const countAfterFailure=dueAnnouncements();await step();assert.equal(dueAnnouncements(),countAfterFailure);
statusThrows=false;await click('timer-ring-check');assert.equal(timer().deliveryStatus,'posted');
nativeTimers.get(recipe.id).deliveryStatus='retrying';await click('timer-ring-check');
assert.match(controls.message.textContent,/正在重试/);const beforeRealRetry=nativeCalls.length;
nativeTimers.get(recipe.id).deliveryStatus='posted';await step(5000);
assert.ok(nativeCalls.slice(beforeRealRetry).some(call=>call.kind==='status'&&call.id===recipe.id),'real delivery retries continue after the one-time UI announcement');
assert.equal(timer().deliveryStatus,'posted');assert.equal(dueAnnouncements(),countAfterFailure);
nativeTimers.get(recipe.id).deliveryStatus='expired';await click('timer-ring-check');assert.match(controls.message.textContent,/不再补响/);
nativeTimers.get(recipe.id).deliveryStatus='blocked';await click('timer-ring-check');assert.match(controls.message.textContent,/提醒触发时通知未开启/);
await click('timer-ring-settings');assert.equal(nativeCalls.at(-1).kind,'settings');

// Choosing a phone ringtone is a void native navigation call, not an audio preview.
health={...health,soundKind:'builtin',soundName:'加加加短铃声',alarmVolume:6,alarmMaxVolume:15,mediaVolume:8,interruptionFilter:1,message:'可以试响。'};
await start(3);await click('timer-ring-test');
const beforeChooseTimer=clone(timer()),beforeChooseNative=clone(nativeTimers.get(recipe.id)),beforeChooseTest=clone(nativeTimers.get(TEST_ID));
controls.panel.scrollTop=342;controls.details.open=true;
const beforeChooseOpen=openCount;
await click('timer-preview');assert.equal(audio.at(-1).paused,false);
const chooseIndex=nativeCalls.length;
await click('timer-ring-choose');
assert.deepEqual(nativeCalls.slice(chooseIndex),[{kind:'choose'}],'new bridge takes precedence over channel-settings fallback and accepts void');
assert.equal(audio.at(-1).paused,true,'opening system ringtone settings stops media preview');
assert.equal(openCount,beforeChooseOpen);assert.equal(controls.panel.scrollTop,342);assert.equal(controls.details.open,true);
assert.deepEqual(timer(),beforeChooseTimer);assert.deepEqual(nativeTimers.get(TEST_ID),beforeChooseTest,'choosing sound keeps the pending test');
assert.match(controls.test.textContent,/取消试响/);

// Periodic health updates stop stale built-in preview without replacing the cooking page.
await click('timer-preview');const builtinAudio=audio.at(-1);
health={...health,soundKind:'system',soundName:'晨光'};
const audioBeforeSystem=audio.length;await step(5000);
assert.equal(builtinAudio.paused,true);assert.equal(controls.preview.hidden,true);
assert.equal(controls.preview.attributes['aria-pressed'],'false');assert.equal(controls.name.textContent,'晨光');
assert.match(controls.note.textContent,/所选铃声/);assert.doesNotMatch(controls.note.textContent,/内置短铃声试听/);
assert.equal(audio.length,audioBeforeSystem,'updating a phone ringtone never creates an Audio preview');
assert.equal(openCount,beforeChooseOpen);assert.equal(controls.panel.scrollTop,342);
assert.deepEqual(timer(),beforeChooseTimer);assert.deepEqual(nativeTimers.get(recipe.id),beforeChooseNative);
assert.equal(nativeTimers.get(TEST_ID).endAt,beforeChooseTest.endAt);assert.equal(controls.test.textContent,'停止试响');
await click('timer-preview');assert.equal(audio.length,audioBeforeSystem);assert.match(announcements.at(-1),/当前使用手机所选铃声.*5 秒试响/);

// Returning from settings refreshes the title and note in place, preserving timer/test state.
health={...health,soundName:'山间溪流'};
document.visibilityState='hidden';listeners.visibilitychange();document.visibilityState='visible';listeners.visibilitychange();await flush();
assert.equal(controls.name.textContent,'山间溪流');assert.equal(controls.preview.hidden,true);
assert.equal(openCount,beforeChooseOpen);assert.equal(controls.panel.scrollTop,342);assert.equal(controls.details.open,true);
assert.deepEqual(timer(),beforeChooseTimer);assert.equal(nativeTimers.get(TEST_ID).endAt,beforeChooseTest.endAt);
health={...health,soundKind:'builtin',soundName:'加加加短铃声'};
document.visibilityState='visible';listeners.visibilitychange();await flush();
assert.equal(controls.preview.hidden,false);assert.equal(controls.name.textContent,'加加加短铃声');assert.match(controls.note.textContent,/内置短铃声试听使用媒体音量/);
assert.equal(openCount,beforeChooseOpen);assert.equal(controls.test.textContent,'停止试响');
await click('timer-preview');assert.equal(audio.at(-1).paused,false);await click('timer-preview');

// Silent/unknown/unreadable choices must never offer the wrong built-in sound.
for(const [soundKind,soundName] of [['silent','静音'],['unknown','未能读取铃声'],['builtin','熊熊提醒音']]){
  health={...health,soundKind,soundName};document.visibilityState='visible';listeners.visibilitychange();await flush();
  assert.equal(controls.name.textContent,soundName);assert.equal(controls.preview.hidden,true);
  const count=audio.length;await click('timer-preview');assert.equal(audio.length,count,'silent, unknown and legacy WAV choices never play the unrelated MP3');
}
healthThrows=true;document.visibilityState='visible';listeners.visibilitychange();await flush();
assert.equal(controls.preview.hidden,true,'new native bridge with unreadable sound metadata must not assume built-in');
assert.equal(controls.name.textContent,'系统计时铃声');assert.match(controls.health.innerHTML,/暂时未能读取系统响铃状态/);
healthThrows=false;health={...health,soundKind:'system',soundName:'<img src=x onerror="bad()"> & "晨光"'};
document.visibilityState='visible';listeners.visibilitychange();await flush();
assert.equal(controls.name.textContent,health.soundName,'live ringtone titles are assigned as literal text');
await kitchen.openCooking(recipe,'2026-11-17');
assert.match(html,/&lt;img src=x onerror=&quot;bad\(\)&quot;&gt; &amp; &quot;晨光&quot;/);
assert.doesNotMatch(html,/<img src=x onerror=/,'initial ringtone title markup escapes native display text');
assert.deepEqual(timer(),beforeChooseTimer);assert.equal(nativeTimers.get(TEST_ID).endAt,beforeChooseTest.endAt);

// Old installed shells still open their existing channel settings; browsers show guidance.
const chooseRingtone=window.BearApp.chooseCookingRingtone;delete window.BearApp.chooseCookingRingtone;
const oldFallbackIndex=nativeCalls.length;await click('timer-ring-choose');
assert.deepEqual(nativeCalls.slice(oldFallbackIndex),[{kind:'settings'}]);assert.match(announcements.at(-1),/系统页面.*声音.*铃声/);
const legacyHealth={...health};delete legacyHealth.soundKind;delete legacyHealth.soundName;health=legacyHealth;
document.visibilityState='visible';listeners.visibilitychange();await flush();
assert.equal(controls.preview.hidden,false,'older bridge without sound metadata retains built-in preview compatibility');
window.BearApp.chooseCookingRingtone=chooseRingtone;
document.visibilityState='visible';listeners.visibilitychange();await flush();assert.equal(controls.preview.hidden,true,'new bridge without sound kind stays conservative');
await click('timer-ring-test');assert.equal(nativeTimers.has(TEST_ID),false);
const nativeApp=window.BearApp;delete window.BearApp;saved.delete('kitchen-sessions');
const browserUrl=new URL(moduleUrl);browserUrl.searchParams.set('integration','browser');
const browserKitchen=await import(browserUrl);await browserKitchen.initKitchen(ui);await browserKitchen.openCooking(recipe,'2026-11-17');
assert.doesNotMatch(html,/data-kitchen-action="timer-ring-choose"|data-kitchen-action="timer-ring-test"/);
assert.equal(controls.name.textContent,'加加加短铃声');assert.equal(controls.preview.hidden,false);assert.match(controls.note.textContent,/浏览器可试听铃声/);
await browserKitchen.kitchenClicked({kitchenAction:'timer-ring-choose'});assert.equal(announcements.at(-1),'请在安卓 App 内选择手机铃声');
window.BearApp=nativeApp;

console.log('Passed ringing integration: foreground reconciliation, independent test alarms, retry/failure/stop states, volume/DND diagnostics, phone ringtone selection/fallback, in-place name updates preserving scroll/timers/tests, correct preview availability, safe native display text, and browser guidance.');
