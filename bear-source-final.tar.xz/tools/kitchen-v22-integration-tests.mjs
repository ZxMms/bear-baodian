import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
const clone=value=>value===undefined?undefined:JSON.parse(JSON.stringify(value));
let html='',heading='',tick,failBatch=false,failPut=false,cancelAllowed=true,now=Date.parse('2026-11-18T03:00:00Z');
const saved=new Map(),native=new Map(),calls=[],records=[],announcements=[],events={};
Date.now=()=>now;
globalThis.setInterval=fn=>{tick=fn;return 1;};globalThis.clearInterval=()=>{};
globalThis.FormData=class{constructor(form){this.values=form.values||{};}get(key){return this.values[key]??null;}getAll(key){const v=this.values[key];return v===undefined?[]:Array.isArray(v)?v:[v];}};
const form=(kind,values,id='')=>({dataset:{form:kind,id},values});
const body={children:[],classes:new Set(),appendChild(node){this.children.push(node);},classList:{toggle(name,on){on?body.classes.add(name):body.classes.delete(name);}}};
globalThis.document={visibilityState:'visible',body,addEventListener(name,fn){events[name]=fn;},createElement(){return {dataset:{},hidden:true,events:{},attributes:{},addEventListener(name,fn){this.events[name]=fn;},setAttribute(name,value){this.attributes[name]=value;}};}};
Object.defineProperty(globalThis,'navigator',{value:{},configurable:true});
globalThis.window={BearStore:{request(id,input){const req=JSON.parse(input);let value;
  if(req.op==='status')value={ready:true};
  else if(req.op==='get')value={value:clone(saved.get(req.key))};
  else if(req.op==='put'){
    if(failPut){failPut=false;queueMicrotask(()=>window.bearStoreResult(id,{ok:false,error:'模拟保存失败'}));return;}
    saved.set(req.key,clone(req.value));value={value:clone(req.value)};
  }else if(req.op==='put-batch'){
    if(failBatch){failBatch=false;queueMicrotask(()=>window.bearStoreResult(id,{ok:false,error:'模拟批量保存失败'}));return;}
    for(const row of req.rows)saved.set(row.key,clone(row.value));value={rows:clone(req.rows)};
  }else throw Error(req.op);
  queueMicrotask(()=>window.bearStoreResult(id,{ok:true,value}));
}},BearApp:{
  startCookingTimer(id,label,seconds){const row={known:true,active:true,endAt:now+seconds*1000,notifications:true};native.set(id,row);calls.push(['start',id]);return JSON.stringify({ok:true,...row});},
  cookingTimerStatus(id){return JSON.stringify(native.get(id)||{known:false});},
  cancelCookingTimer(id){calls.push(['cancel',id]);if(!cancelAllowed)return false;native.delete(id);return true;}
}};
const recipe={id:'rice',title:'番茄米饭',ingredients:'米 200 克\n番茄 2 个',steps:'切菜\n煮饭'};
const old={recipeId:recipe.id,title:recipe.title,date:'2026-11-17',step:1,checked:[0],ingredients:recipe.ingredients,steps:recipe.steps,updated:now-1000,completedAt:null,timer:{endAt:now+90000,system:true,notified:false}};
saved.set('kitchen-sessions',{[recipe.id]:clone(old)});native.set(recipe.id,{known:true,active:true,endAt:old.timer.endAt});
const originalWeek={week:'2026-11-16',plans:[{id:'lunch',date:'2026-11-18',meal:'lunch',recipeId:recipe.id},{id:'manual',date:'2026-11-18',meal:'dinner',title:'妈妈的蒸鱼'},{id:'other-day',date:'2026-11-19',meal:'breakfast',title:'粥'}],shopping:[{id:'buy-1',text:'米 200 克',done:true},{id:'buy-2',text:'番茄 2 个',done:false}],ingredientSources:[],updated:now};
saved.set('kitchen-week:2026-11-16',clone(originalWeek));
const sheet={open:false,dataset:{},addEventListener(name,fn){events['sheet-'+name]=fn;},querySelector(){return null;}};
const moduleUrl=new URL('../web/kitchen.js',import.meta.url),source=await readFile(moduleUrl,'utf8');
await (await import(new URL(source.match(/from ['"]([^'"]*model\.js[^'"]*)['"]/)[1],moduleUrl))).openStore();
const kitchen=await import(moduleUrl);
await kitchen.initKitchen({sheet,open(title,content){heading=title;html=content;sheet.open=true;},announce:message=>announcements.push(message),getRecipes:()=>[recipe],getEntries:()=>[],recordPlannedMeal:item=>records.push({plan:item}),recordMeal:(recipe,date)=>records.push({recipe,date}),openPantryIntake:(items,date)=>records.push({intake:items,date}),confirmLeave:next=>next()});
const mini=kitchen.mountKitchenTimer();assert.equal(body.children.length,1);assert.equal(mini.hidden,false);assert.match(mini.innerHTML,/01:30/);assert.equal(kitchen.mountKitchenTimer(),mini,'mount is idempotent');

// Opening another day offers a choice without changing dates, checkmarks or the native timer.
const beforeChoice=clone(saved.get('kitchen-sessions'));
await kitchen.openCooking(recipe,'2026-11-18');
assert.equal(sheet.dataset.view,'kitchen-session-choice');assert.match(html,/2026-11-17/);assert.match(html,/2026-11-18/);assert.match(html,/停止原计时，重新开始/);
assert.deepEqual(saved.get('kitchen-sessions'),beforeChoice);assert.equal(calls.filter(x=>x[0]==='cancel').length,0);assert.equal(mini.hidden,true);
await kitchen.kitchenClicked({kitchenAction:'cooking-continue'});
assert.equal(sheet.dataset.view,'cooking');assert.equal(saved.get('kitchen-sessions').rice.date,'2026-11-17');assert.match(html,/第 2 步/);assert.equal(native.get('rice').endAt,old.timer.endAt);
await kitchen.openCooking(recipe,'2026-11-18');cancelAllowed=false;
await assert.rejects(kitchen.kitchenClicked({kitchenAction:'cooking-new'}),/原计时暂未取消/);
assert.deepEqual(saved.get('kitchen-sessions').rice.checked,[0]);assert.equal(saved.get('kitchen-sessions').rice.date,'2026-11-17');assert.ok(native.has('rice'));
cancelAllowed=true;await kitchen.kitchenClicked({kitchenAction:'cooking-new'});
assert.equal(saved.get('kitchen-sessions').rice.date,'2026-11-18');assert.equal(saved.get('kitchen-sessions').rice.step,0);assert.deepEqual(saved.get('kitchen-sessions').rice.checked,[]);assert.equal(saved.get('kitchen-sessions').rice.timer,null);assert.equal(native.has('rice'),false);

// Save failure does not silently replace old progress. The choice can be retried.
await kitchen.kitchenClicked({kitchenAction:'step-next'});
await kitchen.openCooking(recipe,'2026-11-19');failPut=true;
await assert.rejects(kitchen.kitchenClicked({kitchenAction:'cooking-new'}),/新进度未保存/);
assert.equal(saved.get('kitchen-sessions').rice.date,'2026-11-18');assert.equal(saved.get('kitchen-sessions').rice.step,1);
await kitchen.kitchenClicked({kitchenAction:'cooking-new'});assert.equal(saved.get('kitchen-sessions').rice.date,'2026-11-19');

// A compact countdown resumes its actual cooking day, rather than silently moving to today.
await kitchen.kitchenSubmitted(form('kitchen-timer',{minutes:'1'}));
sheet.open=false;events['sheet-close']();assert.equal(mini.hidden,false);assert.match(mini.innerHTML,/01:00/);assert.ok(body.classes.has('has-kitchen-mini-timer'));
now+=10000;tick();assert.match(mini.innerHTML,/00:50/);
let stopped=false;mini.events.click({stopPropagation(){stopped=true;}});await new Promise(resolve=>setImmediate(resolve));
assert.ok(stopped);assert.equal(sheet.dataset.view,'cooking');assert.equal(saved.get('kitchen-sessions').rice.date,'2026-11-19');assert.equal(mini.hidden,true);
sheet.open=false;events['sheet-close']();document.visibilityState='hidden';kitchen.refreshKitchenTimer();assert.equal(mini.hidden,true);document.visibilityState='visible';kitchen.refreshKitchenTimer();assert.equal(mini.hidden,false);
now+=50001;native.set('rice',{known:true,finished:true,endAt:now-1});tick();assert.match(mini.innerHTML,/时间到啦/);
now+=60001;tick();assert.equal(mini.hidden,true,'old finished timers do not leave a permanent floating bar');

// Day reads include manual plans without creating recipes or changing the displayed week.
await kitchen.openMealPlanner('2026-11-25');const display=html;
const day=await kitchen.getMealPlan('2026-11-18');assert.equal(html,display);assert.equal(day.plans.length,2);assert.deepEqual(day.plans.map(plan=>plan.mealName),['午餐','晚餐']);assert.equal(day.recipes.length,1);assert.equal(day.plans[1].recipe,null);assert.equal(day.plans[1].title,'妈妈的蒸鱼');
await kitchen.kitchenClicked({kitchenPlanLog:'manual',kitchenDate:'2026-11-18'});assert.deepEqual(records.at(-1).plan,{title:'妈妈的蒸鱼',date:'2026-11-18',recipeId:undefined,meal:'dinner'});
await kitchen.kitchenClicked({kitchenPlanCook:'manual',kitchenDate:'2026-11-18'});assert.equal(sheet.dataset.view,'kitchen-manual-meal');assert.match(html,/没有食材和做法/);assert.match(html,/data-kitchen-plan-log="manual"/);
await kitchen.kitchenClicked({kitchenPlanCook:'lunch',kitchenDate:'2026-11-18'});assert.equal(sheet.dataset.view,'kitchen-session-choice','a calendar action also protects a different-day active session');
const recordCount=records.length;await kitchen.kitchenClicked({kitchenPlanLog:'missing',kitchenDate:'2026-11-18'});assert.equal(records.length,recordCount);assert.match(announcements.at(-1),/安排已经变了/);

// Pantry additions preserve other plans and original quantities, are atomic, and dedupe retries.
const proposed=[{text:'姜 3 片',recipeTitle:'蒸鱼',recipeId:'fish',sourceKey:'pantry:fish:ginger'}];
failBatch=true;await assert.rejects(kitchen.addShoppingItems('2026-11-18',proposed),/批量保存失败/);assert.deepEqual(saved.get('kitchen-week:2026-11-16'),originalWeek);
let result=await kitchen.addShoppingItems('2026-11-18',proposed);assert.equal(result.added,1);assert.deepEqual(saved.get('kitchen-week:2026-11-16').plans,originalWeek.plans);
result=await kitchen.addShoppingItems('2026-11-18',proposed);assert.equal(result.added,0);
result=await kitchen.addShoppingItems('2026-11-18',[{text:'姜 3 片',recipeTitle:'蒸鱼'},{text:'姜 30 克',recipeTitle:'蒸鱼'}]);assert.equal(result.added,1,'different quantities are never merged');
await assert.rejects(kitchen.addShoppingItems('2026-02-30',proposed),/重新选择/);
await assert.rejects(kitchen.addShoppingItems('2026-11-18',[{text:' '}]),/1–120/);

// Only explicitly checked purchases enter the review handoff; no automatic pantry writes.
await kitchen.openMealPlanner('2026-11-18');await kitchen.kitchenClicked({kitchenAction:'shopping-pantry'});
assert.deepEqual(records.at(-1).intake,[{id:'buy-1',text:'米 200 克',sourceKey:'shopping:2026-11-16:buy-1'}]);
const prior=clone(saved.get('kitchen-week:2026-11-16'));const checkbox={name:'kitchenShoppingDone',value:'buy-2',checked:true,closest(){return null;}};
failBatch=true;await assert.rejects(kitchen.kitchenChanged(checkbox),/批量保存失败/);assert.equal(checkbox.checked,false);assert.deepEqual(saved.get('kitchen-week:2026-11-16'),prior);
await kitchen.kitchenClicked({kitchenAction:'shopping-pantry'});assert.equal(records.at(-1).intake.length,1,'a failed checkbox write cannot leak into pantry intake');
failBatch=true;await assert.rejects(kitchen.kitchenClicked({kitchenShoppingRemove:'buy-1'}),/批量保存失败/);await kitchen.kitchenClicked({kitchenAction:'shopping-pantry'});assert.equal(records.at(-1).intake.length,1,'failed removal preserves the purchased item');
console.log('Passed kitchen v2.2 integration: explicit cooking-day choice, native-timer preservation, failed resets, mini countdown/resume/expiry, calendar manual meals, atomic pantry shopping and purchased-only handoffs.');
