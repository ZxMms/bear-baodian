import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';

const source=(await readFile(new URL('../web/workbench.js',import.meta.url),'utf8')).replace(/^import .*;\r?\n/gm,'').replace(/^export /gm,'');
class FormDataDouble{constructor(form){this.values=new Map(Object.entries(form.values));}get(key){return this.values.get(key)??null;}has(key){return this.values.has(key);}}
const dateKey=date=>date?new Date(date).toISOString().slice(0,10):'2026-11-18';
const media='media/'+'a'.repeat(64)+'.jpg';
const secondMedia='media/'+'b'.repeat(64)+'.jpg';
const entries=[
  {id:'life',title:'买花的小日子',date:'2026-11-17',kind:'life',note:'回家的路上买了茉莉花，天气正好。',photos:[media]},
  {id:'event',title:'妈妈生日',date:'2026-12-03',kind:'anniversary',note:'提前准备一束茉莉花'},
  {id:'memo',title:'保存配方',date:'2026-11-15',kind:'memo',note:'字面符号 a+b [x] .* (试试)'},
  {id:'hidden',title:'茉莉花秘密',date:'2026-11-18',kind:'capsule',note:'不要提前看到',photos:[secondMedia]},
  {id:'deleted-entry',title:'茉莉花已删除',date:'2026-11-18',kind:'life',_deletedAt:5},
];
const recipes=[
  {id:'fish',title:'清蒸鲈鱼',created:Date.parse('2026-11-16T12:00:00Z'),ingredients:'鲈鱼、葱、姜、蒸鱼豉油',steps:'处理干净，铺上姜丝。水开后入锅蒸熟。',photos:[secondMedia]},
  {id:'long',title:'暖汤',created:Date.parse('2026-11-14T12:00:00Z'),steps:'先认真备菜。'.repeat(30)+'最后撒一把香菜，便可以上桌。'},
  {id:'html',title:'<script>汤</script>',created:Date.parse('2026-11-13T12:00:00Z'),ingredients:'<img src=x onerror=alert(1)> & "油"'},
  {id:'unknown',title:'老菜谱',ingredients:'花椒'},
  {id:'deleted-recipe',title:'已删除的鲈鱼',created:Date.now(),_deletedAt:1},
];
const ledger=[
  {id:'bill',date:'2026-11-12',category:'food',note:'周末饭钱',photos:[media],receipt:secondMedia,goods:{name:'茉莉花茶',model:'大罐'}},
  {id:'receipt',date:'2026-11-11',category:'food',note:'单独的凭证',photos:[],receipt:secondMedia},
  {id:'deleted-ledger',date:'2026-11-18',category:'food',note:'茉莉花已删除',_deletedAt:2},
];
async function fixture(){
  const box={innerHTML:''},opened=[],routes=[],photoCalls=[];
  const sheet={dataset:{},querySelector:selector=>selector==='#global-results'?box:null};
  const ctx=vm.createContext({FormData:FormDataDouble,dateKey,Number,String,Date,RegExp,kinds:{life:{name:'生活'},memo:{name:'备注'},anniversary:{name:'纪念日'},capsule:{name:'时光胶囊'}},getSetting:async()=>({}),matchMedia:()=>({matches:false,addEventListener(){}}),document:{documentElement:{dataset:{}},querySelector:()=>null},icon:name=>`<svg data-icon="${name}" aria-hidden="true"></svg>`});
  vm.runInContext(source,ctx);
  await ctx.initWorkbench({sheet,open:(title,html)=>opened.push({title,html}),getEntries:()=>entries,getRecipes:()=>recipes,getLedger:()=>ledger,getLedgerCategories:()=>[{id:'food',name:'餐饮'}],capsuleIsHidden:item=>item.id==='hidden',imageMarkup:(src,css,alt)=>{photoCalls.push({src,css,alt});return /^media\/[a-f0-9]{64}\.jpg$/.test(src)?`<img class="${css}" src="${src}" alt="${alt}">`:'';},openEntry:id=>routes.push(['entry',id]),openRecipe:id=>routes.push(['recipe',id]),openLedger:id=>routes.push(['ledger',id]),openPantry:()=>routes.push(['pantry']),openEasyMeals:()=>routes.push(['easy-meals']),openHappyBox:()=>routes.push(['happy-box']),openWishes:()=>routes.push(['wishes'])});
  ctx.openSearch();
  const search=values=>ctx.workbenchSubmitted({dataset:{form:'global-search'},values:{q:'',type:'all',from:'',to:'',...values}});
  return {ctx,box,sheet,opened,routes,photoCalls,search,ids:()=>Array.from(vm.runInContext('searchResults.map(x=>x.id)',ctx))};
}
let count=0;
async function test(name,run){await run();count++;console.log(`ok ${count} - ${name}`);}

await test('Body-only recipe matches show the real ingredient field and photo',async()=>{const f=await fixture();await f.search({q:'蒸鱼豉油'});assert.deepEqual(f.ids(),['fish']);assert.match(f.box.innerHTML,/>食材<\/span>鲈鱼、葱、姜、<mark>蒸鱼豉油<\/mark>/);assert.match(f.box.innerHTML,/search-thumb/);await f.ctx.workbenchClicked({workResult:'0'});assert.deepEqual(f.routes,[['recipe','fish']]);});
await test('Long recipe steps show context around the match, not only the opening words',async()=>{const f=await fixture();await f.search({q:'香菜'});assert.deepEqual(f.ids(),['long']);assert.match(f.box.innerHTML,/>做法<\/span>…/);assert.match(f.box.innerHTML,/<mark>香菜<\/mark>/);assert(f.box.innerHTML.length<1600);});
await test('Search never exposes hidden capsules or soft-deleted rows from any store',async()=>{const f=await fixture();await f.search({q:'茉莉'});assert.deepEqual(f.ids(),['event','life','bill']);assert.doesNotMatch(f.box.innerHTML,/秘密|已删除|不要提前/);});
await test('Empty search preserves privacy and shows unknown creation dates truthfully',async()=>{const f=await fixture();assert(!f.ids().some(id=>id==='hidden'||id.startsWith('deleted-')));assert.match(f.box.innerHTML,/老菜谱<\/strong><small>菜谱 · 未注明日期/);});
await test('HTML in titles and excerpts is escaped while query highlighting remains safe',async()=>{const f=await fixture();await f.search({q:'<img'});assert.deepEqual(f.ids(),['html']);assert.match(f.box.innerHTML,/<mark>&lt;img<\/mark>/);assert.match(f.box.innerHTML,/&lt;script&gt;汤&lt;\/script&gt;/);assert.doesNotMatch(f.box.innerHTML,/<script>|<img src=x|onerror="/);await f.search({q:'<script>'});assert.match(f.box.innerHTML,/<mark>&lt;script&gt;<\/mark>/);});
await test('Regex-like queries are treated as literal text',async()=>{const f=await fixture();await f.search({q:'a+b'});assert.deepEqual(f.ids(),['memo']);assert.match(f.box.innerHTML,/<mark>a\+b<\/mark>/);await f.search({q:'[x]'});assert.deepEqual(f.ids(),['memo']);await f.search({q:'.*'});assert.deepEqual(f.ids(),['memo']);});
await test('Mixed-case matching highlights the original spelling',async()=>{const f=await fixture();await f.search({q:'A+B'});assert.deepEqual(f.ids(),['memo']);assert.match(f.box.innerHTML,/<mark>a\+b<\/mark>/);});
await test('Ledger goods matches have a useful field label and route to the bill',async()=>{const f=await fixture();await f.search({q:'大罐',type:'ledger'});assert.deepEqual(f.ids(),['bill']);assert.match(f.box.innerHTML,/>型号<\/span><mark>大罐<\/mark>/);await f.ctx.workbenchClicked({workResult:'0'});assert.deepEqual(f.routes,[['ledger','bill']]);});
await test('Photo, store and inclusive date filters still combine correctly',async()=>{const f=await fixture();await f.search({q:'茉莉',type:'entries',photos:'on',from:'2026-11-17',to:'2026-11-17'});assert.deepEqual(f.ids(),['life']);await f.ctx.workbenchClicked({workResult:'0'});assert.deepEqual(f.routes,[['entry','life']]);await f.search({type:'recipes',to:'2026-11-16'});assert(!f.ids().includes('unknown'));assert(f.ids().includes('fish'));});
await test('Ordinary ledger photos take priority, receipt-only results still indicate their source',async()=>{const f=await fixture();await f.search({type:'ledger',photos:'on'});assert.deepEqual(f.ids(),['bill','receipt']);assert.match(f.box.innerHTML,/账单 · 2026-11-11 · 有截图凭证/);assert(f.photoCalls.some(p=>p.src===media&&p.alt==='记录照片'));assert(f.photoCalls.some(p=>p.src===secondMedia&&p.alt==='账单截图凭证'));});
await test('An invalid date range does not replace the last successful search',async()=>{const f=await fixture();await f.search({q:'蒸鱼豉油'});const old=f.box.innerHTML;await assert.rejects(f.search({q:'茉莉',from:'2026-12-01',to:'2026-11-01'}),/开始日期/);assert.equal(f.box.innerHTML,old);f.ctx.openSearch();assert.deepEqual(f.ids(),['fish']);assert.match(f.opened.at(-1).html,/value="蒸鱼豉油"/);});
await test('Nonexistent and malformed result indexes cannot open unrelated content',async()=>{const f=await fixture();await f.ctx.workbenchClicked({workResult:'-1'});await f.ctx.workbenchClicked({workResult:'0.5'});await f.ctx.workbenchClicked({workResult:'99'});await f.ctx.workbenchClicked({workResult:'NaN'});assert.deepEqual(f.routes,[]);});
await test('No-match results contain the empty prompt and no stale rows',async()=>{const f=await fixture();await f.search({q:'不存在的晚餐'});assert.deepEqual(f.ids(),[]);assert.match(f.box.innerHTML,/找到 0 条/);assert.match(f.box.innerHTML,/换一个词/);assert.doesNotMatch(f.box.innerHTML,/data-work-result=/);});
await test('All four new tools are grouped, keyboard-native buttons and route once',async()=>{const f=await fixture();f.ctx.openTools();const markup=f.opened.at(-1).html;for(const action of ['pantry','easy-meals','happy-box','wishes']){assert.equal((markup.match(new RegExp(`data-work-action="${action}"`,'g'))||[]).length,1);await f.ctx.workbenchClicked({workAction:action});}assert.deepEqual(f.routes,[['pantry'],['easy-meals'],['happy-box'],['wishes']]);assert.match(markup,/好好吃饭/);assert.match(markup,/留住小幸福/);assert.match(markup,/日常工具/);assert.doesNotMatch(markup,/<button[^>]*>(?:(?!<\/button>)[\s\S])*<button/);assert.equal(f.sheet.dataset.view,'tools');});
console.log(`Workbench search and hub: ${count} checks passed.`);
