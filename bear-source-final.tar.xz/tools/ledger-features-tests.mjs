import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {worthSummary,validLedgerDate,normalizeGoods,goodsReminders,entryFromLedger,starterLedgerCategories} from '../web/ledger-core.js';

assert.equal(validLedgerDate('2028-02-29'),true);
for(const date of ['2026-02-29','2026-04-31','1899-12-31','2026-13-01','2026-2-01'])assert.equal(validLedgerDate(date),false);
const goods=normalizeGoods({name:'  咖啡机  ',model:'A1',purchaseDate:'2026-11-17',returnDate:'2026-11-24',warrantyDate:'2027-11-17',reminder:true,reminderTime:'08:30'});
assert.equal(goods.name,'咖啡机');
assert.equal(normalizeGoods({},false),null);
assert.throws(()=>normalizeGoods({name:'咖啡机',purchaseDate:'2026-11-17',returnDate:'2026-11-01'}),/早于购买/);
assert.throws(()=>normalizeGoods({name:'咖啡机',reminder:true}),/先填写/);
assert.throws(()=>normalizeGoods({name:'咖啡机',returnDate:'2026-02-30'}),/正确/);
assert.throws(()=>normalizeGoods({name:'咖啡机',reminderTime:'25:00'}),/时间/);
const reminderRows=[{id:'bill-1',type:'expense',goods},{id:'deleted',goods,_deletedAt:1}];
assert.deepEqual(goodsReminders(reminderRows).map(r=>[r.id,r.date,r.time,r.kind]),[
  ['goods-return-bill-1','2026-11-24','08:30','memo'],['goods-warranty-bill-1','2027-11-17','08:30','memo']]);
assert.deepEqual(worthSummary([
  {type:'expense',date:'2026-11-17',worth:'worth',eatAgain:true},
  {type:'expense',date:'2026-11-18',worth:'skip'},
  {type:'income',date:'2026-11-18',worth:'worth'},
  {type:'expense',date:'2026-12-18',worth:'worth'},
  {type:'expense',date:'2026-11-18',worth:'worth',_deletedAt:1}
],'2026-11'),{total:2,rated:2,worth:1,okay:0,skip:1,again:1});
const bill={id:'bill',date:'2026-11-17',note:'好吃的面',photos:['photo-a'],created:100};
const life=entryFromLedger(bill,null,'entry','餐饮');
assert.equal(life.kind,'meal');assert.equal(life.ledgerId,'bill');assert.deepEqual(life.photos,bill.photos);assert.notEqual(life.photos,bill.photos);
const existing={...life,note:'后来补写的日记',photos:['photo-b'],custom:'keep'};
assert.deepEqual(entryFromLedger({...bill,date:'2026-11-18'},existing,'unused'),{...existing,date:'2026-11-18'});

// Exercise the real ledger module against an in-memory native bridge: atomic linking,
// failed writes, existing links, receipts, photo viewer, and soft deletion.
const tables=Object.fromEntries(['entries','recipes','moods','ledger','ledgerCategories','settings'].map(name=>[name,new Map()]));
for(const category of starterLedgerCategories)tables.ledgerCategories.set(category.id,category);
let failBatch=false,batchCount=0,lastBatch=[];
globalThis.window={BearStore:{request(id,raw){
  const req=JSON.parse(raw);let result;
  try {
    if(req.op==='status')result={ready:true};
    else if(req.op==='all')result={value:[...tables[req.store].values()]};
    else if(req.op==='get')result={value:tables[req.store].get(req.key)};
    else if(req.op==='put-batch'){
      if(failBatch)throw new Error('模拟磁盘写入失败');
      batchCount++;lastBatch=structuredClone(req.rows);
      for(const row of req.rows)tables[row.store].set(row.key,structuredClone(row.value));
      result={rows:req.rows};
    } else if(req.op==='put') {tables[req.store].set(req.key,structuredClone(req.value));result={value:req.value};}
    else if(req.op==='soft-delete') {
      const row=tables[req.store].get(req.key),next={...row,_deletedAt:req.now,_deleteExpiresAt:req.now+30*86400000};
      tables[req.store].set(req.key,next);result={value:next};
    } else throw new Error(`Unhandled native operation: ${req.op}`);
    queueMicrotask(()=>window.bearStoreResult(id,{ok:true,value:structuredClone(result)}));
  }catch(error){queueMicrotask(()=>window.bearStoreResult(id,{ok:false,error:error.message}));}
}}};
const source=await readFile(new URL('../web/ledger.js',import.meta.url),'utf8');
const modelSpecifier=source.match(/from "(\.\/model\.js[^\"]*)"/)[1];
const model=await import(new URL('../web/'+modelSpecifier.slice(2),import.meta.url));
await model.openStore();
const ledger=await import('../web/ledger.js');
const originalFormData=globalThis.FormData;
globalThis.FormData=class {constructor(form){this.values=new Map(Object.entries(form.values));}get(key){return this.values.get(key)??null;}has(key){return this.values.has(key);}};
let photos=['photo-a','photo-b','photo-c','photo-d','photo-e'],html='',notice='',viewer=null,formCount=0;
const lifecycle=[],savedForms=[];
const ui={open(title,body){html=body;lifecycle.push('open:'+title);},close(){lifecycle.push('close');},render(){lifecycle.push('render');},announce(message){notice=message;},sheet:{dataset:{}},
  imageMarkup:()=>'<img alt="消费照片">',photoFields:()=>'<div class="photo-count"></div>',initPhotos(value){photos=[...value];},getPhotos:()=>photos,
  setDraft(){},showDay(date){lifecycle.push('day:'+date);},showLedgerPage(){lifecycle.push('page:ledger');},onRecordsChanged(){},showPhotos(value){viewer=value;},onDeleted(){},onSaved(form){assert.ok(tables[form.dataset.form==='ledger-category'?'ledgerCategories':'ledger'].has(form.dataset.id));lifecycle.push('saved');savedForms.push({...form.dataset});}};
await ledger.initLedger(ui);
const form=(overrides={},recordId='')=>({dataset:{form:'ledger',id:recordId,draftKey:'draft-'+(++formCount)},values:{ledgerAmount:'25.50',ledgerType:'expense',ledgerCategory:'category-0',ledgerDate:'2026-11-17',ledgerNote:'晚饭面条',ledgerWorth:'worth',...overrides}});
try {
  await ledger.submitLedger(form({ledgerToLife:'on',eatAgain:'on'}));
  assert.equal(batchCount,1);assert.equal(lastBatch.length,2);assert.equal(tables.ledger.size,1);assert.equal(tables.entries.size,1);
  assert.equal(savedForms.length,1);assert.ok(lifecycle.indexOf('saved')<lifecycle.indexOf('close'));assert.equal(lifecycle.at(-1),'open:账单详情');assert.ok(!lifecycle.includes('page:ledger'));
  let saved=ledger.getLedgerRows()[0],linked=tables.entries.get(saved.entryId);
  assert.equal(linked.ledgerId,saved.id);assert.equal(saved.photos.length,5);assert.deepEqual(linked.photos,saved.photos);
  saved.customField='preserved';tables.ledger.set(saved.id,saved);
  tables.entries.set(linked.id,{...linked,note:'独立补写的手账',photos:['independent-photo']});
  await ledger.reloadLedger();photos=['new-ledger-photo'];
  const datedEdit=form({ledgerAmount:'30.00',ledgerDate:'2026-11-18'},saved.id);datedEdit.dataset.returnDay='2026-11-17';
  await ledger.submitLedger(datedEdit);assert.ok(lifecycle.includes('day:2026-11-18'));assert.equal(ui.sheet.dataset.returnDay,'2026-11-18');assert.equal(lifecycle.at(-1),'open:账单详情');
  saved=ledger.getLedgerRows()[0];linked=tables.entries.get(saved.entryId);
  assert.equal(saved.cents,3000);assert.equal(saved.customField,'preserved');assert.equal(tables.entries.size,1);
  assert.equal(linked.date,'2026-11-18');assert.equal(linked.note,'独立补写的手账');assert.deepEqual(linked.photos,['independent-photo']);
  tables.entries.set(linked.id,{...linked,_deletedAt:1});
  await ledger.submitLedger(form({ledgerAmount:'35.00'},saved.id));
  assert.equal(tables.entries.size,1);assert.equal(ledger.getLedgerRows()[0].entryId,linked.id);assert.equal(lastBatch.length,1);
  await ledger.ledgerClick({ledgerEntry:saved.id});assert.match(notice,/最近删除/);
  failBatch=true;
  const callbackCount=savedForms.length;
  await assert.rejects(ledger.submitLedger(form({ledgerToLife:'on'})),/写入失败/);
  assert.equal(savedForms.length,callbackCount);
  assert.equal(tables.ledger.size,1);assert.equal(tables.entries.size,1);assert.equal(ledger.getLedgerRows().length,1);failBatch=false;
  await ledger.ledgerClick({ledgerWorthSet:'skip',ledgerWorthId:saved.id});
  assert.equal(ledger.getLedgerRows()[0].worth,'skip');assert.match(html,/下次不买了/);
  await ledger.ledgerClick({ledgerWorthFilter:'skip'});assert.match(ledger.ledgerMarkup(),/消费回顾/);
  await ledger.ledgerClick({ledgerPhoto:saved.id,ledgerPhotoIndex:'0'});assert.equal(viewer.photos[0],'new-ledger-photo');
  const beforeOpen=batchCount;
  ledger.editLedger({receiptImport:true,receipt:'data:image/png;base64,AA==',receiptHash:'ocr-hash',cents:2250,warnings:['核对'],candidates:[{cents:2250}]});
  assert.equal(batchCount,beforeOpen);assert.equal(ledger.getLedgerDraftContext().receiptHash,'ocr-hash');
  await assert.rejects(ledger.submitLedger(form()),/核对/);
  await ledger.ledgerClick({ledgerRemove:saved.id});
  assert.equal(ledger.getLedgerRows().length,0);assert.ok(tables.ledger.get(saved.id)._deletedAt);assert.equal(tables.entries.get(linked.id).ledgerId,saved.id);
  assert.equal(ledger.ledgerReminderTarget('goods-warranty-bill-1'),'bill-1');assert.equal(ledger.ledgerReminderTarget('memo-1'),null);
  const currentHtml=html;
  await ledger.ledgerClick({ledgerEdit:'already-deleted'});assert.equal(html,currentHtml);assert.match(notice,/最近删除/);
  await ledger.ledgerClick({ledgerDelete:'already-deleted'});assert.match(notice,/最近删除/);
  ledger.editLedger(null);
  await assert.rejects(ledger.submitLedger(form({},saved.id)),/原账单已移入最近删除/);
  await assert.rejects(ledger.submitLedger(form({ledgerDate:'1899-01-01'})),/正确的记账日期/);
  await ledger.ledgerClick({ledgerDrill:'category-0',ledgerDrillType:'expense'});
  ui.onRecordsChanged=()=>{throw new Error('模拟刷新失败');};
  const retry=form({ledgerCategory:'category-3',ledgerWorth:'toString',ledgerToLife:'on'}),entryCount=tables.entries.size;
  await ledger.submitLedger(retry);
  assert.ok(retry.dataset.id);assert.equal(ledger.getLedgerRows().length,1);assert.equal(tables.entries.size,entryCount+1);assert.match(notice,/账单已保存/);
  assert.equal(ledger.getLedgerRows()[0].worth,'');assert.doesNotMatch(ledger.ledgerMarkup(),/class="ledger-filter-tag"/);
  await ledger.submitLedger(retry);assert.equal(ledger.getLedgerRows().length,1);assert.equal(tables.entries.size,entryCount+1);
  const retryDraftKey=retry.dataset.draftKey;
  ui.onSaved=()=>{throw new Error('模拟草稿清理失败');};
  await ledger.submitLedger(retry);assert.equal(ledger.getLedgerRows().length,1);assert.equal(tables.entries.size,entryCount+1);assert.equal(retry.dataset.draftKey,retryDraftKey);assert.match(notice,/账单已保存.*草稿清理未完成/);assert.equal(lifecycle.at(-1),'open:账单详情');
  const fields={hidden:false,disabled:false},expense={hidden:false},goodsSummary={},worthSummary={},optionalSummary={};
  const restored={dataset:{form:'ledger'},elements:{ledgerType:{value:'income'},goodsEnabled:{checked:true},ledgerWorth:{value:'worth'},eatAgain:{checked:true},goodsName:{value:'相机'},ledgerNote:{value:'有备注'},keepReceipt:{checked:false}},querySelector(selector){return {'.ledger-expense-only':expense,'.ledger-goods-fields':fields,'[data-ledger-goods-summary]':goodsSummary,'[data-ledger-worth-summary]':worthSummary,'[data-ledger-optional-summary]':optionalSummary}[selector];}};
  ledger.refreshLedgerForm(restored);assert.equal(expense.hidden,true);assert.equal(fields.disabled,true);assert.equal(goodsSummary.textContent,'相机');assert.match(worthSummary.textContent,/很值得.*还想再吃/);assert.match(optionalSummary.textContent,/有备注/);
  restored.elements.ledgerType.value='expense';ledger.refreshLedgerForm(restored);assert.equal(expense.hidden,false);assert.equal(fields.disabled,false);
  assert.equal(ledger.ledgerChange({name:'photos',form:null}),false);
  assert.match(html,/ui-icon/);
} finally {globalThis.FormData=originalFormData;}
console.log('Passed ledger features: dates, goods, reminders, reviews, atomic links, rollback, independent journal edits, five photos, OCR drafts, viewer, soft deletion, stale drafts, safe retries, draft-cleanup ordering/failure, saved detail and return date, restored optional fields.');
