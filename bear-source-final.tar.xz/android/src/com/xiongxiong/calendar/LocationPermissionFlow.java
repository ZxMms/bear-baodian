package com.xiongxiong.calendar;

/** Permission dialogs pause the Activity; only an explicit cancellation invalidates them. */
final class LocationPermissionFlow {
    enum Result { IGNORED, DENIED, READY, DEFERRED }
    private boolean pending, dialogOpen, foreground, deferred;
    boolean pending() { return pending; }
    boolean dialogOpen() { return dialogOpen; }
    boolean foreground() { return foreground; }
    boolean enterForeground() {
        foreground = true;
        boolean start = deferred; deferred = false; return start;
    }
    void leaveForeground() { foreground = false; }
    boolean begin() {
        if (dialogOpen) return false;
        pending = true; dialogOpen = true; return true;
    }
    // A cancelled selection must still consume the outstanding platform callback before
    // another dialog starts; otherwise that old result could authorize a newer request.
    void cancel() { pending = false; deferred = false; }
    Result resolve(boolean coarse, boolean fine) {
        boolean expected = pending;
        pending = false; dialogOpen = false;
        if (!expected) return Result.IGNORED;
        if (!(coarse || fine)) return Result.DENIED;
        if (!foreground) { deferred = true; return Result.DEFERRED; }
        return Result.READY;
    }
    static String permission(boolean coarse, boolean fine) { return fine ? "precise" : coarse ? "approximate" : "none"; }
    static boolean needsRequest(boolean coarse, boolean fine, boolean explicitPrecise) {
        return !(coarse || fine) || explicitPrecise && !fine;
    }
}
