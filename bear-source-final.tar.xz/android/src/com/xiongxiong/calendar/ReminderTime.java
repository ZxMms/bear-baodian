package com.xiongxiong.calendar;

import java.time.DateTimeException;
import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.ZoneId;
import java.util.Collections;
import java.util.Arrays;
import java.util.List;

/** Calendar-day arithmetic, independent of Android so recurrence and zones can be tested. */
public final class ReminderTime {
    public static final class Occurrence {
        public final long at;
        public final String date;
        Occurrence(long at, String date) { this.at = at; this.date = date; }
    }

    public static Occurrence next(String date, String time, boolean annual, int daysBefore,
            long after, ZoneId zone, String lastOccurrence) {
        return next(date, time, annual ? "yearly" : "none", 1, "last", "official",
            Collections.emptyList(), daysBefore, after, zone, lastOccurrence);
    }

    public static Occurrence next(String date, String time, String recurrence, int monthDay,
            String overflow, String workMode, List<String> workDates, int daysBefore,
            long after, ZoneId zone, String lastOccurrence) {
        LocalDate original = LocalDate.parse(date);
        LocalTime clock = LocalTime.parse(time);
        if (daysBefore != 0 && daysBefore != 1 && daysBefore != 3 && daysBefore != 7)
            throw new IllegalArgumentException("Unsupported reminder offset");
        if (!Arrays.asList("none", "yearly", "monthly", "last-workday").contains(recurrence)
                || monthDay < 1 || monthDay > 31 || !Arrays.asList("last", "skip").contains(overflow)
                || !Arrays.asList("official", "five-day", "weekdays").contains(workMode))
            throw new IllegalArgumentException("Unsupported recurrence rule");
        if (recurrence.equals("none")) return eligible(original, original, clock, daysBefore, after, zone, lastOccurrence);
        LocalDate now = Instant.ofEpochMilli(after).atZone(zone).toLocalDate();
        if (recurrence.equals("yearly")) {
            int start = Math.max(original.getYear(), now.getYear() - 1);
            for (int year = start; year <= Math.min(9999, start + 10); year++) {
                LocalDate occurrence;
                try { occurrence = LocalDate.of(year, original.getMonthValue(), original.getDayOfMonth()); }
                catch (DateTimeException invalidLeapDay) { continue; }
                Occurrence found = eligible(occurrence, original, clock, daysBefore, after, zone, lastOccurrence);
                if (found != null) return found;
            }
            return null;
        }
        if (recurrence.equals("last-workday") && !workMode.equals("weekdays")) {
            Occurrence best = null;
            for (String key : workDates) {
                Occurrence found = eligible(LocalDate.parse(key), original, clock, daysBefore, after, zone, lastOccurrence);
                if (found != null && (best == null || found.at < best.at)) best = found;
            }
            return best; // Unknown official years are never approximated as weekdays.
        }
        YearMonth month = YearMonth.from(now).minusMonths(1);
        if (month.compareTo(YearMonth.from(original)) < 0) month = YearMonth.from(original);
        for (int step = 0; step < 26; step++, month = month.plusMonths(1)) {
            if (month.getYear() > 9999) return null;
            LocalDate occurrence;
            if (recurrence.equals("last-workday")) {
                occurrence = month.atEndOfMonth();
                while (occurrence.getDayOfWeek() == DayOfWeek.SATURDAY || occurrence.getDayOfWeek() == DayOfWeek.SUNDAY)
                    occurrence = occurrence.minusDays(1);
            } else {
                if (monthDay > month.lengthOfMonth() && overflow.equals("skip")) continue;
                occurrence = month.atDay(Math.min(monthDay, month.lengthOfMonth()));
            }
            Occurrence found = eligible(occurrence, original, clock, daysBefore, after, zone, lastOccurrence);
            if (found != null) return found;
        }
        return null;
    }
    private static Occurrence eligible(LocalDate occurrence, LocalDate original, LocalTime clock,
            int daysBefore, long after, ZoneId zone, String lastOccurrence) {
        if (occurrence.isBefore(original) || (!lastOccurrence.isEmpty() && occurrence.toString().compareTo(lastOccurrence) <= 0)) return null;
        long at = occurrence.minusDays(daysBefore).atTime(clock).atZone(zone).toInstant().toEpochMilli();
        return at >= after ? new Occurrence(at, occurrence.toString()) : null;
    }
}
