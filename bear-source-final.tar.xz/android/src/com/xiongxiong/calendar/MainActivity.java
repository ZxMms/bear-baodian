package com.xiongxiong.calendar;

import android.app.Activity;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Settings;
import android.content.ClipData;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

public final class MainActivity extends Activity {
    private static final String ASSET_HOST = "appassets.androidplatform.net";
    private static final int CHOOSE_PHOTOS = 21;
    private final Map<String, Integer> effects = new HashMap<>();
    private WebView web;
    private SoundPool sound;
    private final Object audioLock = new Object();
    private int activeStream;
    private ValueCallback<Uri[]> chooser;
    private volatile int nextPhotoLimit = 5;
    private int activePhotoLimit = 5;
    private volatile String pendingEntry = "";
    private final AtomicReference<String> pendingWidgetAction = new AtomicReference<>("");
    private boolean pendingTest;
    private boolean permissionRequested;
    private WeatherController weather;
    private GoldController gold;
    private WeatherAlerts weatherAlerts;
    private ShareController sharing;
    private LocalStore localStore;
    private String appVersion = "";
    private long appBuild;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            android.content.pm.PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            appVersion = info.versionName;
            appBuild = Build.VERSION.SDK_INT >= 28 ? info.getLongVersionCode() : info.versionCode;
        } catch (PackageManager.NameNotFoundException impossible) { throw new IllegalStateException(impossible); }
        rememberNotification(getIntent());
        rememberWidgetAction(getIntent());
        Reminders.createChannel(this);
        CookingTimers.createChannel(this);
        web = new WebView(this);
        setContentView(web);

        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setBlockNetworkLoads(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        if (getPreferences(MODE_PRIVATE).getLong("assetBuild", -1) != appBuild) {
            // Clear page resources only. IndexedDB, photos and settings are preserved.
            web.clearCache(true);
            getPreferences(MODE_PRIVATE).edit().putLong("assetBuild", appBuild).apply();
        }

        AudioAttributes attributes = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
        sound = new SoundPool.Builder().setAudioAttributes(attributes).setMaxStreams(1).build();
        for (String name : new String[]{"tap", "saved", "recommend"}) {
            try (AssetFileDescriptor file = getAssets().openFd("assets/" + name + ".wav")) {
                effects.put(name, sound.load(file, 1));
            } catch (IOException ignored) {
                // The web bundle can still play the asset when native audio is unavailable.
            }
        }

        try { localStore = new LocalStore(this,web); }
        catch(Exception error){ throw new IllegalStateException("无法打开本机数据库",error); }
        web.addJavascriptInterface(localStore,"BearStore");
        web.addJavascriptInterface(new LocalAudio(), "BearCalendarAudio");
        web.addJavascriptInterface(new LocalReminders(), "BearReminders");
        web.addJavascriptInterface(new LocalApp(), "BearApp");
        sharing = new ShareController(this, web);
        web.addJavascriptInterface(sharing, "BearShare");
        gold = new GoldController(this, web);
        web.addJavascriptInterface(gold, "BearGold");
        weather = new WeatherController(this, web);
        web.addJavascriptInterface(weather, "BearWeather");
        weatherAlerts = new WeatherAlerts(this, web);
        web.addJavascriptInterface(weatherAlerts, "BearWeatherAlerts");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !isAppAsset(request.getUrl());
            }

            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                // Android's file picker returns temporary content URIs to the selected image.
                if ("content".equals(uri.getScheme())) return null;
                if (!isAppAsset(uri)) return missing();
                String path = uri.getPath();
                if(path!=null && path.startsWith("/media/")){
                    try { java.io.File file=localStore.engine.file(path.substring(1));return new WebResourceResponse(StoreEngine.mime(file),null,200,"OK",Collections.singletonMap("Cache-Control","no-store"),new java.io.FileInputStream(file)); }
                    catch(Exception error){return missing();}
                }
                if (path == null || !path.matches("/(?:assets/|ocr/)?[A-Za-z0-9_.-]+") || path.contains("..")) return missing();
                String mime = mimeType(path);
                if (mime == null) return missing();
                String encoding = mime.startsWith("text/") || mime.equals("application/javascript") ? "UTF-8" : null;
                try {
                    return new WebResourceResponse(mime, encoding, 200, "OK",
                        Collections.singletonMap("Cache-Control", "no-store"), getAssets().open(path.substring(1)));
                } catch (IOException error) {
                    return missing();
                }
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = callback;
                activePhotoLimit = params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE ? nextPhotoLimit : 1;
                nextPhotoLimit = 5;
                Intent picker = new Intent(MainActivity.this, PhotoPickerActivity.class).putExtra(PhotoPickerActivity.LIMIT,activePhotoLimit);
                try {
                    startActivityForResult(picker, CHOOSE_PHOTOS);
                } catch (RuntimeException error) {
                    chooser = null;
                    callback.onReceiveValue(null);
                }
                return true;
            }
        });
        loadBundledApp();
    }

    private void loadBundledApp() {
        web.loadUrl("https://" + ASSET_HOST + "/index.html?build=" + appBuild);
    }
    public final class LocalApp {
        @JavascriptInterface public void setImagePickLimit(int limit) { nextPhotoLimit = Math.max(1,Math.min(5,limit)); }
        @JavascriptInterface public String updateWidgets(String snapshot) { return BearWidgets.update(MainActivity.this, snapshot); }
        @JavascriptInterface public String pinWidget(String size) { return BearWidgets.pin(MainActivity.this, size); }
        @JavascriptInterface public String widgetPlatformInfo() {
            try { return new org.json.JSONObject()
                .put("xiaomi", "xiaomi".equalsIgnoreCase(Build.MANUFACTURER)||"redmi".equalsIgnoreCase(Build.MANUFACTURER))
                .put("reviewBuild", BearWidgets.xiaomiBuild(MainActivity.this)).toString();
            } catch(Exception unavailable) { return "{}"; }
        }
        @JavascriptInterface public String consumeWidgetAction() { return pendingWidgetAction.getAndSet(""); }
        @JavascriptInterface public String startCookingTimer(String id, String label, int durationSeconds) {
            return CookingTimers.start(MainActivity.this, id, label, durationSeconds);
        }
        @JavascriptInterface public boolean cancelCookingTimer(String id) { return CookingTimers.cancel(MainActivity.this, id); }
        @JavascriptInterface public boolean stopCookingTimerRinging(String id) { return CookingTimers.stopRinging(MainActivity.this, id); }
        @JavascriptInterface public String cookingTimerStatus(String id) { return CookingTimers.status(MainActivity.this, id); }
        @JavascriptInterface public String cookingRingingStatus() { return CookingTimers.ringingStatus(MainActivity.this); }
        @JavascriptInterface public String testCookingRinging() { return CookingTimers.start(MainActivity.this, CookingTimerRules.TEST_ID, "5 秒响铃测试", 5); }
        @JavascriptInterface public boolean cancelCookingRingingTest() { return CookingTimers.cancel(MainActivity.this, CookingTimerRules.TEST_ID); }
        @JavascriptInterface public void cookingNotificationSettings() { openCookingSoundSettings(false); }
        @JavascriptInterface public void chooseCookingRingtone() { openCookingSoundSettings(true); }
        private void openCookingSoundSettings(boolean choosingSound) {
            runOnUiThread(() -> {
                try {
                    CookingTimers.createChannel(MainActivity.this);
                    startActivity(new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName()).putExtra(Settings.EXTRA_CHANNEL_ID, CookingTimers.CHANNEL));
                    return;
                } catch (RuntimeException unavailable) { /* Some OEMs only expose the app-wide notification settings. */ }
                try {
                    startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName()));
                    android.widget.Toast.makeText(MainActivity.this,choosingSound
                        ?"请进入通知类别 → 熊熊计时响铃 → 声音"
                        :"请在通知类别中打开熊熊计时响铃",android.widget.Toast.LENGTH_LONG).show();
                } catch (RuntimeException unavailable) {
                    notifyWeb("未能打开系统设置，请手动进入设置 → 熊熊宝典 → 通知 → 熊熊计时响铃"+(choosingSound?" → 声音":""));
                }
            });
        }
        @JavascriptInterface public String info() {
            try { return new org.json.JSONObject().put("version", appVersion).put("build", appBuild).toString(); }
            catch (org.json.JSONException invalid) { return "{}"; }
        }
        @JavascriptInterface public void refreshInterface() {
            runOnUiThread(() -> { web.clearCache(true); loadBundledApp(); });
        }
        @JavascriptInterface public boolean openRecipeLink(String link) {
            java.net.URI checked=RecipeLinks.webUri(link);if(checked==null)return false;
            Uri uri=Uri.parse(checked.toString());String preferred=RecipeLinks.preferredPackage(checked);
            runOnUiThread(()->{
                // Prefer the installed Xiaohongshu handler; keep the complete link and its tokens.
                if(preferred!=null){try{startActivity(new Intent(Intent.ACTION_VIEW,uri).addCategory(Intent.CATEGORY_BROWSABLE).setPackage(preferred));return;}catch(RuntimeException unavailable){}}
                try{startActivity(new Intent(Intent.ACTION_VIEW,uri).addCategory(Intent.CATEGORY_BROWSABLE));}
                catch(RuntimeException error){notifyWeb("手机没有可打开该链接的应用");}
            });
            return true;
        }
    }

    private static boolean isAppAsset(Uri uri) {
        return "https".equals(uri.getScheme()) && ASSET_HOST.equals(uri.getHost()) && uri.getPort() == -1;
    }

    private static String mimeType(String path) {
        return AssetMime.type(path);
    }

    private static WebResourceResponse missing() {
        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found",
            Collections.emptyMap(), new ByteArrayInputStream(new byte[0]));
    }

    public final class LocalAudio {
        @JavascriptInterface public boolean play(String name) {
            return playAtVolume(name,.45);
        }
        @JavascriptInterface public boolean playAtVolume(String name,double volume) {
            synchronized(audioLock) {
                Integer clip = effects.get(name);
                if (clip == null || sound == null || Double.isNaN(volume)) return false;
                if(activeStream!=0)sound.stop(activeStream);
                float level=(float)Math.max(0,Math.min(1,volume));
                activeStream=sound.play(clip,level,level,1,0,1f);
                return activeStream!=0;
            }
        }
        @JavascriptInterface public void stop() { stopSound(); }
    }
    private void stopSound() {
        synchronized(audioLock) {
            if(sound!=null&&activeStream!=0)sound.stop(activeStream);
            activeStream=0;
        }
    }

    public final class LocalReminders {
        @JavascriptInterface public String status() { return Reminders.status(MainActivity.this); }
        @JavascriptInterface public String sync(String records) { return Reminders.sync(MainActivity.this, records); }
        @JavascriptInterface public void requestPermission() { runOnUiThread(() -> enableNotifications(false)); }
        @JavascriptInterface public void test() { runOnUiThread(() -> enableNotifications(true)); }
        @JavascriptInterface public void settings() { runOnUiThread(() -> openNotificationSettings()); }
        @JavascriptInterface public void exactSettings() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 31 && !Reminders.exact(MainActivity.this)) {
                    try { startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getPackageName()))); }
                    catch (RuntimeException error) { notifyWeb("请在系统设置中允许闹钟和提醒"); }
                }
            });
        }
        @JavascriptInterface public String consumeOpenEntry() {
            String id = pendingEntry;
            pendingEntry = "";
            return id == null ? "" : id;
        }
    }

    private void openNotificationSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName()).putExtra(Settings.EXTRA_CHANNEL_ID, Reminders.CHANNEL));
        } catch (RuntimeException error) { notifyWeb("请在手机设置中打开熊熊宝典的通知权限"); }
    }
    private void enableNotifications(boolean test) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            pendingTest = pendingTest || test;
            if (permissionRequested) return;
            boolean asked = getPreferences(MODE_PRIVATE).getBoolean("askedNotifications", false);
            if (asked && !shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                openNotificationSettings();
                return;
            }
            permissionRequested = true;
            getPreferences(MODE_PRIVATE).edit().putBoolean("askedNotifications", true).apply();
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 42);
        } else if (!Reminders.enabled(this)) {
            pendingTest = pendingTest || test;
            openNotificationSettings();
        } else {
            Reminders.restore(this);
            if (test) notifyWeb(Reminders.test(this));
            else notifyWeb("通知已开启");
        }
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == WeatherController.LOCATION_PERMISSION) { weather.permissionResult(); return; }
        if (requestCode != 42) return;
        permissionRequested = false;
        Reminders.restore(this);
        CookingTimers.restore(this);
        if (Reminders.enabled(this)) notifyWeb(pendingTest ? Reminders.test(this) : "通知已开启");
        else notifyWeb("记录已保存，允许通知后才能收到提醒");
        pendingTest = false;
    }
    private void notifyWeb(String message) {
        if (web == null) return;
        web.evaluateJavascript("window.bearReminderStatusChanged && window.bearReminderStatusChanged(" + org.json.JSONObject.quote(message) + ")", null);
    }
    @Override protected void onResume() {
        super.onResume();
        CookingTimers.invalidateRingtoneTitle();
        if (web != null) web.onResume();
        if (weather != null) weather.foreground();
        if (weatherAlerts != null) weatherAlerts.resume();
        Reminders.restore(this);
        CookingTimers.restore(this);
        BearWidgets.updateAll(this);
        if (pendingTest && !permissionRequested && Reminders.enabled(this)) {
            pendingTest = false;
            notifyWeb(Reminders.test(this));
        } else notifyWeb("");
    }
    @Override protected void onPause() {
        stopSound();
        if (weather != null) weather.pause();
        if (web != null) web.onPause();
        super.onPause();
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        rememberNotification(intent);
        rememberWidgetAction(intent);
        if (web != null) web.evaluateJavascript("window.bearOpenNotification && window.bearOpenNotification()", null);
        deliverWidgetAction();
    }
    private void rememberWidgetAction(Intent intent) {
        String type = intent == null ? null : intent.getStringExtra(BearWidgets.OPEN_ACTION);
        if (!("calendar".equals(type) || "entry".equals(type) || "ledger".equals(type) || "cooking".equals(type) || "weather".equals(type))) return;
        try {
            org.json.JSONObject action = new org.json.JSONObject().put("type", type);
            if ("cooking".equals(type)) {
                String id = intent.getStringExtra("recipeId");
                if (!CookingTimerRules.validId(id)) return;
                action.put("recipeId", id);
            }
            pendingWidgetAction.set(action.toString());
        } catch (org.json.JSONException invalid) { pendingWidgetAction.set(""); }
    }
    private void deliverWidgetAction() {
        String action = pendingWidgetAction.get();
        if (web == null || action.isEmpty()) return;
        web.evaluateJavascript("(function(){if(typeof window.bearWidgetAction!=='function')return false;window.bearWidgetAction(" + action + ");return true;})()",
            handled -> { if ("true".equals(handled)) pendingWidgetAction.compareAndSet(action, ""); });
    }
    private void rememberNotification(Intent intent) {
        String id = intent.getStringExtra("entryId");
        if (id == null) { pendingEntry = ""; return; }
        try { pendingEntry = new org.json.JSONObject().put("id", id).put("date", intent.getStringExtra("entryDate")).toString(); }
        catch (org.json.JSONException invalid) { pendingEntry = ""; }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == LocalStore.SAVE_BACKUP || requestCode == LocalStore.OPEN_BACKUP) { localStore.activityResult(requestCode,resultCode,data); return; }
        if (requestCode == ShareController.SAVE_CARD) { sharing.activityResult(resultCode, data); return; }
        if (requestCode != CHOOSE_PHOTOS || chooser == null) return;
        Uri[] photos = null;
        if (resultCode == RESULT_OK && data != null) {
            ClipData items = data.getClipData();
            if (items != null) {
                photos = new Uri[Math.min(activePhotoLimit, items.getItemCount())];
                for (int index = 0; index < photos.length; index++) {
                    photos[index] = items.getItemAt(index).getUri();
                }
            } else if (data.getData() != null) {
                photos = new Uri[]{data.getData()};
            }
        }
        ValueCallback<Uri[]> callback = chooser;
        chooser = null;
        callback.onReceiveValue(photos);
    }

    @Override public void onBackPressed() {
        web.evaluateJavascript("window.bearCalendarBack ? window.bearCalendarBack() : false", handled -> {
            if (!"true".equals(handled)) finish();
        });
    }

    @Override protected void onDestroy() {
        if (gold != null) gold.destroy();
        if (weather != null) weather.destroy();
        if (weatherAlerts != null) weatherAlerts.destroy();
        if (chooser != null) chooser.onReceiveValue(null);
        synchronized(audioLock) {
            if (sound != null) { sound.release();sound=null;activeStream=0; }
        }
        if (web != null) {
            web.removeJavascriptInterface("BearGold");
            web.removeJavascriptInterface("BearStore");
            web.removeJavascriptInterface("BearCalendarAudio");
            web.removeJavascriptInterface("BearReminders");
            web.removeJavascriptInterface("BearWeather");
            web.removeJavascriptInterface("BearApp");
            web.removeJavascriptInterface("BearShare");
            web.destroy();
        }
        if(localStore!=null)localStore.close();
        super.onDestroy();
    }
}
