package com.xiongxiong.calendar;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.Address;
import android.location.Geocoder;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import java.net.URLEncoder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.List;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

/** Foreground, opt-in location. Precise permission is requested only by explicit GPS action. */
public final class WeatherController {
    static final int LOCATION_PERMISSION = 43;
    private static final int REQUEST_DEADLINE_MS = 20000;
    private static final String SEARCH_ERROR = "城市搜索暂时连不上，请稍后重试或选择常用城市";
    private final Activity activity;
    private final WebView web;
    private final SharedPreferences preferences;
    private final Handler main = new Handler(Looper.getMainLooper());
    // Searches cannot occupy forecast workers. Two forecast slots let a new city start
    // while a cancelled socket is being closed by the platform.
    private final ExecutorService forecasts = Executors.newFixedThreadPool(2);
    private final ExecutorService searches = Executors.newSingleThreadExecutor();
    private final WeatherNetwork network = new WeatherNetwork();
    private final ExecutorService geocoders = Executors.newFixedThreadPool(2);
    private final ExecutorService locationWorkers = Executors.newFixedThreadPool(3);
    private final ExecutorService locationCacheWorkers = Executors.newFixedThreadPool(2);
    private final LocationPermissionFlow permissionFlow = new LocationPermissionFlow();
    private final NmcCities domesticCities;
    private final LocationManager locations;
    private JSONObject place, weather;
    private final BeijingDistricts beijingDistricts;
    private boolean upgradeLocation;
    private boolean loading, stopped, locationPreparing, recentSelectionPending;
    private String error = "", errorCode = "", phase = "", searchQuery = "";
    private String refreshOutcome = "", refreshNotice = "", refreshAction = "";
    private volatile String snapshot = "{}";
    private int generation, searchGeneration;
    private LocationSession locationSession;
    private int locationGeneration;
    private boolean explicitlyRequestedGps;
    private long nextAutomaticLocationAt;
    private int confirmationGeneration;
    private LocationSession.Fix previewedFix;
    private String previewDistrict;
    private Runnable locationPreparationTimeout, recentSelectionTimeout;
    private JSONObject locationStatus = new JSONObject();
    private Request forecastRequest, searchRequest;

    WeatherController(Activity activity, WebView web) {
        this.activity = activity;
        this.web = web;
        preferences = activity.getSharedPreferences("weather", Context.MODE_PRIVATE);
        domesticCities = new NmcCities(activity);
        beijingDistricts = BeijingDistricts.load(activity);
        locations = (LocationManager) activity.getSystemService(Context.LOCATION_SERVICE);
        place = parse(preferences.getString("place", ""));
        if (place != null && key(place).isEmpty()) place = null;
        // Keep only the user's chosen area. Never restore a forecast or city-result cache.
        weather = null;
        SharedPreferences.Editor migration = preferences.edit().remove("weather").remove("cityCache");
        if (place != null) {
            try {
                upgradeLocation = clearLegacyDistrict(place);
                JSONObject manual = "city".equals(place.optString("source")) ? domesticCities.fromPlace(place) : null;
                if (manual != null) for (String field : new String[]{"displayName","districtName"})
                    if (manual.has(field)) place.put(field,manual.get(field));
                place.put("alertNameAmbiguous", WeatherAlertSelection.ambiguousName(domesticCities, place)); }
            catch (Exception invalid) { }
            migration.putString("place", place.toString());
        }
        migration.apply();
        locationState("idle", "idle", "", null); publish();
    }
    static boolean clearLegacyDistrict(JSONObject saved) throws Exception {
        if (!"location".equals(saved.optString("source")) || saved.optBoolean("districtV28")) return false;
        for (String field : new String[]{"nmcCode","name","admin1","countryCode","alertArea","alertAreaChecked","geoTried"}) saved.remove(field);
        saved.put("name","上次定位位置");
        return true;
    }
    private static JSONObject parse(String value) {
        try { return value == null || value.isEmpty() ? null : new JSONObject(value); } catch (Exception invalid) { return null; }
    }
    private static String key(JSONObject value) {
        if (value == null) return "";
        String coordinates = WeatherRules.placeKey(value.optDouble("latitude", Double.NaN), value.optDouble("longitude", Double.NaN));
        return !coordinates.isEmpty() ? coordinates : value.optString("nmcCode").matches("[A-Za-z0-9]{5,12}") ? "nmc:" + value.optString("nmcCode") : "";
    }
    private static boolean sameSelection(JSONObject previous, JSONObject next) {
        if (previous == null || !key(previous).equals(key(next))) return false;
        for (String field : new String[]{"nmcCode", "source", "name", "admin1", "countryCode"})
            if (!previous.optString(field).equals(next.optString(field))) return false;
        return true;
    }
    private static boolean validWeather(JSONObject value) {
        if (value == null) return false;
        double temperature = value.optDouble("temperature", Double.NaN);
        int code = value.optInt("code", -1);
        return Double.isFinite(temperature) && Math.abs(temperature) <= 100 && code >= ("nmc".equals(value.optString("provider")) ? -1 : 0) && code <= 99
            && value.opt("isDay") instanceof Boolean && value.optLong("updatedAt") > 0;
    }
    @JavascriptInterface public String state() { return snapshot; }
    @JavascriptInterface public void locate() { activity.runOnUiThread(this::requestLocation); }
    @JavascriptInterface public void locatePrecise() { activity.runOnUiThread(() -> requestLocation(true)); }
    @JavascriptInterface public void cancelLocate() {
        activity.runOnUiThread(() -> {
            if (!locating() && !permissionFlow.pending()) return;
            if (locationSession != null && locationSession.running()) { locationSession.stopWaiting(); return; }
            permissionFlow.cancel(); cancelLocation();
            locationState("cancelled", "cancelled", "已停止定位，可以随时重新定位或选择城市", null);
            loading = false; phase = ""; error = ""; errorCode = ""; publish();
        });
    }
    @JavascriptInterface public void locationSettings() {
        activity.runOnUiThread(() -> {
            try { activity.startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)); }
            catch (RuntimeException failure) { fail("请在手机设置中打开定位服务总开关"); }
        });
    }
    @JavascriptInterface public void useRecentLocation() { useLocationCandidate(""); }
    @JavascriptInterface public void useLocationCandidate(String candidateId) {
        activity.runOnUiThread(() -> {
            if (stopped || !permissionFlow.foreground() || forecastRequest != null || locationPreparing || permissionFlow.pending() || recentSelectionPending) return;
            final LocationSession selected = locationSession;
            final int request = locationGeneration;
            if (selected == null || selected.candidate == null) return;
            if (candidateId != null && !candidateId.isEmpty() && !candidateId.equals(candidateId(selected.candidate))) { publish(); return; }
            if (!selected.reserveCandidate()) {
                locationState(selected.running() ? selected.phase : "unavailable", selected.running() ? selected.status : "candidate-expired", "这个位置已过期，请重新定位或选择城市。", selected);
                publish(); return;
            }
            locationState("confirming","checking-candidate","正在核对所选位置…",selected);
            final LocationSession.Fix candidate = selected.candidate;
            final int confirmation = ++confirmationGeneration;
            recentSelectionPending = true; loading = true; phase = "正在确认稍早的位置…"; publish();
            recentSelectionTimeout = () -> {
                if (stopped || request != locationGeneration || confirmation != confirmationGeneration || !recentSelectionPending) return;
                clearRecentSelection();
                locationState("timeout","timeout","确认位置超时，可以重试或选择城市。", selected);
                errorCode = "LOCATION_TIMEOUT"; fail(locationStatus.optString("detail"));
            };
            main.postDelayed(recentSelectionTimeout, 5000);
            // Recheck the current device switch off the UI thread, then revalidate the
            // exact candidate and original fix age. Repeated taps cannot consume it twice.
            locationWorkers.submit(() -> {
                final Boolean service = locationServiceEnabled();
                main.post(() -> {
                    if (stopped || !permissionFlow.foreground() || request != locationGeneration || selected != locationSession || confirmation != confirmationGeneration || !recentSelectionPending) return;
                    clearRecentSelection();
                    if (selected.candidate != candidate || "ready".equals(selected.phase)) return;
                    if (!selected.useRecent(hasCoarse() || hasFine(), Boolean.TRUE.equals(service))) {
                        locationState("unavailable", service == null ? "providers-failed" : service ? "candidate-expired" : "service-off",
                            service == null ? "暂时无法确认手机定位服务，请重试或选择城市" : service ? "稍早的位置已过期或权限已改变，请重新定位或选择城市" : "手机定位总开关已关闭，请开启后重试", null);
                        errorCode = "LOCATION_UNAVAILABLE"; fail(locationStatus.optString("detail"));
                    }
                });
            });
        });
    }
    @JavascriptInterface public void refresh() {
        activity.runOnUiThread(() -> {
            if (!canRefresh()) return;
            if ("location".equals(place.optString("source"))) requestLocation();
            else fetch(place, true);
        });
    }
    @JavascriptInterface public void refreshSavedPlace() {
        activity.runOnUiThread(() -> {
            if (!canRefresh() || !"location".equals(place.optString("source"))) return;
            fetch(place, true, true);
        });
    }
    /** Open/resume requests always contact the source; only an active request is shared. */
    @JavascriptInterface public void refreshNow() { activity.runOnUiThread(this::resume); }
    /** Retained for old UI compatibility; this no longer consults a weather cache. */
    @JavascriptInterface public void refreshIfNeeded() { activity.runOnUiThread(this::resume); }
    @JavascriptInterface public void select(String value) {
        activity.runOnUiThread(() -> {
            if (stopped) return;
            JSONObject input = parse(value);
            if (input == null) return;
            JSONObject domestic = domesticCities.fromPlace(input);
            JSONObject city = domestic == null ? input : domestic;
            double latitude = city.optDouble("latitude", Double.NaN), longitude = city.optDouble("longitude", Double.NaN);
            // An exact domestic city can be queried by its official station code without coordinates.
            if (!WeatherRules.validCoordinates(latitude, longitude) && domestic != null && WeatherRules.validCoordinates(input.optDouble("latitude", Double.NaN), input.optDouble("longitude", Double.NaN))) {
                latitude = input.optDouble("latitude"); longitude = input.optDouble("longitude");
            }
            String label = city.optString("name", "").trim();
            if ((!WeatherRules.validCoordinates(latitude, longitude) && domestic == null) || label.isEmpty() || label.length() > 120) return;
            permissionFlow.cancel(); cancelLocation(); locationState("idle", "idle", "已选择城市", null);
            setPlace(latitude, longitude, label, "city", city, true);
        });
    }
    @JavascriptInterface public void disable() {
        activity.runOnUiThread(() -> {
            generation++; searchGeneration++; permissionFlow.cancel(); cancelLocation(); cancelForecast(); cancelSearch();
            place = null; weather = null; loading = false; error = ""; phase = ""; errorCode = "";
            refreshNotice = ""; refreshOutcome = ""; refreshAction = "";
            locationState("idle", "idle", "", null); preferences.edit().remove("place").remove("weather").remove("cityCache").apply(); publish();
        });
    }
    @JavascriptInterface public void settings() {
        activity.runOnUiThread(() -> {
            try { activity.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + activity.getPackageName()))); }
            catch (RuntimeException failure) { fail("请在手机设置中打开熊熊宝典的位置权限"); }
        });
    }
    @JavascriptInterface public void search(String name) {
        final String query = name == null ? "" : name.trim();
        if (query.length() < 2 || query.length() > 80) return;
        activity.runOnUiThread(() -> {
            if (stopped || (searchRequest != null && query.equals(searchQuery))) return;
            final int request = ++searchGeneration;
            cancelSearch(); searchQuery = query;
            JSONArray local = domesticCities.search(query);
            if (local.length() > 0) { searchQuery = ""; cities(query, local, ""); return; }
            final Request ticket = new Request(); searchRequest = ticket;
            ticket.deadline = () -> {
                if (stopped || searchRequest != ticket || request != searchGeneration) return;
                searchGeneration++; cancelSearch(); cities(query, new JSONArray(), SEARCH_ERROR);
            };
            main.postDelayed(ticket.deadline, 11000);
            ticket.task(searches.submit(() -> {
                JSONArray results = new JSONArray(); String failure = "";
                try {
                    JSONObject response = new JSONObject(network.get("https://geocoding-api.open-meteo.com/v1/search?name=" + URLEncoder.encode(query, "UTF-8") + "&count=8&language=zh&format=json", ticket.operation, 10000));
                    JSONArray rows = response.optJSONArray("results");
                    if (rows != null) for (int index = 0; index < rows.length(); index++) {
                        JSONObject row = rows.getJSONObject(index);
                        double latitude = row.optDouble("latitude", Double.NaN), longitude = row.optDouble("longitude", Double.NaN);
                        if (!WeatherRules.validCoordinates(latitude, longitude)) continue;
                        JSONObject city = new JSONObject().put("name", row.optString("name"))
                            .put("region", row.optString("admin1") + " · " + row.optString("country"))
                            .put("admin1", row.optString("admin1")).put("countryCode", row.optString("country_code"))
                            .put("latitude", latitude).put("longitude", longitude);
                        JSONObject domestic = domesticCities.fromPlace(city);
                        if (domestic != null) city.put("nmcCode", domestic.getString("nmcCode"));
                        results.put(city);
                    }
                } catch (Exception unavailable) { failure = SEARCH_ERROR; }
                final JSONArray found = results; final String message = failure;
                main.post(() -> {
                    if (stopped || request != searchGeneration || searchRequest != ticket) return;
                    finish(ticket); searchRequest = null; searchQuery = ""; cities(query, found, message);
                });
            }));
        });
    }
    private void cities(String query, JSONArray results, String failure) {
        try { callback("bearWeatherCities", new JSONObject().put("query", query).put("results", results).put("error", failure)); }
        catch (Exception ignored) { }
    }
    private boolean hasCoarse() { return activity.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED; }
    private boolean hasFine() { return activity.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED; }
    private String locationPermission() { return LocationPermissionFlow.permission(hasCoarse(), hasFine()); }
    private boolean locating() { return locationPreparing || locationSession != null && locationSession.running(); }
    private Boolean locationServiceEnabled() {
        if (locations == null) return false;
        try {
            return Build.VERSION.SDK_INT >= 28 ? locations.isLocationEnabled()
                : Settings.Secure.getInt(activity.getContentResolver(), Settings.Secure.LOCATION_MODE, Settings.Secure.LOCATION_MODE_OFF) != Settings.Secure.LOCATION_MODE_OFF;
        } catch (RuntimeException unavailable) { return null; } // Unknown is not evidence that the global switch is on or off.
    }
    private void requestLocation() { requestLocation(false); }
    private void requestLocation(boolean precise) {
        if (stopped || !permissionFlow.foreground() || permissionFlow.dialogOpen()) return;
        explicitlyRequestedGps = precise;
        cancelLocation(); generation++; cancelForecast();
        refreshOutcome = ""; refreshNotice = ""; refreshAction = "locate"; errorCode = ""; error = "";
        boolean coarse = hasCoarse(), fine = hasFine();
        if (LocationPermissionFlow.needsRequest(coarse, fine, precise)) {
            String permission = precise ? Manifest.permission.ACCESS_FINE_LOCATION : Manifest.permission.ACCESS_COARSE_LOCATION;
            String askedKey = precise ? "askedFine" : "asked";
            boolean asked = preferences.getBoolean(askedKey, false);
            if (asked && !activity.shouldShowRequestPermissionRationale(permission)) {
                if (coarse || fine) { locateNow(); return; }
                locationState("permission", "permission-denied", "尚未允许位置权限，可以到应用权限设置允许大致位置，或选择城市", null);
                errorCode = "LOCATION_UNAVAILABLE"; fail(locationStatus.optString("detail")); return;
            }
            permissionFlow.begin(); loading = true; phase = "等待位置授权…";
            locationState("permission", "permission-pending", precise ? "可选择精确位置用于 GPS；仅允许大致位置也可以查询天气" : "允许大致位置即可查询附近天气", null);
            preferences.edit().putBoolean(askedKey, true).putBoolean("asked", true).apply(); publish();
            // Android 12 must receive FINE + COARSE together, and may grant only COARSE.
            try { activity.requestPermissions(precise ? new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}
                : new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_PERMISSION); }
            catch (RuntimeException failed) { permissionFlow.resolve(false, false); if (hasCoarse() || hasFine()) locateNow(); else { locationState("permission", "permission-denied", "无法打开授权窗口，可以到应用权限设置允许大致位置", null); errorCode = "LOCATION_UNAVAILABLE"; fail(locationStatus.optString("detail")); } }
            return;
        }
        locateNow();
    }
    void permissionResult() {
        LocationPermissionFlow.Result result = permissionFlow.resolve(hasCoarse(), hasFine());
        if (stopped || result == LocationPermissionFlow.Result.IGNORED) return;
        if (result == LocationPermissionFlow.Result.READY) locateNow();
        else if (result == LocationPermissionFlow.Result.DENIED) {
            locationState("permission", "permission-denied", "未允许位置权限，仍可手动选择城市看天气", null);
            errorCode = "LOCATION_UNAVAILABLE"; fail(locationStatus.optString("detail"));
        }
        // DEFERRED remains pending in the UI until the actual Activity onResume callback.
    }
    private void locateNow() {
        cancelLocation(); generation++; cancelForecast();
        final int request = locationGeneration;
        final String permission = locationPermission();
        final boolean fine = "precise".equals(permission);
        locationPreparing = true; loading = true; phase = "正在连接手机定位服务…"; error = ""; errorCode = ""; refreshNotice = ""; refreshOutcome = "";
        locationState("locating", "preparing", "位置权限已允许，正在检查可用的定位来源", null); publish();
        locationPreparationTimeout = () -> {
            if (stopped || request != locationGeneration || !locationPreparing) return;
            cancelLocation(); locationState("unavailable", "providers-failed", "位置权限已允许，但手机定位服务没有及时响应；可以重试或选择城市", null);
            errorCode = "LOCATION_TIMEOUT"; fail(locationStatus.optString("detail"));
        };
        main.postDelayed(locationPreparationTimeout, 5000);
        // Discovery, registration and cached-location Binder calls must not freeze the sheet.
        locationWorkers.submit(() -> {
            Boolean enabled = locationServiceEnabled();
            List<String> advertised = new ArrayList<>(); Set<String> available = new HashSet<>();
            try {
                if (locations != null) advertised = locations.getAllProviders();
                for (String provider : advertised) {
                    try { if (locations.isProviderEnabled(provider)) available.add(provider); }
                    catch (RuntimeException unavailable) { /* This provider cannot block the others. */ }
                }
            } catch (RuntimeException unavailable) { }
            final Boolean service = enabled;
            final List<String> providers = LocationSession.chooseProviders(advertised, available, fine);
            main.post(() -> {
                if (stopped || request != locationGeneration || !locationPreparing) return;
                locationPreparing = false;
                if (locationPreparationTimeout != null) main.removeCallbacks(locationPreparationTimeout);
                locationPreparationTimeout = null;
                locationSession = new LocationSession(permission, service, providers, explicitlyRequestedGps,
                    (provider, events) -> new AndroidLocationSubscription(provider, events), SystemClock::elapsedRealtimeNanos,
                    (delay, task) -> { main.postDelayed(task, delay); return () -> main.removeCallbacks(task); },
                    new LocationSession.Observer() {
                        public void changed(LocationSession session) {
                            if (stopped || request != locationGeneration || locationSession != session) return;
                            locationState(session.phase, session.status, session.detail, session);
                            if (session.running()) { loading = true; phase = "正在获取手机位置，最多 " + session.waitMs()/1000 + " 秒…"; publish(); }
                            else if ("cancelled".equals(session.phase)) { loading = false; phase = ""; error = ""; errorCode = ""; publish(); }
                            else if (!"ready".equals(session.phase)) { errorCode = "timeout".equals(session.phase) ? "LOCATION_TIMEOUT" : "LOCATION_UNAVAILABLE"; fail(session.detail); }
                        }
                        public void accepted(LocationSession.Fix fix, boolean recent) {
                            if (!stopped && request == locationGeneration) acceptLocation(fix, recent);
                        }
                    });
                locationSession.start();
            });
        });
    }
    private final class AndroidLocationSubscription implements LocationSession.Cancel {
        private volatile boolean cancelled;
        private final LocationListener listener;
        AndroidLocationSubscription(String provider, LocationSession.Events events) {
            listener = new LocationListener() {
                @Override public void onLocationChanged(Location location) { if (!cancelled) events.fix(locationFix(location)); }
                @Override public void onProviderDisabled(String name) { if (!cancelled) events.failed("disabled"); }
                @Override public void onProviderEnabled(String name) { }
                @Override public void onStatusChanged(String name, int status, Bundle extras) { }
            };
            locationWorkers.submit(() -> {
                if (cancelled) return;
                try {
                    locations.requestLocationUpdates(provider, 0, 0, listener, Looper.getMainLooper());
                    if (cancelled) { remove(); return; }
                    // Read cache after registering so a stale/blocked cache cannot postpone updates.
                    locationCacheWorkers.submit(() -> {
                        if (cancelled) return;
                        try {
                            LocationSession.Fix fix = locationFix(locations.getLastKnownLocation(provider));
                            if (fix != null) main.post(() -> { if (!cancelled) events.cached(fix); });
                        } catch (RuntimeException cacheUnavailable) { /* Live updates can still succeed. */ }
                    });
                } catch (RuntimeException failure) {
                    main.post(() -> { if (!cancelled) events.failed(failure instanceof SecurityException ? "provider-permission" : "provider-unavailable"); });
                } finally { if (cancelled) remove(); }
            });
        }
        private void remove() { try { locations.removeUpdates(listener); } catch (RuntimeException ignored) { } }
        public void cancel() {
            cancelled = true;
            if (!locationWorkers.isShutdown()) locationWorkers.submit(this::remove);
        }
    }
    private static LocationSession.Fix locationFix(Location location) {
        if (location == null) return null;
        long age = LocationRules.ageMs(location.getElapsedRealtimeNanos(), SystemClock.elapsedRealtimeNanos());
        return new LocationSession.Fix(location.getLatitude(), location.getLongitude(), location.hasAccuracy() ? location.getAccuracy() : Double.NaN,
            location.getElapsedRealtimeNanos(), age < 0 ? 0 : System.currentTimeMillis() - age, location.getProvider());
    }
    private String candidateId(LocationSession.Fix fix) {
        return locationGeneration + "/" + fix.provider + "/" + fix.elapsedNanos;
    }
    private void locationState(String phase, String status, String detail, LocationSession session) {
        if ("timeout".equals(phase) || "unavailable".equals(phase) || "cancelled".equals(phase))
            nextAutomaticLocationAt = SystemClock.elapsedRealtime() + 60000;
        try {
            JSONObject next = new JSONObject().put("permission", locationPermission()).put("serviceEnabled", session == null ? ("service-off".equals(status) ? false : JSONObject.NULL) : session.serviceEnabled == null ? JSONObject.NULL : session.serviceEnabled)
                .put("providers", session == null ? new JSONArray() : new JSONArray(session.providers))
                .put("phase", phase).put("status", status).put("detail", detail);
            if (session != null) {
                next.put("activeProviders", new JSONArray(session.activeProviders)).put("providerErrors", new JSONObject(session.failures));
                next.put("lastRejection", session.lastRejection);
                if (session.usableCandidate()) {
                    LocationSession.Fix fix = session.candidate;
                    if (fix != previewedFix) {
                        previewedFix = fix;
                        previewDistrict = beijingDistricts.district(fix.latitude, fix.longitude, fix.accuracyMeters, 150);
                    }
                    next.put("candidate", new JSONObject().put("id",candidateId(fix)).put("selectable",true).put("district",previewDistrict == null || previewDistrict.isEmpty() ? "" : "北京市 · " + previewDistrict).put("locatedAt", fix.locatedAt).put("accuracyMeters", Math.round(fix.accuracyMeters))
                        .put("ageMs", LocationRules.ageMs(fix.elapsedNanos, SystemClock.elapsedRealtimeNanos())).put("provider", fix.provider)
                        .put("awaitedGps", "precise".equals(session.permission) && session.providers.contains("gps")));
                }
            }
            locationStatus = next;
        } catch (Exception ignored) { }
    }
    private void acceptLocation(LocationSession.Fix location, boolean recent) {
        nextAutomaticLocationAt = 0;
        try {
            long age = LocationRules.ageMs(location.elapsedNanos, SystemClock.elapsedRealtimeNanos());
            JSONObject fix = new JSONObject().put("locatedAt", location.locatedAt)
                .put("accuracyMeters", Math.round(location.accuracyMeters)).put("locationAgeMs", age).put("locationRecent", recent).put("fixProvider", location.provider);
            String district = beijingDistricts.district(location.latitude, location.longitude, location.accuracyMeters, 150);
            if (district != null) {
                JSONObject local = beijingPlace(district);
                if (local != null) {
                    fix.put("nmcCode", local.getString("nmcCode")).put("admin1","北京市").put("countryCode","CN")
                        .put("alertArea",local.getJSONObject("alertArea"));
                }
            }
            // Every accepted user action resolves its area again and forces weather retrieval,
            // even when the coordinates round to the same area as the previous fix.
            setPlace(location.latitude, location.longitude, "定位附近", "location", fix, true);
        } catch (Exception invalid) { errorCode = "LOCATION_UNAVAILABLE"; fail("定位资料不可用，请重新定位或选择城市"); }
    }
    private void setPlace(double latitude, double longitude, String name, String source, JSONObject metadata, boolean force) {
        JSONObject trusted = metadata == null ? null : domesticCities.fromPlace(metadata);
        if (!WeatherRules.validCoordinates(latitude, longitude) && trusted == null) { fail("位置不可用，请重新选择城市"); return; }
        try {
            JSONObject next = new JSONObject().put("name", name).put("source", source);
            WeatherDistrictRules.coordinates(next, latitude, longitude, "location".equals(source));
            if (metadata != null) for (String field : new String[]{"region", "admin1", "countryCode"}) {
                String text = metadata.optString(field, "").trim();
                if (!text.isEmpty() && text.length() <= 120) next.put(field, text);
            }
            if (trusted != null) {
                next.put("nmcCode", trusted.getString("nmcCode"));
                if ("city".equals(source)) for (String field : new String[]{"displayName","districtName"})
                    if (trusted.has(field)) next.put(field,trusted.getString(field));
            }
            next.put("alertNameAmbiguous", WeatherAlertSelection.ambiguousName(domesticCities, next));
            boolean same = place != null && key(place).equals(key(next));
            if ("location".equals(source) && metadata != null) {
                if (metadata.optJSONObject("alertArea") != null) {
                    JSONObject area = metadata.getJSONObject("alertArea");
                    next.put("alertArea",area).put("name",locationName(area,"北京市"));
                    if (!area.optString("district").isEmpty()) next.put("districtLookupV30",true).put("geoTried",true).put("alertAreaChecked",true);
                }
                next.put("districtV28", true).put("fixProvider", metadata.optString("fixProvider")).put("locatedAt", metadata.optLong("locatedAt"))
                    .put("accuracyMeters", metadata.optLong("accuracyMeters"))
                    .put("locationAgeMs", metadata.optLong("locationAgeMs")).put("locationRecent", metadata.optBoolean("locationRecent"));
            }
            if (!sameSelection(place, next)) { generation++; cancelForecast(); }
            if (!same || place != null && !place.optString("nmcCode").equals(next.optString("nmcCode"))) weather = null;
            upgradeLocation = false;
            place = next;
            loading = forecastRequest != null; phase = loading ? "正在更新天气…" : ""; error = ""; errorCode = ""; refreshNotice = ""; refreshOutcome = "";
            preferences.edit().putString("place", place.toString()).apply();
            publish(); fetch(place, force);
        } catch (Exception invalid) { fail("位置不可用，请重新选择城市"); }
    }
    private void fetch(JSONObject selected, boolean force) { fetch(selected, force, false); }
    private void fetch(JSONObject selected, boolean force, boolean useSavedLocation) {
        if (stopped || selected == null || forecastRequest != null) return;
        final JSONObject chosen = parse(selected.toString());
        final JSONObject knownDomestic = domesticCities.fromPlace(chosen);
        // Every completed user action/foreground entry creates a new network request.
        // Existing on-screen data is used only to explain the response, never to skip it.
        final int request = ++generation;
        final Request ticket = new Request(); forecastRequest = ticket;
        loading = true; phase = useSavedLocation ? "正在按上次保存的位置查询天气…" : knownDomestic == null ? "正在获取天气…" : "正在连接国内天气源…";
        error = ""; errorCode = ""; refreshNotice = useSavedLocation ? "此次使用上次保存的位置，未重新定位。" : ""; refreshOutcome = "";
        refreshAction = useSavedLocation ? "saved-location" : force ? ("location".equals(selected.optString("source")) ? "locate" : "city") : "auto"; publish();
        ticket.deadline = () -> {
            if (stopped || forecastRequest != ticket || request != generation) return;
            generation++; cancelForecast(); errorCode = "TIMEOUT"; fail(networkError());
        };
        main.postDelayed(ticket.deadline, REQUEST_DEADLINE_MS);
        ticket.task(forecasts.submit(() -> {
            JSONObject result = null, resolved = knownDomestic;
            String failureCode = "";
            try {
                if (WeatherDistrictRules.needsLookup(chosen) && !ticket.cancelled()) {
                    JSONObject identified = locateDomestic(chosen, ticket);
                    resolved = WeatherDistrictRules.apply(chosen, knownDomestic, identified);
                    persistAlertMetadata(chosen, request, ticket);
                }
                if (resolved != null) {
                    chosen.put("nmcCode", resolved.getString("nmcCode"));
                    chosen.put("admin1", resolved.getString("admin1")).put("countryCode", "CN");
                    if ("location".equals(chosen.optString("source"))) {
                        JSONObject area = resolved.optJSONObject("alertArea");
                        if (area == null) area = chosen.optJSONObject("alertArea");
                        chosen.put("name", locationName(area, resolved.optString("admin1")));
                    }
                    if (resolved.optJSONObject("alertArea") != null) chosen.put("alertArea", resolved.getJSONObject("alertArea"));
                    try {
                        String raw = network.get("https://www.nmc.cn/rest/real/" + resolved.getString("nmcCode"), ticket.operation, 6000);
                        result = NmcWeatherData.parse(raw, resolved.getString("nmcCode"), System.currentTimeMillis());
                    } catch (Exception unavailable) { failureCode = "NMC_" + WeatherNetwork.errorCode(unavailable); }
                }
                if (needsModel(result) && !ticket.cancelled()) {
                    final boolean missingSky = result != null;
                    main.post(() -> {
                        if (!stopped && request == generation && forecastRequest == ticket) {
                            phase = missingSky ? "正在查询当前晴雨…" : "正在获取天气…"; publish();
                        }
                    });
                    try {
                        JSONObject point = chosen;
                        if (!hasCoordinates(point) && resolved != null) {
                            String query = URLEncoder.encode(resolved.getString("name"), "UTF-8");
                            String list = network.get("https://www.nmc.cn/essearch/api/autocomplete?q=" + query, ticket.operation, 2800);
                            point = stationPoint(resolved, list);
                        }
                        if (!hasCoordinates(point)) throw new IllegalArgumentException("Missing coordinates");
                        result = openMeteo(point, ticket);
                    } catch (Exception unavailable) {
                        failureCode = (failureCode.isEmpty() ? "" : failureCode + "/") + "OPEN_METEO_" + WeatherNetwork.errorCode(unavailable);
                        if (result != null) result.put("skyUnavailable", true);
                    }
                }
                if (result != null) {
                    if (!validWeather(result)) { result = null; throw new IllegalArgumentException("Invalid weather response"); }
                    result.put("placeKey", key(chosen));
                    if ("nmc".equals(result.optString("provider"))) result.put("stationName", result.optString("city", resolved == null ? "" : resolved.optString("name")));
                }
            } catch (Exception invalid) { failureCode = WeatherNetwork.errorCode(invalid); }
            final JSONObject received = result; final String failed = failureCode;
            main.post(() -> {
                if (stopped || request != generation || forecastRequest != ticket) return;
                finish(ticket); forecastRequest = null;
                loading = false; phase = ""; errorCode = received == null ? (failed.isEmpty() ? "UNAVAILABLE" : failed) : "";
                place = chosen;
                SharedPreferences.Editor edit = preferences.edit().putString("place", chosen.toString());
                if (received == null && weather != null && "nmc".equals(weather.optString("provider"))
                    && !chosen.optString("nmcCode").equals(weather.optString("nmcCode"))) {
                    // A newly resolved district cannot wear the previous station's temperature.
                    weather = null;
                }
                error = received == null ? networkError() : "";
                if (received != null) {
                    refreshOutcome = observationOutcome(weather, received);
                    long checked = System.currentTimeMillis();
                    try {
                        if ("older".equals(refreshOutcome)) {
                            // The source went backwards: retain the newer sample, but record
                            // that an actual network check has just completed.
                            weather.put("checkedAt", checked);
                            refreshNotice = "已重新联网查询，来源返回的资料更早，当前画面保留本次会话中已查到的较新资料。";
                        } else {
                            if ("same".equals(refreshOutcome) || "revised".equals(refreshOutcome)) {
                                received.put("updatedAt", weather.optLong("updatedAt"));
                                refreshNotice = "revised".equals(refreshOutcome) ? "来源修订了同一时刻的资料，已显示修订内容。" : "查询成功，天气数据与上次相同。";
                            } else refreshNotice = "source-changed".equals(refreshOutcome) ? "已切换天气来源，资料时间见下方。" : "已取得新的天气资料。";
                            received.put("checkedAt", checked); weather = received;
                        }
                    } catch (Exception invalid) { errorCode = "INVALID_RESPONSE"; error = networkError(); refreshOutcome = "failed"; refreshNotice = "此次更新未完成，保留原有资料。"; }
                } else { refreshOutcome = "failed"; refreshNotice = "此次未取得新资料，保留的天气不会标记为已更新。"; }
                if (useSavedLocation) refreshNotice = "按上次保存的位置查询，未重新定位。" + refreshNotice;
                edit.apply(); publish();
            });
        }));
    }
    private void persistAlertMetadata(JSONObject chosen, int request, Request ticket) {
        final JSONObject metadata = parse(chosen.toString());
        main.post(() -> {
            if (stopped || request != generation || forecastRequest != ticket || place == null || metadata == null) return;
            try {
                if (weather != null && "nmc".equals(weather.optString("provider"))
                    && !metadata.optString("nmcCode").equals(weather.optString("nmcCode"))) weather=null;
                for (String field : new String[]{"name","admin1","countryCode","nmcCode","alertArea","alertAreaChecked","geoTried","districtLookupV30"})
                    if (metadata.has(field)) place.put(field,metadata.get(field));
                preferences.edit().putString("place", place.toString()).apply();
                publish();
            } catch (Exception invalid) { }
        });
    }
    static String locationName(JSONObject area, String province) {
        if (area == null) return province.isEmpty() ? "定位附近" : province + "（区县未确认）";
        String city = area.optString("city"), district = area.optString("district");
        String parent = city.isEmpty() ? province : city;
        return district.isEmpty() ? parent + "（区县未确认）" : parent + " · " + district;
    }

    private JSONObject beijingPlace(String district) {
        try {
            JSONObject station = district.isEmpty() ? null : domesticCities.resolve("北京市", district);
            if (station == null) station = domesticCities.resolve("北京市", "北京");
            JSONObject area = new JSONObject().put("province","北京市").put("city","北京市")
                .put("district",district).put("districtUnique",!district.isEmpty()).put("source","district-boundary");
            return station == null ? null : station.put("alertArea",area);
        } catch (Exception invalid) { return null; }
    }

    private JSONObject locateDomestic(JSONObject chosen, Request ticket) {
        double margin = WeatherDistrictRules.margin(chosen);
        String boundaryDistrict = beijingDistricts.district(chosen.optDouble("latitude"), chosen.optDouble("longitude"), chosen.optDouble("accuracyMeters"), margin);
        JSONObject fallback = boundaryDistrict == null ? null : beijingPlace(boundaryDistrict);
        if (boundaryDistrict != null && !boundaryDistrict.isEmpty()) return fallback;
        // City-only geometry is not a completed district lookup. Try the address service
        // with the actual fix, then check its district against the local boundary.
        if (!Geocoder.isPresent()) return fallback;
        Future<JSONObject> work = geocoders.submit(() -> {
            Geocoder geocoder = new Geocoder(activity, Locale.SIMPLIFIED_CHINESE);
            List<Address> addresses = geocoder.getFromLocation(chosen.optDouble("latitude"), chosen.optDouble("longitude"), 1);
            if (addresses == null || addresses.isEmpty()) return null;
            Address address = addresses.get(0);
            if (!"CN".equalsIgnoreCase(address.getCountryCode())) return null;
            // A wide approximate fix uses only the locality (city), never sublocality
            // or sub-administrative county. Narrow fixes may use an exact unique district.
            boolean district = LocationRules.districtEligible(chosen.optDouble("accuracyMeters", Double.NaN));
            JSONObject found = district ? domesticCities.resolve(address.getAdminArea(), address.getSubLocality()) : null;
            String locality = address.getLocality();
            if (found == null && (district || locality != null && !locality.endsWith("区") && !locality.endsWith("县")))
                found = domesticCities.resolve(address.getAdminArea(), locality);
            if (found == null && district) found = domesticCities.resolve(address.getAdminArea(), address.getSubAdminArea());
            JSONObject alertArea = WeatherAlertArea.fromGeocoder(domesticCities, found, address.getCountryCode(),
                address.getAdminArea(), address.getLocality(), address.getSubAdminArea(), address.getSubLocality(),
                chosen.optDouble("accuracyMeters", Double.NaN));
            if (found != null && "北京市".equals(found.optString("admin1"))) {
                String named = alertArea == null ? "" : alertArea.optString("district");
                if (!named.isEmpty() && beijingDistricts.compatible(named,chosen.optDouble("latitude"),chosen.optDouble("longitude"),chosen.optDouble("accuracyMeters"),margin)) {
                    found = domesticCities.resolve("北京市",named);
                } else {
                    // Never allow an address claiming Changping to rename a Fengtai fix.
                    return fallback;
                }
            } else if (alertArea != null && !alertArea.optString("district").isEmpty()) {
                JSONObject localStation = domesticCities.resolve(alertArea.optString("province"), alertArea.optString("district"));
                if (localStation != null) found = localStation;
            }
            if (found != null && alertArea != null) found.put("alertArea", alertArea);
            return found;
        });
        ticket.geocoder = work;
        try { JSONObject identified=work.get(4000, TimeUnit.MILLISECONDS); return identified == null ? fallback : identified; }
        catch (InterruptedException cancelled) { Thread.currentThread().interrupt(); return fallback; }
        catch (Exception unavailable) { return fallback; }
        finally { work.cancel(true); ticket.geocoder = null; }
    }
    static boolean hasCoordinates(JSONObject point) {
        return point != null && WeatherRules.validCoordinates(point.optDouble("latitude", Double.NaN), point.optDouble("longitude", Double.NaN));
    }
    static boolean needsModel(JSONObject observation) {
        return observation == null || (observation.optInt("code", -1) < 0 && observation.optString("conditionText","").trim().isEmpty());
    }
    static JSONObject stationPoint(JSONObject station, String response) throws Exception {
        JSONObject body = new JSONObject(response);
        if (body.optInt("code",-1) != 0) return null;
        JSONArray rows = body.optJSONArray("data");
        if (rows == null) return null;
        for (int i = 0; i < rows.length(); i++) {
            String[] fields = rows.optString(i).split("\\|", -1);
            if (fields.length != 6 || !station.optString("nmcCode").equals(fields[0])
                || !station.optString("name").equals(fields[1]) || !station.optString("admin1").equals(fields[2])) continue;
            double lon = Double.parseDouble(fields[4]), lat = Double.parseDouble(fields[5]);
            if (WeatherRules.validCoordinates(lat,lon)) return new JSONObject().put("latitude",lat).put("longitude",lon);
        }
        return null;
    }

    private JSONObject openMeteo(JSONObject selected, Request ticket) throws Exception {
        String url = "https://api.open-meteo.com/v1/forecast?latitude=" + (Math.round(selected.optDouble("latitude")*100)/100d) + "&longitude=" + (Math.round(selected.optDouble("longitude")*100)/100d)
            + "&current=temperature_2m,weather_code,is_day,wind_speed_10m,wind_direction_10m,wind_gusts_10m&wind_speed_unit=ms&timezone=auto&forecast_days=1";
        JSONObject response = new JSONObject(network.get(url, ticket.operation, 6500));
        return modelReport(response, System.currentTimeMillis());
    }
    static JSONObject modelReport(JSONObject response, long now) throws Exception {
        JSONObject current = response.getJSONObject("current");
        double temperature = current.getDouble("temperature_2m");
        Object raw = current.opt("weather_code");
        if (!(raw instanceof Number)) throw new IllegalArgumentException("Missing weather code");
        int code = ((Number)raw).intValue(), isDay = current.getInt("is_day");
        if (((Number)raw).doubleValue() != code || !WeatherRules.knownSky(code)) throw new IllegalArgumentException("Unknown weather code");
        if (!Double.isFinite(temperature) || Math.abs(temperature) > 100 || code < 0 || code > 99 || (isDay != 0 && isDay != 1)) throw new IllegalArgumentException("Invalid forecast");
        JSONObject units = response.optJSONObject("current_units");
        long observedAt = modelObservedAt(response, now);
        return new JSONObject().put("temperature", temperature).put("code", code).put("isDay", isDay == 1)
            .put("observedTime", current.getString("time")).put("observedAt", observedAt).put("timezone", response.optString("timezone"))
            .put("windSpeed", wind(current, units, "wind_speed_10m", false))
            .put("windDirection", wind(current, units, "wind_direction_10m", true))
            .put("windGust", wind(current, units, "wind_gusts_10m", false))
            .put("provider", "open-meteo").put("sourceLabel", "Open-Meteo 模型数据").put("sourceUrl", "https://open-meteo.com/")
            .put("updatedAt", System.currentTimeMillis());
    }
    private static String observationOutcome(JSONObject previous, JSONObject next) {
        if (previous == null || next == null) return "new";
        String provider = next.optString("provider", "");
        if (provider.isEmpty() || previous.optString("provider").isEmpty()) return "new";
        if (!provider.equals(previous.optString("provider"))) return "source-changed";
        String scopeField = "nmc".equals(provider) ? "nmcCode" : "placeKey";
        String scope = next.optString(scopeField, "");
        if (scope.isEmpty() || !scope.equals(previous.optString(scopeField))) return "new";
        long before = previous.optLong("observedAt"), after = next.optLong("observedAt");
        if (before <= 0 || after <= 0) return "new";
        if (after < before) return "older";
        if (after > before) return "new";
        for (String field : new String[]{"temperature", "code", "conditionText", "windSpeed", "windDirection", "windGust", "windDirectionText", "windPower"}) {
            Object a = previous.opt(field), b = next.opt(field);
            if (a == JSONObject.NULL) a = null;
            if (b == JSONObject.NULL) b = null;
            if (a instanceof Number && b instanceof Number) {
                if (Double.compare(((Number)a).doubleValue(), ((Number)b).doubleValue()) != 0) return "revised";
            } else if (a == null ? b != null : !a.equals(b)) return "revised";
        }
        // isDay can change because the current clock crossed sunrise/sunset; this is
        // not a revision to the source observation. Its derived presentation may update.
        return "same";
    }
    private static long modelObservedAt(JSONObject response, long now) throws Exception {
        java.time.LocalDateTime local = java.time.LocalDateTime.parse(response.getJSONObject("current").getString("time"));
        long observed = local.toInstant(java.time.ZoneOffset.ofTotalSeconds(response.getInt("utc_offset_seconds"))).toEpochMilli();
        if (observed <= 0 || observed > now + 300000L || now - observed > 10800000L) throw new IllegalArgumentException("STALE_DATA");
        return observed;
    }
    private static Object wind(JSONObject current, JSONObject units, String field, boolean direction) {
        if (units == null || !(direction ? "°" : "m/s").equals(units.optString(field))) return JSONObject.NULL;
        Double value = WeatherRules.wind(current.optDouble(field, Double.NaN), direction);
        return value == null ? JSONObject.NULL : value;
    }
    private String networkError() {
        return weather == null ? "天气来源暂时没有连通，请稍后重试；定位查询失败时，可手动选择国内城市。" : "天气暂时未能更新，已保留上次结果，请稍后重试。";
    }
    private final class Request {
        final WeatherNetwork.Operation operation = network.operation();
        private Future<?> task;
        volatile Future<?> geocoder;
        Runnable deadline;
        synchronized void task(Future<?> value) { task = value; if (operation.cancelled()) value.cancel(true); }
        boolean cancelled() { return operation.cancelled(); }
        void cancel() {
            operation.cancel();
            synchronized (this) { if (task != null) task.cancel(true); }
            Future<?> lookup = geocoder; if (lookup != null) lookup.cancel(true);
        }
    }
    private void finish(Request ticket) { if (ticket.deadline != null) main.removeCallbacks(ticket.deadline); }
    private void cancelForecast() { if (forecastRequest != null) { finish(forecastRequest); forecastRequest.cancel(); forecastRequest = null; } }
    private void cancelSearch() { if (searchRequest != null) { finish(searchRequest); searchRequest.cancel(); searchRequest = null; } searchQuery = ""; }
    private void fail(String message) { loading = false; phase = ""; error = message; refreshOutcome = "failed"; refreshNotice = ("saved-location".equals(refreshAction) ? "按上次保存的位置查询，未重新定位。" : "") + "此次未取得新资料，原有资料时间保持不变。"; publish(); }
    private void publish() {
        try {
            JSONObject state = new JSONObject().put("native", true).put("place", place == null ? JSONObject.NULL : place)
                .put("weather", weather == null ? JSONObject.NULL : weather).put("loading", loading).put("phase", phase).put("error", error).put("errorCode", errorCode)
                .put("checkedAt", weather == null ? 0 : weather.optLong("checkedAt", weather.optLong("updatedAt")))
                .put("refreshOutcome", refreshOutcome).put("refreshNotice", refreshNotice).put("refreshAction", refreshAction)
                .put("locationStatus", locationStatus);
            snapshot = state.toString(); callback("bearWeatherChanged", state);
        } catch (Exception ignored) { }
    }
    private void callback(String function, JSONObject value) {
        if (!stopped) web.evaluateJavascript("window." + function + " && window." + function + "(" + JSONObject.quote(value.toString()) + ")", null);
    }
    void foreground() {
        if (stopped) return;
        if (permissionFlow.enterForeground()) locateNow();
        else resume();
    }
    private boolean canRefresh() {
        return WeatherRefreshRules.canStart(stopped, permissionFlow.foreground(), place != null,
            loading || forecastRequest != null, permissionFlow.pending(), locating(), recentSelectionPending);
    }
    void resume() {
        if (canRefresh()) {
            long age = System.currentTimeMillis() - place.optLong("locatedAt");
            boolean oldFix = "location".equals(place.optString("source")) && (age < 0 || age > LocationRules.CURRENT_MS);
            if ((upgradeLocation || oldFix) && (hasFine() || hasCoarse())) {
                if (SystemClock.elapsedRealtime() < nextAutomaticLocationAt) return;
                upgradeLocation = false;
                requestLocation();
            } else fetch(place, false, oldFix);
        }
    }
    void pause() {
        permissionFlow.leaveForeground();
        // A runtime permission dialog can pause the Activity before delivering its result.
        if (permissionFlow.pending()) return;
        if (locating() || recentSelectionPending) {
            cancelLocation(); locationState("cancelled", "cancelled", "已暂停定位，回到这里后可重新点击定位", null);
            errorCode = "LOCATION_UNAVAILABLE"; fail(locationStatus.optString("detail"));
        }
    }
    private void clearRecentSelection() {
        recentSelectionPending = false;
        if (recentSelectionTimeout != null) { main.removeCallbacks(recentSelectionTimeout); recentSelectionTimeout = null; }
    }
    private void cancelLocation() {
        locationGeneration++; previewedFix = null; previewDistrict = null; locationPreparing = false; permissionFlow.cancel(); clearRecentSelection();
        if (locationPreparationTimeout != null) { main.removeCallbacks(locationPreparationTimeout); locationPreparationTimeout = null; }
        if (locationSession != null) { locationSession.cancel(); locationSession = null; }
    }
    void destroy() {
        stopped = true; generation++; searchGeneration++; permissionFlow.cancel();
        cancelLocation(); cancelForecast(); cancelSearch(); forecasts.shutdownNow(); searches.shutdownNow(); geocoders.shutdownNow(); locationWorkers.shutdown(); locationCacheWorkers.shutdownNow(); network.destroy();
    }
}
