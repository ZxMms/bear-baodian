package com.xiongxiong.calendar;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;
import org.json.JSONObject;

/** Compact current observations from NMC's public city page, never forecast substituted as current. */
final class NmcWeatherData {
    static final long MAX_OBSERVATION_AGE_MS = 3 * 60 * 60 * 1000L;
    private static final TimeZone CHINA = TimeZone.getTimeZone("Asia/Shanghai");
    private NmcWeatherData() { }

    static JSONObject parse(String raw, String expectedCode, long now) throws Exception {
        if (expectedCode == null || !expectedCode.matches("[A-Za-z0-9]{1,16}")) throw new IllegalArgumentException("Invalid station code");
        JSONObject real = new JSONObject(raw);
        JSONObject station = real.getJSONObject("station"), conditions = real.getJSONObject("weather");
        if (!expectedCode.equals(station.getString("code"))) throw new IllegalArgumentException("Different weather station");
        String city = text(station.optString("city", ""), 60), province = text(station.optString("province", ""), 60);
        if (city.isEmpty() || province.isEmpty()) throw new IllegalArgumentException("Missing station identity");
        String observedTime = real.getString("publish_time");
        long observedAt = chinaTime(observedTime);
        if (observedAt <= 0) throw new IllegalArgumentException("INVALID_RESPONSE");
        if (observedAt > now + 300000L || now - observedAt > MAX_OBSERVATION_AGE_MS)
            throw new IllegalArgumentException("STALE_DATA");
        Object temperatureValue = conditions.opt("temperature");
        if (!(temperatureValue instanceof Number)) throw new IllegalArgumentException("Missing temperature");
        double temperature = ((Number) temperatureValue).doubleValue();
        if (!Double.isFinite(temperature) || temperature < -100 || temperature > 100) throw new IllegalArgumentException("Invalid temperature");
        JSONObject wind = real.optJSONObject("wind");
        String directionText = wind == null ? "" : directionText(wind.optString("direct", ""));
        String power = wind == null ? "" : windPower(wind.optString("power", ""));
        Double direction = wind == null ? null : optionalNumber(wind.opt("degree"), 360);
        String condition = text(conditions.optString("info", ""), 30);
        int code = weatherCode(conditions.optString("img", ""));
        String sourceUrl = sourceUrl(station.optString("url", ""));
        boolean isDay = dayAt(real.optJSONObject("sunriseSunset"), now);
        // NMC's official UI labels wind.power, but provides no unit contract for real.wind.speed.
        // Preserve the published Beaufort text; don't silently interpret the raw numeric speed as m/s.
        return new JSONObject().put("temperature", temperature).put("code", code).put("conditionText", condition)
            .put("isDay", isDay).put("windSpeed", JSONObject.NULL).put("windDirection", direction == null ? JSONObject.NULL : direction)
            .put("windGust", JSONObject.NULL).put("windDirectionText", directionText).put("windLabel", directionText)
            .put("windPower", power).put("observedAt", observedAt).put("observedTime", observedTime)
            .put("updatedAt", now).put("timezone", "Asia/Shanghai").put("provider", "nmc")
            .put("sourceLabel", "中央气象台").put("sourceUrl", sourceUrl).put("nmcCode", expectedCode)
            .put("city", city).put("admin1", province);
    }

    static long chinaTime(String value) {
        if (value == null || !value.matches("[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}")) return -1;
        SimpleDateFormat parser = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.ROOT);
        parser.setTimeZone(CHINA); parser.setLenient(false);
        ParsePosition position = new ParsePosition(0);
        java.util.Date date = parser.parse(value, position);
        return date != null && position.getIndex() == value.length() ? date.getTime() : -1;
    }
    private static String text(String value, int max) {
        String clean = value == null ? "" : value.trim();
        if (clean.isEmpty() || clean.equals("-") || clean.equals("9999") || clean.equals("null") || clean.length() > max
            || clean.matches("(?s).*[<>\\p{Cntrl}].*")) return "";
        return clean;
    }
    static String sourceUrl(String path) {
        if (path != null && path.matches("/publish/forecast/[A-Z]{3}/[A-Za-z0-9_-]+\\.html")) return "https://www.nmc.cn" + path;
        return "https://www.nmc.cn/publish/forecast.html";
    }
    static String directionText(String value) {
        for (String supported : new String[]{"北风","东北风","东风","东南风","南风","西南风","西风","西北风","无持续风向","旋转风"})
            if (supported.equals(value)) return value;
        return "";
    }
    static String windPower(String value) {
        if ("微风".equals(value) || "静风".equals(value)) return value;
        return value != null && value.matches("(?:[0-9]|1[0-7])(?:[~～-](?:[0-9]|1[0-7]))?级") ? value : "";
    }
    private static Double optionalNumber(Object value, double max) {
        if (!(value instanceof Number)) return null;
        double number = ((Number) value).doubleValue();
        return Double.isFinite(number) && number >= 0 && number <= max ? number : null;
    }
    static boolean dayAt(JSONObject sun, long now) {
        if (sun != null) {
            long sunrise = chinaTime(sun.optString("sunrise", "")), sunset = chinaTime(sun.optString("sunset", ""));
            if (sunrise > 0 && sunset > sunrise && sunset - sunrise < 24 * 60 * 60 * 1000L && sameChinaDay(sunrise, now))
                return now >= sunrise && now < sunset;
        }
        Calendar current = Calendar.getInstance(CHINA, Locale.ROOT); current.setTimeInMillis(now);
        int hour = current.get(Calendar.HOUR_OF_DAY); return hour >= 6 && hour < 18;
    }
    private static boolean sameChinaDay(long one, long two) {
        Calendar a = Calendar.getInstance(CHINA, Locale.ROOT), b = Calendar.getInstance(CHINA, Locale.ROOT);
        a.setTimeInMillis(one); b.setTimeInMillis(two);
        return a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR);
    }
    static int weatherCode(String value) {
        int source;
        try { if (value == null || !value.matches("[0-9]{1,2}")) return -1; source = Integer.parseInt(value); }
        catch (Exception invalid) { return -1; }
        switch (source) {
            case 0: return 0;
            case 1: return 2;
            case 2: return 3;
            case 3: return 80;
            case 4: return 95;
            case 5: return 96;
            case 6: return 67;
            case 7: return 61;
            case 8: case 21: return 63;
            case 9: case 10: case 11: case 12: case 22: case 23: case 24: case 25: return 65;
            case 13: return 85;
            case 14: return 71;
            case 15: case 26: return 73;
            case 16: case 17: case 27: case 28: return 75;
            case 18: return 45;
            case 19: return 66;
            default: return -1;
        }
    }
}
