package com.xiongxiong.calendar;

import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Callable;
import java.util.zip.GZIPInputStream;
import javax.net.ssl.HttpsURLConnection;

/** Three fixed public data reads. No user data, credentials, arbitrary URL or persistent cache. */
final class GoldNetwork implements Callable<String> {
    static final int MAX_BYTES = 1500000;
    private final String kind;
    private volatile boolean cancelled;
    private volatile HttpsURLConnection connection;
    GoldNetwork(String kind) {
        if (!kind.equals("quote") && !kind.equals("history") && !kind.equals("brands")) throw new IllegalArgumentException("Unknown quote source");
        this.kind = kind;
    }
    void cancel() { cancelled = true; HttpsURLConnection c = connection; if (c != null) c.disconnect(); }
    @Override public String call() throws Exception {
        long deadline = System.nanoTime() + 12000000000L;
        boolean brands = kind.equals("brands");
        String url = brands ? "https://precious.smm.cn/gold-price" : "https://ms.jr.jd.com/gw2/generic/ugActs/h5/m/" + (kind.equals("quote") ? "queryStockData" : "queryStockKLine");
        HttpsURLConnection c = (HttpsURLConnection)new URL(url).openConnection(); connection = c;
        try {
            if (cancelled) throw new IOException("Cancelled");
            c.setConnectTimeout(5000); c.setReadTimeout(5000); c.setUseCaches(false); c.setInstanceFollowRedirects(false);
            c.setRequestProperty("Cache-Control","no-cache, no-store"); c.setRequestProperty("Accept-Encoding","gzip");
            c.setRequestProperty("User-Agent","BearBaodian/2.2.18");
            if (!brands) {
                c.setRequestMethod("POST"); c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json");
                byte[] body = ("{\"paramMap\":{\"stockCode\":\"SGE-Au99.99\""+(kind.equals("history")?",\"kType\":\"day\"":"")+"}}").getBytes(StandardCharsets.UTF_8);
                c.setFixedLengthStreamingMode(body.length); try(OutputStream out=c.getOutputStream()) { out.write(body); }
            }
            if (c.getResponseCode()!=200) throw new IOException("Source unavailable");
            try (BufferedInputStream in = new BufferedInputStream(c.getInputStream()); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                in.mark(2); int a=in.read(), b=in.read(); in.reset();
                InputStream decoded = a==0x1f && b==0x8b ? new GZIPInputStream(in) : in;
                byte[] buffer=new byte[8192]; int n;
                while ((n=decoded.read(buffer))!=-1) {
                    if (cancelled || Thread.currentThread().isInterrupted() || System.nanoTime()>deadline) throw new IOException("Timed out");
                    if(out.size()+n>MAX_BYTES) throw new IOException("Response too large"); out.write(buffer,0,n);
                }
                if(cancelled || System.nanoTime()>deadline) throw new IOException("Timed out");
                return out.toString("UTF-8");
            }
        } finally { c.disconnect(); connection=null; }
    }
}
