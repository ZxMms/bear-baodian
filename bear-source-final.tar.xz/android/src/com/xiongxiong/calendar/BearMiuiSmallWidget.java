package com.xiongxiong.calendar;
public final class BearMiuiSmallWidget extends BearMiuiWidget {
    @Override boolean large(){return false;}
}
