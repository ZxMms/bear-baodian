package com.xiongxiong.calendar;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Serialized foreground location state machine, independent of Android and tested with fake providers. */
final class LocationSession {
    interface Cancel { void cancel(); }
    interface Events { void fix(Fix fix); void cached(Fix fix); void failed(String reason); }
    interface Port { Cancel request(String provider, Events events); }
    interface Clock { long elapsedNanos(); }
    interface Scheduler { Cancel after(long milliseconds, Runnable task); }
    interface Observer { void changed(LocationSession session); void accepted(Fix fix, boolean recent); }
    static final class Fix {
        final double latitude, longitude, accuracyMeters;
        final long elapsedNanos, locatedAt;
        final String provider;
        Fix(double latitude, double longitude, double accuracyMeters, long elapsedNanos, long locatedAt, String provider) {
            this.latitude = latitude; this.longitude = longitude; this.accuracyMeters = accuracyMeters;
            this.elapsedNanos = elapsedNanos; this.locatedAt = locatedAt; this.provider = provider == null ? "" : provider;
        }
    }
    final String permission;
    final Boolean serviceEnabled;
    final List<String> providers;
    final Set<String> activeProviders = new LinkedHashSet<>();
    final Map<String, String> failures = new LinkedHashMap<>();
    String phase = "idle", status = "", detail = "", lastRejection = "";
    Fix candidate, lastFix;
    private Fix liveAlternative, comparisonFix;
    private boolean conflictingFixes;
    private final boolean gpsRetry;
    private final Port port;
    private final Clock clock;
    private final Scheduler scheduler;
    private final Observer observer;
    private final Map<String, Cancel> subscriptions = new LinkedHashMap<>();
    private Cancel deadline;
    private boolean running, started, cancelled;
    private long startedAt;
    LocationSession(String permission, Boolean serviceEnabled, List<String> providers, boolean gpsRetry, Port port, Clock clock, Scheduler scheduler, Observer observer) {
        this.permission = permission; this.serviceEnabled = serviceEnabled; this.providers = new ArrayList<>(providers);
        this.gpsRetry = gpsRetry;
        this.port = port; this.clock = clock; this.scheduler = scheduler; this.observer = observer;
    }
    static List<String> chooseProviders(List<String> advertised, Set<String> enabled, boolean fine) {
        List<String> result = new ArrayList<>();
        for (String provider : new String[]{"network", "fused", "gps", "passive"}) {
            // Android 10 requires FINE for PASSIVE as well as GPS. Internal fused is not advertised there.
            if ((!fine && ("gps".equals(provider) || "passive".equals(provider))) || !advertised.contains(provider) || !enabled.contains(provider)) continue;
            result.add(provider);
        }
        return result;
    }
    boolean running() { return running; }
    long waitMs() {
        return gpsRetry && providers.contains("gps") ? LocationRules.PRECISE_WAIT_MS : LocationRules.WEATHER_WAIT_MS;
    }
    void start() {
        if (started || cancelled) return;
        started = true;
        if ("none".equals(permission)) { phase = "permission"; status = "permission-denied"; detail = "尚未允许位置权限，可以允许大致位置或选择城市"; observer.changed(this); return; }
        if (Boolean.FALSE.equals(serviceEnabled)) { phase = "unavailable"; status = "service-off"; detail = "位置权限已允许，但手机的定位总开关已关闭"; observer.changed(this); return; }
        if (providers.isEmpty()) { phase = "unavailable"; status = "no-provider"; detail = "位置权限已允许，当前没有可用的定位来源" + ("approximate".equals(permission) ? "；可以用 GPS 再试或选择城市" : "；请检查系统定位设置或选择城市"); observer.changed(this); return; }
        startedAt = clock.elapsedNanos();
        running = true; activeProviders.addAll(providers);
        phase = "locating"; status = "waiting"; updateWaiting();
        deadline = scheduler.after(waitMs(), this::timeout);
        for (String provider : providers) {
            if (!running) break;
            try {
                Cancel handle = port.request(provider, new Events() {
                    public void fix(Fix fix) { receive(provider, fix, false); }
                    public void cached(Fix fix) { receive(provider, fix, true); }
                    public void failed(String reason) { providerFailed(provider, reason); }
                });
                if (!running || !activeProviders.contains(provider)) { if (handle != null) handle.cancel(); }
                else subscriptions.put(provider, handle);
            } catch (RuntimeException failed) { providerFailed(provider, "request-failed"); }
        }
    }
    private void receive(String provider, Fix fix, boolean cached) {
        if (!running || !activeProviders.contains(provider)) return;
        lastFix = fix;
        String rejected = LocationRules.rejection(fix, clock.elapsedNanos());
        if (!rejected.isEmpty()) { lastRejection = rejected; updateWaiting(); return; }
        boolean waitingForGps = "precise".equals(permission) && activeProviders.contains("gps");
        boolean freshGps = !cached && "gps".equals(fix.provider) && fix.elapsedNanos >= startedAt - 2000000000L && fix.accuracyMeters <= 150;
        if (!cached && (!waitingForGps || freshGps) && LocationRules.current(fix.elapsedNanos, clock.elapsedNanos(), fix.accuracyMeters)) {
            accept(fix, false); return;
        }
        if (!gpsRetry && waitingForGps && fix.accuracyMeters <= 100 &&
                LocationRules.current(fix.elapsedNanos, clock.elapsedNanos(), fix.accuracyMeters)) {
            if (comparisonFix == null) comparisonFix = fix;
            else {
                double dy = Math.toRadians(fix.latitude - comparisonFix.latitude);
                double dx = Math.toRadians(fix.longitude - comparisonFix.longitude);
                double h = Math.pow(Math.sin(dy/2),2) + Math.cos(Math.toRadians(fix.latitude))
                    * Math.cos(Math.toRadians(comparisonFix.latitude)) * Math.pow(Math.sin(dx/2),2);
                // A multi-kilometre disagreement inside the two-minute window needs a user choice.
                if (h > Math.pow(Math.sin(3000.0/(2*6371000)),2)) conflictingFixes = true;
            }
        }
        if (!cached && !gpsRetry && fix.elapsedNanos >= startedAt &&
                ("fused".equals(fix.provider) || "network".equals(fix.provider)) && fix.accuracyMeters <= 100) {
            if (liveAlternative == null || fix.accuracyMeters <= liveAlternative.accuracyMeters) liveAlternative = fix;
        }
        if (candidate == null || fix.elapsedNanos > candidate.elapsedNanos || fix.elapsedNanos == candidate.elapsedNanos && fix.accuracyMeters < candidate.accuracyMeters) candidate = fix;
        lastRejection = "recent"; updateWaiting();
    }
    private void providerFailed(String provider, String reason) {
        if (!running || !activeProviders.remove(provider)) return;
        failures.put(provider, reason);
        Cancel handle = subscriptions.remove(provider); if (handle != null) handle.cancel();
        if (activeProviders.isEmpty()) { finish("unavailable", "providers-failed", "位置权限已允许，但可用定位来源均未能继续提供位置。" + candidateDetail()); }
        else updateWaiting();
    }
    private void updateWaiting() {
        detail = activeProviders.contains("gps") ? "已允许精确位置，正在等待 GPS 与其他可用来源；靠近窗边可能更快" : ("precise".equals(permission) ? "已允许精确位置，正在等待其他可用定位来源返回位置" : "已允许大致位置，正在等待系统网络定位返回位置");
        if (!failures.isEmpty()) detail += "；部分来源不可用，仍在等待其他来源";
        if (conflictingFixes) detail = "手机返回的位置相差较远，请核对下方地区或手动选择区县。";
        else if (usableCandidate()) detail = "手机已返回一个可用位置。可以立即用它查天气，也可以继续等待更准确的位置。";
        else if ("stale".equals(lastRejection)) detail += "；系统目前只返回了超过 10 分钟的旧位置";
        else if ("accuracy-wide".equals(lastRejection)) detail += "；返回的位置范围超过 20 公里";
        else if (!lastRejection.isEmpty()) detail += "；返回的位置资料不完整，继续等待";
        observer.changed(this);
    }
    private String candidateDetail() {
        if (usableCandidate()) return "可以使用下方位置，或手动选择城市。";
        if ("stale".equals(lastRejection)) return "系统返回的位置已超过 10 分钟，未用于本次查询。";
        if ("accuracy-wide".equals(lastRejection)) return "系统返回的位置范围超过 20 公里，请用 GPS 再试或选择城市。";
        if (!lastRejection.isEmpty() && !"recent".equals(lastRejection)) return "返回的位置资料不完整，请重试或选择城市。";
        return "尚未收到可用于天气查询的位置，请用 GPS 再试或选择城市。";
    }
    private void timeout() {
        if (!running) return;
        if (!conflictingFixes && liveAlternative != null && LocationRules.current(liveAlternative.elapsedNanos, clock.elapsedNanos(), liveAlternative.accuracyMeters)) {
            accept(liveAlternative, false);
        } else finish("timeout", "timeout", usableCandidate() ? "本次定位等待已结束。可以使用下方位置，或自行选择区县。" : "本次定位等待已结束。" + candidateDetail());
    }
    private void finish(String nextPhase, String nextStatus, String message) {
        stopTransport(); phase = nextPhase; status = nextStatus; detail = message; observer.changed(this);
    }
    private void accept(Fix fix, boolean recent) {
        stopTransport(); candidate = null; phase = "ready"; status = recent ? "recent" : "current";
        detail = recent ? "已按你的选择使用稍早的位置，定位时间保持原样" : "已取得可用于天气查询的位置";
        if (fix.accuracyMeters > 5000) detail += "；定位范围较大，请核对城市";
        observer.changed(this); observer.accepted(fix, recent);
    }
    boolean usableCandidate() {
        return !cancelled && candidate != null && LocationRules.rejection(candidate, clock.elapsedNanos()).isEmpty();
    }
    void stopWaiting() {
        if (running) finish("cancelled","cancelled",usableCandidate() ? "已停止等待，可使用下方位置查天气。" : "已停止定位，可以重新定位或选择城市。");
    }
    boolean reserveCandidate() {
        if (!usableCandidate()) return false;
        stopTransport();
        phase = "confirming";
        status = "checking-candidate";
        return true;
    }
    boolean useRecent(boolean permissionGranted, boolean serviceOn) {
        if (cancelled || !permissionGranted || !serviceOn || !usableCandidate()) return false;
        accept(candidate, true); return true;
    }
    void cancel() { cancelled = true; candidate = null; stopTransport(); phase = "cancelled"; status = "cancelled"; }
    private void stopTransport() {
        running = false; liveAlternative = null;
        if (deadline != null) { deadline.cancel(); deadline = null; }
        List<Cancel> handles = new ArrayList<>(subscriptions.values()); subscriptions.clear(); activeProviders.clear();
        for (Cancel handle : handles) if (handle != null) handle.cancel();
    }
}
