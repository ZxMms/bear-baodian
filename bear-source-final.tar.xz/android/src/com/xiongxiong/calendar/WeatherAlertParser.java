package com.xiongxiong.calendar;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import org.json.JSONArray;
import org.json.JSONObject;

/** Parses recent official releases; the feed does not identify expiration or active status. */
final class WeatherAlertParser {
    static final long WINDOW_MS = 24 * 60 * 60 * 1000L;
    static final int LIMIT = 500;
    static final int PAGE_SIZE = 100, MAX_PAGES = 5;
    static final String[] PROVINCES = {
        "北京市", "天津市", "河北省", "山西省", "内蒙古自治区", "辽宁省", "吉林省", "黑龙江省",
        "上海市", "江苏省", "浙江省", "安徽省", "福建省", "江西省", "山东省", "河南省", "湖北省",
        "湖南省", "广东省", "广西壮族自治区", "海南省", "重庆市", "四川省", "贵州省", "云南省",
        "西藏自治区", "陕西省", "甘肃省", "青海省", "宁夏回族自治区", "新疆维吾尔自治区"
    };
    private static final String[] CODES = {
        "11", "12", "13", "14", "15", "21", "22", "23", "31", "32", "33", "34", "35", "36", "37",
        "41", "42", "43", "44", "45", "46", "50", "51", "52", "53", "54", "61", "62", "63", "64", "65"
    };

    static boolean supported(String province) { return code(province) != null; }

    private static String code(String province) {
        for (int index = 0; index < PROVINCES.length; index++) if (PROVINCES[index].equals(province)) return CODES[index];
        return null;
    }

    static String officialUrl(String id) {
        if (id == null || !id.matches("[0-9]{14}_[0-9]{14}")) return null;
        return "https://www.nmc.cn/publish/alarm/" + id + ".html";
    }

    static long issueTime(String text) {
        if (text == null || !text.matches("[0-9]{4}/[0-9]{2}/[0-9]{2} [0-9]{2}:[0-9]{2}")) return -1;
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.ROOT);
        format.setTimeZone(TimeZone.getTimeZone("GMT+08:00"));
        format.setLenient(false);
        ParsePosition position = new ParsePosition(0);
        java.util.Date date = format.parse(text, position);
        return date != null && position.getIndex() == text.length() ? date.getTime() : -1;
    }

    static final class Page {
        final JSONArray alerts;
        final java.util.Set<String> primaryIds;
        final int number, totalPages, totalCount;
        final boolean incomplete;
        Page(JSONArray alerts, java.util.Set<String> primaryIds, int number, int totalPages, int totalCount, boolean incomplete) {
            this.alerts = alerts; this.primaryIds = primaryIds; this.number = number;
            this.totalPages = totalPages; this.totalCount = totalCount; this.incomplete = incomplete;
        }
    }

    /** One query's bounded pages. Partial data is never labelled a complete local search. */
    static final class Batch {
        final String province;
        final long now;
        private final Map<String, JSONObject> releases = new HashMap<>();
        private final java.util.Set<String> primaryIds = new java.util.HashSet<>();
        private final java.util.Set<Integer> pages = new java.util.HashSet<>();
        private int totalPages = 1, totalCount;
        private boolean incomplete;
        Batch(String province, long now) {
            if (!supported(province)) throw new IllegalArgumentException("Unsupported province");
            this.province = province; this.now = now;
        }
        void add(Page page, int requested) throws Exception {
            if (requested < 1 || requested > MAX_PAGES || page.number != requested || !pages.add(requested))
                throw new IllegalArgumentException("Wrong response page");
            totalPages = Math.max(totalPages, page.totalPages); totalCount = Math.max(totalCount, page.totalCount);
            primaryIds.addAll(page.primaryIds); incomplete |= page.incomplete;
            for (int i = 0; i < page.alerts.length(); i++) {
                JSONObject row = page.alerts.getJSONObject(i); releases.put(row.getString("id"), row);
            }
        }
        int nextPage() { return pages.size() < Math.min(totalPages, MAX_PAGES) ? pages.size() + 1 : 0; }
        boolean hasPages() { return !pages.isEmpty(); }
        JSONObject result(boolean interrupted) throws Exception {
            ArrayList<JSONObject> sorted = new ArrayList<>(releases.values());
            sorted.sort((left, right) -> {
                int time = Long.compare(right.optLong("issuedAt"), left.optLong("issuedAt"));
                return time != 0 ? time : left.optString("id").compareTo(right.optString("id"));
            });
            JSONArray alerts = new JSONArray();
            for (int i = 0; i < Math.min(LIMIT, sorted.size()); i++) alerts.put(sorted.get(i));
            return new JSONObject().put("province", province).put("alerts", alerts).put("updatedAt", now)
                .put("truncated", interrupted || incomplete || pages.size() < totalPages || primaryIds.size() < totalCount || sorted.size() > LIMIT);
        }
    }

    interface PageReader { String read(int pageNumber) throws Exception; }
    interface Progress { void received(JSONObject result) throws Exception; }
    static JSONObject query(String province, long now, PageReader reader, Progress progress) throws Exception {
        Batch batch = new Batch(province, now);
        int requested = 1;
        do {
            try {
                batch.add(page(reader.read(requested), province, now), requested);
                progress.received(batch.result(true));
            } catch (Exception unavailable) {
                if (!batch.hasPages()) throw unavailable;
                return batch.result(true).put("partialFailure", true);
            }
            requested = batch.nextPage();
        } while (requested != 0);
        return batch.result(false);
    }

    static JSONObject parse(String raw, String province, long now) throws Exception {
        Batch batch = new Batch(province, now);
        Page page = page(raw, province, now);
        batch.add(page, page.number);
        return batch.result(false);
    }

    static Page page(String raw, String province, long now) throws Exception {
        if (!supported(province)) throw new IllegalArgumentException("Unsupported province");
        JSONObject body = new JSONObject(raw);
        Object codeValue = body.opt("code");
        if (!(codeValue instanceof Number) || ((Number) codeValue).doubleValue() != 0d) throw new IllegalArgumentException("Feed status");
        JSONObject data = body.getJSONObject("data"), page = data.getJSONObject("page");
        JSONArray list = page.getJSONArray("list");
        if (list.length() > PAGE_SIZE) throw new IllegalArgumentException("Unexpected page size");
        int number = integer(page, "pageNo", 1), totalPages = integer(page, "totalPage", 1), totalCount = integer(page, "count", list.length());
        if (number < 1 || totalPages < 0 || number > Math.max(1, totalPages) || totalCount < 0 || totalCount > 100000)
            throw new IllegalArgumentException("Invalid pagination");
        totalPages = Math.max(1, Math.max(totalPages, (totalCount + PAGE_SIZE - 1) / PAGE_SIZE));
        JSONArray provinceRows = data.optJSONArray("provinceAlarms");
        if (data.has("provinceAlarms") && provinceRows == null) throw new IllegalArgumentException("Invalid province releases");
        if (provinceRows != null && provinceRows.length() > PAGE_SIZE) throw new IllegalArgumentException("Unexpected province list");
        boolean incomplete = false;
        Map<String, JSONObject> releases = new HashMap<>();
        java.util.Set<String> primaryIds = new java.util.HashSet<>();
        int seen = 0, valid = 0;
        for (JSONArray rows : new JSONArray[]{list, provinceRows}) {
            if (rows == null) continue;
            for (int index = 0; index < rows.length(); index++) {
                seen++;
                JSONObject row = rows.optJSONObject(index);
                if (row == null) { incomplete = true; continue; }
                String id = row.optString("alertid", ""), title = row.optString("title", "").trim();
                String url = officialUrl(id);
                long issued = issueTime(row.optString("issuetime", ""));
                if (url == null || !id.startsWith(code(province)) || !title.startsWith(province)
                    || title.length() > 180 || title.length() <= province.length() || issued <= 0 || issued > now + 300000L) {
                    incomplete = true; continue;
                }
                valid++;
                if (rows == list) primaryIds.add(id);
                if (issued < now - WINDOW_MS) continue;
                releases.put(id, new JSONObject().put("id", id).put("title", title).put("issuedAt", issued)
                    .put("url", url).put("level", level(title)));
            }
        }
        if (seen > 0 && valid == 0) throw new IllegalArgumentException("No valid release rows");
        if (releases.isEmpty() && valid < seen) throw new IllegalArgumentException("Incomplete empty result");
        if (list.length() == 0 && totalCount > 0) throw new IllegalArgumentException("Missing release rows");
        return new Page(new JSONArray(releases.values()), primaryIds, number, totalPages, totalCount, incomplete);
    }

    private static int integer(JSONObject object, String key, int fallback) {
        if (!object.has(key)) return fallback;
        Object value = object.opt(key);
        if (!(value instanceof Number) || !Double.isFinite(((Number)value).doubleValue())
            || ((Number)value).doubleValue() != ((Number)value).intValue()) throw new IllegalArgumentException("Invalid pagination number");
        return ((Number)value).intValue();
    }

    /** Revalidates the current in-memory result only. The app does not persist alert results. */
    static JSONObject cache(String raw, String province, long now) {
        try {
            if (!supported(province)) return null;
            JSONObject cached = new JSONObject(raw);
            long updated = cached.getLong("updatedAt");
            if (!province.equals(cached.getString("province")) || updated <= 0 || updated > now + 300000L) return null;
            JSONArray rows = cached.getJSONArray("alerts"), alerts = new JSONArray();
            if (rows.length() > LIMIT) return null;
            for (int index = 0; index < rows.length(); index++) {
                JSONObject row = rows.getJSONObject(index);
                String id = row.getString("id"), title = row.getString("title"), url = officialUrl(id);
                long issued = row.getLong("issuedAt");
                if (url == null || !id.startsWith(code(province)) || !title.startsWith(province)
                    || title.length() > 180 || issued <= 0 || issued > updated + 300000L) return null;
                if (issued < now - WINDOW_MS) continue;
                alerts.put(new JSONObject().put("id", id).put("title", title).put("issuedAt", issued)
                    .put("url", url).put("level", level(title)));
            }
            return new JSONObject().put("province", province).put("alerts", alerts).put("updatedAt", updated)
                .put("truncated", cached.optBoolean("truncated", false));
        } catch (Exception invalid) { return null; }
    }

    private static String level(String title) {
        if (title.contains("红色预警")) return "red";
        if (title.contains("橙色预警")) return "orange";
        if (title.contains("黄色预警")) return "yellow";
        if (title.contains("蓝色预警")) return "blue";
        return "unknown";
    }
}
