package com.xiongxiong.calendar;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;

public final class LocalStore {
    static final int SAVE_BACKUP=81,OPEN_BACKUP=82;
    final StoreEngine engine;
    private final AndroidSqlAccess database;
    private final Activity activity;
    private final WebView web;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private volatile boolean closed;
    private StoreEngine.PreparedBackup prepared;
    private String restoreToken="";
    LocalStore(Activity activity,WebView web)throws Exception{
        this.activity=activity;this.web=web;database=new AndroidSqlAccess(activity);
        engine=new StoreEngine(database,new File(activity.getFilesDir(),"media"));
    }
    @JavascriptInterface public void request(String id,String input){
        if(closed||!id.matches("[0-9]{1,12}"))return;
        worker.execute(()->{
            JSONObject result=new JSONObject();
            try{
                if(input.length()>60*1024*1024)throw new IOException("单条数据过大");
                JSONObject request=new JSONObject(input);String op=request.getString("op");
                if(op.equals("restore-confirm")){
                    if(prepared==null||!restoreToken.equals(request.optString("token")))throw new IOException("备份预览已过期，请重新选择");
                    result.put("value",engine.mergeBackup(prepared));cleanup(prepared.folder);prepared=null;restoreToken="";
                }else result.put("value",engine.request(request));
                result.put("ok",true);
            }catch(Exception error){try{result.put("ok",false).put("error",message(error));}catch(JSONException ignored){}}
            emit("window.bearStoreResult",JSONObject.quote(id)+","+result);
        });
    }
    private String message(Exception error){String message=error.getMessage();if(message!=null&&message.contains("UNIQUE"))return "这条记录已经存在，请刷新后查看";return message==null?"本机存储未完成，原数据仍保留":message;}
    private void emit(String fn,String args){if(closed)return;activity.runOnUiThread(()->{if(!closed)web.evaluateJavascript(fn+" && "+fn+"("+args+")",null);});}
    private void status(String type,String message){try{emit("window.bearBackupResult",new JSONObject().put("type",type).put("message",message).toString());}catch(JSONException ignored){}}
    @JavascriptInterface public void exportBackup(){activity.runOnUiThread(()->{
        try{String date=new SimpleDateFormat("yyyyMMdd_HHmm",Locale.ROOT).format(new Date());activity.startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/zip").putExtra(Intent.EXTRA_TITLE,"熊熊宝典备份_"+date+".zip"),SAVE_BACKUP);}
        catch(RuntimeException error){status("error","无法打开保存位置，请重试");}
    });}
    @JavascriptInterface public void chooseBackup(){activity.runOnUiThread(()->{
        try{activity.startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*").putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/zip","application/octet-stream","application/x-zip-compressed"}),OPEN_BACKUP);}
        catch(RuntimeException error){status("error","无法打开备份选择器，请重试");}
    });}
    void activityResult(int request,int result,Intent data){
        if(result!=Activity.RESULT_OK||data==null||data.getData()==null){status("cancelled","已取消");return;}
        Uri uri=data.getData();status("working",request==SAVE_BACKUP?"正在保存记录和附件…":"正在检查备份完整性…");
        worker.execute(()->{
            File folder=null;
            try{
                if(request==SAVE_BACKUP){try(OutputStream output=activity.getContentResolver().openOutputStream(uri,"w")){if(output==null)throw new IOException("无法写入所选位置");engine.backup(output);}status("exported","备份已保存，包含记录和附件");}
                else {
                    if(prepared!=null){cleanup(prepared.folder);prepared=null;}
                    folder=new File(activity.getCacheDir(),"restore-"+UUID.randomUUID());
                    try(InputStream input=activity.getContentResolver().openInputStream(uri)){if(input==null)throw new IOException("无法读取备份");prepared=engine.inspectBackup(input,folder);}
                    restoreToken=UUID.randomUUID().toString();
                    emit("window.bearBackupResult",new JSONObject().put("type","preview").put("token",restoreToken).put("manifest",prepared.manifest).toString());
                }
            }catch(Exception error){if(folder!=null)cleanup(folder);prepared=null;restoreToken="";status("error","未完成："+message(error)+"。本机记录未被覆盖。");}
        });
    }
    private static void cleanup(File file){if(file.isDirectory()){File[] children=file.listFiles();if(children!=null)for(File child:children)cleanup(child);}file.delete();}
    void close(){closed=true;worker.execute(()->{if(prepared!=null)cleanup(prepared.folder);database.close();});worker.shutdown();}
}
