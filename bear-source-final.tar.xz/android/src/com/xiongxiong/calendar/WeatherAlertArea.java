package com.xiongxiong.calendar;

import org.json.JSONObject;

/** Names from one geocoder result, independently checked against the official city directory. */
final class WeatherAlertArea {
    private WeatherAlertArea() { }

    static JSONObject fromGeocoder(NmcCities cities, JSONObject station, String country, String admin,
            String locality, String subAdmin, String subLocality, double accuracy) {
        try {
            if (!"CN".equalsIgnoreCase(country) || station == null) return null;
            JSONObject canonical = cities.fromPlace(station);
            if (canonical == null) return null;
            String province = canonical.getString("admin1");
            // The same address must resolve to this station in this province. Never use
            // a station or parent left over from the previous position.
            JSONObject sameProvince = cities.resolve(admin, canonical.getString("name"));
            if (sameProvince == null || !canonical.getString("nmcCode").equals(sameProvince.optString("nmcCode"))) return null;

            String city = "", district = "";
            if (municipality(province)) city = province;
            else {
                // A supplied sub-administrative city can be the parent of a county-level
                // locality. Retain only explicitly named city/prefecture components.
                city = cityName(cities, province, admin, subAdmin);
                if (city.isEmpty()) city = cityName(cities, province, admin, locality);
            }
            if (LocationRules.districtEligible(accuracy)) {
                district = districtName(cities, province, admin, subLocality, city, true);
                if (district.isEmpty()) district = districtName(cities, province, admin, locality, city, !city.isEmpty());
                if (district.isEmpty()) district = districtName(cities, province, admin, subAdmin, city, false);
            }
            if (city.isEmpty() && district.isEmpty()) return null;
            JSONObject area = new JSONObject().put("province", province).put("city", city).put("district", district).put("source", "geocoder");
            if (!district.isEmpty()) area.put("districtUnique", true);
            return area;
        } catch (Exception invalid) { return null; }
    }

    private static boolean municipality(String province) {
        return "北京市".equals(province) || "天津市".equals(province) || "上海市".equals(province) || "重庆市".equals(province);
    }
    private static String cityName(NmcCities cities, String province, String admin, String value) {
        String name = text(value);
        if (!(name.endsWith("市") || name.endsWith("自治州") || name.endsWith("地区") || name.endsWith("盟"))) return "";
        return verified(cities, province, admin, name);
    }
    private static String districtName(NmcCities cities, String province, String admin, String value, String city, boolean allowCountyCity) {
        String name = text(value);
        if (sameName(name, city) || !(name.endsWith("区") || name.endsWith("县") || name.endsWith("旗") || allowCountyCity && name.endsWith("市"))) return "";
        return verified(cities, province, admin, name);
    }
    private static String verified(NmcCities cities, String province, String admin, String name) {
        if (name.isEmpty() || name.length() > 80 || !name.matches("[\\p{IsHan}·]+") || "市辖区".equals(name)) return "";
        JSONObject match = cities.resolve(admin, name);
        return match != null && province.equals(match.optString("admin1")) ? name : "";
    }
    private static String text(String value) { return value == null ? "" : value.trim(); }
    private static boolean sameName(String a, String b) {
        return !b.isEmpty() && a.replaceFirst("[市县区]$", "").equals(b.replaceFirst("[市县区]$", ""));
    }
}
