package com.xiongxiong.calendar;

import org.json.JSONObject;

/** Upgrade and ambiguity rules for alert areas; never changes the chosen weather station. */
final class WeatherAlertSelection {
    private WeatherAlertSelection() { }
    static boolean ambiguousName(NmcCities cities, JSONObject place) {
        if (place == null || !"city".equals(place.optString("source"))) return false;
        JSONObject canonical = cities.fromPlace(place);
        return canonical != null && cities.resolve(canonical.optString("admin1"), canonical.optString("name")) == null;
    }
    static boolean needsAreaLookup(JSONObject place, JSONObject known) {
        return place != null && known != null && "location".equals(place.optString("source"))
            && place.optJSONObject("alertArea") == null && !place.optBoolean("alertAreaChecked")
            && WeatherRules.validCoordinates(place.optDouble("latitude", Double.NaN), place.optDouble("longitude", Double.NaN));
    }
    static void completeAreaLookup(JSONObject place, JSONObject known, JSONObject found) throws Exception {
        place.put("alertAreaChecked", true);
        if (known == null || found == null || known.optString("nmcCode").isEmpty()
            || !known.optString("nmcCode").equals(found.optString("nmcCode"))
            || !known.optString("admin1").equals(found.optString("admin1"))) return;
        JSONObject area = found.optJSONObject("alertArea");
        if (area != null && known.optString("admin1").equals(area.optString("province")))
            place.put("alertArea", new JSONObject(area.toString()));
    }
}
