package com.xiongxiong.calendar;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.UUID;

public final class ShareController {
    public static final int SAVE_CARD = 73;
    private final Activity activity;
    private final WebView web;
    private final LinkedHashMap<String, ArrayList<File>> prepared = new LinkedHashMap<>();
    private File pendingSave;
    private boolean albumSaving;
    public ShareController(Activity activity, WebView web) { this.activity = activity; this.web = web; }
    private void notifyWeb(String message) {
        activity.runOnUiThread(() -> {
            if (!activity.isDestroyed()) web.evaluateJavascript("window.bearShareResult && window.bearShareResult(" + JSONObject.quote(message) + ")", null);
        });
    }
    @JavascriptInterface public synchronized String prepare(String json) {
        ArrayList<File> created = new ArrayList<>();
        try {
            if (json == null || json.length() > 24000000) throw new IllegalArgumentException();
            JSONArray pages = new JSONArray(json);
            if (pages.length() < 1 || pages.length() > 9) throw new IllegalArgumentException();
            File directory = new File(activity.getCacheDir(), "share-cards");
            if (!directory.isDirectory() && !directory.mkdirs()) throw new IllegalStateException();
            File[] old = directory.listFiles();
            if (old != null) for (File file : old) if (file.getName().matches("card-[0-9a-f-]{36}\\.png") && file.lastModified() < System.currentTimeMillis() - 7L*86400000L) file.delete();
            for (int i = 0; i < pages.length(); i++) {
                String data = pages.getString(i), prefix = "data:image/png;base64,";
                if (!data.startsWith(prefix) || data.length() > 6000000) throw new IllegalArgumentException();
                byte[] bytes = Base64.decode(data.substring(prefix.length()), Base64.DEFAULT);
                BitmapFactory.Options bounds = new BitmapFactory.Options(); bounds.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(bytes, 0, bytes.length, bounds);
                if (!"image/png".equals(bounds.outMimeType) || bounds.outWidth != 720 || bounds.outHeight < 1 || bounds.outHeight > 1800) throw new IllegalArgumentException();
                File file = new File(directory, "card-" + UUID.randomUUID() + ".png"); created.add(file);
                try (FileOutputStream stream = new FileOutputStream(file)) { stream.write(bytes); }
            }
            String token = UUID.randomUUID().toString();
            prepared.put(token, created);
            while (prepared.size() > 3) prepared.remove(prepared.keySet().iterator().next());
            return new JSONObject().put("ok", true).put("token", token).toString();
        } catch (Exception error) {
            for (File file : created) file.delete();
            return "{\"ok\":false,\"error\":\"分享图片未能准备好，请减少所选内容后重试\"}";
        }
    }
    private synchronized ArrayList<File> files(String token) {
        ArrayList<File> files = prepared.get(token);
        return files == null ? null : new ArrayList<>(files);
    }
    private Uri uri(File file) { return new Uri.Builder().scheme("content").authority(activity.getPackageName() + ".share").appendPath(file.getName()).build(); }
    @JavascriptInterface public void share(String token) {
        final ArrayList<File> files = files(token);
        activity.runOnUiThread(() -> {
            if (files == null || files.isEmpty()) { notifyWeb("分享预览已过期，请重新生成"); return; }
            try {
                ArrayList<Uri> uris = new ArrayList<>();
                for (File file : files) { if (!file.isFile()) throw new IllegalStateException(); uris.add(uri(file)); }
                Intent send = new Intent(uris.size() == 1 ? Intent.ACTION_SEND : Intent.ACTION_SEND_MULTIPLE).setType("image/png");
                if (uris.size() == 1) send.putExtra(Intent.EXTRA_STREAM, uris.get(0));
                else send.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                ClipData clips = ClipData.newUri(activity.getContentResolver(), "熊熊分享卡", uris.get(0));
                for (int i = 1; i < uris.size(); i++) clips.addItem(new ClipData.Item(uris.get(i)));
                send.setClipData(clips); send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                Intent chooser = Intent.createChooser(send, "分享到微信或其他应用");
                chooser.setClipData(clips); chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                activity.startActivity(chooser);
            } catch (RuntimeException unavailable) { notifyWeb("暂时无法打开分享面板，可先保存图片再发送"); }
        });
    }
    @JavascriptInterface public boolean canSaveToAlbum() { return Build.VERSION.SDK_INT >= 29; }
    /** A real gallery JPEG for consumers that cannot import our temporary share URI. */
    @JavascriptInterface public void saveToAlbum(String token, int index) {
        final ArrayList<File> files = files(token);
        if (files == null || index < 0 || index >= files.size() || !files.get(index).isFile()) { notifyWeb("分享预览已过期，请重新生成"); return; }
        if (Build.VERSION.SDK_INT < 29) {
            notifyWeb("请在保存窗口选择图片文件夹，再从微信相册选择这张卡片");
            save(token, index); return;
        }
        synchronized (this) {
            if (albumSaving) { notifyWeb("正在保存到相册，请稍等"); return; }
            albumSaving = true;
        }
        final File file = files.get(index);
        notifyWeb("正在保存到相册…");
        new Thread(() -> {
            Bitmap bitmap = null;
            try {
                BitmapFactory.Options options = new BitmapFactory.Options(); options.inPreferredConfig = Bitmap.Config.ARGB_8888;
                bitmap = BitmapFactory.decodeFile(file.getAbsolutePath(), options);
                if (bitmap == null || bitmap.getWidth() != 720 || bitmap.getHeight() > 1800) throw new IllegalStateException();
                final Bitmap image = bitmap;
                ShareAlbumCommit.write(new ShareAlbumCommit.Store<Uri>() {
                    public Uri create() {
                        ContentValues values = new ContentValues();
                        values.put(MediaStore.Images.Media.DISPLAY_NAME, "熊熊分享卡_" + System.currentTimeMillis() + "_" + (index + 1) + ".jpg");
                        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/熊熊宝典");
                        values.put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis());
                        values.put(MediaStore.Images.Media.IS_PENDING, 1);
                        return activity.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    }
                    public void write(Uri destination) throws Exception {
                        try (OutputStream output = activity.getContentResolver().openOutputStream(destination)) {
                            if (output == null || !image.compress(Bitmap.CompressFormat.JPEG, 95, output)) throw new IllegalStateException();
                            output.flush();
                        }
                    }
                    public boolean publish(Uri destination) {
                        ContentValues values = new ContentValues(); values.put(MediaStore.Images.Media.IS_PENDING, 0);
                        return activity.getContentResolver().update(destination, values, null, null) > 0;
                    }
                    public void remove(Uri destination) { activity.getContentResolver().delete(destination, null, null); }
                });
                notifyWeb("已保存到相册「熊熊宝典」。请在微信状态中从相册选择刚保存的图片");
            } catch (Exception failed) {
                notifyWeb("相册保存未完成，请检查剩余空间，或使用「保存图片」重试");
            } finally {
                if (bitmap != null) bitmap.recycle();
                synchronized (ShareController.this) { albumSaving = false; }
            }
        }, "bear-share-album").start();
    }
    @JavascriptInterface public void save(String token, int index) {
        final ArrayList<File> files = files(token);
        activity.runOnUiThread(() -> {
            if (files == null || index < 0 || index >= files.size()) { notifyWeb("分享预览已过期，请重新生成"); return; }
            if (pendingSave != null) { notifyWeb("请先完成当前保存"); return; }
            pendingSave = files.get(index);
            try {
                activity.startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("image/png").putExtra(Intent.EXTRA_TITLE, "熊熊分享卡_" + (index + 1) + ".png"), SAVE_CARD);
            } catch (RuntimeException unavailable) { pendingSave = null; notifyWeb("暂时无法打开保存位置，请稍后重试"); }
        });
    }
    public void activityResult(int resultCode, Intent data) {
        final File file = pendingSave; pendingSave = null;
        if (resultCode != Activity.RESULT_OK || data == null || data.getData() == null || file == null) { notifyWeb("已取消保存"); return; }
        final Uri destination = data.getData();
        new Thread(() -> {
            try (FileInputStream input = new FileInputStream(file); OutputStream output = activity.getContentResolver().openOutputStream(destination)) {
                if (output == null) throw new IllegalStateException();
                byte[] buffer = new byte[8192]; int count;
                while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
                output.flush(); notifyWeb("分享图片已保存");
            } catch (Exception failed) { notifyWeb("图片未能保存，请重试"); }
        }, "bear-save-card").start();
    }
    @JavascriptInterface public void copy(String text) {
        if (text == null || text.length() > 100000) return;
        activity.runOnUiThread(() -> {
            ClipboardManager clipboard = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("熊熊宝典分享", text));
            notifyWeb("分享文字已复制");
        });
    }
}
