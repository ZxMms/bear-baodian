package com.xiongxiong.calendar;

import android.app.PendingIntent;
import android.app.AlarmManager;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.util.TypedValue;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.time.LocalDate;
import java.time.Instant;
import java.time.ZoneId;

/** No record contents are exported: widgets receive a bounded private display snapshot. */
final class BearWidgets {
    static final String OPEN_ACTION="bearWidgetAction";
    static final String BOUNDARY="com.xiongxiong.calendar.WIDGET_BOUNDARY";
    private static SharedPreferences prefs(Context c){return c.getSharedPreferences("bear-widgets",Context.MODE_PRIVATE);}
    private static int resource(Context c,String name,String type){return c.getResources().getIdentifier(name,type,c.getPackageName());}
    private static int textHeight(Context c,int sp,int minimum){
        Paint paint=new Paint();
        paint.setTextSize(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP,sp,c.getResources().getDisplayMetrics()));
        Paint.FontMetricsInt metrics=paint.getFontMetricsInt();
        return Math.max(minimum,(int)Math.ceil((metrics.descent-metrics.ascent)/c.getResources().getDisplayMetrics().density));
    }
    static synchronized String update(Context c,String input){
        try {
            if(input==null||input.length()>200000)throw new IllegalArgumentException();
            JSONObject source=new JSONObject(input),saved=new JSONObject();
            JSONObject countdown=source.optJSONObject("countdown");
            if(countdown!=null){
                String date=countdown.optString("date");LocalDate.parse(date);
                saved.put("countdown",new JSONObject().put("title",WidgetContent.clean(countdown.optString("title"),50)).put("date",date));
            }
            JSONArray countdowns=new JSONArray(),next=source.optJSONArray("countdowns");
            if(next!=null)for(int i=0;i<Math.min(64,next.length());i++){
                JSONObject item=next.getJSONObject(i);String date=item.optString("date");LocalDate.parse(date);
                countdowns.put(new JSONObject().put("title",WidgetContent.clean(item.optString("title"),50)).put("date",date));
            }
            saved.put("countdowns",countdowns);
            JSONArray days=new JSONArray(),incoming=source.optJSONArray("days");
            if(incoming!=null)for(int i=0;i<Math.min(370,incoming.length());i++){
                JSONObject item=incoming.getJSONObject(i);String date=item.optString("date");LocalDate.parse(date);
                JSONArray records=new JSONArray(),list=item.optJSONArray("items");
                if(list!=null)for(int n=0;n<Math.min(20,list.length());n++){
                    JSONObject row=list.getJSONObject(n);records.put(new JSONObject().put("id",WidgetContent.clean(row.optString("id"),100)).put("title",WidgetContent.clean(row.optString("title"),70)).put("time",WidgetContent.clean(row.optString("time"),8)));
                }
                JSONObject day=new JSONObject().put("date",date).put("items",records);
                // Metadata is dated together with the schedule. Never reuse yesterday's
                // mood or record count after a midnight refresh or stale snapshot.
                if(item.has("recordCount"))day.put("recordCount",WidgetContent.recordCount(item.optInt("recordCount")))
                    .put("lunarLabel",WidgetContent.clean(item.optString("lunarLabel"),24))
                    .put("seasonLabel",WidgetContent.clean(item.optString("seasonLabel"),24))
                    .put("moodLabel",WidgetContent.clean(item.optString("moodLabel"),12));
                days.put(day);
            }
            // Desktop colours are a separate preference. Old snapshots deliberately
            // remain light rather than inheriting the app, launcher or clock theme.
            saved.put("days",days).put("widgetTheme",WidgetContent.widgetTheme(source.optString("widgetTheme"))).put("updatedAt",System.currentTimeMillis());
            if(!prefs(c).edit().putString("snapshot",saved.toString()).commit())throw new IllegalStateException();
            updateAll(c);return new JSONObject().put("ok",true).toString();
        }catch(Exception invalid){return "{\"ok\":false,\"message\":\"桌面组件暂未更新，请重新打开应用\"}";}
    }
    private static JSONObject snapshot(Context c){try{return new JSONObject(prefs(c).getString("snapshot","{}"));}catch(Exception invalid){return new JSONObject();}}
    private static JSONObject countdown(JSONObject saved,LocalDate today){
        JSONArray list=saved.optJSONArray("countdowns");
        if(list!=null){
            String[] dates=new String[list.length()];
            for(int i=0;i<list.length();i++){JSONObject item=list.optJSONObject(i);dates[i]=item==null?"":item.optString("date");}
            int chosen=WidgetContent.upcomingIndex(dates,today);
            if(chosen>=0)return list.optJSONObject(chosen);
        }
        return saved.optJSONObject("countdown");
    }
    static void updateAll(Context c){
        AppWidgetManager manager=AppWidgetManager.getInstance(c);
        update(c,manager,manager.getAppWidgetIds(new ComponentName(c,BearSmallWidget.class)),false);
        update(c,manager,manager.getAppWidgetIds(new ComponentName(c,BearLargeWidget.class)),true);
    }
    static void scheduleBoundary(Context c){
        // DATE_CHANGED manifest broadcasts are restricted on modern Android. An explicit,
        // non-wakeup alarm adds a cross-day refresh without asking for another permission.
        try {
            AlarmManager alarms=c.getSystemService(AlarmManager.class);
            PendingIntent pending=PendingIntent.getBroadcast(c,0,new Intent(c,BearSmallWidget.class).setAction(BOUNDARY),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            AppWidgetManager manager=AppWidgetManager.getInstance(c);
            int count=manager.getAppWidgetIds(new ComponentName(c,BearSmallWidget.class)).length+manager.getAppWidgetIds(new ComponentName(c,BearLargeWidget.class)).length;
            if(count==0){alarms.cancel(pending);return;}
            alarms.set(AlarmManager.RTC,WidgetContent.nextBoundary(Instant.now(),ZoneId.systemDefault()).toEpochMilli(),pending);
        }catch(RuntimeException unavailable){/* The system's periodic widget updates remain available. */}
    }
    static void update(Context c,AppWidgetManager manager,int[] ids,boolean large){
        JSONObject saved=snapshot(c);LocalDate today=LocalDate.now();
        JSONObject currentDay=null;JSONArray days=saved.optJSONArray("days");
        if(days!=null)for(int i=0;i<days.length();i++){JSONObject day=days.optJSONObject(i);if(day!=null&&today.toString().equals(day.optString("date"))){currentDay=day;break;}}
        boolean currentMetadata=currentDay!=null&&currentDay.has("recordCount");
        for(int widgetId:ids){
            RemoteViews views=new RemoteViews(c.getPackageName(),resource(c,large?"bear_widget_large":"bear_widget_small","layout"));
            Bundle options=manager.getAppWidgetOptions(widgetId);
            int minimumHeight=options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT,large?180:110);
            if(minimumHeight<=0)minimumHeight=large?180:110;
            WidgetContent.Layout layout=WidgetContent.layout(minimumHeight,large,textHeight(c,11,0),textHeight(c,10,14),textHeight(c,large?14:13,0),textHeight(c,large?11:10,14),textHeight(c,12,0));
            boolean compact=layout.compact;
            views.setViewVisibility(resource(c,"widget_title","id"),compact?View.GONE:View.VISIBLE);
            views.setViewVisibility(resource(c,"widget_lunar","id"),layout.lunar?View.VISIBLE:View.GONE);
            views.setViewVisibility(resource(c,"widget_summary","id"),layout.summary?View.VISIBLE:View.GONE);
            String theme=WidgetContent.widgetTheme(saved.optString("widgetTheme"));
            views.setInt(resource(c,"widget_root","id"),"setBackgroundResource",resource(c,"cream".equals(theme)?"widget_background":"widget_background_"+theme,"drawable"));
            int ink=Color.parseColor("#5A3C2B"),muted=Color.parseColor("mint".equals(theme)?"#607865":"peach".equals(theme)?"#986957":"#8A705B");
            int accent=Color.parseColor("mint".equals(theme)?"#436B55":"peach".equals(theme)?"#A25240":"#985538");
            views.setTextViewText(resource(c,"widget_date","id"),WidgetContent.dateLabel(today));
            views.setTextColor(resource(c,"widget_date","id"),muted);
            views.setTextColor(resource(c,"widget_title","id"),ink);
            views.setTextColor(resource(c,"widget_countdown","id"),accent);
            views.setTextColor(resource(c,"widget_lunar","id"),muted);
            views.setTextColor(resource(c,"widget_summary","id"),muted);
            views.setTextViewText(resource(c,"widget_lunar","id"),currentMetadata?WidgetContent.dayLabel(currentDay.optString("lunarLabel"),currentDay.optString("seasonLabel"),large):"打开更新农历与节气");
            views.setTextViewText(resource(c,"widget_summary","id"),currentMetadata?WidgetContent.daySummary(currentDay.optString("moodLabel"),currentDay.optInt("recordCount"),large):"打开更新今日内容");
            JSONObject countdown=countdown(saved,today);
            views.setTextViewText(resource(c,"widget_title","id"),countdown==null?"一二布布陪着你":countdown.optString("title","重要日子"));
            String countdownText=countdown==null?"收好今天的小日子":compact?WidgetContent.clean(countdown.optString("title","重要日子"),large?9:5)+" · "+WidgetContent.compactCountdown(countdown.optString("date"),today):WidgetContent.countdown(countdown.optString("date"),today);
            views.setTextViewText(resource(c,"widget_countdown","id"),countdownText);
            PendingIntent open=openIntent(c,"calendar","",widgetId);
            views.setOnClickPendingIntent(resource(c,"widget_root","id"),open);
            if(large){
                JSONArray items=currentDay==null?null:currentDay.optJSONArray("items");
                int lines=Math.max(1,layout.agendaLines);
                views.setViewVisibility(resource(c,"widget_items","id"),layout.agenda?View.VISIBLE:View.GONE);
                views.setInt(resource(c,"widget_items","id"),"setMaxLines",lines);
                StringBuilder summary=new StringBuilder();
                int shown=items==null?0:Math.min(items.length(),items.length()>lines?Math.max(1,lines-1):lines);
                if(items!=null)for(int i=0;i<shown;i++){JSONObject item=items.optJSONObject(i);if(item==null)continue;if(summary.length()>0)summary.append('\n');String time=item.optString("time");if(lines==1&&items.length()>1)summary.append(items.length()).append("件安排 · ");summary.append(time.isEmpty()?"• ":time+"  ").append(item.optString("title"));}
                if(summary.length()==0)summary.append(items==null?"点开更新今天的安排":"今天无安排，记点生活吧");
                else if(items!=null&&items.length()>shown&&lines>1)summary.append("\n还有 ").append(items.length()-shown).append(" 件，点开看看");
                views.setTextViewText(resource(c,"widget_items","id"),summary.toString());
                views.setTextColor(resource(c,"widget_items","id"),ink);
                views.setTextColor(resource(c,"widget_entry","id"),ink);
                views.setTextColor(resource(c,"widget_weather","id"),ink);
                views.setTextColor(resource(c,"widget_ledger","id"),ink);
                boolean largeType=c.getResources().getConfiguration().fontScale>1.3f;
                views.setTextViewText(resource(c,"widget_entry","id"),largeType?"记生活":"＋ 记生活");
                views.setTextViewText(resource(c,"widget_ledger","id"),largeType?"记账":"¥ 记一笔");
                int button=resource(c,"cream".equals(theme)?"widget_button":"widget_button_"+theme,"drawable");
                views.setInt(resource(c,"widget_entry","id"),"setBackgroundResource",button);
                views.setInt(resource(c,"widget_ledger","id"),"setBackgroundResource",button);
                views.setOnClickPendingIntent(resource(c,"widget_entry","id"),openIntent(c,"entry","",widgetId));
                views.setInt(resource(c,"widget_weather","id"),"setBackgroundResource",button);
                views.setOnClickPendingIntent(resource(c,"widget_weather","id"),openIntent(c,"weather","",widgetId));
                views.setOnClickPendingIntent(resource(c,"widget_ledger","id"),openIntent(c,"ledger","",widgetId));
            }
            manager.updateAppWidget(widgetId,views);
        }
        scheduleBoundary(c);
    }
    static PendingIntent openIntent(Context c,String type,String recipeId,int discriminator){
        Intent open=new Intent(c,MainActivity.class).setData(new Uri.Builder().scheme("bear-calendar").authority("widget").appendPath(type).appendPath(recipeId).appendQueryParameter("widget",String.valueOf(discriminator)).build())
            .putExtra(OPEN_ACTION,type).putExtra("recipeId",recipeId).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(c,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    static String pin(Context c,String size){
        try {
            AppWidgetManager manager=AppWidgetManager.getInstance(c);
            boolean supported=manager.isRequestPinAppWidgetSupported();
            if(!supported)return new JSONObject().put("supported",false).put("requested",false).put("message","请长按桌面空白处，在小组件中找到熊熊宝典").toString();
            boolean requested=manager.requestPinAppWidget(new ComponentName(c,"large".equals(size)?BearLargeWidget.class:BearSmallWidget.class),null,null);
            return new JSONObject().put("supported",true).put("requested",requested).put("message",requested?"请在系统弹窗中确认添加；也可以长按桌面添加":"桌面未接受请求，请长按桌面添加小组件").toString();
        }catch(Exception error){return "{\"supported\":false,\"requested\":false,\"message\":\"请长按桌面空白处添加熊熊宝典小组件\"}";}
    }
}
