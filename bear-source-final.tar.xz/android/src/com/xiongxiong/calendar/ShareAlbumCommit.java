package com.xiongxiong.calendar;

/** Only a completely written image becomes visible to other gallery clients. */
final class ShareAlbumCommit {
    interface Store<T> {
        T create() throws Exception;
        void write(T item) throws Exception;
        boolean publish(T item) throws Exception;
        void remove(T item) throws Exception;
    }
    static <T> T write(Store<T> store) throws Exception {
        T item = store.create();
        if (item == null) throw new IllegalStateException("Image allocation failed");
        try {
            store.write(item);
            if (!store.publish(item)) throw new IllegalStateException("Image publication failed");
            return item;
        } catch (Exception failure) {
            try { store.remove(item); } catch (Exception cleanup) { failure.addSuppressed(cleanup); }
            throw failure;
        }
    }
}
