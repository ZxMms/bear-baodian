package com.xiongxiong.calendar;

import java.util.ArrayList;
import java.util.Collection;

/** Selection order is also the order returned to the WebView. */
final class GallerySelection {
    final int limit;
    private final ArrayList<String> keys = new ArrayList<>();
    GallerySelection(int maximum) { limit = Math.max(1, Math.min(5, maximum)); }
    boolean toggle(String key) {
        if (key == null || key.isEmpty()) return false;
        if (keys.remove(key)) return true;
        if (limit == 1) keys.clear();
        if (keys.size() == limit) return false;
        keys.add(key); return true;
    }
    int number(String key) { return keys.indexOf(key) + 1; }
    int size() { return keys.size(); }
    ArrayList<String> values() { return new ArrayList<>(keys); }
    void restore(Collection<String> saved) {
        keys.clear(); if (saved == null) return;
        for (String key : saved) if (key != null && !key.isEmpty() && !keys.contains(key) && keys.size() < limit) keys.add(key);
    }
    void retain(Collection<String> available) { keys.retainAll(available); }
}
