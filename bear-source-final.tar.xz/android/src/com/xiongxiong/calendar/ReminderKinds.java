package com.xiongxiong.calendar;

/** One kind mapping for both native reminder validation and notification wording. */
final class ReminderKinds {
    private static String name(String kind) {
        if ("memo".equals(kind)) return "备注";
        if ("event".equals(kind)) return "活动";
        if ("anniversary".equals(kind)) return "纪念日";
        if ("capsule".equals(kind)) return "时光胶囊";
        return null;
    }
    static boolean allowed(String kind) { return name(kind) != null; }
    static String label(String kind) {
        String result = name(kind);
        if (result == null) throw new IllegalArgumentException("不支持的提醒类型");
        return result;
    }
}
