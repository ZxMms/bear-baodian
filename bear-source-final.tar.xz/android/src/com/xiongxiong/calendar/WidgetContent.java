package com.xiongxiong.calendar;

import java.time.LocalDate;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;

/** Date/text rules kept independent of Android for regression checks. */
final class WidgetContent {
    static String clean(String value,int max){
        if(value==null)return "";
        String text=value.replaceAll("[\\p{Cntrl}&&[^\\n]]","").trim();
        return text.length()>max?text.substring(0,max-1)+"…":text;
    }
    static String countdown(String date,LocalDate today){
        try {
            long days=ChronoUnit.DAYS.between(today,LocalDate.parse(date));
            return days==0?"就是今天":days>0?"还有 "+days+" 天":"已过 "+(-days)+" 天";
        } catch(RuntimeException invalid){return "打开挑一个重要日子";}
    }
    static String dateLabel(LocalDate date){
        return date.getMonthValue()+"月"+date.getDayOfMonth()+"日 · 周"+"一二三四五六日".charAt(date.getDayOfWeek().getValue()-1);
    }
    static String compactCountdown(String date,LocalDate today){
        try{
            long days=ChronoUnit.DAYS.between(today,LocalDate.parse(date));
            return days==0?"今天":days>0?days+"天后":(-days)+"天前";
        }catch(RuntimeException invalid){return "待设置";}
    }
    static int recordCount(int count){return Math.max(0,Math.min(9999,count));}
    static String dayLabel(String lunar,String season,boolean large){
        String l=clean(lunar,24),s=clean(season,24);
        if(l.isEmpty()&&s.isEmpty())return "打开更新农历与节气";
        return (l.isEmpty()?"":(large?"农历 ":"")+l)+(l.isEmpty()||s.isEmpty()?"":" · ")+s;
    }
    static String daySummary(String mood,int count,boolean large){
        String label=clean(mood,12);
        return (label.isEmpty()?"心情待记录":label)+" · "+recordCount(count)+(large?" 条记录":"条");
    }
    static int upcomingIndex(String[] dates,LocalDate today){
        int result=-1;LocalDate nearest=null;
        for(int i=0;i<dates.length;i++){
            try {LocalDate date=LocalDate.parse(dates[i]);if(!date.isBefore(today)&&(nearest==null||date.isBefore(nearest))){result=i;nearest=date;}}
            catch(RuntimeException invalid){/* A malformed entry must not hide other valid dates. */}
        }
        return result;
    }
    static String widgetTheme(String value){
        return "peach".equals(value)||"mint".equals(value)?value:"cream";
    }
    /** Budget one-line text using measured font heights, so large system type
     * does not get cut off by the launcher's fixed widget bounds. */
    static final class Layout {
        boolean compact,lunar=true,summary=true,agenda;
        int agendaLines;
    }
    private static int layoutHeight(Layout layout,boolean large,int date,int lunar,int title,int summary,int agenda){
        if(large){
            int heading=Math.max(52,date+2+24+(layout.lunar?lunar+2:0)+(layout.compact?0:title+4));
            return 24+heading+44+(layout.summary?summary+5:0)+(layout.agenda?agenda+22:0);
        }
        return 20+Math.max(28,date)+3+26+(layout.lunar?lunar+2:0)+(layout.compact?0:title+5)+(layout.summary?summary+3:0);
    }
    static Layout layout(int height,boolean large,int date,int lunar,int title,int summary,int agenda){
        Layout result=new Layout();result.compact=height<(large?205:130);result.agenda=large;
        if(layoutHeight(result,large,date,lunar,title,summary,agenda)>height)result.compact=true;
        if(layoutHeight(result,large,date,lunar,title,summary,agenda)>height)result.summary=false;
        if(layoutHeight(result,large,date,lunar,title,summary,agenda)>height)result.agenda=false;
        if(layoutHeight(result,large,date,lunar,title,summary,agenda)>height)result.lunar=false;
        if(result.agenda){
            int base=layoutHeight(result,large,date,lunar,title,summary,0)-22;
            result.agendaLines=Math.max(1,Math.min(4,(height-base-22+3)/(agenda+3)));
        }
        return result;
    }
    static Instant nextBoundary(Instant now,ZoneId zone){
        ZonedDateTime local=now.atZone(zone);LocalDate date=local.toLocalDate();
        // No sunrise/sunset colour changes: only the content's local day matters.
        return date.plusDays(1).atStartOfDay(zone).toInstant();
    }
}
