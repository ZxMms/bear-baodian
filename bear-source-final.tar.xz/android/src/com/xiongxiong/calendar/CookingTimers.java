package com.xiongxiong.calendar;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.service.notification.StatusBarNotification;
import android.net.Uri;
import android.os.Build;
import android.os.SystemClock;
import android.provider.Settings;
import org.json.JSONArray;
import org.json.JSONObject;

/** Independent from calendar reminders: one durable alarm per cooking session. */
final class CookingTimers {
    static final String CHANNEL = "bear_cooking_timers_v2";
    private static final String LEGACY_CHANNEL = "bear_cooking_timers_v1";
    static final String ALARM = "com.xiongxiong.calendar.COOKING_TIMER";
    static final String STOP_RINGING = "com.xiongxiong.calendar.COOKING_TIMER_STOP_RINGING";
    private static String cachedSoundUri="",cachedSoundTitle="";
    private static long cachedSoundAt;
    private static SharedPreferences prefs(Context c) { return c.getSharedPreferences("cooking-timers", Context.MODE_PRIVATE); }
    private static NotificationManager notifications(Context c) { return c.getSystemService(NotificationManager.class); }
    private static int boot(Context c) { return Settings.Global.getInt(c.getContentResolver(), Settings.Global.BOOT_COUNT, -1); }

    static void createChannel(Context c) {
        NotificationManager manager = notifications(c);
        // Channel sound/usage cannot be changed after creation. Carry the user's
        // previous blocking, silence and custom sound choices into the new channel.
        if (manager.getNotificationChannel(CHANNEL) != null) return;
        NotificationChannel previous = manager.getNotificationChannel(LEGACY_CHANNEL);
        NotificationChannel channel = new NotificationChannel(CHANNEL, "熊熊计时响铃",
            previous == null ? NotificationManager.IMPORTANCE_HIGH : previous.getImportance());
        channel.setDescription("计时结束响铃，最多 30 秒；可在通知中停止。使用系统闹钟音量与勿扰设置。");
        channel.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
        String raw = c.getResources().getIdentifier("bear_cooking_alarm", "raw", c.getPackageName()) == 0
            ? "bear_reminder" : "bear_cooking_alarm";
        Uri sound = Uri.parse("android.resource://" + c.getPackageName() + "/raw/" + raw);
        Uri legacyDefault = Uri.parse("android.resource://" + c.getPackageName() + "/raw/bear_reminder");
        if (previous != null && (previous.getSound() == null || !legacyDefault.equals(previous.getSound())
            || (Build.VERSION.SDK_INT >= 30 && previous.hasUserSetSound()))) sound = previous.getSound();
        channel.setSound(sound, new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
        channel.setBypassDnd(false);
        channel.enableVibration(previous == null || previous.shouldVibrate());
        manager.createNotificationChannel(channel);
    }
    private static boolean enabled(Context c) {
        createChannel(c);
        NotificationChannel channel = notifications(c).getNotificationChannel(CHANNEL);
        return notifications(c).areNotificationsEnabled() && channel != null && channel.getImportance() != NotificationManager.IMPORTANCE_NONE;
    }
    private static JSONArray rows(Context c) {
        try { return new JSONArray(prefs(c).getString("rows", "[]")); }
        catch (Exception invalid) { return new JSONArray(); }
    }
    private static void persist(Context c, JSONArray rows) {
        if (!prefs(c).edit().putString("rows", rows.toString()).commit()) throw new IllegalStateException("计时未能保存，请重试");
    }
    private static JSONObject find(JSONArray rows, String id) {
        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.optJSONObject(i);
            if (row != null && id.equals(row.optString("id"))) return row;
        }
        return null;
    }
    private static JSONArray prune(JSONArray old, String removedId) {
        JSONArray saved = new JSONArray();
        long now = System.currentTimeMillis();
        for (int i = 0; i < old.length(); i++) {
            JSONObject row = old.optJSONObject(i);
            if (row == null || row.optString("id").equals(removedId)) continue;
            if (!row.optBoolean("active") && now - row.optLong("finishedAt") > CookingTimerRules.DAY) continue;
            saved.put(row);
        }
        return saved;
    }
    private static PendingIntent alarmIntent(Context c, String id) {
        Intent intent = new Intent(c, CookingTimerReceiver.class).setAction(ALARM)
            .setData(new Uri.Builder().scheme("bear-calendar").authority("cooking-timer").appendPath(id).build()).putExtra("recipeId", id);
        return PendingIntent.getBroadcast(c, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    private static PendingIntent stopIntent(Context c, String id) {
        Intent intent = new Intent(c, CookingTimerReceiver.class).setAction(STOP_RINGING)
            .setData(new Uri.Builder().scheme("bear-calendar").authority("cooking-timer-stop").appendPath(id).build())
            .putExtra("recipeId", id);
        return PendingIntent.getBroadcast(c, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    /** Stops only the sounding notice; the completed cooking session stays available. */
    static synchronized boolean stopRinging(Context c, String id) {
        if (!CookingTimerRules.validId(id)) return false;
        try {
            try {
                JSONArray saved=rows(c);JSONObject row=find(saved,id);
                if(row!=null&&row.optInt("deliveryAttempts")>0){
                    c.getSystemService(AlarmManager.class).cancel(alarmIntent(c,id));
                    complete(c,saved,row,"stopped","");
                }
            } finally {
                // A storage failure must never keep an already sounding notice
                // alive after the user has explicitly asked it to stop.
                notifications(c).cancel("cooking-"+id,1);
            }
            return true;
        } catch(Exception unavailable) { return false; }
    }
    private static boolean soundEnabled(Context c) {
        NotificationChannel channel = notifications(c).getNotificationChannel(CHANNEL);
        return channel != null && channel.getImportance() >= NotificationManager.IMPORTANCE_DEFAULT && channel.getSound() != null;
    }
    static synchronized void invalidateRingtoneTitle() {
        cachedSoundUri="";cachedSoundTitle="";cachedSoundAt=0;
    }
    private static String soundTitle(Context c,Uri uri) {
        String key=uri.toString();long now=SystemClock.elapsedRealtime();
        if(key.equals(cachedSoundUri)&&now-cachedSoundAt<60000L)return cachedSoundTitle;
        Ringtone ringtone=null;String title="";
        try {
            ringtone=RingtoneManager.getRingtone(c,uri);
            if(ringtone!=null)title=WidgetContent.clean(ringtone.getTitle(c),100);
        } catch(RuntimeException unavailable) { /* Reading another provider's title does not require requesting file access. */ }
        finally {
            // getRingtone may prepare a player even though metadata is all we need.
            // Never play it; release that player after reading its title.
            if(ringtone!=null)try{ringtone.stop();}catch(RuntimeException ignored){}
        }
        cachedSoundUri=key;cachedSoundTitle=title;cachedSoundAt=now;
        return title;
    }
    private static JSONObject soundDetails(Context c) throws Exception {
        NotificationChannel channel=notifications(c).getNotificationChannel(CHANNEL);
        if(channel==null)return new JSONObject().put("soundName","暂未读到铃声名称").put("soundKind","unknown");
        Uri uri=channel.getSound();String value=uri==null?null:uri.toString();
        String builtin=CookingTimerRules.builtinSoundName(value,c.getPackageName(),
            c.getResources().getIdentifier("bear_cooking_alarm","raw",c.getPackageName()),
            c.getResources().getIdentifier("bear_reminder","raw",c.getPackageName()));
        String kind=CookingTimerRules.soundKind(value,builtin,uri!=null&&RingtoneManager.isDefault(uri));
        String title=uri!=null&&!"silent".equals(kind)&&!"builtin".equals(kind)?soundTitle(c,uri):"";
        return new JSONObject().put("soundName",CookingTimerRules.soundName(kind,builtin,title)).put("soundKind",kind);
    }
    private static long remaining(Context c, JSONObject row) {
        return CookingTimerRules.remaining(row.optLong("endAt"), row.optLong("elapsedEnd"), row.optInt("boot", -1), boot(c), System.currentTimeMillis(), SystemClock.elapsedRealtime());
    }
    /** Returns whether an exact alarm was actually accepted, rather than just checking permission. */
    private static boolean schedule(Context c, JSONObject row, long remaining) throws Exception {
        long at = SystemClock.elapsedRealtime() + Math.max(1, remaining);
        AlarmManager alarms = c.getSystemService(AlarmManager.class);
        PendingIntent pending = alarmIntent(c, row.getString("id"));
        alarms.cancel(pending);
        row.put("endAt", System.currentTimeMillis() + Math.max(0, remaining))
            .put("elapsedEnd", at).put("boot", boot(c));
        boolean exact = Build.VERSION.SDK_INT < 31 || alarms.canScheduleExactAlarms();
        if (exact) {
            try {
                alarms.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pending);
                row.put("scheduled", true).put("exact", true);
                return true;
            } catch (SecurityException revoked) { /* Permission may have changed since the check. */ }
        }
        alarms.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pending);
        row.put("scheduled", true).put("exact", false);
        return false;
    }
    private static JSONObject health(Context c) throws Exception {
        boolean notification=enabled(c),sound=soundEnabled(c),exact=Reminders.exact(c);
        int alarmVolume=-1,alarmMaxVolume=-1,mediaVolume=-1,filter=NotificationManager.INTERRUPTION_FILTER_UNKNOWN;
        try { AudioManager audio=c.getSystemService(AudioManager.class);alarmVolume=audio.getStreamVolume(AudioManager.STREAM_ALARM);alarmMaxVolume=audio.getStreamMaxVolume(AudioManager.STREAM_ALARM);mediaVolume=audio.getStreamVolume(AudioManager.STREAM_MUSIC); } catch(RuntimeException ignored) {}
        try { filter=notifications(c).getCurrentInterruptionFilter(); } catch(RuntimeException ignored) {}
        return soundDetails(c).put("notifications",notification).put("channelSound",sound).put("soundEnabled",notification&&sound)
            .put("alarmVolume",alarmVolume).put("alarmMaxVolume",alarmMaxVolume).put("mediaVolume",mediaVolume)
            .put("interruptionFilter",filter).put("exact",exact).put("ringMaxSeconds",CookingTimerRules.RING_TIMEOUT_MS/1000)
            .put("message",CookingTimerRules.healthMessage(notification,sound,alarmVolume,filter,exact));
    }
    static synchronized String ringingStatus(Context c) {
        try { return health(c).put("ok",true).toString(); }
        catch(Exception unavailable) { return "{\"ok\":false,\"message\":\"暂时无法读取系统响铃状态，请打开响铃与通知设置检查\"}"; }
    }
    private static String message(boolean scheduled,boolean exact,JSONObject health) {
        if(!scheduled)return "倒计时已开始，后台提醒暂未安排；请保持做菜页打开";
        if(!health.optBoolean("notifications")||!health.optBoolean("channelSound")||health.optInt("alarmVolume",-1)==0
            ||health.optInt("interruptionFilter")==2||health.optInt("interruptionFilter")==3)return "倒计时已开始；"+health.optString("message");
        if(!exact)return "倒计时已开始；未允许精确提醒，后台通知可能延迟";
        return "倒计时已开始，到点尝试响铃最多 30 秒，可在通知里停止";
    }
    static synchronized String start(Context c, String id, String label, int seconds) {
        try {
            if (!CookingTimerRules.validId(id)) throw new IllegalArgumentException("菜谱编号不正确");
            long duration = CookingTimerRules.durationMillis(seconds);
            JSONArray saved = prune(rows(c), id);
            int active = 0;
            for (int i = 0; i < saved.length(); i++) if (saved.getJSONObject(i).optBoolean("active")) active++;
            if (active >= 20) throw new IllegalArgumentException("最多同时开启 20 个做菜计时");
            String title = WidgetContent.clean(label, 80);
            if (title.isEmpty()) title = "做菜计时";
            JSONObject row = new JSONObject().put("id", id).put("title", title).put("active", true)
                .put("endAt", System.currentTimeMillis() + duration).put("elapsedEnd", SystemClock.elapsedRealtime() + duration)
                .put("boot", boot(c)).put("exact", false).put("scheduled", false);
            saved.put(row);
            persist(c, saved);
            notifications(c).cancel("cooking-" + id, 1);
            boolean exact = false, scheduled = false;
            try { exact = schedule(c, row, duration); scheduled = true; }
            catch (RuntimeException unavailable) { row.put("scheduled", false).put("exact", false); }
            persist(c, saved);
            JSONObject health=health(c);
            return health.put("ok",true).put("scheduled",scheduled).put("exact",exact)
                .put("endAt",row.getLong("endAt")).put("message",message(scheduled,exact,health)).toString();
        } catch (Exception error) {
            try { return new JSONObject().put("ok", false).put("scheduled", false).put("message", error.getMessage() == null ? "计时未能开始，请重试" : error.getMessage()).toString(); }
            catch (Exception ignored) { return "{\"ok\":false,\"scheduled\":false}"; }
        }
    }
    static synchronized boolean cancel(Context c, String id) {
        if (!CookingTimerRules.validId(id)) return false;
        try {
            persist(c, prune(rows(c), id));
            c.getSystemService(AlarmManager.class).cancel(alarmIntent(c, id));
            notifications(c).cancel("cooking-" + id, 1);
            return true;
        } catch (Exception error) { return false; }
    }
    static synchronized String status(Context c, String id) {
        try {
            JSONObject row=find(rows(c),id);
            // The visible app shares the broadcast's single synchronized completion
            // path, so an OEM-delayed alarm still rings while the cook is watching.
            if(row!=null&&row.optBoolean("active")&&remaining(c,row)<=0){fire(c,id);row=find(rows(c),id);}
            JSONObject result=health(c);
            if(row==null)return result.put("active",false).put("known",false).toString();
            long left=remaining(c,row);
            return result.put("known",true).put("active",row.optBoolean("active")&&left>0)
                .put("finished",!row.optBoolean("active")||left<=0).put("endAt",row.optBoolean("active")?System.currentTimeMillis()+left:row.optLong("endAt"))
                .put("exact",row.optBoolean("exact")).put("scheduled",row.optBoolean("scheduled"))
                .put("deliveryStatus",row.optString("deliveryStatus")).put("deliveryError",row.optString("deliveryError"))
                .put("deliveryAttempts",row.optInt("deliveryAttempts")).toString();
        } catch(Exception invalid) { return "{\"active\":false,\"known\":false}"; }
    }
    /** 1 = posted, 0 = definitely absent, -1 = cannot determine. */
    private static int posted(Context c,String id){
        try{for(StatusBarNotification notice:notifications(c).getActiveNotifications())if(notice.getId()==1&&("cooking-"+id).equals(notice.getTag()))return 1;return 0;}
        catch(RuntimeException unknown){return -1;}
    }
    private static void complete(Context c,JSONArray saved,JSONObject row,String state,String error) throws Exception {
        row.put("active",false).put("scheduled",false).put("finishedAt",System.currentTimeMillis()).put("nextRetryAt",0)
            .put("deliveryStatus",state).put("deliveryError",error);
        persist(c,saved);c.getSystemService(AlarmManager.class).cancel(alarmIntent(c,row.getString("id")));
    }
    private static void retry(Context c,JSONArray saved,JSONObject row,long left) throws Exception {
        if(!CookingTimerRules.retryDelivery(row.optInt("deliveryAttempts"),left)){
            complete(c,saved,row,"failed","计时已结束，但系统通知未能发出；请用 5 秒试响检查");return;
        }
        row.put("active",true).put("scheduled",false).put("deliveryStatus","retrying")
            .put("deliveryError","计时已结束，系统通知暂未发出，正在重试")
            .put("nextRetryAt",System.currentTimeMillis()+CookingTimerRules.DELIVERY_RETRY_MS);
        persist(c,saved);
        AlarmManager alarms=c.getSystemService(AlarmManager.class);PendingIntent pending=alarmIntent(c,row.getString("id"));
        long at=SystemClock.elapsedRealtime()+CookingTimerRules.DELIVERY_RETRY_MS;
        try{
            if(Reminders.exact(c))alarms.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP,at,pending);
            else alarms.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP,at,pending);
            row.put("scheduled",true);persist(c,saved);
        }catch(Exception unavailable){/* The next visible status check may retry after the same backoff. */}
    }
    private static void finish(Context c, JSONArray saved, JSONObject row, long left) throws Exception {
        String id=row.getString("id"),state=row.optString("deliveryStatus");
        int attempts=row.optInt("deliveryAttempts");
        CookingTimerRules.DeliveryAction action=CookingTimerRules.deliveryAction(attempts,state,left,
            System.currentTimeMillis(),row.optLong("nextRetryAt"),attempts>0?posted(c,id):0);
        switch(action){
            case WAIT:return;
            case POSTED:complete(c,saved,row,"posted","");return;
            case UNCONFIRMED:complete(c,saved,row,"unconfirmed","计时已结束，系统响铃状态暂无法确认；请用 5 秒试响检查");return;
            case FAILED:complete(c,saved,row,"failed","计时已结束，系统通知未能发出；请用 5 秒试响检查");return;
            default:break;
        }
        if(!CookingTimerRules.shouldNotify(left)){complete(c,saved,row,"expired","");return;}
        if(!enabled(c)){complete(c,saved,row,"blocked","计时已结束，通知未开启；请打开响铃与通知设置");return;}
        int icon=c.getResources().getIdentifier("ic_reminder","drawable",c.getPackageName());
        PendingIntent stop=stopIntent(c,id);boolean test=CookingTimerRules.TEST_ID.equals(id);
        Notification notification=new Notification.Builder(c,CHANNEL).setSmallIcon(icon)
            .setContentTitle(test?"熊熊厨房 · 响铃测试":"熊熊厨房 · 计时到啦")
            .setContentText(test?"如果能听到铃声，计时提醒已正常工作":row.optString("title")+"，该看看火候啦")
            .setStyle(new Notification.BigTextStyle().bigText((test?"这是 5 秒响铃测试":row.optString("title")+"，该看看火候啦")+"\n响铃最多 30 秒，点下方可提前停止。"))
            .setCategory(Notification.CATEGORY_ALARM).setVisibility(Notification.VISIBILITY_PRIVATE).setAutoCancel(true).setOnlyAlertOnce(true)
            .setTimeoutAfter(CookingTimerRules.RING_TIMEOUT_MS).setDeleteIntent(stop)
            .addAction(new Notification.Action.Builder((android.graphics.drawable.Icon)null,"停止响铃",stop).build())
            .setContentIntent(BearWidgets.openIntent(c,test?"calendar":"cooking",test?"":id,0)).build();
        if(soundEnabled(c))notification.flags|=Notification.FLAG_INSISTENT;
        row.put("deliveryStatus","posting").put("deliveryAttempts",row.optInt("deliveryAttempts")+1).put("deliveryError","");
        persist(c,saved);
        try { notifications(c).notify("cooking-"+id,1,notification); }
        catch(RuntimeException failed){
            int delivery=posted(c,id);
            if(delivery==1){complete(c,saved,row,"posted","");return;}
            if(delivery<0){complete(c,saved,row,"unconfirmed","计时已结束，系统响铃状态暂无法确认；请用 5 秒试响检查");return;}
            retry(c,saved,row,left);return;
        }
        // If this commit fails, persisted "posting" plus the same active tag/id
        // let recovery acknowledge delivery without playing the alarm again.
        complete(c,saved,row,"posted","");
    }
    static synchronized void fire(Context c, String id) {
        if (!CookingTimerRules.validId(id)) return;
        try {
            JSONArray saved = rows(c);
            JSONObject row = find(saved, id);
            if (row == null || !row.optBoolean("active")) return;
            long left = remaining(c, row);
            if (left > 0) { schedule(c, row, left); persist(c, saved); }
            else finish(c, saved, row, left);
        } catch (Exception ignored) { /* Retry on next resume/boot instead of crashing a broadcast receiver. */ }
    }
    static synchronized void restore(Context c) {
        try {
            createChannel(c);
            JSONArray saved = prune(rows(c), "");
            for (int i = 0; i < saved.length(); i++) {
                JSONObject row = saved.getJSONObject(i);
                if (!row.optBoolean("active")) continue;
                long left = remaining(c, row);
                if (left <= 0) finish(c, saved, row, left);
                else {
                    try { schedule(c, row, left); }
                    catch (Exception unavailable) { row.put("scheduled", false).put("exact", false); }
                }
            }
            persist(c, saved);
        } catch (Exception ignored) { /* Keep saved sessions for the next recovery opportunity. */ }
    }
}
