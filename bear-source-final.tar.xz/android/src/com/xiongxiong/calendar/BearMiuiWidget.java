package com.xiongxiong.calendar;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

/** Registered only in the Xiaomi review build. Never starts the main process on refresh. */
public abstract class BearMiuiWidget extends AppWidgetProvider {
    abstract boolean large();
    @Override public void onUpdate(Context c,AppWidgetManager manager,int[] requested) {
        // Work only on this provider's current IDs, even if a malformed broadcast supplies IDs.
        int[] installed=manager.getAppWidgetIds(new ComponentName(c,getClass()));
        if(installed.length>0)BearWidgets.update(c,manager,installed,large(),true);
    }
    @Override public void onReceive(Context c,Intent intent) {
        String action=intent.getAction();
        if("miui.appwidget.action.APPWIDGET_UPDATE".equals(action)||Intent.ACTION_DATE_CHANGED.equals(action)
            ||Intent.ACTION_TIME_CHANGED.equals(action)||Intent.ACTION_TIMEZONE_CHANGED.equals(action)
            ||Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)||Intent.ACTION_BOOT_COMPLETED.equals(action)) {
            onUpdate(c,AppWidgetManager.getInstance(c),null);
        } else super.onReceive(c,intent);
    }
    @Override public void onAppWidgetOptionsChanged(Context c,AppWidgetManager manager,int id,Bundle options) {
        android.appwidget.AppWidgetProviderInfo info=manager.getAppWidgetInfo(id);
        if(info==null||!new ComponentName(c,getClass()).equals(info.provider))return;
        if(options.getBoolean("miuiIdChanged")&&!options.getBoolean("miuiIdChangedComplete")) {
            Bundle completed=new Bundle(options);completed.putBoolean("miuiIdChangedComplete",true);
            manager.updateAppWidgetOptions(id,completed);
        }
        onUpdate(c,manager,null);
    }
    @Override public void onRestored(Context c,int[] oldIds,int[] newIds) {
        onUpdate(c,AppWidgetManager.getInstance(c),newIds);
    }
}
