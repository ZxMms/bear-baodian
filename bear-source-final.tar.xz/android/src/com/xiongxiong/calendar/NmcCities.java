package com.xiongxiong.calendar;

import android.content.Context;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;

/** Small official city directory. Matching never infers the nearest city from coordinates. */
final class NmcCities {
    private final Map<String, JSONObject> byCode = new HashMap<>();
    private final ArrayList<JSONObject> rows = new ArrayList<>();
    private final Map<String, String> provinceNames = new HashMap<>();
    private static final String[] ENGLISH = {"Beijing","Tianjin","Hebei","Shanxi","Inner Mongolia","Liaoning","Jilin","Heilongjiang","Shanghai","Jiangsu","Zhejiang","Anhui","Fujian","Jiangxi","Shandong","Henan","Hubei","Hunan","Guangdong","Guangxi","Hainan","Chongqing","Sichuan","Guizhou","Yunnan","Tibet","Shaanxi","Gansu","Qinghai","Ningxia","Xinjiang"};
    private static final String[] SHORT = {"北京","天津","河北","山西","内蒙古","辽宁","吉林","黑龙江","上海","江苏","浙江","安徽","福建","江西","山东","河南","湖北","湖南","广东","广西","海南","重庆","四川","贵州","云南","西藏","陕西","甘肃","青海","宁夏","新疆"};

    NmcCities(Context context) {
        try (InputStream input = context.getAssets().open("nmc-cities.json"); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192]; int count;
            while ((count = input.read(buffer)) != -1) { if (out.size() + count > 600000) throw new IllegalArgumentException("Directory too large"); out.write(buffer, 0, count); }
            load(new String(out.toByteArray(), java.nio.charset.StandardCharsets.UTF_8));
        } catch (Exception unavailable) { byCode.clear(); rows.clear(); }
    }
    /** Uses the exact same decoding and matching as the app, for fixture and catalogue verification. */
    NmcCities(String json) throws Exception { load(json); }
    private void load(String json) throws Exception {
        for (int i = 0; i < WeatherAlertParser.PROVINCES.length; i++) {
            String full = WeatherAlertParser.PROVINCES[i];
            provinceNames.put(full.toLowerCase(Locale.ROOT), full);
            provinceNames.put(SHORT[i], full); provinceNames.put(ENGLISH[i].toLowerCase(Locale.ROOT), full);
        }
        JSONArray cities = new JSONObject(json).getJSONArray("cities");
        for (int i = 0; i < cities.length(); i++) {
            JSONObject source = cities.getJSONObject(i);
            String code = source.getString("code"), name = source.getString("city"), province = source.getString("province"), url = source.getString("url");
            if (!code.matches("[A-Za-z0-9]{5,12}") || byCode.containsKey(code) || name.trim().isEmpty() || name.length() > 80
                || !WeatherAlertParser.supported(province) || !url.matches("/publish/forecast/[A-Z0-9]+/[a-zA-Z0-9_-]+\\.html")) throw new IllegalArgumentException("Invalid official directory row");
            JSONObject row = new JSONObject().put("nmcCode", code).put("name", name).put("admin1", province)
                .put("countryCode", "CN").put("region", province + " · 国内天气")
                .put("sourceUrl", "https://www.nmc.cn" + url);
            if ("北京市".equals(province)) {
                String district="北京".equals(name)?"":name+"区";
                row.put("displayName",district.isEmpty()?province:province+" · "+district).put("districtName",district);
            }
            double latitude = source.optDouble("latitude", Double.NaN), longitude = source.optDouble("longitude", Double.NaN);
            if (WeatherRules.validCoordinates(latitude, longitude)) row.put("latitude", latitude).put("longitude", longitude);
            byCode.put(code, row); rows.add(row);
        }
    }
    private static JSONObject copy(JSONObject value) {
        try { return value == null ? null : new JSONObject(value.toString()); } catch (Exception invalid) { return null; }
    }
    JSONObject canonical(String code) { return copy(byCode.get(code)); }
    JSONObject fromPlace(JSONObject place) {
        if (place == null) return null;
        String code = place.optString("nmcCode", "");
        if (!code.isEmpty()) return canonical(code);
        if ("CN".equals(place.optString("countryCode"))) return resolve(place.optString("admin1", ""), place.optString("name", ""));
        // Older versions saved only name/coordinates for the eight popular city buttons.
        // Migrate those explicit selections, never infer a city for a GPS location.
        if (!place.optString("countryCode", "").isEmpty() || !"city".equals(place.optString("source"))) return null;
        double lat = place.optDouble("latitude", Double.NaN), lon = place.optDouble("longitude", Double.NaN);
        if (!WeatherRules.validCoordinates(lat, lon)) return null;
        JSONObject matched = null;
        for (JSONObject row : rows) {
            if (!place.optString("name").equals(row.optString("name")) || !row.has("latitude") || !row.has("longitude")) continue;
            if (Math.abs(lat - row.optDouble("latitude")) > .5 || Math.abs(lon - row.optDouble("longitude")) > .5) continue;
            if (matched != null) return null;
            matched = row;
        }
        return copy(matched);
    }
    JSONObject resolve(String province, String name) {
        String expected = provinceNames.get(province == null ? "" : province.trim().toLowerCase(Locale.ROOT));
        String wanted = normalize(name);
        if (expected == null || wanted.isEmpty()) return null;
        JSONObject matched = null;
        for (JSONObject row : rows) {
            if (!expected.equals(row.optString("admin1")) || !wanted.equals(normalize(row.optString("name")))) continue;
            if (matched != null) return null; // A repeated county name needs an explicit user choice.
            matched = row;
        }
        return copy(matched);
    }
    JSONArray search(String query) {
        String raw = query == null ? "" : query.trim().toLowerCase(Locale.ROOT), wanted = normalize(raw);
        JSONArray result = new JSONArray();
        if (wanted.isEmpty() || raw.length() > 80) return result;
        ArrayList<JSONObject> matches = new ArrayList<>();
        for (JSONObject row : rows) if (score(row, raw, wanted) < 9) matches.add(row);
        matches.sort((a,b) -> { int value = Integer.compare(score(a, raw, wanted), score(b, raw, wanted)); return value != 0 ? value : (a.optString("name") + a.optString("admin1")).compareTo(b.optString("name") + b.optString("admin1")); });
        for (int i = 0; i < Math.min(40, matches.size()); i++) result.put(copy(matches.get(i)));
        return result;
    }
    private static int score(JSONObject row, String raw, String wanted) {
        String name = normalize(row.optString("name")), province = row.optString("admin1").toLowerCase(Locale.ROOT);
        String url = row.optString("sourceUrl"), pinyin = url.substring(url.lastIndexOf('/') + 1).replace(".html", "").toLowerCase(Locale.ROOT);
        if (name.equals(wanted)) return 0;
        if (name.startsWith(wanted) || pinyin.equals(wanted)) return 1;
        if (name.contains(wanted) || pinyin.startsWith(wanted)) return 2;
        if ((province + row.optString("name")).contains(raw) || province.contains(raw)) return 3;
        return 9;
    }
    private static String normalize(String value) {
        if (value == null) return "";
        String text = value.trim().toLowerCase(Locale.ROOT).replace("'", "").replace("’", "");
        if (text.length() > 1 && (text.endsWith("市") || text.endsWith("县") || text.endsWith("区"))) text = text.substring(0, text.length() - 1);
        return text;
    }
}
