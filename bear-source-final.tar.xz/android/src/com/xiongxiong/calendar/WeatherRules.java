package com.xiongxiong.calendar;

/** Pure boundary rules shared by location, cache and forecast decoding. */
final class WeatherRules {
    static final long FRESH_MS = 10 * 60 * 1000L;
    static final long RETRY_MS = 60 * 1000L;
    static final long CLOCK_SKEW_MS = 5 * 60 * 1000L;
    private WeatherRules() { }
    static boolean validCoordinates(double latitude, double longitude) {
        return Double.isFinite(latitude) && Double.isFinite(longitude) && Math.abs(latitude) <= 90 && Math.abs(longitude) <= 180;
    }
    static String placeKey(double latitude, double longitude) {
        if (!validCoordinates(latitude, longitude)) return "";
        return Math.round(latitude * 100) + ":" + Math.round(longitude * 100);
    }
    static boolean fresh(long updatedAt, long now) {
        return updatedAt > 0 && updatedAt <= now + CLOCK_SKEW_MS && now - updatedAt <= FRESH_MS;
    }
    static boolean retryDue(long lastAttemptElapsed, long nowElapsed) {
        return lastAttemptElapsed < 0 || nowElapsed < lastAttemptElapsed || nowElapsed - lastAttemptElapsed >= RETRY_MS;
    }
    static boolean usableLocation(long locationElapsedNanos, long nowElapsedNanos) {
        return LocationRules.current(locationElapsedNanos, nowElapsedNanos, 1);
    }
    static boolean usableLocation(long locationElapsedNanos, long nowElapsedNanos, double accuracyMeters) {
        return LocationRules.current(locationElapsedNanos, nowElapsedNanos, accuracyMeters);
    }
    static boolean knownSky(int code) {
        switch (code) {
            case 0: case 1: case 2: case 3: case 45: case 48:
            case 51: case 53: case 55: case 56: case 57: case 61: case 63: case 65: case 66: case 67:
            case 71: case 73: case 75: case 77: case 80: case 81: case 82: case 85: case 86:
            case 95: case 96: case 99: return true;
            default: return false;
        }
    }
    static Double wind(double value, boolean direction) {
        return Double.isFinite(value) && value >= 0 && value <= (direction ? 360 : 150) ? value : null;
    }
}
