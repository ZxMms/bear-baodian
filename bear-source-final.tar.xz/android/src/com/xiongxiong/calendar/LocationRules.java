package com.xiongxiong.calendar;

/** Weather needs a disclosed city-sized area, not a navigation-grade position. */
final class LocationRules {
    static final long CURRENT_MS = 2 * 60 * 1000L;
    static final long RECENT_MS = 10 * 60 * 1000L;
    static final double MAX_ACCURACY_METERS = 20000;
    static final long WEATHER_WAIT_MS = 10000, PRECISE_WAIT_MS = 35000;
    private LocationRules() { }
    static long ageMs(long fixNanos, long nowNanos) {
        return fixNanos > 0 && nowNanos >= fixNanos ? (nowNanos - fixNanos) / 1000000L : -1;
    }
    static String rejection(LocationSession.Fix fix, long nowNanos) {
        if (fix == null) return "empty";
        if (!WeatherRules.validCoordinates(fix.latitude, fix.longitude)) return "coordinates";
        if (fix.elapsedNanos <= 0) return "timestamp";
        if (fix.elapsedNanos > nowNanos) return "future";
        if (!Double.isFinite(fix.accuracyMeters) || fix.accuracyMeters <= 0) return "accuracy-missing";
        if (fix.accuracyMeters > MAX_ACCURACY_METERS) return "accuracy-wide";
        if (nowNanos - fix.elapsedNanos > RECENT_MS * 1000000L) return "stale";
        return "";
    }
    static boolean districtEligible(double accuracy) {
        return Double.isFinite(accuracy) && accuracy > 0 && accuracy <= 5000;
    }
    static boolean current(long fixNanos, long nowNanos, double accuracy) {
        return fixNanos > 0 && nowNanos >= fixNanos && nowNanos - fixNanos <= CURRENT_MS * 1000000L
            && Double.isFinite(accuracy) && accuracy > 0 && accuracy <= MAX_ACCURACY_METERS;
    }
}
