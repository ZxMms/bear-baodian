package com.xiongxiong.calendar;

import android.app.Activity;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.*;
import org.json.JSONObject;

final class GoldController {
    private final Activity activity;
    private final WebView web;
    private final ThreadPoolExecutor pool = new ThreadPoolExecutor(3,3,20,TimeUnit.SECONDS,new ArrayBlockingQueue<Runnable>(3));
    private final Map<String,GoldNetwork> active = new HashMap<>();
    private boolean destroyed;
    GoldController(Activity activity,WebView web) { this.activity=activity;this.web=web;pool.allowCoreThreadTimeOut(true); }
    @JavascriptInterface public synchronized void request(String id,String kind) {
        if(destroyed || id==null || !id.matches("[0-9]{1,12}") || kind==null) return;
        final GoldNetwork job;try { job=new GoldNetwork(kind); } catch(IllegalArgumentException e) { return; }
        GoldNetwork old=active.put(kind,job);if(old!=null)old.cancel();
        try { pool.execute(()->{
            JSONObject result=new JSONObject();
            try { result.put("ok",true).put("body",job.call()); }
            catch(Exception e) { try{result=new JSONObject().put("ok",false).put("error","连接暂时没有成功，请检查网络后重试");}catch(Exception ignored){} }
            final JSONObject output=result;
            activity.runOnUiThread(()->{synchronized(GoldController.this){if(destroyed||active.get(kind)!=job)return;active.remove(kind);web.evaluateJavascript("window.bearGoldResult&&window.bearGoldResult("+JSONObject.quote(id)+","+output+")",null);}});
        }); } catch(RejectedExecutionException e) { active.remove(kind,job);activity.runOnUiThread(()->web.evaluateJavascript("window.bearGoldResult&&window.bearGoldResult("+JSONObject.quote(id)+",{ok:false,error:'请求繁忙，请稍后重试'})",null)); }
    }
    @JavascriptInterface public synchronized void cancel() { for(GoldNetwork job:active.values())job.cancel();active.clear();pool.getQueue().clear(); }
    synchronized void destroy() { destroyed=true;cancel();pool.shutdownNow(); }
}
