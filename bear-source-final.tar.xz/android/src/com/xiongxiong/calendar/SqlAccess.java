package com.xiongxiong.calendar;

import java.util.List;
import org.json.JSONObject;

/** Small adapter keeps migration/backup logic testable against real SQLite on the JVM. */
interface SqlAccess {
    void execute(String sql, Object... args) throws Exception;
    List<JSONObject> query(String sql, Object... args) throws Exception;
    void begin() throws Exception;
    void commit() throws Exception;
    void rollback() throws Exception;
}
