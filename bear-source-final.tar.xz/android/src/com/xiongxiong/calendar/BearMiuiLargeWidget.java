package com.xiongxiong.calendar;
public final class BearMiuiLargeWidget extends BearMiuiWidget {
    @Override boolean large(){return true;}
}
