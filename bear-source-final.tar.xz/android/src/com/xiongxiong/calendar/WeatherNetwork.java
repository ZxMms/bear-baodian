package com.xiongxiong.calendar;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLException;

/** HTTPS-only, bounded weather transport. A failed source never produces an empty success. */
final class WeatherNetwork {
    interface Connections { HttpsURLConnection open(URL url) throws IOException; }
    private final ExecutorService workers = Executors.newFixedThreadPool(4);
    private final ExecutorService cleanup = Executors.newFixedThreadPool(2);
    private final Connections connections;
    WeatherNetwork() { this(url -> (HttpsURLConnection)url.openConnection()); }
    WeatherNetwork(Connections connections) { this.connections = connections; }
    final class Operation {
        private volatile boolean cancelled;
        private Call active;
        synchronized void bind(Call call) throws InterruptedException {
            if (cancelled) throw new InterruptedException("Cancelled");
            active = call;
        }
        synchronized void clear(Call call) { if (active == call) active = null; }
        void cancel() {
            Call call;
            synchronized (this) { cancelled = true; call = active; active = null; }
            if (call != null) call.cancel();
        }
        boolean cancelled() { return cancelled || Thread.currentThread().isInterrupted(); }
    }
    Operation operation() { return new Operation(); }
    private final class Call {
        boolean cancelled;
        HttpsURLConnection connection;
        Future<?> work;
        synchronized boolean bind(HttpsURLConnection value) {
            if (cancelled) return false;
            connection = value; return true;
        }
        synchronized void task(Future<?> value) { work = value; if (cancelled) value.cancel(true); }
        synchronized void clear(HttpsURLConnection value) { if (connection == value) connection = null; }
        void cancel() {
            HttpsURLConnection socket; Future<?> task;
            synchronized(this) { cancelled = true; socket = connection; connection = null; task = work; }
            if (task != null) task.cancel(true);
            closeLater(socket);
        }
    }
    static final class HttpFailure extends IOException {
        final int status;
        HttpFailure(int status) { super("HTTP_" + status); this.status = status; }
    }
    String get(String address, Operation operation, int deadlineMs) throws Exception {
        URL url = checked(address);
        if (operation.cancelled()) throw new InterruptedException("Cancelled");
        Call call = new Call(); operation.bind(call);
        Future<String> future = workers.submit(() -> read(url, call, operation)); call.task(future);
        try { return future.get(deadlineMs, TimeUnit.MILLISECONDS); }
        catch (TimeoutException expired) { call.cancel(); throw new SocketTimeoutException("Weather request deadline"); }
        catch (InterruptedException cancelled) { call.cancel(); Thread.currentThread().interrupt(); throw cancelled; }
        catch (CancellationException cancelled) { throw new InterruptedException("Cancelled"); }
        catch (ExecutionException failed) {
            Throwable cause = failed.getCause();
            if (cause instanceof Exception) throw (Exception)cause;
            throw new IOException("Weather request failed", cause);
        } finally { operation.clear(call); }
    }
    private String read(URL url, Call call, Operation operation) throws Exception {
        HttpsURLConnection connection = connections.open(url);
        connection.setConnectTimeout(4500); connection.setReadTimeout(5000);
        connection.setInstanceFollowRedirects(false); connection.setRequestProperty("Accept", "application/json");
        // The controller owns our timestamped cache. A network refresh must revalidate
        // at the source, even if a platform ResponseCache has been installed elsewhere.
        // The provider can still return the same observation; its time remains unchanged.
        connection.setUseCaches(false);
        connection.setIfModifiedSince(0);
        connection.setRequestProperty("Cache-Control", "no-cache, no-store");
        connection.setRequestProperty("Pragma", "no-cache");
        try {
            if (!call.bind(connection) || operation.cancelled()) throw new InterruptedException("Cancelled");
            int status = connection.getResponseCode();
            if (status != 200) throw new HttpFailure(status);
            try (InputStream input = connection.getInputStream(); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192]; int count;
                while ((count = input.read(buffer)) != -1) {
                    if (operation.cancelled() || Thread.currentThread().isInterrupted()) throw new InterruptedException("Cancelled");
                    if (output.size() + count > 262144) throw new IOException("RESPONSE_TOO_LARGE");
                    output.write(buffer, 0, count);
                }
                if (operation.cancelled()) throw new InterruptedException("Cancelled");
                return new String(output.toByteArray(), StandardCharsets.UTF_8);
            }
        } finally { call.clear(connection); closeLater(connection); }
    }
    private void closeLater(HttpsURLConnection socket) {
        if (socket == null) return;
        try { cleanup.execute(socket::disconnect); } catch (RejectedExecutionException closed) { }
    }
    static URL checked(String address) throws Exception {
        URL url = new URL(address);
        if (!"https".equals(url.getProtocol()) || url.getPort() != -1 || url.getUserInfo() != null || url.getRef() != null) throw new IllegalArgumentException("Invalid weather source");
        boolean valid = "api.open-meteo.com".equals(url.getHost()) && "/v1/forecast".equals(url.getPath())
            || "geocoding-api.open-meteo.com".equals(url.getHost()) && "/v1/search".equals(url.getPath())
            || "www.nmc.cn".equals(url.getHost()) && "/essearch/api/autocomplete".equals(url.getPath()) && url.getQuery() != null && url.getQuery().matches("q=(?:[A-Za-z0-9+_-]|%[0-9a-fA-F]{2}){1,600}")
            || "www.nmc.cn".equals(url.getHost()) && url.getPath().matches("/rest/real/[A-Za-z0-9]{5,12}") && url.getQuery() == null;
        if (!valid) throw new IllegalArgumentException("Invalid weather source");
        return url;
    }
    static String errorCode(Exception error) {
        if (error instanceof HttpFailure) return "HTTP_" + ((HttpFailure)error).status;
        if (error instanceof SocketTimeoutException || error instanceof TimeoutException) return "TIMEOUT";
        if (error instanceof UnknownHostException) return "DNS";
        if (error instanceof SSLException) return "TLS";
        if (error instanceof InterruptedException || error instanceof CancellationException) return "CANCELLED";
        if ("STALE_DATA".equals(error.getMessage())) return "STALE_DATA";
        if (error instanceof IllegalArgumentException || error instanceof java.time.DateTimeException || error.getClass().getName().equals("org.json.JSONException")) return "INVALID_RESPONSE";
        return "NETWORK";
    }
    void destroy() { workers.shutdownNow(); cleanup.shutdown(); }
}
