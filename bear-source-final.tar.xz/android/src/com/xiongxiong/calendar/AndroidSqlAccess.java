package com.xiongxiong.calendar;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONObject;

final class AndroidSqlAccess extends SQLiteOpenHelper implements SqlAccess {
    AndroidSqlAccess(Context context) { super(context, "bear-calendar.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase db) { }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }
    @Override public void execute(String sql, Object... args) { getWritableDatabase().execSQL(sql, args); }
    @Override public List<JSONObject> query(String sql, Object... args) throws Exception {
        String[] parameters = new String[args.length];
        for (int i=0;i<args.length;i++) parameters[i]=args[i]==null?null:String.valueOf(args[i]);
        List<JSONObject> result=new ArrayList<>();
        try(Cursor cursor=getReadableDatabase().rawQuery(sql,parameters)) {
            while(cursor.moveToNext()) {
                JSONObject row=new JSONObject();
                for(int i=0;i<cursor.getColumnCount();i++) {
                    Object value=cursor.isNull(i)?JSONObject.NULL:cursor.getType(i)==Cursor.FIELD_TYPE_INTEGER?cursor.getLong(i):cursor.getType(i)==Cursor.FIELD_TYPE_FLOAT?cursor.getDouble(i):cursor.getString(i);
                    row.put(cursor.getColumnName(i),value);
                }
                result.add(row);
            }
        }
        return result;
    }
    @Override public void begin(){getWritableDatabase().beginTransaction();}
    @Override public void commit(){getWritableDatabase().setTransactionSuccessful();getWritableDatabase().endTransaction();}
    @Override public void rollback(){getWritableDatabase().endTransaction();}
}
