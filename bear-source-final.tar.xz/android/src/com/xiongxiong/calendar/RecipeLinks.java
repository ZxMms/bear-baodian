package com.xiongxiong.calendar;

import java.net.URI;
import java.util.Locale;

/** Opens ordinary web links without requiring a particular short-link domain. */
final class RecipeLinks {
    static URI webUri(String input) {
        if(input==null||input.length()>16000)return null;
        try {
            URI uri=new URI(input);
            String scheme=uri.getScheme();
            if(!("https".equalsIgnoreCase(scheme)||"http".equalsIgnoreCase(scheme))||uri.getHost()==null||uri.getRawUserInfo()!=null)return null;
            return uri;
        }catch(Exception error){return null;}
    }
    static String preferredPackage(URI uri) {
        String host=uri.getHost().toLowerCase(Locale.ROOT);
        for(String domain:new String[]{"xiaohongshu.com","xhslink.com","xhslink.cn"})
            if(host.equals(domain)||host.endsWith("."+domain))return "com.xingin.xhs";
        return null;
    }
}
