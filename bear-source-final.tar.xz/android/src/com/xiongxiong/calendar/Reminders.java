package com.xiongxiong.calendar;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.time.ZoneId;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;

public final class Reminders {
    public static final String CHANNEL = "bear_calendar_reminders_v1";
    static final String ALARM = "com.xiongxiong.calendar.REMIND";
    private static final long DAY = 86400000L;
    private static SharedPreferences prefs(Context c) { return c.getSharedPreferences("reminders", Context.MODE_PRIVATE); }
    private static NotificationManager notifications(Context c) { return c.getSystemService(NotificationManager.class); }

    public static void createChannel(Context c) {
        NotificationChannel channel = new NotificationChannel(CHANNEL, "熊熊宝典提醒", NotificationManager.IMPORTANCE_DEFAULT);
        channel.setDescription("纪念日、活动和备注的本机提醒");
        channel.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
        channel.setSound(Uri.parse("android.resource://" + c.getPackageName() + "/raw/bear_reminder"),
            new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build());
        notifications(c).createNotificationChannel(channel);
    }
    public static boolean enabled(Context c) {
        createChannel(c);
        NotificationChannel channel = notifications(c).getNotificationChannel(CHANNEL);
        return notifications(c).areNotificationsEnabled() && channel.getImportance() != NotificationManager.IMPORTANCE_NONE;
    }
    public static boolean exact(Context c) {
        return Build.VERSION.SDK_INT < 31 || c.getSystemService(AlarmManager.class).canScheduleExactAlarms();
    }
    private static JSONArray rows(Context c) {
        try { return new JSONArray(prefs(c).getString("rows", "[]")); }
        catch (Exception ignored) { return new JSONArray(); }
    }
    private static void persist(Context c, JSONArray rows) {
        if (!prefs(c).edit().putString("rows", rows.toString()).commit())
            throw new IllegalStateException("提醒未能写入手机，请重试");
    }
    private static String signature(JSONObject row) {
        return row.optString("date") + "/" + row.optString("recurrence", row.optBoolean("annual") ? "yearly" : "none") + "/" + row.optInt("monthDay", 1) + "/" + row.optString("overflow", "last") + "/" + row.optString("workMode", "official") + "/" + row.optInt("days") + "/" + row.optString("time");
    }
    private static void next(JSONObject row, long after) throws Exception {
        after = Math.max(after, row.optLong("startAfter", 0));
        List<String> workDates = new ArrayList<>();
        JSONArray dates = row.optJSONArray("workDates");
        if (dates != null) for (int i = 0; i < dates.length(); i++) workDates.add(dates.getString(i));
        ReminderTime.Occurrence next = ReminderTime.next(row.getString("date"), row.getString("time"),
            row.optString("recurrence", row.optBoolean("annual") ? "yearly" : "none"), row.optInt("monthDay", 1),
            row.optString("overflow", "last"), row.optString("workMode", "official"), workDates,
            row.getInt("days"), after, ZoneId.systemDefault(), row.optString("last"));
        row.put("nextAt", next == null ? -1 : next.at);
        row.put("nextDate", next == null ? "" : next.date);
    }

    public static synchronized String sync(Context c, String source) {
        try {
            if (source.length() > 2000000) throw new IllegalArgumentException("提醒数量过多");
            JSONArray incoming = new JSONArray(source), existing = rows(c), updated = new JSONArray();
            Map<String, JSONObject> byId = new HashMap<>();
            for (int i = 0; i < existing.length(); i++) byId.put(existing.getJSONObject(i).getString("id"), existing.getJSONObject(i));
            long now = System.currentTimeMillis();
            for (int i = 0; i < incoming.length(); i++) {
                JSONObject input = incoming.getJSONObject(i), row = new JSONObject();
                String id = input.getString("id"), kind = input.getString("kind");
                if (!id.matches("[A-Za-z0-9_-]{1,100}") || !ReminderKinds.allowed(kind))
                    throw new IllegalArgumentException("提醒记录格式不正确");
                row.put("id", id).put("title", input.getString("title")).put("kind", kind)
                    .put("date", input.getString("date")).put("time", input.getString("time"))
                    .put("days", input.getInt("days")).put("annual", input.optBoolean("annual"))
                    .put("recurrence", input.optString("recurrence", input.optBoolean("annual") ? "yearly" : "none"))
                    .put("monthDay", input.optInt("monthDay", 1)).put("overflow", input.optString("overflow", "last"))
                    .put("workMode", input.optString("workMode", "official"))
                    .put("workDates", input.optJSONArray("workDates") == null ? new JSONArray() : input.getJSONArray("workDates"));
                JSONObject old = byId.remove(id);
                if (old != null && signature(old).equals(signature(row))) {
                    row.put("last", old.optString("last"));
                    row.put("startAfter", old.optLong("startAfter", now));
                    // Preserve a pending occurrence even if Android is delivering it late.
                    if (old.optLong("nextAt", -1) >= now - DAY && old.optLong("nextAt", -1) > 0) {
                        row.put("nextAt", old.getLong("nextAt")).put("nextDate", old.getString("nextDate"));
                    } else next(row, now);
                } else { row.put("startAfter", now); next(row, now); }
                updated.put(row);
            }
            persist(c, updated);
            for (String id : byId.keySet()) notifications(c).cancel(id, 1);
            schedule(c, updated);
            prefs(c).edit().remove("error").apply();
            return status(c);
        } catch (Exception error) { return failure(error); }
    }

    private static PendingIntent alarmIntent(Context c) {
        Intent intent = new Intent(c, ReminderReceiver.class).setAction(ALARM);
        return PendingIntent.getBroadcast(c, 41, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    private static void schedule(Context c, JSONArray rows) throws Exception {
        AlarmManager alarms = c.getSystemService(AlarmManager.class);
        PendingIntent intent = alarmIntent(c);
        alarms.cancel(intent);
        if (!enabled(c)) return;
        long earliest = Long.MAX_VALUE;
        for (int i = 0; i < rows.length(); i++) {
            long at = rows.getJSONObject(i).optLong("nextAt", -1);
            if (at > 0) earliest = Math.min(earliest, at);
        }
        if (earliest == Long.MAX_VALUE) return;
        earliest = Math.max(earliest, System.currentTimeMillis() + 1000);
        if (exact(c)) {
            try { alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, earliest, intent); return; }
            catch (SecurityException revoked) { /* Fall back without claiming exact delivery. */ }
        }
        alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, earliest, intent);
    }

    public static synchronized void restore(Context c) {
        try {
            JSONArray saved = rows(c);
            long after = System.currentTimeMillis() - DAY;
            for (int i = 0; i < saved.length(); i++) next(saved.getJSONObject(i), after);
            persist(c, saved);
            schedule(c, saved);
            prefs(c).edit().remove("error").apply();
        } catch (Exception error) { prefs(c).edit().putString("error", "提醒恢复失败，请打开应用重新保存提醒").apply(); }
    }

    public static synchronized void fire(Context c) {
        try {
            JSONArray saved = rows(c), due = new JSONArray();
            long now = System.currentTimeMillis();
            for (int i = 0; i < saved.length(); i++) {
                JSONObject row = saved.getJSONObject(i);
                long at = row.optLong("nextAt", -1);
                if (at <= 0 || at > now) continue;
                if (at >= now - DAY) due.put(new JSONObject(row.toString()));
                row.put("last", row.optString("nextDate"));
                next(row, now + 1);
            }
            persist(c, saved);
            schedule(c, saved);
            for (int i = 0; i < due.length(); i++) {
                JSONObject row = due.getJSONObject(i);
                String kind = ReminderKinds.label(row.getString("kind"));
                String text = kind + " · " + row.getString("nextDate") + "。一二布布提醒你，别忘了这件小事。";
                show(c, row.getString("id"), row.getString("title"), text, row.getString("nextDate"));
            }
        } catch (Exception error) { prefs(c).edit().putString("error", "提醒发送失败，请检查系统通知设置").apply(); }
    }

    private static void show(Context c, String id, String title, String body, String date) {
        if (!enabled(c)) return;
        Intent open = new Intent(c, MainActivity.class)
            .setData(new Uri.Builder().scheme("bear-calendar").authority("reminder").appendPath(id).build())
            .putExtra("entryId", id).putExtra("entryDate", date).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent tap = PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        int icon = c.getResources().getIdentifier("ic_reminder", "drawable", c.getPackageName());
        Notification note = new Notification.Builder(c, CHANNEL).setSmallIcon(icon)
            .setColor(Color.rgb(183, 80, 49)).setContentTitle(title).setContentText(body)
            .setStyle(new Notification.BigTextStyle().bigText(body)).setCategory(Notification.CATEGORY_REMINDER)
            .setVisibility(Notification.VISIBILITY_PRIVATE).setAutoCancel(true).setContentIntent(tap).build();
        notifications(c).notify(id, 1, note);
    }
    public static synchronized String test(Context c) {
        if (!enabled(c)) return "请先允许熊熊宝典发送通知";
        try { show(c, "test", "一二布布来提醒你啦", "这是一条测试通知。看到这条消息，说明通知栏可以收到提醒。点击回到熊熊宝典。", ""); return "测试通知已发送，请下拉通知栏查看"; }
        catch (RuntimeException denied) { return "测试通知未能发送，请检查系统通知设置"; }
    }
    public static synchronized String status(Context c) {
        try {
            JSONArray saved = rows(c);
            int scheduled = 0;
            for (int i = 0; i < saved.length(); i++) if (saved.getJSONObject(i).optLong("nextAt", -1) > 0) scheduled++;
            return new JSONObject().put("native", true).put("enabled", enabled(c)).put("exact", exact(c))
                .put("scheduled", scheduled).put("error", prefs(c).getString("error", "")).toString();
        } catch (Exception error) { return failure(error); }
    }
    private static String failure(Exception error) {
        return "{\"native\":true,\"error\":\"提醒未能设置，请重新打开应用后再试\"}";
    }
}
