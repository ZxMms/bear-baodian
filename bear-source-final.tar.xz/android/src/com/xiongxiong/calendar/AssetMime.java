package com.xiongxiong.calendar;

/** MIME types for the same bundled bytes served by the Android WebView. */
final class AssetMime {
    static String type(String path) {
        if (path == null) return null;
        if (path.endsWith(".html")) return "text/html";
        if (path.endsWith(".css")) return "text/css";
        if (path.endsWith(".js")) return "application/javascript";
        if (path.endsWith(".json")) return "application/json";
        if (path.endsWith(".wasm")) return "application/wasm";
        if (path.endsWith(".traineddata.gz")) return "application/gzip";
        if (path.endsWith(".jpg")) return "image/jpeg";
        if (path.endsWith(".gif")) return "image/gif";
        if (path.endsWith(".png")) return "image/png";
        if (path.endsWith(".webp")) return "image/webp";
        if (path.endsWith(".wav")) return "audio/wav";
        if (path.endsWith(".mp3")) return "audio/mpeg";
        return null;
    }
}
