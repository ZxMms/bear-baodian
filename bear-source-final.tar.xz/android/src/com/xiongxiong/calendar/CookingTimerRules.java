package com.xiongxiong.calendar;

/** Pure rules shared by native timer persistence and its regression tests. */
final class CookingTimerRules {
    static final long DAY = 86400000L;
    static final long RING_TIMEOUT_MS = 30000L;
    static final String TEST_ID = "__bear_ring_test__";
    static final long DELIVERY_RETRY_MS = 5000L;
    static final long DELIVERY_RETRY_WINDOW_MS = 15000L;
    static final int MAX_DELIVERY_ATTEMPTS = 3;
    static String builtinSoundName(String value,String packageName,int alarmResource,int reminderResource) {
        if(value==null||value.isEmpty())return "";
        try {
            java.net.URI uri=new java.net.URI(value);
            if(!"android.resource".equals(uri.getScheme())||!packageName.equals(uri.getAuthority()))return "";
            String path=uri.getPath();
            if("/raw/bear_cooking_alarm".equals(path)||(alarmResource>0&&("/"+alarmResource).equals(path)))return "加加加短铃声";
            if("/raw/bear_reminder".equals(path)||(reminderResource>0&&("/"+reminderResource).equals(path)))return "熊熊提醒音";
        } catch(Exception invalid) { /* OEM or inaccessible URI: retain its system title instead. */ }
        return "";
    }
    static String soundKind(String value,String builtinName,boolean systemDefault) {
        if(value==null||value.isEmpty())return "silent";
        if(builtinName!=null&&!builtinName.isEmpty())return "builtin";
        if(systemDefault)return "system";
        try {
            java.net.URI uri=new java.net.URI(value);String path=uri.getPath();
            if("content".equals(uri.getScheme())&&"media".equals(uri.getAuthority())&&path!=null){
                if(path.startsWith("/internal/audio/media/"))return "system";
                if(path.startsWith("/external/audio/media/")||path.startsWith("/external_primary/audio/media/"))return "custom";
            }
            if("file".equals(uri.getScheme()))return "custom";
        } catch(Exception invalid) { /* Unknown providers must not be labelled as a built-in phone sound. */ }
        return "unknown";
    }
    static String soundName(String kind,String builtinName,String title) {
        if("silent".equals(kind))return "无声";
        if("builtin".equals(kind)&&builtinName!=null&&!builtinName.isEmpty())return builtinName;
        String clean=WidgetContent.clean(title,100);
        if(!clean.isEmpty())return clean;
        if("system".equals(kind))return "系统铃声";
        if("custom".equals(kind))return "自定义铃声";
        return "暂未读到铃声名称";
    }
    static boolean retryDelivery(int attempts,long remaining) {
        return attempts > 0 && attempts < MAX_DELIVERY_ATTEMPTS && remaining <= 0 && remaining >= -DELIVERY_RETRY_WINDOW_MS;
    }
    enum DeliveryAction { ATTEMPT, WAIT, POSTED, UNCONFIRMED, FAILED }
    static DeliveryAction deliveryAction(int attempts,String state,long remaining,long now,long retryAt,int posted) {
        if("retrying".equals(state)&&now<retryAt)return DeliveryAction.WAIT;
        if(attempts<=0)return DeliveryAction.ATTEMPT;
        if(posted==1)return DeliveryAction.POSTED;
        // A persisted in-flight post or an unreadable notification list must never
        // be treated as a confirmed failure: the user may already have heard it.
        if(!"retrying".equals(state)||posted<0)return DeliveryAction.UNCONFIRMED;
        return retryDelivery(attempts,remaining)?DeliveryAction.ATTEMPT:DeliveryAction.FAILED;
    }
    static String healthMessage(boolean notifications,boolean sound,int alarmVolume,int interruptionFilter,boolean exact) {
        if(!notifications)return "计时通知未开启，请在响铃与通知设置中允许通知";
        if(!sound)return "计时通知当前为静音，请在响铃与通知设置中选择铃声";
        if(alarmVolume==0)return "系统闹钟音量为 0，请调高闹钟音量后试响";
        // Android's ALARMS-only filter (4) explicitly permits alarm usage.
        if(interruptionFilter==3)return "手机处于完全勿扰，计时声音可能被拦截";
        if(interruptionFilter==2)return "手机已开启优先勿扰，是否响铃取决于系统允许的提醒";
        if(!exact)return "响铃设置可用；未允许精确提醒，后台计时可能延迟";
        if(alarmVolume<0)return "暂未读到系统闹钟音量，请用 5 秒试响确认";
        return "通知与闹钟音量可用，可用 5 秒试响确认";
    }
    static boolean validId(String id) { return id != null && id.matches("[A-Za-z0-9_-]{1,160}"); }
    static long durationMillis(int seconds) {
        if (seconds < 1 || seconds > 86400) throw new IllegalArgumentException("计时请设置在 1 秒至 24 小时之间");
        return seconds * 1000L;
    }
    static long remaining(long endAt, long elapsedEnd, int savedBoot, int currentBoot, long now, long elapsedNow) {
        // Within one boot, changing the phone clock must not lengthen a cooking timer.
        if (savedBoot >= 0 && savedBoot == currentBoot && elapsedEnd > 0) return elapsedEnd - elapsedNow;
        return endAt - now;
    }
    static boolean shouldNotify(long remaining) { return remaining <= 0 && remaining >= -DAY; }
}
