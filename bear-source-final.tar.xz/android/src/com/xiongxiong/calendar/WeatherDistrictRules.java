package com.xiongxiong.calendar;

import org.json.JSONObject;

/** District identity belongs to a fix, independently of a weather station or response. */
final class WeatherDistrictRules {
    private WeatherDistrictRules() { }
    static boolean hasDistrict(JSONObject place) {
        JSONObject area=place == null ? null : place.optJSONObject("alertArea");
        return area != null && !area.optString("district").trim().isEmpty();
    }
    static boolean needsLookup(JSONObject place) {
        return place != null && "location".equals(place.optString("source")) && !hasDistrict(place)
            && !place.optBoolean("districtLookupV30") && WeatherController.hasCoordinates(place);
    }
    static double margin(JSONObject place) { return place.optInt("coordinateDecimals",2)>=5 ? 150 : 850; }
    static void coordinates(JSONObject place, double latitude, double longitude, boolean located) throws Exception {
        if (!WeatherRules.validCoordinates(latitude,longitude)) return;
        int scale=located?100000:100;
        place.put("latitude",Math.round(latitude*scale)/(double)scale).put("longitude",Math.round(longitude*scale)/(double)scale)
            .put("coordinateDecimals",located?5:2);
    }
    static JSONObject apply(JSONObject place, JSONObject known, JSONObject found) throws Exception {
        place.put("districtLookupV30",true).put("geoTried",true).put("alertAreaChecked",true);
        JSONObject area=found == null ? null : found.optJSONObject("alertArea");
        if (area == null || !found.optString("admin1").equals(area.optString("province"))) return known;
        place.put("alertArea",new JSONObject(area.toString()));
        place.put("name",WeatherController.locationName(area,found.optString("admin1")))
            .put("admin1",found.optString("admin1")).put("countryCode","CN").put("nmcCode",found.optString("nmcCode"));
        return found;
    }
}
