package com.xiongxiong.calendar;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ContentUris;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.Matrix;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.LruCache;
import android.util.Size;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.*;
import java.io.InputStream;
import java.util.*;
import java.util.concurrent.*;

/** Local, four-column photo gallery. Only opened by an explicit file-input gesture. */
public final class PhotoPickerActivity extends Activity {
    public static final String LIMIT = "photoLimit";
    private static final int ACCESS = 71, SYSTEM_PICKER = 72;
    private static final int PAPER = 0xfffff9f0, INK = 0xff553e31, MUTED = 0xff746052, ACCENT = 0xffa95738;
    private final ExecutorService queries = Executors.newSingleThreadExecutor();
    private final ThreadPoolExecutor thumbnails = (ThreadPoolExecutor) Executors.newFixedThreadPool(2);
    private final LruCache<String, Bitmap> cache = new LruCache<String, Bitmap>(12 * 1024 * 1024) {
        @Override protected int sizeOf(String key, Bitmap bitmap) { return bitmap.getAllocationByteCount(); }
    };
    private final ArrayList<Photo> all = new ArrayList<>(), shown = new ArrayList<>(), external = new ArrayList<>();
    private GallerySelection selection;
    private GridView grid;
    private GalleryAdapter adapter;
    private Spinner albums;
    private TextView hint, emptyText;
    private Button done, preview, access;
    private LinearLayout empty;
    private String bucket = "";
    private int generation, previewGeneration;
    private boolean requesting, changingAlbums, destroyed, completing;
    private Dialog imageDialog;
    private Future<?> previewJob;
    private ArrayList<Photo> previewPhotos;
    private int previewIndex;
    private TextView previewTitle;
    private ImageView previewImage;
    private Button previewChoice, previous, next;
    private boolean previewLoaded;

    private static final class Photo {
        final Uri uri; final String bucket, album, name; final int orientation;
        Photo(Uri uri, String bucket, String album, String name, int orientation) {
            this.uri=uri;this.bucket=bucket==null?"unknown":bucket;this.album=album==null?"其他相册":album;this.name=name;this.orientation=orientation;
        }
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        selection = new GallerySelection(getIntent().getIntExtra(LIMIT,5));
        if (state != null) {
            selection.restore(state.getStringArrayList("selection")); bucket=state.getString("bucket","");
            ArrayList<String> imported=state.getStringArrayList("external");
            if(imported!=null)for(String value:imported)external.add(new Photo(Uri.parse(value),"external","其他位置","所选图片",0));
        }
        buildUi();
    }
    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private TextView text(String value,int sp,int color) {
        TextView t=new TextView(this);t.setText(value);t.setTextSize(sp);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);return t;
    }
    private GradientDrawable shape(int color,int radius) {
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;
    }
    private Button button(String value,boolean primary) {
        Button b=new Button(this);b.setText(value);b.setAllCaps(false);b.setTextSize(14);b.setTextColor(primary?Color.WHITE:INK);
        b.setMinWidth(0);b.setMinimumWidth(0);b.setMinHeight(0);b.setMinimumHeight(0);b.setPadding(dp(12),0,dp(12),0);
        b.setBackground(shape(primary?ACCENT:0xfff2e8dc,12));return b;
    }
    private LinearLayout row() { LinearLayout l=new LinearLayout(this);l.setGravity(Gravity.CENTER_VERTICAL);l.setOrientation(LinearLayout.HORIZONTAL);return l; }
    private void buildUi() {
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(PAPER);setContentView(root);
        LinearLayout top=row();top.setPadding(dp(12),dp(10),dp(12),dp(8));
        Button back=button("取消",false);back.setOnClickListener(v->finish());top.addView(back,new LinearLayout.LayoutParams(dp(64),dp(48)));
        TextView title=text("选择图片",18,INK);title.setGravity(Gravity.CENTER);title.setTypeface(null,Typeface.BOLD);top.addView(title,new LinearLayout.LayoutParams(0,dp(44),1));
        Button system=button("其他位置",false);system.setTextSize(13);system.setOnClickListener(v->systemPicker());top.addView(system,new LinearLayout.LayoutParams(dp(82),dp(48)));root.addView(top);
        LinearLayout albumRow=row();albumRow.setPadding(dp(12),0,dp(12),0);
        albums=new Spinner(this);albumRow.addView(albums,new LinearLayout.LayoutParams(0,dp(48),1));
        access=button("照片权限",false);access.setTextSize(13);access.setOnClickListener(v->requestAccess());albumRow.addView(access,new LinearLayout.LayoutParams(dp(86),dp(48)));root.addView(albumRow);
        hint=text("本次最多选 "+selection.limit+" 张 · 点图预览，点圆圈勾选",12,MUTED);hint.setPadding(dp(16),dp(4),dp(16),dp(12));root.addView(hint);
        FrameLayout content=new FrameLayout(this);root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        grid=new GridView(this);grid.setNumColumns(4);grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);grid.setHorizontalSpacing(dp(3));grid.setVerticalSpacing(dp(3));grid.setPadding(dp(3),0,dp(3),0);grid.setClipToPadding(false);
        adapter=new GalleryAdapter();grid.setAdapter(adapter);content.addView(grid,new FrameLayout.LayoutParams(-1,-1));
        empty=new LinearLayout(this);empty.setOrientation(LinearLayout.VERTICAL);empty.setGravity(Gravity.CENTER);empty.setPadding(dp(28),dp(30),dp(28),dp(30));empty.setBackgroundColor(PAPER);
        TextView heart=text("♡",48,ACCENT);heart.setGravity(Gravity.CENTER);empty.addView(heart);
        emptyText=text("正在整理相册…",15,INK);emptyText.setGravity(Gravity.CENTER);emptyText.setLineSpacing(dp(6),1);empty.addView(emptyText,new LinearLayout.LayoutParams(-1,-2));
        Button allow=button("显示相册缩略图",true);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,dp(48));ap.topMargin=dp(22);empty.addView(allow,ap);allow.setOnClickListener(v->requestAccess());
        TextView privacy=text("照片只在本机读取，不会上传。\n也可以点右上角「其他位置」选择图片。",12,MUTED);privacy.setGravity(Gravity.CENTER);privacy.setPadding(0,dp(18),0,0);empty.addView(privacy);content.addView(empty,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout bottom=row();bottom.setPadding(dp(14),dp(12),dp(14),dp(12));
        preview=button("预览",false);preview.setOnClickListener(v->{ArrayList<Photo> photos=new ArrayList<>();for(String key:selection.values())for(Photo p:all)if(p.uri.toString().equals(key)){photos.add(p);break;}showPreview(photos,0);});bottom.addView(preview,new LinearLayout.LayoutParams(dp(94),dp(48)));
        TextView local=text("只收好你选中的照片",11,MUTED);local.setGravity(Gravity.CENTER);bottom.addView(local,new LinearLayout.LayoutParams(0,dp(48),1));
        done=button("完成",true);done.setOnClickListener(v->complete());bottom.addView(done,new LinearLayout.LayoutParams(dp(110),dp(48)));root.addView(bottom);
        updateAlbums();updateSelection();
    }
    private boolean granted(String permission) { return checkSelfPermission(permission)==PackageManager.PERMISSION_GRANTED; }
    private boolean fullAccess() { return granted(Build.VERSION.SDK_INT>=33?Manifest.permission.READ_MEDIA_IMAGES:Manifest.permission.READ_EXTERNAL_STORAGE); }
    private boolean canRead() { return fullAccess() || (Build.VERSION.SDK_INT>=34 && granted(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)); }
    private void requestAccess() {
        if(requesting)return;
        String primary=Build.VERSION.SDK_INT>=33?Manifest.permission.READ_MEDIA_IMAGES:Manifest.permission.READ_EXTERNAL_STORAGE;
        if(fullAccess()){loadPhotos();return;}
        boolean asked=getPreferences(MODE_PRIVATE).getBoolean("asked",false);
        if(asked&&!canRead()&&!shouldShowRequestPermissionRationale(primary)) {
            try{startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));}catch(RuntimeException e){Toast.makeText(this,"可以通过「其他位置」选图",Toast.LENGTH_SHORT).show();}return;
        }
        requesting=true;getPreferences(MODE_PRIVATE).edit().putBoolean("asked",true).apply();
        if(Build.VERSION.SDK_INT>=34)requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES,Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED},ACCESS);
        else requestPermissions(new String[]{primary},ACCESS);
    }
    @Override public void onRequestPermissionsResult(int code,String[] names,int[] results) {
        super.onRequestPermissionsResult(code,names,results);if(code==ACCESS){requesting=false;loadPhotos();}
    }
    @Override protected void onResume(){super.onResume();if(!requesting)loadPhotos();}
    private void loadPhotos() {
        final int job=++generation;
        if(!canRead()){all.clear();all.addAll(external);selection.retain(keys(all));updateAlbums();applyAlbum();emptyText.setText("允许读取照片后，\n就能在这里一排四张挑选啦");return;}
        hint.setText(fullAccess()?"本次最多选 "+selection.limit+" 张 · 点图预览，点圆圈勾选":"仅显示已授权照片 · 点「管理照片」添加更多");
        access.setText(fullAccess()?"刷新相册":"管理照片");
        queries.execute(()->{
            ArrayList<Photo> result=new ArrayList<>();boolean failed=false;
            String[] columns={MediaStore.Images.Media._ID,MediaStore.Images.Media.BUCKET_ID,MediaStore.Images.Media.BUCKET_DISPLAY_NAME,MediaStore.Images.Media.DISPLAY_NAME,MediaStore.Images.Media.ORIENTATION};
            try(Cursor c=getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,columns,null,null,MediaStore.Images.Media.DATE_ADDED+" DESC, "+MediaStore.Images.Media._ID+" DESC")){
                if(c!=null)while(c.moveToNext()){if(destroyed||Thread.currentThread().isInterrupted())return;result.add(new Photo(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,c.getLong(0)),c.getString(1),c.getString(2)==null?"其他相册":c.getString(2),c.getString(3),c.getInt(4)));}
            }catch(RuntimeException e){failed=true;}
            final boolean error=failed;
            runOnUiThread(()->{if(destroyed||job!=generation)return;all.clear();all.addAll(result);for(Photo p:external)if(!keys(all).contains(p.uri.toString()))all.add(p);selection.retain(keys(all));updateAlbums();applyAlbum();emptyText.setText(error?"相册暂时没读到，\n可刷新或通过「其他位置」选图":"这里还没有可见的照片。\n可切换相册或添加照片授权。");});
        });
    }
    private ArrayList<String> keys(List<Photo> photos){ArrayList<String> keys=new ArrayList<>();for(Photo p:photos)keys.add(p.uri.toString());return keys;}
    private void updateAlbums(){
        changingAlbums=true;
        LinkedHashMap<String,String> choices=new LinkedHashMap<>();choices.put("","全部照片");for(Photo p:all)choices.put(p.bucket,p.album);
        ArrayList<String> ids=new ArrayList<>(choices.keySet()),labels=new ArrayList<>();
        for(String id:ids){int count=0;for(Photo p:all)if(id.isEmpty()||id.equals(p.bucket))count++;labels.add(choices.get(id)+"  ("+count+")");}
        if(!ids.contains(bucket))bucket="";
        ArrayAdapter<String> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,labels);a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);albums.setAdapter(a);albums.setSelection(ids.indexOf(bucket));
        albums.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onNothingSelected(AdapterView<?> p){}public void onItemSelected(AdapterView<?> p,View v,int position,long id){if(changingAlbums||position>=ids.size())return;String selected=ids.get(position);if(!selected.equals(bucket)){bucket=selected;applyAlbum();grid.setSelection(0);}}});changingAlbums=false;
    }
    private void applyAlbum(){shown.clear();for(Photo p:all)if(bucket.isEmpty()||bucket.equals(p.bucket))shown.add(p);adapter.notifyDataSetChanged();empty.setVisibility(shown.isEmpty()?View.VISIBLE:View.GONE);updateSelection();}
    private void updateSelection(){done.setText(completing?"正在读取…":"完成 ("+selection.size()+"/"+selection.limit+")");done.setEnabled(!completing&&selection.size()>0);done.setAlpha(selection.size()>0?1f:.45f);preview.setText("预览 ("+selection.size()+")");preview.setEnabled(!completing&&selection.size()>0);}
    private void toggle(Photo photo){if(completing)return;if(!selection.toggle(photo.uri.toString()))Toast.makeText(this,"本次最多选择 "+selection.limit+" 张",Toast.LENGTH_SHORT).show();adapter.notifyDataSetChanged();updateSelection();updatePreviewChoice();}
    private void complete(){
        if(selection.size()==0||completing)return;
        completing=true;done.setEnabled(false);preview.setEnabled(false);done.setText("正在读取…");
        ArrayList<String> chosen=selection.values();
        // Recheck access at completion: selected-photo grants can be revoked while the picker is open.
        queries.execute(()->{
            ArrayList<Uri> valid=new ArrayList<>();for(String key:chosen)try(android.content.res.AssetFileDescriptor f=getContentResolver().openAssetFileDescriptor(Uri.parse(key),"r")){if(f!=null)valid.add(Uri.parse(key));}catch(Exception ignored){}
            runOnUiThread(()->{
                if(destroyed||isFinishing())return;completing=false;
                if(valid.size()!=chosen.size()){ArrayList<String> keys=new ArrayList<>();for(Uri uri:valid)keys.add(uri.toString());selection.retain(keys);adapter.notifyDataSetChanged();updateSelection();Toast.makeText(this,"部分照片已删除或无权读取，请重新选择",Toast.LENGTH_LONG).show();return;}
                Intent data=new Intent().setData(valid.get(0)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                ClipData clips=ClipData.newUri(getContentResolver(),"所选照片",valid.get(0));for(int i=1;i<valid.size();i++)clips.addItem(new ClipData.Item(valid.get(i)));data.setClipData(clips);setResult(RESULT_OK,data);finish();
            });
        });
    }
    private void systemPicker(){
        if(completing)return;
        if(selection.size()>=selection.limit){Toast.makeText(this,"已选满，请先取消一张",Toast.LENGTH_SHORT).show();return;}
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*").putExtra(Intent.EXTRA_ALLOW_MULTIPLE,selection.limit-selection.size()>1);
        try{startActivityForResult(i,SYSTEM_PICKER);}catch(RuntimeException e){Toast.makeText(this,"手机暂时没有可用的图片选择器",Toast.LENGTH_SHORT).show();}
    }
    @Override protected void onActivityResult(int code,int result,Intent data){
        super.onActivityResult(code,result,data);if(code!=SYSTEM_PICKER||result!=RESULT_OK||data==null)return;
        ArrayList<Uri> incoming=new ArrayList<>();if(data.getClipData()!=null){ClipData clip=data.getClipData();for(int i=0;i<clip.getItemCount();i++)incoming.add(clip.getItemAt(i).getUri());}else if(data.getData()!=null)incoming.add(data.getData());
        boolean excess=false;
        for(Uri uri:incoming){if(uri==null||!"content".equals(uri.getScheme())||selection.number(uri.toString())>0)continue;if(selection.size()==selection.limit){excess=true;continue;}
            Photo p=new Photo(uri,"external","其他位置","所选图片",0);external.add(p);selection.toggle(uri.toString());
        }
        bucket="";loadPhotos();if(excess)Toast.makeText(this,"本次最多选择 "+selection.limit+" 张，已保留前面的图片",Toast.LENGTH_LONG).show();
    }
    private Bitmap decode(Photo photo,int size) throws Exception {
        if(size<=512&&Build.VERSION.SDK_INT>=29)return getContentResolver().loadThumbnail(photo.uri,new Size(size,size),null);
        if(Build.VERSION.SDK_INT>=28)return ImageDecoder.decodeBitmap(ImageDecoder.createSource(getContentResolver(),photo.uri),(decoder,info,source)->{
            float ratio=Math.min(1f,(float)size/Math.max(info.getSize().getWidth(),info.getSize().getHeight()));
            decoder.setTargetSize(Math.max(1,Math.round(info.getSize().getWidth()*ratio)),Math.max(1,Math.round(info.getSize().getHeight()*ratio)));decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
        });
        BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;
        try(InputStream in=getContentResolver().openInputStream(photo.uri)){BitmapFactory.decodeStream(in,null,bounds);}
        if(bounds.outWidth<=0||bounds.outHeight<=0)throw new IllegalArgumentException("Unreadable image");
        BitmapFactory.Options options=new BitmapFactory.Options();int sample=1;while(Math.max(bounds.outWidth,bounds.outHeight)/sample>size*2)sample*=2;options.inSampleSize=sample;options.inPreferredConfig=Bitmap.Config.RGB_565;
        Bitmap image;try(InputStream in=getContentResolver().openInputStream(photo.uri)){image=BitmapFactory.decodeStream(in,null,options);}
        if(image!=null&&photo.orientation!=0){Matrix rotation=new Matrix();rotation.postRotate(photo.orientation);Bitmap turned=Bitmap.createBitmap(image,0,0,image.getWidth(),image.getHeight(),rotation,true);if(turned!=image)image.recycle();image=turned;}return image;
    }
    private final class Cell extends FrameLayout {
        final ImageView image=new ImageView(PhotoPickerActivity.this);final TextView badge=text("○",16,Color.WHITE);Future<?> task;String key;
        Cell(){super(PhotoPickerActivity.this);setBackgroundColor(0xffeee5db);image.setScaleType(ImageView.ScaleType.CENTER_CROP);addView(image,new FrameLayout.LayoutParams(-1,-1));
            FrameLayout hit=new FrameLayout(PhotoPickerActivity.this);FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(dp(48),dp(48),Gravity.TOP|Gravity.RIGHT);addView(hit,hp);badge.setGravity(Gravity.CENTER);FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(25),dp(25),Gravity.TOP|Gravity.RIGHT);bp.setMargins(0,dp(5),dp(5),0);hit.addView(badge,bp);hit.setOnClickListener(v->{Photo p=(Photo)getTag();if(p!=null)toggle(p);});setOnClickListener(v->{Photo p=(Photo)getTag();if(p!=null)showPreview(new ArrayList<>(shown),shown.indexOf(p));});hit.setTag("check");
        }
        @Override protected void onMeasure(int widthSpec,int heightSpec){int side=View.MeasureSpec.getSize(widthSpec);super.onMeasure(widthSpec,View.MeasureSpec.makeMeasureSpec(side,View.MeasureSpec.EXACTLY));}
    }
    private final class GalleryAdapter extends BaseAdapter {
        public int getCount(){return shown.size();}public Object getItem(int p){return shown.get(p);}public long getItemId(int p){return p;}
        public View getView(int position,View convert,ViewGroup parent){
            Cell cell=convert instanceof Cell?(Cell)convert:new Cell();Photo photo=shown.get(position);String key=photo.uri.toString();cell.setTag(photo);cell.setContentDescription("预览图片："+(photo.name==null?"照片":photo.name));
            int number=selection.number(key);cell.badge.setText(number>0?String.valueOf(number):"○");cell.badge.setBackground(shape(number>0?ACCENT:0x66000000,20));cell.image.setAlpha(number>0?.7f:1f);View check=cell.findViewWithTag("check");check.setContentDescription(number>0?"取消选择，第 "+number+" 张":"选择图片");
            if(key.equals(cell.key))return cell;
            cell.key=key;if(cell.task!=null)cell.task.cancel(false);thumbnails.purge();cell.image.setImageDrawable(null);Bitmap ready=cache.get(key);if(ready!=null){cell.image.setImageBitmap(ready);return cell;}
            cell.task=thumbnails.submit(()->{Bitmap image=null;try{image=decode(photo,Math.max(160,dp(100)));}catch(Exception|OutOfMemoryError ignored){}final Bitmap loaded=image;if(destroyed)return;if(loaded!=null)cache.put(key,loaded);runOnUiThread(()->{if(!destroyed&&key.equals(cell.key))cell.image.setImageBitmap(loaded);});});return cell;
        }
    }
    private void showPreview(ArrayList<Photo> photos,int index){
        if(photos.isEmpty()||index<0)return;previewPhotos=photos;previewIndex=index;
        imageDialog=new Dialog(this);imageDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setBackgroundColor(0xff241e1b);
        LinearLayout top=row();top.setPadding(dp(12),dp(10),dp(12),dp(8));Button back=button("返回",false);back.setOnClickListener(v->imageDialog.dismiss());top.addView(back,new LinearLayout.LayoutParams(dp(64),dp(48)));
        previewTitle=text("",15,Color.WHITE);previewTitle.setGravity(Gravity.CENTER);top.addView(previewTitle,new LinearLayout.LayoutParams(0,dp(44),1));previewChoice=button("选择",true);previewChoice.setOnClickListener(v->toggle(previewPhotos.get(previewIndex)));top.addView(previewChoice,new LinearLayout.LayoutParams(dp(100),dp(48)));box.addView(top);
        previewImage=new ImageView(this);previewImage.setScaleType(ImageView.ScaleType.FIT_CENTER);box.addView(previewImage,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout bottom=row();bottom.setPadding(dp(14),dp(12),dp(14),dp(12));previous=button("上一张",false);previous.setOnClickListener(v->{previewIndex--;loadPreview();});bottom.addView(previous,new LinearLayout.LayoutParams(0,dp(48),1));next=button("下一张",false);next.setOnClickListener(v->{previewIndex++;loadPreview();});LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,dp(48),1);np.leftMargin=dp(12);bottom.addView(next,np);box.addView(bottom);
        imageDialog.setContentView(box);imageDialog.setOnDismissListener(d->{previewGeneration++;if(previewJob!=null)previewJob.cancel(false);imageDialog=null;});imageDialog.show();imageDialog.getWindow().setLayout(-1,-1);loadPreview();
    }
    private void updatePreviewChoice(){if(imageDialog==null)return;int n=selection.number(previewPhotos.get(previewIndex).uri.toString());previewChoice.setText(n>0?"已选 "+n:"选择");previewChoice.setEnabled(previewLoaded);}
    private void loadPreview(){
        int job=++previewGeneration;Photo photo=previewPhotos.get(previewIndex);previewTitle.setText((previewIndex+1)+" / "+previewPhotos.size()+" · 加载中");previewImage.setImageDrawable(null);previewLoaded=false;updatePreviewChoice();previous.setEnabled(previewIndex>0);next.setEnabled(previewIndex+1<previewPhotos.size());if(previewJob!=null)previewJob.cancel(false);
        previewJob=thumbnails.submit(()->{Bitmap image=null;try{image=decode(photo,1600);}catch(Exception|OutOfMemoryError ignored){}final Bitmap result=image;runOnUiThread(()->{if(destroyed||job!=previewGeneration||imageDialog==null)return;previewLoaded=result!=null;previewImage.setImageBitmap(result);previewTitle.setText((previewIndex+1)+" / "+previewPhotos.size()+(result==null?" · 无法读取":""));updatePreviewChoice();});});
    }
    @Override protected void onSaveInstanceState(Bundle out){super.onSaveInstanceState(out);out.putStringArrayList("selection",selection.values());out.putString("bucket",bucket);out.putStringArrayList("external",keys(external));}
    @Override protected void onDestroy(){destroyed=true;generation++;previewGeneration++;if(imageDialog!=null)imageDialog.dismiss();queries.shutdownNow();thumbnails.shutdownNow();cache.evictAll();super.onDestroy();}
}
