package com.xiongxiong.calendar;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public final class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (Reminders.ALARM.equals(intent.getAction())) Reminders.fire(context);
        else Reminders.restore(context);
    }
}
