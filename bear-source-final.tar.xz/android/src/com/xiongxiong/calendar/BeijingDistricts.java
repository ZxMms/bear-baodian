package com.xiongxiong.calendar;

import android.content.Context;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONObject;

/** WGS84 point-in-polygon lookup. Address names are checked against the same geometry. */
final class BeijingDistricts {
    private final JSONObject polygons;
    BeijingDistricts(JSONObject polygons) { this.polygons = polygons; }

    static BeijingDistricts load(Context context) {
        try (InputStream file = context.getAssets().open("beijing-districts.json");
             ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int size;
            while ((size = file.read(buffer)) != -1) bytes.write(buffer, 0, size);
            return new BeijingDistricts(new JSONObject(bytes.toString("UTF-8")));
        } catch (Exception unavailable) { return new BeijingDistricts(new JSONObject()); }
    }

    // null outside the covered polygons, empty when only Beijing is confirmed.
    String district(double lat, double lon, double accuracy, double marginMeters) {
        if (!(lat >= 39.4 && lat <= 41.1 && lon >= 115.4 && lon <= 117.6)) return null;
        double scaleX = 111320 * Math.cos(Math.toRadians(lat));
        String found = null;
        for (Iterator<String> names = polygons.keys(); names.hasNext();) {
            String name = names.next();
            JSONArray parts = polygons.optJSONArray(name);
            for (int i = 0; i < parts.length(); i++) {
                JSONArray rings = parts.optJSONArray(i);
                boolean inside = false;
                double nearest = Double.POSITIVE_INFINITY;
                for (int r = 0; r < rings.length(); r++) {
                    JSONArray ring = rings.optJSONArray(r);
                    JSONArray last = ring.optJSONArray(ring.length() - 1);
                    double ax = (last.optDouble(0) - lon) * scaleX, ay = (last.optDouble(1) - lat) * 111320;
                    for (int j = 0; j < ring.length(); j++) {
                        JSONArray next = ring.optJSONArray(j);
                        double bx = (next.optDouble(0) - lon) * scaleX, by = (next.optDouble(1) - lat) * 111320;
                        if ((ay > 0) != (by > 0) && ax + (bx-ax) * (-ay) / (by-ay) > 0) inside = !inside;
                        double dx = bx-ax, dy = by-ay, length2 = dx*dx + dy*dy;
                        double t = length2 == 0 ? 0 : Math.max(0, Math.min(1, -(ax*dx+ay*dy) / length2));
                        nearest = Math.min(nearest, Math.hypot(ax + t*dx, ay + t*dy));
                        ax = bx; ay = by;
                    }
                }
                if (!inside) continue;
                if (!LocationRules.districtEligible(accuracy) || nearest <= accuracy + marginMeters || found != null) return "";
                found = name;
            }
        }
        return found;
    }

    /** A geocoder can resolve an uncertain edge, but cannot move a fix to a faraway district. */
    boolean compatible(String name, double lat, double lon, double accuracy, double marginMeters) {
        if (!LocationRules.districtEligible(accuracy) || !WeatherRules.validCoordinates(lat,lon)) return false;
        JSONArray parts = polygons.optJSONArray(name);
        if (parts == null) return false;
        double scaleX = 111320 * Math.cos(Math.toRadians(lat));
        for (int i=0; i<parts.length(); i++) {
            JSONArray rings = parts.optJSONArray(i);
            boolean inside = false;
            double nearest = Double.POSITIVE_INFINITY;
            for (int r=0; r<rings.length(); r++) {
                JSONArray ring = rings.optJSONArray(r), last = ring.optJSONArray(ring.length()-1);
                double ax=(last.optDouble(0)-lon)*scaleX, ay=(last.optDouble(1)-lat)*111320;
                for (int j=0; j<ring.length(); j++) {
                    JSONArray next=ring.optJSONArray(j);
                    double bx=(next.optDouble(0)-lon)*scaleX, by=(next.optDouble(1)-lat)*111320;
                    if ((ay>0)!=(by>0) && ax+(bx-ax)*(-ay)/(by-ay)>0) inside=!inside;
                    double dx=bx-ax,dy=by-ay,length2=dx*dx+dy*dy;
                    double t=length2==0?0:Math.max(0,Math.min(1,-(ax*dx+ay*dy)/length2));
                    nearest=Math.min(nearest,Math.hypot(ax+t*dx,ay+t*dy));
                    ax=bx;ay=by;
                }
            }
            if (inside || nearest<=accuracy+marginMeters) return true;
        }
        return false;
    }
}
