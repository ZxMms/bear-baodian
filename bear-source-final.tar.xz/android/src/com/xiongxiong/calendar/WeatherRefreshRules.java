package com.xiongxiong.calendar;

/** No freshness interval: every eligible entry requests the source, with in-flight coalescing only. */
final class WeatherRefreshRules {
    private WeatherRefreshRules() { }
    static boolean canStart(boolean stopped, boolean foreground, boolean hasPlace,
                            boolean loading, boolean permissionPending, boolean locating, boolean selectingRecent) {
        return !stopped && foreground && hasPlace && !loading && !permissionPending && !locating && !selectingRecent;
    }
}
