package com.xiongxiong.calendar;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public final class CookingTimerReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        if (CookingTimers.ALARM.equals(intent.getAction())) CookingTimers.fire(context, intent.getStringExtra("recipeId"));
        else if (CookingTimers.STOP_RINGING.equals(intent.getAction())) CookingTimers.stopRinging(context, intent.getStringExtra("recipeId"));
        else CookingTimers.restore(context);
    }
}
