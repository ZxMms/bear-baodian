package com.xiongxiong.calendar;

import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.*;

/** SQLite records plus immutable, content-addressed files in the app's private directory. */
final class StoreEngine {
    static final String[] STORES={"entries","recipes","moods","ledger","ledgerCategories","settings"};
    static final String FILE_PATTERN="[0-9a-f]{64}\\.(jpg|png|webp|gif|wav|mp3|m4a|ogg|bin)";
    static final long MAX_BACKUP=512L*1024*1024;
    static final long TRASH_LIFETIME=30L*86400000L;
    private final SqlAccess db;
    final File media;
    StoreEngine(SqlAccess db, File media) throws Exception {
        this.db=db;this.media=media;
        if(!media.isDirectory()&&!media.mkdirs())throw new IOException("无法创建附件目录");
        db.execute("CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL)");
        db.execute("CREATE TABLE IF NOT EXISTS records (store TEXT NOT NULL, key TEXT NOT NULL, payload TEXT NOT NULL, day TEXT, kind TEXT, category TEXT, cents INTEGER, PRIMARY KEY(store,key))");
        db.execute("CREATE INDEX IF NOT EXISTS record_days ON records(store,day)");
        db.execute("CREATE INDEX IF NOT EXISTS ledger_categories ON records(store,kind,category,day)");
        db.execute("CREATE TABLE IF NOT EXISTS migration_records (store TEXT NOT NULL, key TEXT NOT NULL, payload TEXT NOT NULL, checksum TEXT NOT NULL, PRIMARY KEY(store,key))");
    }
    private String meta(String key) throws Exception {List<JSONObject> rows=db.query("SELECT value FROM metadata WHERE key=?",key);return rows.isEmpty()?null:rows.get(0).getString("value");}
    private void meta(String key,String value)throws Exception{db.execute("INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)",key,value);}
    private void store(String store)throws Exception{if(!Arrays.asList(STORES).contains(store))throw new IOException("不支持的数据类型");}
    private void key(String key)throws Exception{if(key==null||key.isEmpty()||key.length()>300)throw new IOException("记录标识无效");}
    static String hash(byte[] bytes)throws Exception{byte[] digest=MessageDigest.getInstance("SHA-256").digest(bytes);StringBuilder out=new StringBuilder();for(byte b:digest)out.append(String.format(Locale.ROOT,"%02x",b&255));return out.toString();}
    static byte[] bounded(InputStream input,long max)throws IOException{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buffer=new byte[32768];long length=0;int n;while((n=input.read(buffer))!=-1){length+=n;if(length>max)throw new IOException("文件超过支持大小");out.write(buffer,0,n);}return out.toByteArray();}
    private static String extension(String mime){switch(mime){case "image/jpeg":return "jpg";case "image/png":return "png";case "image/webp":return "webp";case "image/gif":return "gif";case "audio/wav":case "audio/x-wav":case "audio/wave":return "wav";case "audio/mpeg":case "audio/mp3":return "mp3";case "audio/mp4":case "audio/x-m4a":return "m4a";case "audio/ogg":return "ogg";default:return "bin";}}
    static String mime(File file){String name=file.getName();if(name.endsWith(".jpg"))return "image/jpeg";if(name.endsWith(".png"))return "image/png";if(name.endsWith(".webp"))return "image/webp";if(name.endsWith(".gif"))return "image/gif";if(name.endsWith(".wav"))return "audio/wav";if(name.endsWith(".mp3"))return "audio/mpeg";if(name.endsWith(".m4a"))return "audio/mp4";if(name.endsWith(".ogg"))return "audio/ogg";return "application/octet-stream";}
    synchronized File file(String reference)throws Exception{
        if(!reference.startsWith("media/")||!reference.substring(6).matches(FILE_PATTERN))throw new IOException("附件地址无效");
        File file=new File(media,reference.substring(6));if(!file.isFile())throw new IOException("附件文件缺失");return file;
    }
    synchronized String attachment(String data)throws Exception{
        if(data.startsWith("media/")){file(data);return data;}
        int separator=data.indexOf(";base64,");
        if(!data.startsWith("data:")||separator<5||separator>100||data.length()>45*1024*1024)throw new IOException("附件格式或大小不支持");
        String mime=data.substring(5,separator).toLowerCase(Locale.ROOT);
        if(!(mime.startsWith("image/")||mime.startsWith("audio/")||mime.equals("application/octet-stream")))throw new IOException("附件类型不支持");
        byte[] bytes=Base64.getDecoder().decode(data.substring(separator+8));
        if(bytes.length==0||bytes.length>32*1024*1024)throw new IOException("附件大小不支持");
        String name=hash(bytes)+"."+extension(mime);File target=new File(media,name);
        if(!target.isFile()){
            File temp=File.createTempFile("incoming-",".part",media);
            try(FileOutputStream output=new FileOutputStream(temp)){output.write(bytes);output.getFD().sync();}
            if(!temp.renameTo(target)){temp.delete();throw new IOException("附件写入未完成");}
        }
        if(target.length()!=bytes.length||!hash(Files.readAllBytes(target.toPath())).equals(name.substring(0,64)))throw new IOException("附件校验失败");
        return "media/"+name;
    }
    private static boolean trashStore(String store){return store.equals("entries")||store.equals("recipes")||store.equals("ledger");}
    private static boolean deleted(Object value){return value instanceof JSONObject&&((JSONObject)value).optLong("_deletedAt",0)>0;}
    private static long expires(JSONObject value){return value.optLong("_deleteExpiresAt",value.optLong("_deletedAt",0)+TRASH_LIFETIME);}
    private static boolean explicitImageField(String name){return Arrays.asList("foodRecipeCover","receipt","photo","recipeImportPhoto","cover").contains(name);}
    private static boolean attachmentValue(String text){return text.startsWith("data:image/")||text.startsWith("media/");}
    // Only named media fields are traversed: arbitrary diary/form text is never interpreted as a file.
    private void normalizeDocumentMedia(Object value,int depth)throws Exception{
        if(depth>32)throw new IOException("文档层级过多");
        if(value instanceof JSONArray){JSONArray array=(JSONArray)value;for(int i=0;i<array.length();i++)normalizeDocumentMedia(array.get(i),depth+1);return;}
        if(!(value instanceof JSONObject))return;
        JSONObject object=(JSONObject)value;
        for(Iterator<String> it=object.keys();it.hasNext();){String name=it.next();Object child=object.get(name);
            if(name.equals("photos")&&child instanceof JSONArray){JSONArray photos=(JSONArray)child;if(photos.length()>20)throw new IOException("文档照片数量异常");for(int i=0;i<photos.length();i++)photos.put(i,attachment(photos.getString(i)));}
            else if(explicitImageField(name)&&child instanceof String&&attachmentValue((String)child))object.put(name,attachment((String)child));
            else if(child instanceof JSONObject||child instanceof JSONArray)normalizeDocumentMedia(child,depth+1);
        }
    }
    private void documentReferences(Object value,Set<String> refs,int depth)throws Exception{
        if(depth>32)throw new IOException("文档层级过多");
        if(value instanceof JSONArray){JSONArray array=(JSONArray)value;for(int i=0;i<array.length();i++)documentReferences(array.get(i),refs,depth+1);return;}
        if(!(value instanceof JSONObject))return;
        JSONObject object=(JSONObject)value;
        for(Iterator<String> it=object.keys();it.hasNext();){String name=it.next();Object child=object.get(name);
            if(name.equals("photos")&&child instanceof JSONArray){JSONArray photos=(JSONArray)child;for(int i=0;i<photos.length();i++)refs.add(photos.getString(i));}
            else if(explicitImageField(name)&&child instanceof String&&attachmentValue((String)child))refs.add((String)child);
            else if(child instanceof JSONObject||child instanceof JSONArray)documentReferences(child,refs,depth+1);
        }
    }
    private Object normalize(String store,Object value)throws Exception{
        if(store.equals("settings")&&value instanceof JSONArray){JSONArray result=new JSONArray(value.toString());normalizeDocumentMedia(result,0);return result;}
        if(store.equals("settings")&&!(value instanceof JSONObject))return value;
        if(!(value instanceof JSONObject))throw new IOException("记录格式无效");
        JSONObject result=new JSONObject(value.toString());
        if(store.equals("settings"))normalizeDocumentMedia(result,0);
        if(store.equals("entries")||store.equals("recipes")||store.equals("ledger")){
            JSONArray photos=result.optJSONArray("photos");
            if(photos!=null){if(photos.length()>(store.equals("ledger")?5:20))throw new IOException("照片数量异常");for(int i=0;i<photos.length();i++)photos.put(i,attachment(photos.getString(i)));}
        }
        if(store.equals("ledger")&&!result.optString("receipt").isEmpty())result.put("receipt",attachment(result.getString("receipt")));
        if(store.equals("settings")&&result.optJSONObject("clips")!=null){JSONObject clips=result.getJSONObject("clips");for(Iterator<String> it=clips.keys();it.hasNext();){JSONObject clip=clips.optJSONObject(it.next());if(clip!=null&&!clip.optString("data").isEmpty())clip.put("data",attachment(clip.getString("data")));}}
        return result;
    }
    private void validate(String store,String key,Object value)throws Exception{
        store(store);key(key);
        if(store.equals("settings"))return;
        if(!(value instanceof JSONObject))throw new IOException("记录格式无效");
        JSONObject row=(JSONObject)value;
        if(!key.equals(row.optString(store.equals("moods")?"date":"id")))throw new IOException("记录标识不一致");
        if(store.equals("ledger")){
            if(row.has("photos")&&!row.isNull("photos")&&(row.optJSONArray("photos")==null||row.getJSONArray("photos").length()>5))throw new IOException("每笔账单最多 5 张消费照片");
            if(!Arrays.asList("income","expense").contains(row.optString("type"))||!row.optString("date").matches("\\d{4}-\\d{2}-\\d{2}")||row.optLong("cents",0)<=0||row.optLong("cents")>999999999L)throw new IOException("账单数据无效");
        }
    }
    private void insert(String store,String key,Object value,boolean add)throws Exception{
        validate(store,key,value);JSONObject row=value instanceof JSONObject?(JSONObject)value:new JSONObject();
        db.execute((add?"INSERT":"INSERT OR REPLACE")+" INTO records(store,key,payload,day,kind,category,cents) VALUES(?,?,?,?,?,?,?)",store,key,json(value),row.optString("date",null),row.optString("type",row.optString("kind",null)),row.optString("category",null),row.has("cents")?row.getLong("cents"):null);
    }
    private static String json(Object value){String wrapped=new JSONArray().put(value).toString();return wrapped.substring(1,wrapped.length()-1);}
    private JSONArray all(String store)throws Exception{store(store);JSONArray values=new JSONArray();for(JSONObject row:db.query("SELECT payload FROM records WHERE store=? ORDER BY key",store))values.put(new JSONTokener(row.getString("payload")).nextValue());return values;}
    private JSONObject counts(String table)throws Exception{JSONObject result=new JSONObject();for(String name:STORES)result.put(name,0);for(JSONObject row:db.query("SELECT store,COUNT(*) AS count FROM "+table+" GROUP BY store"))result.put(row.getString("store"),row.getLong("count"));return result;}
    private Set<String> references(String store,Object value)throws Exception{
        Set<String> refs=new TreeSet<>();if(store.equals("settings"))documentReferences(value,refs,0);if(!(value instanceof JSONObject))return refs;JSONObject obj=(JSONObject)value;
        if(store.equals("entries")||store.equals("recipes")||store.equals("ledger")){JSONArray photos=obj.optJSONArray("photos");if(photos!=null)for(int i=0;i<photos.length();i++)refs.add(photos.getString(i));}
        if(store.equals("ledger")&&!obj.optString("receipt").isEmpty())refs.add(obj.getString("receipt"));
        if(store.equals("settings")&&obj.optJSONObject("clips")!=null){JSONObject clips=obj.getJSONObject("clips");for(Iterator<String> it=clips.keys();it.hasNext();){JSONObject clip=clips.optJSONObject(it.next());if(clip!=null&&!clip.optString("data").isEmpty())refs.add(clip.getString("data"));}}
        return refs;
    }
    private Set<String> references(JSONArray rows)throws Exception{
        Set<String> out=new TreeSet<>();for(int i=0;i<rows.length();i++){JSONObject row=rows.getJSONObject(i);out.addAll(references(row.getString("store"),row.get("value")));}return out;
    }
    synchronized JSONObject request(JSONObject req)throws Exception{
        String op=req.getString("op"),store=req.optString("store"),key=req.optString("key");
        if(op.equals("status"))return new JSONObject().put("ready","1".equals(meta("ready"))).put("counts",counts("records")).put("engine","SQLite").put("lastBackup",meta("lastBackup"));
        if(op.equals("migration-start")){
            if("1".equals(meta("ready")))throw new IOException("迁移已完成，请重新打开");
            JSONObject expected=req.getJSONObject("counts");for(String name:STORES)if(expected.getLong(name)<0)throw new IOException("迁移数量无效");
            db.execute("DELETE FROM migration_records");meta("migrationCounts",expected.toString());return new JSONObject();
        }
        if(op.equals("migration-row")){
            if("1".equals(meta("ready"))||meta("migrationCounts")==null)throw new IOException("迁移状态无效");
            Object value=req.get("value");validate(store,key,value);value=normalize(store,value);String payload=json(value);
            db.execute("INSERT OR REPLACE INTO migration_records(store,key,payload,checksum) VALUES(?,?,?,?)",store,key,payload,hash(payload.getBytes(StandardCharsets.UTF_8)));return new JSONObject();
        }
        if(op.equals("migration-finish")){
            if("1".equals(meta("ready")))return new JSONObject().put("ready",true);
            JSONObject expected=new JSONObject(meta("migrationCounts"));JSONObject actual=counts("migration_records");
            for(String name:STORES)if(expected.getLong(name)!=actual.getLong(name))throw new IOException("迁移数量校验失败，旧记录仍保留");
            List<JSONObject> staged=db.query("SELECT * FROM migration_records");
            for(JSONObject row:staged){String payload=row.getString("payload");if(!hash(payload.getBytes(StandardCharsets.UTF_8)).equals(row.getString("checksum")))throw new IOException("迁移内容校验失败");for(String reference:references(row.getString("store"),new JSONTokener(payload).nextValue()))verify(file(reference));}
            db.begin();try{
                if(db.query("SELECT key FROM records LIMIT 1").size()>0)throw new IOException("目标库非空，已停止迁移");
                for(JSONObject row:staged)insert(row.getString("store"),row.getString("key"),new JSONTokener(row.getString("payload")).nextValue(),true);
                meta("ready","1");meta("migratedAt",Long.toString(System.currentTimeMillis()));db.execute("DELETE FROM migration_records");db.commit();
            }catch(Exception error){db.rollback();throw error;}
            return new JSONObject().put("ready",true).put("counts",actual);
        }
        if(!"1".equals(meta("ready")))throw new IOException("数据尚未迁移完成");
        if(op.equals("all"))return new JSONObject().put("value",all(store));
        if(op.equals("get")){store(store);key(key);List<JSONObject> result=db.query("SELECT payload FROM records WHERE store=? AND key=?",store,key);return new JSONObject().put("value",result.isEmpty()?JSONObject.NULL:new JSONTokener(result.get(0).getString("payload")).nextValue());}
        if(op.equals("put-batch")){
            JSONArray rows=req.getJSONArray("rows"),normalized=new JSONArray();Set<String> batchKeys=new HashSet<>();if(rows.length()<1||rows.length()>20)throw new IOException("批量记录数量无效");
            for(int i=0;i<rows.length();i++){JSONObject row=rows.getJSONObject(i);String table=row.getString("store"),id=row.getString("key");if(!batchKeys.add(table+"\u0000"+id))throw new IOException("关联保存含重复记录");validate(table,id,row.get("value"));normalized.put(new JSONObject().put("store",table).put("key",id).put("value",normalize(table,row.get("value"))));}
            db.begin();try{for(int i=0;i<normalized.length();i++){JSONObject row=normalized.getJSONObject(i);insert(row.getString("store"),row.getString("key"),row.get("value"),false);}db.commit();}catch(Exception error){db.rollback();throw error;}
            return new JSONObject().put("rows",normalized);
        }
        if(op.equals("put")){
            validate(store,key,req.get("value"));Object value=normalize(store,req.get("value"));
            db.begin();try{insert(store,key,value,req.optBoolean("add"));db.commit();}catch(Exception error){db.rollback();throw error;}
            return new JSONObject().put("value",value);
        }
        if(op.equals("soft-delete")||op.equals("restore")||op.equals("purge-trash-item")){
            store(store);key(key);if(!trashStore(store))throw new IOException("这类内容不在最近删除中");
            db.begin();try{
                List<JSONObject> found=db.query("SELECT payload FROM records WHERE store=? AND key=?",store,key);
                if(found.isEmpty()){if(op.equals("restore"))throw new IOException("这条记录已不在最近删除中");db.commit();return new JSONObject().put("value",JSONObject.NULL);}
                JSONObject item=new JSONObject(found.get(0).getString("payload"));
                if(op.equals("soft-delete")){
                    if(!deleted(item)){long now=req.optLong("now",System.currentTimeMillis());if(now<=0)throw new IOException("删除时间无效");item.put("_deletedAt",now).put("_deleteExpiresAt",now+TRASH_LIFETIME);insert(store,key,item,false);}
                }else{
                    if(!deleted(item))throw new IOException("这条记录已不在最近删除中");
                    if(op.equals("restore")){item.remove("_deletedAt");item.remove("_deleteExpiresAt");insert(store,key,item,false);}
                    else db.execute("DELETE FROM records WHERE store=? AND key=?",store,key);
                }
                db.commit();return new JSONObject().put("value",item);
            }catch(Exception error){db.rollback();throw error;}
        }
        if(op.equals("purge-trash")){
            long now=req.optLong("now",System.currentTimeMillis());boolean expiredOnly=req.optBoolean("expiredOnly",true);int removed=0;
            db.begin();try{
                for(JSONObject row:db.query("SELECT store,key,payload FROM records")){
                    String table=row.getString("store");Object value=new JSONTokener(row.getString("payload")).nextValue();
                    if(trashStore(table)&&deleted(value)&&(!expiredOnly||expires((JSONObject)value)<=now)){db.execute("DELETE FROM records WHERE store=? AND key=?",table,row.getString("key"));removed++;}
                }
                db.commit();return new JSONObject().put("removed",removed);
            }catch(Exception error){db.rollback();throw error;}
        }
        if(op.equals("remove")){store(store);key(key);db.execute("DELETE FROM records WHERE store=? AND key=?",store,key);return new JSONObject();}
        if(op.equals("cleanup-files")){
            if(meta("lastBackup")==null)throw new IOException("请先导出完整备份");
            Set<String> live=references(snapshotRows());long freed=0;File[] files=media.listFiles();
            if(files!=null)for(File file:files)if(file.isFile()&&!live.contains("media/"+file.getName())){long length=file.length();if(file.delete())freed+=length;}
            return new JSONObject().put("freedBytes",freed);
        }
        if(op.equals("stats")){
            JSONArray rows=snapshotRows();Set<String> refs=references(rows);long bytes=0;for(String ref:refs)bytes+=file(ref).length();
            JSONObject activeCounts=new JSONObject();for(String name:STORES)activeCounts.put(name,0);int trashCount=0;
            for(int i=0;i<rows.length();i++){JSONObject row=rows.getJSONObject(i);String name=row.getString("store");if(trashStore(name)&&deleted(row.get("value")))trashCount++;else activeCounts.put(name,activeCounts.getInt(name)+1);}
            return new JSONObject().put("counts",activeCounts).put("trashCount",trashCount).put("attachments",refs.size()).put("attachmentBytes",bytes).put("lastBackup",meta("lastBackup")).put("engine","SQLite");
        }
        throw new IOException("不支持的存储操作");
    }
    private JSONArray snapshotRows()throws Exception{JSONArray rows=new JSONArray();for(JSONObject row:db.query("SELECT store,key,payload FROM records ORDER BY store,key"))rows.put(new JSONObject().put("store",row.getString("store")).put("key",row.getString("key")).put("value",new JSONTokener(row.getString("payload")).nextValue()));return rows;}
    private static void verify(File file)throws Exception{if(!file.isFile()||!hash(Files.readAllBytes(file.toPath())).equals(file.getName().substring(0,64)))throw new IOException("附件校验失败");}
    synchronized void backup(OutputStream stream)throws Exception{
        if(!"1".equals(meta("ready")))throw new IOException("请等待迁移完成");
        JSONArray rows=snapshotRows();Set<String> references=references(rows);JSONArray files=new JSONArray();
        for(String ref:references){File file=file(ref);verify(file);files.put(new JSONObject().put("path",ref).put("size",file.length()).put("sha256",file.getName().substring(0,64)));}
        byte[] data=rows.toString().getBytes(StandardCharsets.UTF_8);
        if(data.length>16*1024*1024)throw new IOException("记录数据超过此版本备份支持大小");
        long totalBytes=data.length;for(String ref:references)totalBytes+=file(ref).length();if(totalBytes>MAX_BACKUP)throw new IOException("完整备份超过 512 MB，此版本暂不支持");
        JSONObject manifest=new JSONObject().put("app","com.xiongxiong.calendar").put("format",1).put("created",System.currentTimeMillis()).put("counts",counts("records")).put("recordsSha256",hash(data)).put("files",files);
        try(ZipOutputStream zip=new ZipOutputStream(stream)){
            zip.putNextEntry(new ZipEntry("manifest.json"));zip.write(manifest.toString().getBytes(StandardCharsets.UTF_8));zip.closeEntry();
            zip.putNextEntry(new ZipEntry("records.json"));zip.write(data);zip.closeEntry();
            for(String ref:references){zip.putNextEntry(new ZipEntry(ref));Files.copy(file(ref).toPath(),zip);zip.closeEntry();}
        }
        meta("lastBackup",Long.toString(System.currentTimeMillis()));
    }
    static final class PreparedBackup {
        final JSONObject manifest;final JSONArray rows;final File folder;
        PreparedBackup(JSONObject manifest,JSONArray rows,File folder){this.manifest=manifest;this.rows=rows;this.folder=folder;}
    }
    synchronized PreparedBackup inspectBackup(InputStream input,File folder)throws Exception{
        if(!folder.mkdirs()&&!folder.isDirectory())throw new IOException("无法准备恢复目录");
        Set<String> names=new HashSet<>();long size=0;int entries=0;
        try(ZipInputStream zip=new ZipInputStream(input)){
            ZipEntry entry;while((entry=zip.getNextEntry())!=null){String name=entry.getName();if(++entries>20002||!names.add(name)||!(name.equals("manifest.json")||name.equals("records.json")||name.matches("media/"+FILE_PATTERN)))throw new IOException("备份文件结构无效");
                File target=new File(folder,name);if(target.getParentFile()!=null)target.getParentFile().mkdirs();
                byte[] bytes=bounded(zip,name.startsWith("media/")?32L*1024*1024:16L*1024*1024);size+=bytes.length;if(size>MAX_BACKUP)throw new IOException("备份解压后超过 512 MB");Files.write(target.toPath(),bytes);zip.closeEntry();
            }
        }
        JSONObject manifest=new JSONObject(new String(Files.readAllBytes(new File(folder,"manifest.json").toPath()),StandardCharsets.UTF_8));
        if(!"com.xiongxiong.calendar".equals(manifest.getString("app"))||manifest.getInt("format")!=1)throw new IOException("这不是支持的熊熊宝典备份");
        byte[] data=Files.readAllBytes(new File(folder,"records.json").toPath());if(!hash(data).equals(manifest.getString("recordsSha256")))throw new IOException("备份记录校验失败");
        JSONArray rows=new JSONArray(new String(data,StandardCharsets.UTF_8));Set<String> unique=new HashSet<>();JSONObject counts=new JSONObject();for(String name:STORES)counts.put(name,0);
        for(int i=0;i<rows.length();i++){JSONObject row=rows.getJSONObject(i);String store=row.getString("store"),key=row.getString("key");validate(store,key,row.get("value"));if(!unique.add(store+"\u0000"+key))throw new IOException("备份含重复记录");counts.put(store,counts.getInt(store)+1);}
        for(String name:STORES)if(counts.getInt(name)!=manifest.getJSONObject("counts").getInt(name))throw new IOException("备份数量校验失败");
        Set<String> refs=references(rows),declared=new TreeSet<>();JSONArray files=manifest.getJSONArray("files");
        for(int i=0;i<files.length();i++){JSONObject info=files.getJSONObject(i);String path=info.getString("path");if(!path.matches("media/"+FILE_PATTERN)||!declared.add(path))throw new IOException("备份附件名称无效");File file=new File(folder,path);verify(file);if(file.length()!=info.getLong("size")||!file.getName().startsWith(info.getString("sha256")+"."))throw new IOException("备份附件信息不一致");}
        if(!refs.equals(declared)||names.size()!=declared.size()+2)throw new IOException("备份附件不完整");
        // Reject external URLs or embedded data in known attachment fields by validating against staged files.
        for(int i=0;i<rows.length();i++)validateBackupAttachments(rows.getJSONObject(i),declared);
        return new PreparedBackup(manifest,rows,folder);
    }
    private void validateBackupAttachments(JSONObject row,Set<String> declared)throws Exception{
        if(!declared.containsAll(references(row.getString("store"),row.get("value"))))throw new IOException("备份含不支持的附件地址");
    }
    synchronized JSONObject mergeBackup(PreparedBackup backup)throws Exception{
        if(!"1".equals(meta("ready")))throw new IOException("请等待本机数据准备完成");
        int added=0,kept=0;
        // Copy immutable bytes before the transaction; failed copies leave existing records unchanged.
        for(String ref:references(backup.rows)){File source=new File(backup.folder,ref);verify(source);File target=new File(media,source.getName());if(!target.isFile()){File temp=File.createTempFile("restore-",".part",media);Files.copy(source.toPath(),temp.toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING);try(FileOutputStream out=new FileOutputStream(temp,true)){out.getFD().sync();}if(!temp.renameTo(target)){temp.delete();throw new IOException("附件恢复未完成");}}verify(target);}
        db.begin();try{
            for(int i=0;i<backup.rows.length();i++){JSONObject row=backup.rows.getJSONObject(i);String store=row.getString("store"),key=row.getString("key");if(!db.query("SELECT key FROM records WHERE store=? AND key=?",store,key).isEmpty()){kept++;continue;}insert(store,key,row.get("value"),true);added++;}
            db.commit();
        }catch(Exception error){db.rollback();throw error;}
        return new JSONObject().put("added",added).put("kept",kept);
    }
}
