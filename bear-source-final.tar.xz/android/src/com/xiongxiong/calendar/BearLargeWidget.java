package com.xiongxiong.calendar;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.os.Bundle;

public final class BearLargeWidget extends AppWidgetProvider {
    @Override public void onDisabled(Context c){BearWidgets.scheduleBoundary(c);}
    @Override public void onUpdate(Context c,AppWidgetManager manager,int[] ids){BearWidgets.update(c,manager,ids,true);}
    @Override public void onAppWidgetOptionsChanged(Context c,AppWidgetManager manager,int id,Bundle options){BearWidgets.update(c,manager,new int[]{id},true);}
}
