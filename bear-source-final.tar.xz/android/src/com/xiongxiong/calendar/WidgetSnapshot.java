package com.xiongxiong.calendar;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONObject;

/** Private, bounded display snapshot. SQLite avoids SharedPreferences' cross-process cache. */
final class WidgetSnapshot extends SQLiteOpenHelper {
    private WidgetSnapshot(Context c) { super(c, "widget-display.sqlite", null, 1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE display_snapshot (id INTEGER PRIMARY KEY CHECK(id=1), payload TEXT NOT NULL)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion) {
        throw new IllegalStateException("Unsupported widget snapshot version");
    }
    static void save(Context c,String json) {
        if(json==null||json.length()>200000)throw new IllegalArgumentException("Snapshot too large");
        try(WidgetSnapshot helper=new WidgetSnapshot(c)) {
            ContentValues values=new ContentValues();values.put("id",1);values.put("payload",json);
            if(helper.getWritableDatabase().insertWithOnConflict("display_snapshot",null,values,SQLiteDatabase.CONFLICT_REPLACE)<0)
                throw new IllegalStateException("Widget snapshot was not saved");
        }
    }
    static JSONObject read(Context c) {
        if(!c.getDatabasePath("widget-display.sqlite").isFile())return new JSONObject();
        try(SQLiteDatabase db=SQLiteDatabase.openDatabase(c.getDatabasePath("widget-display.sqlite").getPath(),null,SQLiteDatabase.OPEN_READONLY);
            Cursor cursor=db.rawQuery("SELECT payload FROM display_snapshot WHERE id=1",null)) {
            return cursor.moveToFirst()?new JSONObject(cursor.getString(0)):new JSONObject();
        }catch(Exception unavailable){return new JSONObject();}
    }
}
