package com.xiongxiong.calendar;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.HttpsURLConnection;
import org.json.JSONArray;
import org.json.JSONObject;

/** Optional province-wide recent releases. This never claims an alert is active or covers a GPS point. */
public final class WeatherAlerts {
    private static final long DEADLINE_MS = 10000L;
    private final Activity activity;
    private final WebView web;
    private final SharedPreferences preferences;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newFixedThreadPool(2);
    private final ScheduledExecutorService deadlines = Executors.newSingleThreadScheduledExecutor();
    private final ExecutorService cleanup = Executors.newCachedThreadPool();
    private String province = "", error = "";
    private JSONObject response;
    private volatile String snapshot = "{}";
    private volatile boolean stopped;
    private Request active;

    private static final class Request {
        final long started = SystemClock.elapsedRealtime();
        volatile boolean cancelled;
        volatile HttpsURLConnection connection;
        volatile Future<?> task;
        volatile JSONObject progress;
        ScheduledFuture<?> deadline;
        synchronized boolean bind(HttpsURLConnection value) {
            if (cancelled) return false;
            connection = value; return true;
        }
        synchronized void clear(HttpsURLConnection value) { if (connection == value) connection = null; }
        synchronized HttpsURLConnection cancelConnection() {
            cancelled = true;
            HttpsURLConnection current = connection; connection = null; return current;
        }
    }

    WeatherAlerts(Activity activity, WebView web) {
        this.activity = activity;
        this.web = web;
        preferences = activity.getSharedPreferences("weather_alerts", Context.MODE_PRIVATE);
        String saved = preferences.getString("province", "");
        if (WeatherAlertParser.supported(saved)) province = saved;
        // Selection is a preference; weather releases are fetched anew, never restored from disk.
        preferences.edit().remove("lastresponse").apply();
        publish();
    }

    @JavascriptInterface public String state() { return snapshot; }
    @JavascriptInterface public void selectProvince(String value) {
        final String selected = value == null ? "" : value.trim();
        activity.runOnUiThread(() -> {
            if (stopped) return;
            if (!WeatherAlertParser.supported(selected)) { error = "请选择列表中的省份或直辖市"; publish(); return; }
            if (province.equals(selected)) { if (active == null) fetch(); else publish(); return; }
            cancel(); province = selected; response = null; error = "";
            preferences.edit().putString("province", province).remove("lastresponse").apply();
            fetch();
        });
    }
    @JavascriptInterface public void refresh() {
        activity.runOnUiThread(() -> { if (!stopped && !province.isEmpty() && active == null) fetch(); });
    }
    @JavascriptInterface public void refreshIfNeeded() { activity.runOnUiThread(this::resume); }
    @JavascriptInterface public void disable() {
        activity.runOnUiThread(() -> {
            if (stopped) return;
            cancel(); province = ""; response = null; error = "";
            preferences.edit().remove("province").remove("lastresponse").apply(); publish();
        });
    }

    private void fetch() {
        if (stopped || province.isEmpty() || active != null) return;
        final String selected = province;
        final Request request = new Request();
        active = request; response = null; error = ""; publish();
        request.deadline = deadlines.schedule(() -> {
            HttpsURLConnection connection = request.cancelConnection();
            main.post(() -> complete(request, request.progress, request.progress == null ? "预警查询超时，请稍后重试或查看官方页面" : "仅取得部分预警，其他地区查询超时，请查看官方完整列表"));
            if (request.task != null) request.task.cancel(true);
            closeLater(connection);
        }, DEADLINE_MS, TimeUnit.MILLISECONDS);
        request.task = worker.submit(() -> {
            JSONObject result = null; String failure = "";
            try {
                // These empty filters are required by the website endpoint; omitting them returns HTTP 417.
                String suffix = "&pageSize=" + WeatherAlertParser.PAGE_SIZE + "&signaltype=&signallevel=&province=" + URLEncoder.encode(selected, "UTF-8");
                result = WeatherAlertParser.query(selected, System.currentTimeMillis(),
                    pageNumber -> get("https://www.nmc.cn/rest/findAlarm?pageNo=" + pageNumber + suffix, request),
                    partial -> request.progress = partial);
                if (result.optBoolean("partialFailure")) failure = "仅取得部分预警，其他地区暂未查询完成，请查看官方完整列表";
            } catch (Exception unavailable) { failure = "预警信息暂时未能更新，请重试或查看官方页面"; }
            final JSONObject received = result; final String message = failure;
            main.post(() -> { if (!request.cancelled) complete(request, received, message); });
        });
    }

    private void complete(Request request, JSONObject result, String failure) {
        if (stopped || active != request) return;
        if (request.deadline != null) request.deadline.cancel(false);
        active = null; error = failure;
        response = result;
        publish();
    }

    private static String get(String address, Request request) throws Exception {
        URL url = new URL(address);
        if (!"https".equals(url.getProtocol()) || !"www.nmc.cn".equals(url.getHost())
            || !"/rest/findAlarm".equals(url.getPath())) throw new IllegalArgumentException("Invalid source");
        HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
        configure(connection);
        try {
            if (!request.bind(connection)) throw new java.io.IOException("Request cancelled");
            checkDeadline(request);
            if (connection.getResponseCode() != 200) throw new java.io.IOException("Source unavailable");
            try (InputStream input = connection.getInputStream(); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192]; int count;
                while ((count = input.read(buffer)) != -1) {
                    checkDeadline(request);
                    if (output.size() + count > 262144) throw new java.io.IOException("Response too large");
                    output.write(buffer, 0, count);
                }
                checkDeadline(request);
                return new String(output.toByteArray(), StandardCharsets.UTF_8);
            }
        } finally { request.clear(connection); connection.disconnect(); }
    }

    static void configure(HttpsURLConnection connection) {
        connection.setConnectTimeout(4500); connection.setReadTimeout(4500);
        connection.setInstanceFollowRedirects(false);
        connection.setUseCaches(false);
        connection.setRequestProperty("Cache-Control", "no-cache, no-store, max-age=0");
        connection.setRequestProperty("Pragma", "no-cache");
        connection.setRequestProperty("Accept", "application/json");
    }

    private static void checkDeadline(Request request) throws java.io.IOException {
        if (request.cancelled || Thread.currentThread().isInterrupted() || SystemClock.elapsedRealtime() - request.started >= DEADLINE_MS)
            throw new java.io.IOException("Request cancelled or expired");
    }

    private void cancel() {
        Request previous = active; active = null;
        if (previous == null) return;
        HttpsURLConnection connection = previous.cancelConnection();
        if (previous.deadline != null) previous.deadline.cancel(false);
        if (previous.task != null) previous.task.cancel(true);
        closeLater(connection);
    }

    private void closeLater(HttpsURLConnection connection) {
        if (connection == null) return;
        try { cleanup.execute(connection::disconnect); }
        catch (java.util.concurrent.RejectedExecutionException closed) {
            // The request worker also disconnects in finally after lifecycle shutdown.
        }
    }

    private void publish() {
        try {
            if (response != null) response = WeatherAlertParser.cache(response.toString(), province, System.currentTimeMillis());
            JSONObject state = new JSONObject().put("native", true).put("province", province)
                .put("alerts", response == null ? new JSONArray() : response.getJSONArray("alerts"))
                .put("updatedAt", response == null ? 0 : response.optLong("updatedAt"))
                .put("truncated", response != null && response.optBoolean("truncated"))
                .put("loading", active != null).put("error", error);
            snapshot = state.toString();
            if (!stopped) web.evaluateJavascript("window.bearWeatherAlertsChanged && window.bearWeatherAlertsChanged("
                + JSONObject.quote(snapshot) + ")", null);
        } catch (Exception ignored) { }
    }

    void resume() {
        if (stopped) return;
        if (!province.isEmpty() && active == null) fetch();
        else publish();
    }

    void destroy() {
        stopped = true; cancel(); worker.shutdownNow(); deadlines.shutdown(); cleanup.shutdown();
    }
}
