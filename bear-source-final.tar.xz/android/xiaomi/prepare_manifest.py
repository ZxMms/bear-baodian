#!/usr/bin/env python3
"""Create the opt-in Xiaomi review manifest; never mutate the normal APK manifest."""
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

A = '{http://schemas.android.com/apk/res/android}'
ET.register_namespace('android', A[1:-1])

def prepare(source, destination):
    tree = ET.parse(source)
    app = tree.getroot().find('application')
    assert app is not None
    ET.SubElement(app, 'meta-data', {A+'name':'miuiWidgetVersion', A+'value':'1'})
    for size, title in [('Small', '重要日子'), ('Large', '今日生活')]:
        receiver = ET.SubElement(app, 'receiver', {A+'name':'.BearMiui'+size+'Widget', A+'label':title,
            A+'process':':widgetProvider', A+'exported':'true'})
        intent = ET.SubElement(receiver, 'intent-filter')
        for action in ['android.appwidget.action.APPWIDGET_UPDATE', 'miui.appwidget.action.APPWIDGET_UPDATE',
                       'android.intent.action.DATE_CHANGED', 'android.intent.action.TIME_SET',
                       'android.intent.action.TIMEZONE_CHANGED', 'android.intent.action.BOOT_COMPLETED',
                       'android.intent.action.MY_PACKAGE_REPLACED']:
            ET.SubElement(intent, 'action', {A+'name':action})
        for name, value in [('miuiWidget','true'), ('miuiWidgetRefresh','exposure'), ('miuiWidgetRefreshMinInterval','60000')]:
            ET.SubElement(receiver, 'meta-data', {A+'name':name, A+'value':value})
        ET.SubElement(receiver, 'meta-data', {A+'name':'android.appwidget.provider',
            A+'resource':'@xml/bear_miui_'+size.lower()+'_widget_info'})
    ET.indent(tree, space='    ')
    tree.write(destination, encoding='utf-8', xml_declaration=True)

if __name__ == '__main__':
    prepare(Path(sys.argv[1]), Path(sys.argv[2]))
