# 小米负一屏适配版本

目标设备：小米 14 Pro，澎湃 OS 3.0.309.0。此处是按小米公开规范实现的**提测版本**，尚无该设备真机验证、35 MB 内存验收或小米审核结果，不能当作已上线的负一屏入口。

普通安装包仍保留现有安卓桌面组件。专用版本通过构建开关增加两种 Provider：

- `BearMiuiSmallWidget`：重要日子，2×2；日期、周几、农历节气、倒计时、心情及记录数，空间不足时逐级收起次要行。
- `BearMiuiLargeWidget`：今日生活，4×4；增加当天安排和记生活、记账、查天气快捷入口。

两种 Provider 均在 `:widgetProvider` 进程刷新，仅读取应用私有 SQLite 展示快照。快照没有完整账本、照片或天气缓存；记录数据不上传。曝光刷新最短间隔 60 秒，不轮询天气、不主动启动主进程。日期与倒计时按刷新时的本地日期计算，缺失当天资料时提示打开应用更新。

布局使用 `@android:id/background`、可伸缩内容、资源级日夜配色；普通桌面组件原有三种浅色不受影响。用户点击时通过显式、不可变 Activity PendingIntent 直达现有页面。此版没有自定义编辑页，也不接入 MI PUSH、优先级排序事件或私有系统接口。

## 构建

先设置 `android/build.sh` 中已有的 Android SDK 与签名环境变量，然后在项目根目录运行：

```bash
BEAR_XIAOMI_WIDGETS=1 bash android/build.sh
```

开关仅生成 `android/build/XiaomiManifest.xml`；不修改普通版本的 Manifest。此提测 APK 使用相同包名和签名，因此会替换已安装的普通版，不是单独的 App。未通过小米测试与审核前，不向用户承诺能在负一屏添加。正式上架后不得移除这些 Provider 或小米标识，组件变动须递增 `miuiWidgetVersion`。

## 剩余上线步骤

1. 按小米要求申请开发者接入和自测环境，确认应用商店发布条件。
2. 在目标系统验证 2K/1080p、不同桌面网格、大字体、日夜切换、跨天、重启、清除数据、备份恢复及入口跳转。
3. 验证独立进程内存/功耗；对照审核规范完善预览图和提交材料。
4. 完成应用商店与小部件平台审核。审核前，正常的小部件中心不会展示该应用的专用卡片。

资料：

- https://dev.mi.com/xiaomihyperos/documentation/detail?pId=1584
- https://dev.mi.com/xiaomihyperos/documentation/detail?pId=1591
- https://dev.mi.com/xiaomihyperos/documentation/detail?pId=1588
