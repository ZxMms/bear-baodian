#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${ANDROID_SDK_ROOT:?Install Android SDK platform 35 and build-tools 35.0.0}"
: "${BEAR_CALENDAR_KEYSTORE:?Set the path to your APK signing keystore}"
: "${BEAR_CALENDAR_STORE_PASSWORD:?Set the signing store password}"
: "${BEAR_CALENDAR_KEY_ALIAS:?Set the signing key alias}"
build_tools="$ANDROID_SDK_ROOT/build-tools/35.0.0"
platform="$ANDROID_SDK_ROOT/platforms/android-35/android.jar"
mkdir -p build/classes build/dex
manifest_path=AndroidManifest.xml
if [[ "${BEAR_XIAOMI_WIDGETS:-0}" == "1" ]]; then
    python3 xiaomi/prepare_manifest.py AndroidManifest.xml build/XiaomiManifest.xml
    manifest_path=build/XiaomiManifest.xml
fi
"$build_tools/aapt2" compile --dir res -o build/resources.zip
"$build_tools/aapt2" link -I "$platform" --manifest "$manifest_path" -A ../web \
    -0 wav -o build/base.apk build/resources.zip
javac --release 17 -classpath "$platform" -d build/classes src/com/xiongxiong/calendar/*.java
jar cf build/classes.jar -C build/classes .
"$build_tools/d8" --min-api 26 --lib "$platform" --output build/dex build/classes.jar
cp build/base.apk build/unsigned.apk
(cd build/dex && zip -q -u ../unsigned.apk classes.dex)
"$build_tools/zipalign" -f 4 build/unsigned.apk build/aligned.apk
"$build_tools/apksigner" sign --ks "$BEAR_CALENDAR_KEYSTORE" --ks-key-alias "$BEAR_CALENDAR_KEY_ALIAS" \
    --ks-pass env:BEAR_CALENDAR_STORE_PASSWORD --out build/bear-calendar.apk build/aligned.apk
"$build_tools/apksigner" verify --verbose build/bear-calendar.apk
