package com.xiongxiong.calendar;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class ShareAlbumCommitTest {
    static final class Fake implements ShareAlbumCommit.Store<String> {
        final List<String> calls = new ArrayList<>();
        final String fail;
        Fake(String fail) { this.fail = fail; }
        public String create() throws Exception { calls.add("create"); if (fail.equals("create")) throw new Exception("create"); return fail.equals("null") ? null : "new-image"; }
        public void write(String item) throws Exception { check(item.equals("new-image")); calls.add("write"); if (fail.equals("write") || fail.equals("cleanup")) throw new Exception("write"); }
        public boolean publish(String item) throws Exception { calls.add("publish"); if (fail.equals("publish-throw")) throw new Exception("publish"); return !fail.equals("publish"); }
        public void remove(String item) throws Exception { check(item.equals("new-image")); calls.add("remove"); if (fail.equals("cleanup")) throw new Exception("cleanup"); }
    }
    static void check(boolean value) { if (!value) throw new AssertionError(); }
    public static void main(String[] args) throws Exception {
        Fake good = new Fake(""); check(ShareAlbumCommit.write(good).equals("new-image")); check(good.calls.equals(Arrays.asList("create","write","publish")));
        for (String failure : new String[]{"create","null","write","publish","publish-throw","cleanup"}) {
            Fake fake = new Fake(failure); Exception caught = null;
            try { ShareAlbumCommit.write(fake); } catch (Exception expected) { caught = expected; }
            check(caught != null);
            if (failure.equals("create") || failure.equals("null")) check(fake.calls.equals(Arrays.asList("create")));
            else { check(fake.calls.get(fake.calls.size()-1).equals("remove")); check(!fake.calls.contains("publish") || fake.calls.indexOf("write") < fake.calls.indexOf("publish")); }
            if (failure.equals("cleanup")) { check(caught.getMessage().equals("write")); check(caught.getSuppressed().length == 1); }
        }
        System.out.println("Passed gallery commit: success, allocation/write/publish failures, cleanup, and preservation of original failure.");
    }
}
