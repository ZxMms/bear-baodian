package com.xiongxiong.calendar;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Exercises the actual production coordinator with deterministic provider, clock and deadline ports. */
public final class LocationSessionTest {
    private static int assertions;
    static void check(boolean value, String message) { assertions++; if (!value) throw new AssertionError(message); }
    private static final class Fixture implements LocationSession.Port, LocationSession.Clock, LocationSession.Scheduler, LocationSession.Observer {
        long now = 3_600_000_000_000L, delay;
        final Map<String, LocationSession.Events> events = new LinkedHashMap<>();
        final List<String> cancelled = new ArrayList<>();
        LocationSession.Fix accepted;
        boolean recent, timerCancelled;
        String throwProvider;
        Runnable timer;
        int acceptanceCount, changes;
        LocationSession session;
        Fixture(String permission, Boolean service, String... providers) {
            this(permission,service,false,providers);
        }
        Fixture(String permission, Boolean service, boolean gpsRetry, String... providers) {
            session = new LocationSession(permission, service, Arrays.asList(providers), gpsRetry, this, this, this, this);
        }
        public LocationSession.Cancel request(String provider, LocationSession.Events listener) {
            if (provider.equals(throwProvider)) throw new IllegalArgumentException("provider unavailable");
            events.put(provider, listener); return () -> cancelled.add(provider);
        }
        public long elapsedNanos() { return now; }
        public LocationSession.Cancel after(long milliseconds, Runnable action) { delay = milliseconds; timer = action; return () -> timerCancelled = true; }
        public void changed(LocationSession state) { changes++; }
        public void accepted(LocationSession.Fix fix, boolean older) { accepted = fix; recent = older; acceptanceCount++; }
        LocationSession.Fix fix(String provider, long ageMs, double accuracy) { return new LocationSession.Fix(31.2, 121.5, accuracy, now - ageMs * 1000000, 1_800_000_000_000L - ageMs, provider); }
        void send(String provider, long age, double accuracy) { events.get(provider).fix(fix(provider, age, accuracy)); }
        void expire() { now += delay * 1000000; timer.run(); }
    }
    public static void main(String[] args) {
        List<String> advertised = Arrays.asList("network", "gps", "passive", "fused");
        HashSet<String> enabled = new HashSet<>(advertised);
        check(LocationSession.chooseProviders(advertised, enabled, false).equals(Arrays.asList("network", "fused")), "coarse does not request Android10 FINE-only GPS/PASSIVE");
        check(LocationSession.chooseProviders(Arrays.asList("network", "gps", "passive"), enabled, false).equals(Arrays.asList("network")), "never probe Android10 internal fused");
        check(LocationSession.chooseProviders(advertised, enabled, true).equals(advertisedOrdered()), "fine uses all advertised enabled sources");
        enabled.remove("network");
        check(LocationSession.chooseProviders(advertised, enabled, true).equals(Arrays.asList("fused", "gps", "passive")), "disabled NETWORK does not imply global service disabled");

        Fixture coarse = new Fixture("approximate", true, "network"); coarse.session.start();
        check(coarse.delay == 10000 && coarse.session.running(), "regular lookup capped at 10 seconds");
        coarse.send("network", 90_000, 15_000);
        check(coarse.accepted != null && !coarse.recent, "90-second coarse 15km live callback is immediately usable");
        check(coarse.session.detail.contains("核对城市"), "wide fix clearly discloses approximate city scope");
        check(coarse.timerCancelled && coarse.cancelled.contains("network"), "accepted fix cancels deadline and provider");
        coarse.send("network", 0, 100);
        check(coarse.acceptanceCount == 1, "late callbacks cannot silently replace chosen location or weather");

        Fixture race = new Fixture("precise", true, "network", "gps"); race.session.start();
        race.events.get("gps").cached(race.fix("gps",1000,6));
        race.send("network",0,25);
        check(race.accepted == null && race.session.running(), "cached GPS and live network cannot win a precise GPS request");
        race.send("gps",60_000,4);
        check(race.accepted == null, "earlier GPS fix delivered via listener is still held back");
        race.send("gps",0,8);
        check(race.accepted != null && "gps".equals(race.accepted.provider) && !race.recent, "new precise GPS wins");
        Fixture noGps = new Fixture("precise",true,true,"network","gps"); noGps.session.start();
        noGps.send("network",0,30);noGps.expire();
        check(noGps.accepted==null && noGps.session.useRecent(true,true) && noGps.recent, "timeout only uses alternate fix with explicit choice");

        Fixture indoor = new Fixture("precise",true,"network","gps"); indoor.session.start();
        indoor.events.get("network").cached(indoor.fix("network",0,2));
        indoor.send("network",0,40);
        check(indoor.accepted==null && indoor.delay==10_000,"GPS has a bounded first chance in regular mode");
        indoor.expire(); check(indoor.accepted!=null && indoor.accepted.accuracyMeters==40 && !indoor.recent,"current live alternative beats even a more precise cached fix");
        indoor.send("gps",0,3);check(indoor.acceptanceCount==1,"late GPS cannot start a second forecast");

        Fixture conflicting = new Fixture("precise",true,"network","gps");conflicting.session.start();
        conflicting.events.get("gps").cached(new LocationSession.Fix(39.86,116.29,20,conflicting.now-5_000_000_000L,1,"gps"));
        conflicting.events.get("network").fix(new LocationSession.Fix(40.22,116.23,40,conflicting.now,2,"network"));
        conflicting.expire();check(conflicting.accepted==null && conflicting.session.usableCandidate(),"Fengtai and Changping disagreement requires a choice");
        Fixture wide = new Fixture("precise",true,"network","gps"); wide.session.start(); wide.send("network",0,700);wide.expire();
        check(wide.accepted==null && wide.session.usableCandidate(),"broad position needs explicit user choice");
        Fixture onlyCache = new Fixture("precise",true,"network","gps"); onlyCache.session.start();
        onlyCache.events.get("network").cached(onlyCache.fix("network",0,40));onlyCache.expire();
        check(onlyCache.accepted==null && onlyCache.session.usableCandidate(),"fresh-looking cached position never triggers automatic fallback");
        Fixture choose = new Fixture("precise",true,"network","gps");choose.session.start();
        choose.events.get("network").cached(choose.fix("network",10_000,40));LocationSession.Fix tapped=choose.session.candidate;
        check(choose.session.reserveCandidate() && !choose.session.running(),"tap candidate while GPS is waiting");
        choose.send("gps",0,5);choose.timer.run();
        check(choose.acceptanceCount==0 && choose.session.candidate==tapped,"in-flight GPS cannot replace tapped candidate during permission check");
        check(choose.session.useRecent(true,true) && choose.accepted==tapped && !choose.session.useRecent(true,true),"confirm exactly one selected candidate");
        Fixture stop = new Fixture("precise",true,"network","gps");stop.session.start();stop.send("network",0,40);stop.session.stopWaiting();
        stop.timer.run();check(stop.acceptanceCount==0 && stop.session.reserveCandidate(),"stop keeps choice without auto-selecting");

        Fixture latest = new Fixture("precise", true, true, "network", "gps", "passive"); latest.session.start();
        check(latest.delay == 35000, "available GPS gets bounded 35-second deadline");
        latest.send("network", 240_000, 10000);
        check(latest.accepted == null && latest.session.usableCandidate(), "2–10 minute fix is only offered, never silently used");
        latest.send("network", 200_000, 12000);
        long newer = latest.session.candidate.elapsedNanos;
        latest.send("passive", 250_000, 10);
        check(latest.session.candidate.elapsedNanos == newer, "newer recent candidate is stable despite older more accurate update");
        latest.send("gps", 0, 12);
        check(latest.accepted.provider.equals("gps") && latest.session.candidate == null, "fresh GPS supersedes pending old candidate before weather begins");
        check(latest.cancelled.size() == 3, "all provider listeners are removed after success");

        Fixture failure = new Fixture("precise", true, "network", "gps"); failure.session.start();
        failure.events.get("network").failed("disabled");
        check(failure.session.running() && failure.session.activeProviders.contains("gps"), "one disabled provider leaves remaining GPS active");
        check(failure.session.failures.get("network").equals("disabled"), "provider failure reason remains diagnostic");
        failure.send("gps", 500, 5);
        check(failure.accepted != null && failure.cancelled.size() == 2, "another provider delivers after isolated failure and both cleaned");
        Fixture throwing = new Fixture("precise", true, "network", "gps"); throwing.throwProvider = "network"; throwing.session.start(); throwing.send("gps", 0, 20);
        check(throwing.accepted != null, "synchronous registration exception does not abort remaining providers");

        Fixture timed = new Fixture("approximate", true, "network"); timed.session.start(); timed.send("network", 180_000, 5000);
        long timestamp = timed.session.candidate.locatedAt;
        timed.expire();
        check("timeout".equals(timed.session.phase) && timed.session.usableCandidate() && timed.accepted == null, "timeout retains older candidate for explicit choice");
        check(timed.session.detail.contains("等待已结束"), "no-fix message does not blame granted permission");
        check(timed.session.useRecent(true, true), "explicit choice accepts validated recent candidate");
        check(timed.recent && timed.accepted.locatedAt == timestamp, "explicit reuse retains real fix timestamp");
        check(!timed.session.useRecent(true, true), "candidate is consumed once");

        Fixture expired = new Fixture("approximate", true, "network"); expired.session.start(); expired.send("network", 590_001, 20); expired.expire();
        check(!expired.session.usableCandidate() && !expired.session.useRecent(true, true), "candidate age revalidated after timeout and on click");
        Fixture denied = new Fixture("approximate", true, "network"); denied.session.start(); denied.send("network", 180_000, 40); denied.expire();
        check(!denied.session.useRecent(false, true) && denied.accepted == null, "revoked permission blocks reuse");
        check(!denied.session.useRecent(true, false) && denied.accepted == null, "disabled device service blocks reuse");

        Fixture cancel = new Fixture("precise", true, "network", "gps"); cancel.session.start(); cancel.send("network", 180_000, 50); cancel.session.cancel();
        cancel.send("gps", 0, 3); cancel.timer.run();
        check(cancel.accepted == null && cancel.session.candidate == null && cancel.cancelled.size() == 2, "new selection/destroy cancellation invalidates candidate, callbacks and timer");

        Fixture invalid = new Fixture("approximate", true, "network"); invalid.session.start();
        invalid.send("network", 0, 0); check("accuracy-missing".equals(invalid.session.lastRejection), "zero accuracy rejected");
        invalid.send("network", 0, Double.NaN); check("accuracy-missing".equals(invalid.session.lastRejection), "missing accuracy diagnosed");
        invalid.send("network", 0, 20001); check("accuracy-wide".equals(invalid.session.lastRejection), "overly wide accuracy diagnosed");
        invalid.send("network", -1, 10); check("future".equals(invalid.session.lastRejection), "future monotonic timestamp rejected");
        invalid.send("network", 600001, 10); check("stale".equals(invalid.session.lastRejection), "ancient location diagnosed");
        invalid.events.get("network").fix(new LocationSession.Fix(Double.NaN, 120, 10, invalid.now, 1, "network"));
        check("coordinates".equals(invalid.session.lastRejection), "invalid coordinates rejected");
        invalid.send("network", 120000, 20000); check(invalid.accepted != null, "exact freshness and city accuracy boundaries accepted");
        check(!LocationRules.current(1,120_000_000_002L,20), "sub-millisecond-over-boundary freshness rejected");
        check(!LocationRules.rejection(new LocationSession.Fix(1,2,1,1,1,"network"),600_000_000_002L).isEmpty(), "sub-millisecond-over-boundary recent fix rejected");

        Fixture off = new Fixture("approximate", false, "network"); off.session.start();
        check("service-off".equals(off.session.status) && off.events.isEmpty(), "global location off distinguished from permission");
        Fixture noProvider = new Fixture("approximate", true); noProvider.session.start();
        check("no-provider".equals(noProvider.session.status) && noProvider.session.detail.contains("GPS"), "coarse-only phone without NETWORK gets explicit precise fallback");
        Fixture unknownService = new Fixture("approximate", null, "network"); unknownService.session.start();
        check(unknownService.session.serviceEnabled == null && unknownService.session.running(), "unknown system switch is not falsely reported on, but available providers may work");
        unknownService.send("network", 0, 500);
        check(unknownService.accepted != null, "unknown switch status does not block a valid provider fix");
        check(LocationRules.districtEligible(5000), "known narrower fix may resolve an exact district");
        check(!LocationRules.districtEligible(5000.01) && !LocationRules.districtEligible(Double.NaN) && !LocationRules.districtEligible(0), "wide or unknown fix cannot resolve a district automatically");
        Fixture noPermission = new Fixture("none", true, "network"); noPermission.session.start();
        check("permission-denied".equals(noPermission.session.status) && noPermission.events.isEmpty(), "denied permission does not request providers");

        LocationPermissionFlow permission = new LocationPermissionFlow();
        check(!LocationPermissionFlow.needsRequest(true,false,false), "default locate never nags coarse user for fine");
        check(LocationPermissionFlow.needsRequest(true,false,true), "GPS action requests fine explicitly");
        check(!permission.enterForeground(), "first Activity resume does not start unsolicited location");
        check(permission.begin() && permission.pending(), "permission flow begins");
        permission.leaveForeground();
        check(permission.pending() && !permission.foreground(), "Activity pause leaves permission request valid but not foreground");
        check(permission.resolve(true,false) == LocationPermissionFlow.Result.DEFERRED, "approximate-only grant while paused queues rather than locating in background");
        check(permission.enterForeground(), "actual Activity resume starts the queued coarse query");
        check(!permission.enterForeground(), "duplicate Activity resume cannot restart consumed permission flow");
        check("approximate".equals(LocationPermissionFlow.permission(true,false)), "denied fine never reported precise");
        permission.begin(); permission.cancel();
        check(!permission.pending() && permission.dialogOpen() && !permission.begin(), "switch city during dialog prevents a second overlapping permission request");
        check(permission.resolve(true,true) == LocationPermissionFlow.Result.IGNORED, "cancelled dialog result cannot restore old location task");
        check(permission.begin() && permission.resolve(false,true) == LocationPermissionFlow.Result.READY, "fresh request after cancelled callback can use fine");
        permission.begin(); check(permission.resolve(false,false) == LocationPermissionFlow.Result.DENIED, "both denied cannot start location");
        check(permission.resolve(true,true) == LocationPermissionFlow.Result.IGNORED, "unsolicited permission callback cannot start location");
        permission.begin(); check(permission.resolve(true,false) == LocationPermissionFlow.Result.READY, "denied fine with coarse still starts foreground network lookup");
        permission.begin(); permission.leaveForeground();
        check(permission.resolve(true,true) == LocationPermissionFlow.Result.DEFERRED, "pressing Home during permission dialog cannot start background GPS");
        permission.cancel(); check(!permission.enterForeground(), "city switch/disable cancels deferred authorized lookup before resume");
        System.out.println("Location coordinator and permission flow: " + assertions + " assertions passed");
    }
    static List<String> advertisedOrdered() { return Arrays.asList("network", "fused", "gps", "passive"); }
}
