package com.xiongxiong.calendar;

public final class CookingRingingRulesTest {
    private static int assertions;
    private static void check(boolean value,String note){assertions++;if(!value)throw new AssertionError(note);}
    private static void message(boolean notifications,boolean sound,int volume,int filter,boolean exact,String expected){
        check(CookingTimerRules.healthMessage(notifications,sound,volume,filter,exact).contains(expected),expected);
    }
    private static void action(int attempts,String state,long remaining,long now,long retryAt,int posted,CookingTimerRules.DeliveryAction expected,String note){
        check(CookingTimerRules.deliveryAction(attempts,state,remaining,now,retryAt,posted)==expected,note);
    }
    public static void main(String[] args){
        check(CookingTimerRules.validId(CookingTimerRules.TEST_ID),"isolated test ID is valid");
        check(CookingTimerRules.durationMillis(5)==5000,"five-second test duration");
        message(false,true,5,1,true,"通知未开启");
        message(true,false,5,1,true,"当前为静音");
        message(true,true,0,1,true,"闹钟音量为 0");
        message(true,true,0,4,true,"闹钟音量为 0");
        message(true,true,5,3,true,"完全勿扰");
        message(true,true,5,2,true,"取决于系统");
        message(true,true,5,4,true,"通知与闹钟音量可用");
        message(true,true,5,1,true,"通知与闹钟音量可用");
        message(true,true,5,1,false,"可能延迟");
        message(true,true,-1,1,true,"暂未读到");
        // No speculative retries: only attempts already made, and no late alarms.
        check(!CookingTimerRules.retryDelivery(0,0),"no retry before a confirmed attempt");
        check(!CookingTimerRules.retryDelivery(-1,0),"negative count rejected");
        check(CookingTimerRules.retryDelivery(1,0),"first confirmed failure can retry");
        check(CookingTimerRules.retryDelivery(2,-5000),"second confirmed failure can retry");
        check(!CookingTimerRules.retryDelivery(3,-10000),"three attempts total maximum");
        check(!CookingTimerRules.retryDelivery(4,-10000),"over-limit failure stays terminal");
        check(CookingTimerRules.retryDelivery(1,-15000),"15-second boundary inclusive");
        check(!CookingTimerRules.retryDelivery(1,-15001),"late retry expires");
        check(!CookingTimerRules.retryDelivery(1,1),"future deadline not a retry");
        check(CookingTimerRules.DELIVERY_RETRY_MS==5000,"polls respect five-second backoff");
        action(0,"",0,1000,0,0,CookingTimerRules.DeliveryAction.ATTEMPT,"initial deadline may post");
        action(1,"retrying",-1000,2000,6000,0,CookingTimerRules.DeliveryAction.WAIT,"foreground polling cannot bypass backoff");
        action(1,"retrying",-5000,6000,6000,0,CookingTimerRules.DeliveryAction.ATTEMPT,"first confirmed failure retries at boundary");
        action(2,"retrying",-10000,11000,11000,0,CookingTimerRules.DeliveryAction.ATTEMPT,"second confirmed failure retries");
        action(3,"retrying",-15000,16000,16000,0,CookingTimerRules.DeliveryAction.FAILED,"third failure is terminal");
        action(1,"retrying",-15001,20000,6000,0,CookingTimerRules.DeliveryAction.FAILED,"doze-delayed retries expire");
        action(1,"posting",-1,1001,0,1,CookingTimerRules.DeliveryAction.POSTED,"notify succeeded but save failed acknowledges active notification");
        action(1,"posting",-31000,32000,0,0,CookingTimerRules.DeliveryAction.UNCONFIRMED,"expired delivered notification cannot ring again after crash");
        action(1,"posting",-1,1001,0,0,CookingTimerRules.DeliveryAction.UNCONFIRMED,"crash between persist and notify never speculates");
        action(1,"retrying",-5000,6000,6000,-1,CookingTimerRules.DeliveryAction.UNCONFIRMED,"unreadable notification status cannot trigger duplicate");
        action(1,"retrying",-5000,6000,6000,1,CookingTimerRules.DeliveryAction.POSTED,"concurrent accepted delivery is acknowledged");
        action(1,"",-5000,6000,0,0,CookingTimerRules.DeliveryAction.UNCONFIRMED,"only confirmed failure state may retry");
        System.out.println("Cooking ringing rules: "+assertions+" assertions passed");
    }
}
