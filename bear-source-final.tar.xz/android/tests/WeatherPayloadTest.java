package com.xiongxiong.calendar;

import java.lang.reflect.Method;
import org.json.JSONObject;

/** Runs the controller's real decoding boundaries with desktop org.json and Android stubs. */
public final class WeatherPayloadTest {
    private static int assertions;
    private static void check(boolean value, String note) { assertions++; if (!value) throw new AssertionError(note); }
    private static Object call(String name, Class<?>[] types, Object... arguments) throws Exception {
        Method method = WeatherController.class.getDeclaredMethod(name, types);
        method.setAccessible(true);
        return method.invoke(null, arguments);
    }
    private static boolean valid(JSONObject data) throws Exception { return (boolean)call("validWeather", new Class<?>[]{JSONObject.class}, data); }
    private static Object wind(JSONObject current, JSONObject units, String field, boolean direction) throws Exception {
        return call("wind", new Class<?>[]{JSONObject.class, JSONObject.class, String.class, boolean.class}, current, units, field, direction);
    }
    public static void main(String[] args) throws Exception {
        JSONObject weather = new JSONObject().put("temperature", 12.5).put("code", 3).put("isDay", true).put("updatedAt", System.currentTimeMillis());
        check(valid(weather), "received temperature remains displayable when wind fields are absent");
        check(WeatherRefreshRules.canStart(false,true,true,false,false,false,false), "opening weather with an area always requests the source");
        weather.put("windSpeed", JSONObject.NULL);
        check(WeatherRefreshRules.canStart(false,true,true,false,false,false,false), "next completed entry has no successful-result cooldown");
        check(!valid(new JSONObject()), "empty response cannot become a weather card");
        check(!valid(new JSONObject(weather.toString()).put("temperature", "NaN")), "malformed response temperature rejected");
        check(!valid(new JSONObject(weather.toString()).put("temperature", 200)), "impossible response temperature rejected");
        check(!valid(new JSONObject(weather.toString()).put("code", -1)), "invalid response condition rejected");
        check(!valid(new JSONObject(weather.toString()).put("isDay", "true")), "string flag does not count as a day state");
        check(!valid(new JSONObject(weather.toString()).put("updatedAt", 0)), "undated weather response rejected");
        check(!WeatherRefreshRules.canStart(false,false,true,false,false,false,false), "background UI callback cannot trigger a foreground request");
        JSONObject values = new JSONObject().put("wind_speed_10m", 3.8).put("wind_gusts_10m", 12.2).put("wind_direction_10m", 360);
        JSONObject units = new JSONObject().put("wind_speed_10m", "m/s").put("wind_gusts_10m", "m/s").put("wind_direction_10m", "°");
        check(((Number)wind(values, units, "wind_speed_10m", false)).doubleValue() == 3.8, "speed decoded in explicitly requested m/s");
        check(((Number)wind(values, units, "wind_gusts_10m", false)).doubleValue() == 12.2, "gusts decoded independently of sustained wind");
        check(((Number)wind(values, units, "wind_direction_10m", true)).intValue() == 360, "north direction decoded");
        check(wind(values, null, "wind_speed_10m", false) == JSONObject.NULL, "unknown units cannot be displayed as m/s");
        units.put("wind_speed_10m", "km/h");
        check(wind(values, units, "wind_speed_10m", false) == JSONObject.NULL, "mismatched units cannot silently triple displayed speed");
        units.put("wind_speed_10m", "m/s"); values.put("wind_speed_10m", JSONObject.NULL);
        check(wind(values, units, "wind_speed_10m", false) == JSONObject.NULL, "missing wind stays unavailable, never a calm forecast");
        values.put("wind_speed_10m", 0);
        check(((Number)wind(values, units, "wind_speed_10m", false)).doubleValue() == 0, "actual zero remains calm wind");
        values.put("wind_gusts_10m", -2);
        check(wind(values, units, "wind_gusts_10m", false) == JSONObject.NULL, "corrupt gust does not spoil otherwise valid temperature");
        values.put("wind_direction_10m", 361);
        check(wind(values, units, "wind_direction_10m", true) == JSONObject.NULL, "out of range bearing suppressed");
        JSONObject domestic = new JSONObject(weather.toString()).put("provider", "nmc").put("code", -1).put("observedAt", System.currentTimeMillis());
        check(valid(domestic), "official missing sky condition keeps valid temperature, never invented sunshine");
        check(!WeatherRefreshRules.canStart(true,true,true,false,false,false,false), "destroyed controller cannot request weather");
        check(!WeatherRefreshRules.canStart(false,true,false,false,false,false,false), "no selected place cannot request an invented area");
        check(!WeatherRefreshRules.canStart(false,true,true,true,false,false,false), "simultaneous open and resume share the in-flight request");
        check(!valid(new JSONObject(weather.toString()).put("code", -1)), "unknown sky code is accepted only for explicit official provider");
        check("nmc:A1234".equals(call("key", new Class<?>[]{JSONObject.class}, new JSONObject().put("nmcCode", "A1234"))), "official city without coordinates has stable selected-area identity");
        check("3990:11640".equals(call("key", new Class<?>[]{JSONObject.class}, new JSONObject().put("latitude",39.9).put("longitude",116.4).put("nmcCode","54511"))), "adding official metadata preserves an existing coordinate selected-area identity");
        JSONObject chosen = new JSONObject().put("latitude",39.9).put("longitude",116.4).put("source","city").put("name","北京").put("admin1","北京市").put("countryCode","CN");
        check((boolean)call("sameSelection",new Class<?>[]{JSONObject.class,JSONObject.class},chosen,new JSONObject(chosen.toString())), "identical in-flight selection may be deduplicated");
        check(!(boolean)call("sameSelection",new Class<?>[]{JSONObject.class,JSONObject.class},chosen,new JSONObject(chosen.toString()).put("nmcCode","54511")), "same coordinate upgrade to domestic source supersedes old request");
        check(!(boolean)call("sameSelection",new Class<?>[]{JSONObject.class,JSONObject.class},chosen,new JSONObject(chosen.toString()).put("source","location")), "same coordinates with new selection source must not be overwritten by old callback");
        long modelNow = java.time.Instant.parse("2026-11-18T08:10:00Z").toEpochMilli();
        JSONObject model = new JSONObject().put("utc_offset_seconds",28800).put("current",new JSONObject().put("time","2026-11-18T16:00"));
        check((long)call("modelObservedAt",new Class<?>[]{JSONObject.class,long.class},model,modelNow)==modelNow-600000, "model timestamp respects response UTC offset");
        for(String time:new String[]{"2026-11-18T12:00","2026-11-18T17:00"}) {
            model.getJSONObject("current").put("time",time); boolean rejected=false;
            try{call("modelObservedAt",new Class<?>[]{JSONObject.class,long.class},model,modelNow);}catch(java.lang.reflect.InvocationTargetException failure){rejected="STALE_DATA".equals(failure.getCause().getMessage());}
            check(rejected,"stale or future fallback observation cannot be downloaded into freshness");
        }
        long checkedNow = System.currentTimeMillis();
        check(!WeatherRefreshRules.canStart(false,true,true,false,true,false,false), "page opening cannot interrupt a permission dialog");
        check(!WeatherRefreshRules.canStart(false,true,true,false,false,true,false), "page opening cannot replace a fresh location request with saved coordinates");
        check(!WeatherRefreshRules.canStart(false,true,true,false,false,false,true), "recent-location confirmation completes before querying its weather");
        JSONObject oldStation = new JSONObject(domestic.toString()).put("nmcCode", "Wqsps").put("observedAt", checkedNow - 120000L).put("placeKey", "3990:11640");
        Class<?>[] observationTypes = new Class<?>[]{JSONObject.class, JSONObject.class};
        check("revised".equals(call("observationOutcome", observationTypes, oldStation, new JSONObject(oldStation.toString()).put("temperature", 15))), "same source timestamp with corrected temperature is a revision, not a later observation");
        check("same".equals(call("observationOutcome", observationTypes, oldStation, new JSONObject(oldStation.toString()).put("updatedAt", checkedNow + 1))), "same observed content remains same despite a different network check timestamp");
        check("same".equals(call("observationOutcome", observationTypes, oldStation, new JSONObject(oldStation.toString()).put("isDay", !oldStation.getBoolean("isDay")))), "derived sunrise/sunset display does not claim an observation revision");
        check("revised".equals(call("observationOutcome", observationTypes, oldStation, new JSONObject(oldStation.toString()).put("windPower", "3级"))), "wind corrections at identical publication time are applied");
        check("older".equals(call("observationOutcome", observationTypes, oldStation, new JSONObject(oldStation.toString()).put("observedAt", checkedNow - 180000L))), "same-station regression is detected");
        check("new".equals(call("observationOutcome", observationTypes, oldStation, new JSONObject(oldStation.toString()).put("observedAt", checkedNow - 60000L))), "later station observation is new");
        check("new".equals(call("observationOutcome", observationTypes, oldStation, new JSONObject(oldStation.toString()).put("nmcCode", "RfjCI").put("observedAt", checkedNow - 180000L))), "new district with older report must not retain the old station temperature");
        check("source-changed".equals(call("observationOutcome", observationTypes, oldStation, new JSONObject(oldStation.toString()).put("provider", "open-meteo").put("observedAt", checkedNow - 180000L))), "models and station observations change source without claiming a later observation");
        JSONObject modelObservation = new JSONObject(oldStation.toString()).put("provider", "open-meteo");
        check("older".equals(call("observationOutcome", observationTypes, modelObservation, new JSONObject(modelObservation.toString()).put("observedAt", checkedNow - 180000L))), "same model grid response cannot regress time");
        check("new".equals(call("observationOutcome", observationTypes, modelObservation, new JSONObject(modelObservation.toString()).put("placeKey", "3000:11000").put("observedAt", checkedNow - 180000L))), "different grid accepts its own weather without comparing old location time");
        check("new".equals(call("observationOutcome", observationTypes, null, oldStation)), "first downloaded observation is new");
        check("new".equals(call("observationOutcome", observationTypes, new JSONObject(), oldStation)), "previous in-memory result lacking publication identity cannot block a new response");
        System.out.println("Weather payload boundaries: " + assertions + " assertions passed");
    }
}
