package com.xiongxiong.calendar;

import java.nio.file.Files;
import java.nio.file.Path;
import org.json.JSONArray;
import org.json.JSONObject;

/** Executes the shipped matcher against the bundled official directory. */
public final class NmcCitiesTest {
    static int checks;
    static void check(boolean value, String label) { checks++; if (!value) throw new AssertionError(label); }
    static JSONObject clone(JSONObject value) throws Exception { return new JSONObject(value.toString()); }
    static void code(JSONObject value, String expected, String label) { check(value != null && expected.equals(value.optString("nmcCode")), label); }
    static JSONObject legacy(String name, double lat, double lon) throws Exception { return new JSONObject().put("name",name).put("source","city").put("latitude",lat).put("longitude",lon); }
    public static void main(String[] args) throws Exception {
        Path file = Path.of(args.length == 0 ? "bear-calendar/web/nmc-cities.json" : args[0]);
        String raw = Files.readString(file);
        JSONObject asset = new JSONObject(raw);
        NmcCities cities = new NmcCities(raw);
        JSONArray rows = asset.getJSONArray("cities");
        check(rows.length() == 2522, "all 2522 official directory rows loaded");
        check(asset.getJSONArray("provinces").length() == 31, "all mainland provinces included");
        int coordinates = 0;
        for (int i=0; i<rows.length(); i++) {
            JSONObject row = rows.getJSONObject(i), result = cities.canonical(row.getString("code"));
            check(result != null, "every code resolves");
            check(result.getString("name").equals(row.getString("city")), "city name preserved");
            check(result.getString("admin1").equals(row.getString("province")), "province preserved");
            check(result.getString("countryCode").equals("CN"), "catalogue country scope preserved");
            check(result.getString("sourceUrl").equals("https://www.nmc.cn" + row.getString("url")), "verified official source link preserved");
            check(result.has("latitude") == row.has("latitude") && result.has("longitude") == row.has("longitude"), "no invented coordinates");
            if (row.has("latitude")) {
                coordinates++;
                check(result.getDouble("latitude") == row.getDouble("latitude") && result.getDouble("longitude") == row.getDouble("longitude"), "verified coordinates unchanged");
            }
        }
        check(coordinates == 8, "only eight verified popular cities have coordinates");
        check(cities.canonical("unknown") == null && cities.canonical(null) == null, "unknown codes unavailable");
        String[] popular={"Wqsps","WwcJd","DwzZf","AhpEU","RfjCI","yGYHR","HIieJ","bSpCz"};
        for(String id:popular)check(cities.canonical(id).has("latitude"),"popular station has verified coordinate");
        code(cities.search("西安").getJSONObject(0),"RfjCI","exact Chinese city ranks first");
        code(cities.search("  西安市  ").getJSONObject(0),"RfjCI","city suffix and whitespace normalize");
        code(cities.search("XI'AN").getJSONObject(0),"RfjCI","pinyin and apostrophe match exact city");
        code(cities.search("shanghai").getJSONObject(0),"WwcJd","pinyin search works offline");
        check(cities.search(null).length()==0 && cities.search("   ").length()==0, "blank queries do not return every city");
        check(cities.search("广东").length() <= 40, "broad query bounded");
        check(cities.search("x".repeat(81)).length()==0,"oversized query rejected");
        code(cities.resolve("陕西省","西安"),"RfjCI","full province exact resolution");
        code(cities.resolve("陕西","西安市"),"RfjCI","short province resolution");
        code(cities.resolve("Shaanxi","西安"),"RfjCI","English province resolution");
        check(cities.resolve("Shanxi","西安")==null,"Shanxi is not Shaanxi");
        check(cities.resolve("广东省","西安")==null,"mismatched province not accepted");
        check(cities.resolve("","西安")==null && cities.resolve("陕西省","")==null,"missing province/name not guessed");
        check(cities.resolve(null,null)==null,"null lookup safe");
        JSONObject explicit = new JSONObject().put("countryCode","CN").put("admin1","陕西省").put("name","西安");
        code(cities.fromPlace(explicit),"RfjCI","Chinese selected city resolves");
        check(cities.fromPlace(clone(explicit).put("countryCode","US"))==null,"foreign country rejected");
        check(cities.fromPlace(new JSONObject().put("countryCode","CN").put("name","西安"))==null,"CN without province not guessed");
        JSONObject old = legacy("西安",34.26,108.94);
        code(cities.fromPlace(old),"RfjCI","legacy popular city migrated from explicit selection");
        check(cities.fromPlace(clone(old).put("countryCode","US"))==null,"legacy foreign country blocked");
        check(cities.fromPlace(clone(old).put("source","location"))==null,"GPS coordinate never inferred as a city");
        check(cities.fromPlace(clone(old).put("latitude",40).put("longitude",-75))==null,"same name with foreign coordinates blocked");
        check(cities.fromPlace(clone(old).put("latitude",35.0))==null,"legacy position beyond tolerance blocked");
        check(cities.fromPlace(clone(old).put("name","西安市"))==null,"legacy migration requires exact original popular name");
        check(cities.fromPlace(legacy("咸阳",34.3,108.7))==null,"nonpopular city without verified coordinates not guessed");
        check(cities.fromPlace(null)==null,"null saved place safe");
        JSONObject exported=cities.canonical("RfjCI");exported.put("name","tampered").put("latitude",0);
        code(cities.canonical("RfjCI"),"RfjCI","canonical lookup remains intact after caller mutation");
        check(cities.canonical("RfjCI").getString("name").equals("西安") && cities.canonical("RfjCI").getDouble("latitude")==34.3,"canonical returns defensive copy");
        cities.search("西安").getJSONObject(0).put("name","changed");
        check(cities.resolve("陕西省","西安").getString("name").equals("西安"),"search result cannot mutate trusted catalogue");
        JSONObject a=clone(rows.getJSONObject(0)).put("code","AAAaa").put("city","测试县"), b=clone(a).put("code","BBBbb");
        NmcCities ambiguous=new NmcCities(new JSONObject().put("cities",new JSONArray().put(a).put(b)).toString());
        check(ambiguous.resolve(a.getString("province"),"测试县")==null,"ambiguous county names require explicit choice");
        code(ambiguous.canonical("AAAaa"),"AAAaa","explicit ID resolves an ambiguous name");
        boolean rejected=false;
        try { new NmcCities(new JSONObject().put("cities",new JSONArray().put(clone(a).put("url","https://evil.example/city"))).toString()); }
        catch(Exception expected){rejected=true;}
        check(rejected,"external catalogue URL rejected");
        System.out.println("NMC city catalogue/matcher: " + checks + " checks passed over " + rows.length() + " official cities");
    }
}
