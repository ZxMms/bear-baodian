package com.xiongxiong.calendar;

import java.nio.file.Files;
import java.nio.file.Path;
import org.json.JSONObject;
import org.json.JSONArray;

public final class DistrictWeatherTest {
    private static int checks;
    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
        checks++;
    }
    public static void main(String[] args) throws Exception {
        JSONObject polygons = new JSONObject(Files.readString(Path.of("web/beijing-districts.json")));
        BeijingDistricts bj = new BeijingDistricts(polygons);
        check(polygons.length() == 16, "all Beijing districts present");
        check("丰台区".equals(bj.district(39.8586,116.2868,12,150)), "Fengtai center");
        check("昌平区".equals(bj.district(40.2200,116.2300,15,150)), "Changping center");
        check("".equals(bj.district(39.8586,116.2868,9000,150)), "broad accuracy never claims a district");
        check(bj.district(34.26,108.94,10,150) == null, "outside Beijing has no result");
        JSONArray pt = polygons.getJSONArray("丰台区").getJSONArray(0).getJSONArray(0).getJSONArray(0);
        String edge = bj.district(pt.getDouble(1),pt.getDouble(0),100,150);
        check(edge == null || edge.isEmpty(), "district boundary suppresses unconfirmed district");
        JSONObject area = new JSONObject().put("city","北京市").put("district","丰台区");
        check("北京市 · 丰台区".equals(WeatherController.locationName(area,"北京市")), "full location heading");
        check(!WeatherController.locationName(area.put("district",""),"北京市").contains("昌平"), "unknown district never becomes station name");
        JSONObject legacy = new JSONObject().put("source","location").put("name","昌平附近").put("nmcCode","niStC").put("latitude",39.86).put("longitude",116.29).put("alertArea",area);
        check(WeatherController.clearLegacyDistrict(legacy) && !legacy.has("alertArea") && !legacy.has("nmcCode") && legacy.has("latitude"),"upgrade clears stale district and station before new fix");
        check(!WeatherController.clearLegacyDistrict(new JSONObject().put("source","city").put("name","昌平")),"manual choices stay manual");
        JSONObject partial = new JSONObject().put("code",-1).put("conditionText","").put("temperature",8);
        check(WeatherController.needsModel(partial), "partial primary response requests alternate source");
        check(WeatherController.needsModel(null), "failed primary response requests alternate source");
        check(!WeatherController.needsModel(new JSONObject(partial.toString()).put("code",0)), "real sunny code avoids extra request");
        check(!WeatherController.needsModel(new JSONObject(partial.toString()).put("conditionText","扬沙")), "station reporting dust stays intact");
        JSONObject station = new JSONObject().put("nmcCode","WgwUa").put("name","丰台").put("admin1","北京市");
        String response = new JSONObject().put("code",0).put("data",new JSONArray()
            .put("qzDwS|凤台|安徽省|/AAH/fengtai.html|116.76|32.71")
            .put("niStC|昌平|北京市|/ABJ/changping.html|116.21|40.22")
            .put("WgwUa|丰台|北京市|/ABJ/fengtai.html|116.24|39.87")).toString();
        check(WeatherController.stationPoint(station,response).getDouble("latitude")==39.87, "homophones do not change coordinates");
        check(WeatherController.stationPoint(station.put("admin1","安徽省"),response)==null, "wrong province rejected");
        if (args.length == 3) {
            JSONObject primary = new JSONObject(Files.readString(Path.of(args[0])));
            long now = Long.parseLong(args[2]);
            JSONObject observation = NmcWeatherData.parse(primary.toString(),primary.getJSONObject("station").getString("code"),now);
            JSONObject model = WeatherController.modelReport(new JSONObject(Files.readString(Path.of(args[1]))),now);
            check(WeatherRules.knownSky(model.getInt("code")), "live fallback sky code recognized");
            System.out.println("Live station="+observation.getString("city")+" primarySky="+observation.optString("conditionText")+" needsFallback="+WeatherController.needsModel(observation)+" modelCode="+model.getInt("code")+" modelTime="+model.getString("observedTime"));
        }
        System.out.println(checks+" district and weather checks passed");
    }
}
