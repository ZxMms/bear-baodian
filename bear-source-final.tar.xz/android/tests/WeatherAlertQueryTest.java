package com.xiongxiong.calendar;

import java.io.IOException;
import java.net.URL;
import java.security.cert.Certificate;
import java.util.concurrent.atomic.AtomicInteger;
import javax.net.ssl.HttpsURLConnection;
import org.json.JSONArray;
import org.json.JSONObject;

/** Exercises the exact production pagination loop and HTTP request configuration. */
public final class WeatherAlertQueryTest {
    static int assertions;
    static final String PROVINCE = "浙江省";
    static final long NOW = WeatherAlertParser.issueTime("2026/11/18 18:00");
    static void check(boolean value, String message) { assertions++; if (!value) throw new AssertionError(message); }
    static JSONObject row(int id) throws Exception {
        return new JSONObject().put("alertid", String.format(java.util.Locale.ROOT, "33010041600000_20261118%06d", id))
            .put("title", "浙江省杭州市气象台发布霜冻蓝色预警信号").put("issuetime", "2026/11/18 17:00");
    }
    static String page(int number, int pages, int count, int start, int length) throws Exception {
        JSONArray rows = new JSONArray(); for (int i=0; i<length; i++) rows.put(row(start+i));
        return new JSONObject().put("code", 0).put("data", new JSONObject().put("page", new JSONObject()
            .put("pageNo", number).put("pageSize",100).put("totalPage",pages).put("count",count).put("list",rows))
            .put("provinceAlarms",new JSONArray().put(new JSONObject().put("alertid","33000041600000_20261118170000")
                .put("title","浙江省气象台发布霜冻蓝色预警信号").put("issuetime","2026/11/18 17:00")))).toString();
    }
    static class FakeConnection extends HttpsURLConnection {
        FakeConnection() throws Exception { super(new URL("https://www.nmc.cn/rest/findAlarm")); }
        public void connect() { }
        public void disconnect() { }
        public boolean usingProxy() { return false; }
        public String getCipherSuite() { return "TLS_FAKE"; }
        public Certificate[] getLocalCertificates() { return null; }
        public Certificate[] getServerCertificates() { return null; }
    }
    public static void main(String[] args) throws Exception {
        AtomicInteger reads=new AtomicInteger(), progress=new AtomicInteger();
        JSONObject full=WeatherAlertParser.query(PROVINCE,NOW,n->{reads.incrementAndGet(); return page(n,2,110,(n-1)*100,n==1?100:10);},partial->{
            progress.incrementAndGet(); check(partial.getBoolean("truncated"),"in-flight pages never claim completion");
        });
        check(reads.get()==2 && progress.get()==2,"all required pages fetched exactly once");
        check(full.getJSONArray("alerts").length()==111,"county results beyond first 20 retained and province row deduplicated");
        check(!full.getBoolean("truncated"),"two complete pages are not partial");
        check(!full.optBoolean("partialFailure"),"successful full query has no network failure");

        JSONObject partial=WeatherAlertParser.query(PROVINCE,NOW,n->{if(n==2)throw new IOException("offline"); return page(1,2,110,0,100);},p->{});
        check(partial.getJSONArray("alerts").length()==101,"second-page failure keeps newly received data");
        check(partial.getBoolean("truncated") && partial.getBoolean("partialFailure"),"second-page failure disclosed as partial");
        try { WeatherAlertParser.query(PROVINCE,NOW,n->{throw new IOException("offline");},p->{}); throw new AssertionError("first failure succeeded"); }
        catch(IOException expected) { assertions++; }

        JSONObject duplicated=WeatherAlertParser.query(PROVINCE,NOW,n->page(n,2,110,0,n==1?100:10),p->{});
        check(duplicated.getBoolean("truncated"),"moving feed with missing unique rows is disclosed");
        check(duplicated.getJSONArray("alerts").length()==101,"overlapping pages never duplicate cards");

        reads.set(0);
        JSONObject bounded=WeatherAlertParser.query(PROVINCE,NOW,n->{reads.incrementAndGet();return page(n,8,716,(n-1)*100,100);},p->{});
        check(reads.get()==5,"bounded to five requests");
        check(bounded.getJSONArray("alerts").length()==500 && bounded.getBoolean("truncated"),"bounded results are capped and labelled incomplete");

        JSONObject wrongPage=WeatherAlertParser.query(PROVINCE,NOW,n->page(1,2,110,0,100),p->{});
        check(wrongPage.getBoolean("partialFailure") && wrongPage.getBoolean("truncated"),"server repeating first page cannot masquerade as complete pagination");
        JSONObject malformedLater=WeatherAlertParser.query(PROVINCE,NOW,n->n==1?page(1,2,110,0,100):"bad json",p->{});
        check(malformedLater.getBoolean("partialFailure"),"malformed later pages preserve partial disclaimer");
        JSONObject badNumbers=new JSONObject(page(1,1,1,0,1));
        badNumbers.getJSONObject("data").getJSONObject("page").put("count","1");
        try { WeatherAlertParser.page(badNumbers.toString(),PROVINCE,NOW); throw new AssertionError("bad count succeeded"); }
        catch(IllegalArgumentException expected) { assertions++; }

        FakeConnection connection=new FakeConnection(); WeatherAlerts.configure(connection);
        check(!connection.getUseCaches(),"HTTP local cache disabled");
        check(connection.getRequestProperty("Cache-Control").contains("no-store"),"HTTP result not stored");
        check(connection.getRequestProperty("Cache-Control").contains("no-cache"),"HTTP source revalidation requested");
        check("no-cache".equals(connection.getRequestProperty("Pragma")),"legacy HTTP cache bypass");
        check(!connection.getInstanceFollowRedirects(),"source redirects remain disabled");
        check(connection.getConnectTimeout()==4500 && connection.getReadTimeout()==4500,"each transfer retains bounded timeout");
        check("application/json".equals(connection.getRequestProperty("Accept")),"JSON content requested");
        check(WeatherAlertParser.cache(full.toString(),PROVINCE,NOW).getJSONArray("alerts").length()==111,"in-memory validation retains complete pages");
        System.out.println("Weather alert query: " + assertions + " assertions passed");
    }
}
