package com.xiongxiong.calendar;

import org.json.JSONObject;

public final class NmcWeatherDataTest {
    static int checks;
    static void check(boolean yes, String message) { checks++; if (!yes) throw new AssertionError(message); }
    static JSONObject fixture() throws Exception {
        return new JSONObject("{\"station\":{\"code\":\"Wqsps\",\"province\":\"北京市\",\"city\":\"北京\",\"url\":\"/publish/forecast/ABJ/beijing.html\"},\"publish_time\":\"2026-11-18 15:05\",\"weather\":{\"temperature\":7.1,\"info\":\"-\",\"img\":\"9999\"},\"wind\":{\"direct\":\"西北风\",\"degree\":271,\"power\":\"微风\",\"speed\":3.3},\"sunriseSunset\":{\"sunrise\":\"2026-11-18 07:01\",\"sunset\":\"2026-11-18 16:56\"}}");
    }
    interface Throwing { void run() throws Exception; }
    static void rejected(Throwing call, String message) throws Exception {
        try { call.run(); } catch (Exception rejected) { check(true, message); return; }
        throw new AssertionError(message);
    }
    public static void main(String[] args) throws Exception {
        long now = NmcWeatherData.chinaTime("2026-11-18 15:30");
        JSONObject data = NmcWeatherData.parse(fixture().toString(), "Wqsps", now);
        check(data.getDouble("temperature") == 7.1, "temperature is current observation");
        check(data.getInt("code") == -1, "9999 must not become sunny");
        check(data.getString("conditionText").isEmpty(), "missing condition stays missing");
        check(data.getBoolean("isDay"), "actual sunrise and sunset mark daylight");
        check(data.getString("windDirectionText").equals("西北风"), "source direction label retained");
        check(data.getString("windPower").equals("微风"), "published wind power retained");
        check(data.isNull("windSpeed"), "no assumed numeric wind units");
        check(data.isNull("windGust"), "no fabricated gust");
        check(data.getLong("observedAt") == NmcWeatherData.chinaTime("2026-11-18 15:05"), "source time independent from retrieval");
        check(data.getLong("updatedAt") == now, "fetch timestamp retained");
        check(data.getString("provider").equals("nmc"), "actual provider marked");
        check(data.getString("sourceUrl").equals("https://www.nmc.cn/publish/forecast/ABJ/beijing.html"), "official source detail link");
        rejected(() -> NmcWeatherData.parse(fixture().toString(), "RfjCI", now), "wrong city rejected");
        rejected(() -> NmcWeatherData.parse("{\"code\":0,\"data\":\"\"}", "Wqsps", now), "empty provider success rejected");
        JSONObject stale=fixture().put("publish_time","2026-11-18 12:00");
        rejected(() -> NmcWeatherData.parse(stale.toString(), "Wqsps", now), "old observation rejected");
        JSONObject future=fixture().put("publish_time","2026-11-18 15:36");
        rejected(() -> NmcWeatherData.parse(future.toString(), "Wqsps", now), "future observation rejected");
        JSONObject invalid=fixture();invalid.getJSONObject("weather").put("temperature",9999);
        rejected(() -> NmcWeatherData.parse(invalid.toString(), "Wqsps", now), "sentinel temperature rejected");
        JSONObject strings=fixture();strings.getJSONObject("weather").put("temperature","7.1");
        rejected(() -> NmcWeatherData.parse(strings.toString(), "Wqsps", now), "schema drift rejected");
        JSONObject zero=fixture();zero.getJSONObject("weather").put("temperature",0);
        check(NmcWeatherData.parse(zero.toString(),"Wqsps",now).getDouble("temperature")==0,"real zero temperature accepted");
        JSONObject missingWind=fixture().put("wind",JSONObject.NULL);
        check(NmcWeatherData.parse(missingWind.toString(),"Wqsps",now).isNull("windDirection"),"missing wind accepted independently");
        check(NmcWeatherData.chinaTime("2026-02-30 12:00")<0,"impossible date rejected");
        check(NmcWeatherData.chinaTime("2026-11-18 15:05junk")<0,"trailing date junk rejected");
        check(NmcWeatherData.chinaTime("2026-11-18 15:05") == 1794985500000L,"China time converted to UTC millis");
        check(!NmcWeatherData.dayAt(fixture().getJSONObject("sunriseSunset"),NmcWeatherData.chinaTime("2026-11-18 17:00")),"sunset boundary wins over generic6to18");
        check(!NmcWeatherData.dayAt(null,NmcWeatherData.chinaTime("2026-11-18 20:00")),"missing sunset uses China night not hosttimezone");
        check(NmcWeatherData.sourceUrl("//evil.example/a").equals("https://www.nmc.cn/publish/forecast.html"),"untrusted absolute link rejected");
        check(NmcWeatherData.sourceUrl("/publish/forecast/ABJ/../../evil.html").equals("https://www.nmc.cn/publish/forecast.html"),"traversal link rejected");
        check(NmcWeatherData.windPower("3级").equals("3级"),"wind force value accepted");
        check(NmcWeatherData.windPower("3~4级").equals("3~4级"),"wind force range accepted");
        check(NmcWeatherData.windPower("9999").isEmpty(),"sentinel force omitted");
        check(NmcWeatherData.directionText("<script>").isEmpty(),"direction injection rejected");
        check(NmcWeatherData.weatherCode("0")==0,"explicit clear mapsclear");
        check(NmcWeatherData.weatherCode("7")==61,"source light rain mapsrain");
        check(NmcWeatherData.weatherCode("14")==71,"source light snow mapssnow");
        check(NmcWeatherData.weatherCode("53")==-1,"unrecognized condition not guessed");
        System.out.println("NMC current observation parser: " + checks + " checks passed");
    }
}
