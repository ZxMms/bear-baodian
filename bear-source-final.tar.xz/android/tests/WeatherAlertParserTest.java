package com.xiongxiong.calendar;

import org.json.JSONArray;
import org.json.JSONObject;

public final class WeatherAlertParserTest {
    private static int checks;
    private static final String PROVINCE = "四川省";
    private static final long NOW = WeatherAlertParser.issueTime("2026/11/18 15:00");
    private static void check(boolean result) { checks++; if (!result) throw new AssertionError("case " + checks); }
    private static JSONObject row(String id, String time, String title) throws Exception {
        return new JSONObject().put("alertid", id).put("issuetime", time).put("title", title)
            .put("url", "https://attacker.invalid/do-not-use");
    }
    private static JSONObject good(String suffix, String time) throws Exception {
        return row("51332841600000_20261118" + suffix, time, "四川省甘孜县气象台发布大风黄色预警信号");
    }
    private static JSONObject feed(JSONArray rows) throws Exception {
        return new JSONObject().put("code", 0).put("data", new JSONObject().put("page", new JSONObject()
            .put("list", rows).put("count", rows.length()).put("totalPage", 1)).put("provinceAlarms", new JSONArray()));
    }
    private static JSONObject parse(JSONObject feed) throws Exception { return WeatherAlertParser.parse(feed.toString(), PROVINCE, NOW); }
    private static void rejected(String text) throws Exception {
        try { WeatherAlertParser.parse(text, PROVINCE, NOW); throw new AssertionError("Unexpected success"); }
        catch (AssertionError failure) { throw failure; }
        catch (Exception expected) { checks++; }
    }
    public static void main(String[] args) throws Exception {
        check(NOW == 1794985200000L); // 15:00 China time is 07:00 UTC, independent of host timezone.
        check(WeatherAlertParser.PROVINCES.length == 31);
        check(!WeatherAlertParser.supported("四川"));
        check(!WeatherAlertParser.supported(""));
        check(WeatherAlertParser.issueTime("2026/02/30 12:00") == -1);
        check(WeatherAlertParser.issueTime("2026/11/18 24:00") == -1);
        check(WeatherAlertParser.issueTime("2026/11/18 12:00 trailing") == -1);
        check(WeatherAlertParser.officialUrl("../../bad") == null);
        check(WeatherAlertParser.officialUrl("51332841600000_20261118141633?x=1") == null);

        JSONObject one = good("141633", "2026/11/18 14:16");
        JSONObject parsed = parse(feed(new JSONArray().put(one)));
        JSONArray alerts = parsed.getJSONArray("alerts");
        check(alerts.length() == 1);
        check(alerts.getJSONObject(0).getString("level").equals("yellow"));
        check(alerts.getJSONObject(0).getString("url").equals("https://www.nmc.cn/publish/alarm/51332841600000_20261118141633.html"));
        check(parsed.getLong("updatedAt") == NOW);
        check(!parsed.getBoolean("truncated"));

        JSONObject duplicate = feed(new JSONArray().put(one).put(good("100000", "2026/11/18 10:00")));
        duplicate.getJSONObject("data").getJSONArray("provinceAlarms").put(one)
            .put(row("51000041600000_20261118143000", "2026/11/18 14:30", "四川省气象台发布大风蓝色预警"));
        JSONArray merged = parse(duplicate).getJSONArray("alerts");
        check(merged.length() == 3);
        check(merged.getJSONObject(0).getString("level").equals("blue"));
        check(merged.getJSONObject(2).getLong("issuedAt") == WeatherAlertParser.issueTime("2026/11/18 10:00"));

        check(parse(feed(new JSONArray())).getJSONArray("alerts").length() == 0);
        check(parse(feed(new JSONArray().put(good("141633", "2026/11/17 14:59")))).getJSONArray("alerts").length() == 0);
        check(parse(feed(new JSONArray().put(good("141633", "2026/11/17 15:00")))).getJSONArray("alerts").length() == 1);
        JSONObject partial = parse(feed(new JSONArray().put(one).put("invalid")));
        check(partial.getBoolean("truncated"));
        check(partial.getJSONArray("alerts").length() == 1);

        rejected("not JSON");
        rejected("{\"code\":0,\"data\":{\"page\":{}}}");
        rejected(feed(new JSONArray()).put("code", 500).toString());
        rejected(feed(new JSONArray()).put("code", "0").toString());
        rejected(feed(new JSONArray().put("invalid")).toString());
        rejected(feed(new JSONArray().put(good("141633", "2026/11/17 14:59")).put("invalid recent row")).toString());
        rejected(feed(new JSONArray().put(row("11011241600000_20261118100000", "2026/11/18 10:00", "北京市发布大风蓝色预警"))).toString());
        rejected(feed(new JSONArray().put(row("11011241600000_20261118100000", "2026/11/18 10:00", "四川省发布大风蓝色预警"))).toString());
        rejected(feed(new JSONArray().put(good("141633", "2026/11/19 12:00"))).toString());
        JSONObject missing = feed(new JSONArray()); missing.getJSONObject("data").getJSONObject("page").put("count", 5); rejected(missing.toString());
        JSONObject badProvinceRows = feed(new JSONArray()); badProvinceRows.getJSONObject("data").put("provinceAlarms", "changed schema"); rejected(badProvinceRows.toString());

        JSONArray many = new JSONArray();
        for (int index = 0; index < 25; index++) many.put(good(String.format(java.util.Locale.ROOT, "%06d", index), "2026/11/18 10:00"));
        JSONObject limited = parse(feed(many));
        check(limited.getJSONArray("alerts").length() == 25);
        check(!limited.getBoolean("truncated"));
        JSONObject paged = feed(new JSONArray().put(one)); paged.getJSONObject("data").getJSONObject("page").put("totalPage", 2);
        check(parse(paged).getBoolean("truncated"));

        JSONObject cached = WeatherAlertParser.cache(parsed.toString(), PROVINCE, NOW + 3600000L);
        check(cached != null && cached.getJSONArray("alerts").length() == 1);
        check(WeatherAlertParser.cache(parsed.toString(), "北京市", NOW) == null);
        check(WeatherAlertParser.cache(parsed.toString(), PROVINCE, NOW - 600000L) == null);
        check(WeatherAlertParser.cache(parsed.toString(), PROVINCE, NOW + WeatherAlertParser.WINDOW_MS).getJSONArray("alerts").length() == 0);
        check(WeatherAlertParser.cache("{broken", PROVINCE, NOW) == null);
        parsed.getJSONArray("alerts").getJSONObject(0).put("url", "https://attacker.invalid/");
        check(WeatherAlertParser.cache(parsed.toString(), PROVINCE, NOW).getJSONArray("alerts").getJSONObject(0).getString("url").startsWith("https://www.nmc.cn/publish/alarm/"));
        System.out.println("Passed " + checks + " official release parser checks: strict China time, 24-hour window, province scope, safe source URLs, errors, deduplication, truncation and in-memory revalidation.");
    }
}
