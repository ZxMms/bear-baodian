import com.xiongxiong.calendar.ReminderTime;
import java.time.Instant;
import java.time.ZoneId;

public class ReminderTimeTest {
    private static int assertions;
    private static void same(Object actual, Object expected) {
        assertions++;
        if (!java.util.Objects.equals(actual, expected)) throw new AssertionError(actual + " != " + expected);
    }
    private static long at(String utc) { return Instant.parse(utc).toEpochMilli(); }
    public static void main(String[] args) {
        ZoneId shanghai = ZoneId.of("Asia/Shanghai");
        ReminderTime.Occurrence day = ReminderTime.next("2026-11-17", "09:00", false, 0, at("2026-11-16T00:00:00Z"), shanghai, "");
        same(day.at, at("2026-11-17T01:00:00Z"));
        same(day.date, "2026-11-17");
        same(ReminderTime.next("2026-11-15", "09:00", false, 0, at("2026-11-16T00:00:00Z"), shanghai, ""), null);
        ReminderTime.Occurrence early = ReminderTime.next("2027-01-01", "09:00", false, 7, at("2026-11-16T00:00:00Z"), shanghai, "");
        same(early.at, at("2026-12-25T01:00:00Z"));
        same(early.date, "2027-01-01");
        ReminderTime.Occurrence leap = ReminderTime.next("2024-02-29", "08:30", true, 1, at("2026-11-16T00:00:00Z"), shanghai, "");
        same(leap.date, "2028-02-29");
        same(leap.at, at("2028-02-28T00:30:00Z"));
        // Century years without a leap day must be skipped as well.
        same(ReminderTime.next("2024-02-29", "09:00", true, 0, at("2097-01-01T00:00:00Z"), shanghai, "").date, "2104-02-29");
        same(ReminderTime.next("2020-11-16", "09:00", true, 1, at("2026-11-16T00:00:00Z"), shanghai, "").date, "2027-11-16");
        // Reboot / duplicate delivery must not notify an occurrence a second time.
        same(ReminderTime.next("2020-11-16", "09:00", true, 0, at("2026-11-15T00:00:00Z"), shanghai, "2026-11-16").date, "2027-11-16");
        same(ReminderTime.next("2026-11-17", "09:00", false, 0, at("2026-11-16T00:00:00Z"), shanghai, "2026-11-17"), null);
        // Before the first anniversary, no prior-year occurrence can be invented.
        same(ReminderTime.next("2030-05-12", "09:00", true, 0, at("2026-11-16T00:00:00Z"), shanghai, "").date, "2030-05-12");
        // A calendar day across DST is not always 24 hours.
        same(ReminderTime.next("2027-03-15", "09:00", false, 1, at("2027-03-01T00:00:00Z"), ZoneId.of("America/New_York"), "").at, at("2027-03-14T13:00:00Z"));
        same(ReminderTime.next("2027-03-14", "02:30", false, 0, at("2027-03-01T00:00:00Z"), ZoneId.of("America/New_York"), "").at, at("2027-03-14T07:30:00Z"));
        same(ReminderTime.next("2026-11-17", "09:00", false, 0, at("2026-11-17T01:00:00Z"), shanghai, "").at, at("2026-11-17T01:00:00Z"));
        boolean rejected = false;
        try { ReminderTime.next("2026-11-17", "09:00", false, 2, 0, shanghai, ""); }
        catch (IllegalArgumentException expected) { rejected = true; }
        same(rejected, true);
        java.util.List<String> empty = java.util.Collections.emptyList();
        same(ReminderTime.next("2026-01-31", "09:00", "monthly", 31, "last", "official", empty, 0, at("2026-02-01T00:00:00Z"), shanghai, "").date, "2026-02-28");
        same(ReminderTime.next("2026-01-31", "09:00", "monthly", 31, "skip", "official", empty, 0, at("2026-02-01T00:00:00Z"), shanghai, "").date, "2026-03-31");
        same(ReminderTime.next("2026-01-31", "09:00", "monthly", 31, "last", "official", empty, 0, at("2028-02-01T00:00:00Z"), shanghai, "").date, "2028-02-29");
        same(ReminderTime.next("2026-11-26", "09:00", "monthly", 25, "last", "official", empty, 0, at("2026-11-16T00:00:00Z"), shanghai, "").date, "2026-12-25");
        // Advance reminders can fall in the previous month and must not duplicate after reboot.
        same(ReminderTime.next("2026-01-01", "09:00", "monthly", 1, "last", "official", empty, 7, at("2026-11-23T00:00:00Z"), shanghai, "").at, at("2026-11-24T01:00:00Z"));
        same(ReminderTime.next("2026-01-01", "09:00", "monthly", 25, "last", "official", empty, 0, at("2026-11-24T00:00:00Z"), shanghai, "2026-11-25").date, "2026-12-25");
        java.util.List<String> official = java.util.Arrays.asList("2027-01-31", "2027-02-26");
        same(ReminderTime.next("2026-01-01", "09:00", "last-workday", 1, "last", "official", official, 0, at("2027-01-01T00:00:00Z"), shanghai, "").date, "2027-01-31");
        same(ReminderTime.next("2026-01-01", "09:00", "last-workday", 1, "last", "official", official, 0, at("2027-03-01T00:00:00Z"), shanghai, ""), null);
        same(ReminderTime.next("2026-01-01", "09:00", "last-workday", 1, "last", "weekdays", empty, 0, at("2027-01-01T00:00:00Z"), shanghai, "").date, "2027-01-29");
        same(ReminderTime.next("2026-01-01", "09:00", "last-workday", 1, "last", "weekdays", empty, 0, at("2030-01-01T00:00:00Z"), shanghai, "").date, "2030-01-31");
        same(ReminderTime.next("2026-01-01", "09:00", "monthly", 15, "last", "weekdays", empty, 1, at("2027-03-01T00:00:00Z"), ZoneId.of("America/New_York"), "").at, at("2027-03-14T13:00:00Z"));
        System.out.println("Passed " + assertions + " reminder calendar assertions");
    }
}
