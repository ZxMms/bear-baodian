package com.xiongxiong.calendar;

public final class CookingRingtoneRulesTest {
    private static int assertions;
    private static final String PACKAGE="com.xiongxiong.calendar";
    private static void check(boolean value,String note){assertions++;if(!value)throw new AssertionError(note);}
    private static String builtin(String uri){return CookingTimerRules.builtinSoundName(uri,PACKAGE,123,456);}
    private static void kind(String uri,boolean defaultSound,String expected){
        check(expected.equals(CookingTimerRules.soundKind(uri,builtin(uri),defaultSound)),"kind for "+uri);
    }
    public static void main(String[] args){
        check("加加加短铃声".equals(builtin("android.resource://"+PACKAGE+"/raw/bear_cooking_alarm")),"exact bundled MP3 name");
        check("熊熊提醒音".equals(builtin("android.resource://"+PACKAGE+"/raw/bear_reminder")),"old WAV keeps its own name");
        check("加加加短铃声".equals(builtin("android.resource://"+PACKAGE+"/123")),"numeric cooking resource URI");
        check("熊熊提醒音".equals(builtin("android.resource://"+PACKAGE+"/456")),"numeric legacy resource URI");
        check(builtin("android.resource://other.app/raw/bear_cooking_alarm").isEmpty(),"another app must not impersonate bundled sound");
        check(builtin("android.resource://"+PACKAGE+"/raw/other_sound").isEmpty(),"unknown bundled asset stays unknown");
        check(builtin("android.resource://"+PACKAGE+"/raw/bear_cooking_alarm_extra").isEmpty(),"resource match is exact");
        check(CookingTimerRules.builtinSoundName("android.resource://"+PACKAGE+"/0",PACKAGE,0,0).isEmpty(),"missing resource ID cannot match zero");
        check(builtin(null).isEmpty(),"silent URI is safe");
        check(builtin("%%% bad").isEmpty(),"invalid URI is safe");
        kind("android.resource://"+PACKAGE+"/raw/bear_cooking_alarm",false,"builtin");
        kind(null,false,"silent");
        kind("",false,"silent");
        kind("content://settings/system/notification_sound",true,"system");
        kind("content://media/internal/audio/media/35",false,"system");
        kind("content://media/internal/audio/media/35?title=Morning",false,"system");
        kind("content://media/external/audio/media/35",false,"custom");
        kind("content://media/external_primary/audio/media/35",false,"custom");
        kind("file:///storage/emulated/0/Notifications/铃声.mp3",false,"custom");
        kind("content://com.vendor.sounds/ringtone/35",false,"unknown");
        kind("content://media.fake/internal/audio/media/35",false,"unknown");
        kind("content://media/internal/audio/media_extra/35",false,"unknown");
        kind("%%% bad",false,"unknown");
        check("加加加短铃声".equals(CookingTimerRules.soundName("builtin","加加加短铃声","bear_cooking_alarm")),"bundled title overrides raw filename");
        check("无声".equals(CookingTimerRules.soundName("silent","","Old name")),"silence cannot show stale sound title");
        check("Morning".equals(CookingTimerRules.soundName("system","","  Morning  ")),"system sound keeps human title");
        check("默认（Morning）".equals(CookingTimerRules.soundName("system","","默认（Morning）")),"default symbolic title preserved");
        check("我的铃声".equals(CookingTimerRules.soundName("custom","","我的铃声")),"custom title preserved without file permission");
        check("Vendor bell".equals(CookingTimerRules.soundName("unknown","","Vendor bell")),"unknown provider can still expose a title");
        check("系统铃声".equals(CookingTimerRules.soundName("system","",null)),"unreadable system title fallback");
        check("自定义铃声".equals(CookingTimerRules.soundName("custom","","")),"unreadable custom title fallback");
        check("暂未读到铃声名称".equals(CookingTimerRules.soundName("unknown","","")),"unknown title never claims a bundled sound");
        check(CookingTimerRules.soundName("system","","a".repeat(200)).length()==100,"long system title is bounded");
        System.out.println("Cooking ringtone rules: "+assertions+" assertions passed");
    }
}
