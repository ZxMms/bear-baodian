package com.xiongxiong.calendar;

import java.time.LocalDate;
import java.time.Instant;
import java.time.ZoneId;

public final class WidgetAndCookingRulesTest {
    private static int assertions;
    private static void equal(Object expected, Object actual) {
        assertions++;
        if (!expected.equals(actual)) throw new AssertionError("Expected " + expected + ", got " + actual);
    }
    private static void rejects(int seconds) {
        assertions++;
        try { CookingTimerRules.durationMillis(seconds); }
        catch (IllegalArgumentException expected) { return; }
        throw new AssertionError("Invalid duration was accepted: " + seconds);
    }
    public static void main(String[] args) {
        LocalDate today = LocalDate.of(2026, 11, 17);
        equal("11月17日 · 周二", WidgetContent.dateLabel(today));
        equal("11月22日 · 周日", WidgetContent.dateLabel(LocalDate.of(2026, 11, 22)));
        equal("就是今天", WidgetContent.countdown("2026-11-17", today));
        equal("还有 1 天", WidgetContent.countdown("2026-11-18", today));
        equal("已过 1 天", WidgetContent.countdown("2026-11-16", today));
        equal("还有 2 天", WidgetContent.countdown("2028-03-01", LocalDate.of(2028, 2, 28)));
        equal("还有 1 天", WidgetContent.countdown("2027-01-01", LocalDate.of(2026, 12, 31)));
        equal("打开挑一个重要日子", WidgetContent.countdown("not-a-date", today));
        equal("今天", WidgetContent.compactCountdown("2026-11-17",today));
        equal("1天后", WidgetContent.compactCountdown("2026-11-18",today));
        equal("1天前", WidgetContent.compactCountdown("2026-11-16",today));
        equal("待设置", WidgetContent.compactCountdown("broken",today));
        equal(0,WidgetContent.recordCount(-2));
        equal(9999,WidgetContent.recordCount(10000));
        equal(3,WidgetContent.recordCount(3));
        equal("十月初九 · 立冬时节",WidgetContent.dayLabel("十月初九","立冬时节",false));
        equal("农历 十月初九 · 立冬时节",WidgetContent.dayLabel("十月初九","立冬时节",true));
        equal("立冬时节",WidgetContent.dayLabel("","立冬时节",true));
        equal("农历 十月初九",WidgetContent.dayLabel("十月初九","",true));
        equal("打开更新农历与节气",WidgetContent.dayLabel(null,null,false));
        equal("开心 · 3条",WidgetContent.daySummary("开心",3,false));
        equal("心情待记录 · 0 条记录",WidgetContent.daySummary(null,-1,true));
        equal("平静 · 9999 条记录",WidgetContent.daySummary("平静",99999,true));
        equal("中文姓名", WidgetContent.clean(" \u0000中文姓名\t ", 10));
        equal("三月工资…", WidgetContent.clean("三月工资到账", 5));
        equal("", WidgetContent.clean(null, 10));
        equal(2, WidgetContent.upcomingIndex(new String[]{"2026-12-30", "2026-11-16", "2026-11-30"}, today));
        equal(1, WidgetContent.upcomingIndex(new String[]{"2026-11-30", "2026-11-17"}, today));
        equal(1, WidgetContent.upcomingIndex(new String[]{null, "2026-11-30", "broken"}, today));
        equal(-1, WidgetContent.upcomingIndex(new String[]{"2026-10-30", "2026-11-16"}, today));
        equal(1, WidgetContent.upcomingIndex(new String[]{"2026-11-30", "2026-12-31"}, LocalDate.of(2026, 12, 1)));
        equal("cream", WidgetContent.widgetTheme(null));
        equal("cream", WidgetContent.widgetTheme(""));
        equal("cream", WidgetContent.widgetTheme("night"));
        equal("cream", WidgetContent.widgetTheme("invalid"));
        equal("cream", WidgetContent.widgetTheme("cream"));
        equal("peach", WidgetContent.widgetTheme("peach"));
        equal("mint", WidgetContent.widgetTheme("mint"));
        // Minimum supported sizes still show normal-sized metadata and one agenda
        // line. Enlarged system text removes lower-priority rows instead of clipping.
        WidgetContent.Layout small=WidgetContent.layout(110,false,14,14,17,14,15);
        equal(true,small.compact);equal(true,small.lunar);equal(true,small.summary);equal(false,small.agenda);
        WidgetContent.Layout large=WidgetContent.layout(180,true,14,14,17,14,15);
        equal(true,large.lunar);equal(true,large.summary);equal(true,large.agenda);equal(1,large.agendaLines);
        WidgetContent.Layout roomy=WidgetContent.layout(260,true,14,14,17,14,15);
        equal(false,roomy.compact);equal(4,roomy.agendaLines);
        WidgetContent.Layout smallLargeType=WidgetContent.layout(110,false,28,26,34,26,30);
        equal(true,smallLargeType.lunar);equal(false,smallLargeType.summary);
        WidgetContent.Layout largeLargeType=WidgetContent.layout(180,true,28,26,34,28,30);
        equal(true,largeLargeType.lunar);equal(false,largeLargeType.summary);equal(false,largeLargeType.agenda);
        WidgetContent.Layout expandedLargeType=WidgetContent.layout(300,true,28,26,34,28,30);
        equal(true,expandedLargeType.summary);equal(true,expandedLargeType.agenda);
        WidgetContent.Layout extraLargeType=WidgetContent.layout(110,false,42,39,51,42,45);
        equal(true,extraLargeType.compact);equal(false,extraLargeType.lunar);equal(false,extraLargeType.summary);
        ZoneId shanghai = ZoneId.of("Asia/Shanghai");
        equal(Instant.parse("2028-02-29T16:00:00Z"), WidgetContent.nextBoundary(Instant.parse("2028-02-29T15:59:00Z"), shanghai));
        equal(Instant.parse("2026-11-17T16:00:00Z"), WidgetContent.nextBoundary(Instant.parse("2026-11-16T21:59:00Z"), shanghai));
        equal(Instant.parse("2026-11-17T16:00:00Z"), WidgetContent.nextBoundary(Instant.parse("2026-11-17T10:59:00Z"), shanghai));
        equal(Instant.parse("2026-11-17T16:00:00Z"), WidgetContent.nextBoundary(Instant.parse("2026-11-17T11:00:00Z"), shanghai));
        // DST transition must choose local midnight, not assume a day always has 24 hours.
        equal(Instant.parse("2026-03-09T04:00:00Z"), WidgetContent.nextBoundary(Instant.parse("2026-03-09T00:00:00Z"), ZoneId.of("America/New_York")));
        equal(true, CookingTimerRules.validId("recipe_168-abc"));
        equal(false, CookingTimerRules.validId("../../other"));
        equal(false, CookingTimerRules.validId(null));
        equal(1000L, CookingTimerRules.durationMillis(1));
        equal(86400000L, CookingTimerRules.durationMillis(86400));
        rejects(0); rejects(-1); rejects(86401); rejects(Integer.MAX_VALUE);
        // Ten seconds left remains ten seconds even if the wall clock jumps backwards or forwards.
        equal(10000L, CookingTimerRules.remaining(500000, 60000, 4, 4, 0, 50000));
        equal(10000L, CookingTimerRules.remaining(500000, 60000, 4, 4, 900000, 50000));
        equal(-1000L, CookingTimerRules.remaining(500000, 60000, 4, 4, 499000, 61000));
        // Reboot discards the prior boot's elapsed clock and restores against the saved end date.
        equal(1000L, CookingTimerRules.remaining(500000, 60000, 4, 5, 499000, 1000));
        equal(1000L, CookingTimerRules.remaining(500000, 60000, -1, -1, 499000, 1000));
        equal(true, CookingTimerRules.shouldNotify(0));
        equal(true, CookingTimerRules.shouldNotify(-CookingTimerRules.DAY));
        equal(false, CookingTimerRules.shouldNotify(1));
        equal(false, CookingTimerRules.shouldNotify(-CookingTimerRules.DAY - 1));
        System.out.println("Widget and cooking timer rules: " + assertions + " assertions passed");
    }
}
