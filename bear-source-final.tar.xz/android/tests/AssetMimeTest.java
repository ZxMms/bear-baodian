package com.xiongxiong.calendar;

import java.nio.file.Files;
import java.nio.file.Path;

/** An asset that works on an HTTP preview must also be accepted by Android. */
public final class AssetMimeTest {
    public static void main(String[] args) throws Exception {
        if (!"audio/mpeg".equals(AssetMime.type("/assets/cooking-alarm.mp3")))
            throw new AssertionError("Bundled timer preview must be served as MP3, not 404");
        if (!"audio/wav".equals(AssetMime.type("/assets/tap.wav")))
            throw new AssertionError("Existing WAV effects must remain supported");
        if (AssetMime.type(null) != null || AssetMime.type("/private.db") != null)
            throw new AssertionError("Unknown resources must remain unsupported");
        Path web = Path.of(args.length == 0 ? "web" : args[0]);
        int count = 0;
        try (var paths = Files.walk(web)) {
            for (Path file : paths.filter(Files::isRegularFile).toList()) {
                String relative = "/" + web.relativize(file).toString().replace('\\', '/');
                if (!relative.matches("/(?:assets/|ocr/)?[A-Za-z0-9_.-]+") || relative.contains("..") || AssetMime.type(relative) == null)
                    throw new AssertionError("Android cannot serve bundled asset: " + relative);
                count++;
            }
        }
        System.out.println("Android WebView asset MIME: all " + count + " bundled files supported; MP3/WAV and unknown-type checks passed.");
    }
}
