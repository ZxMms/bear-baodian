package com.xiongxiong.calendar;
import java.util.Arrays;
public final class GallerySelectionTest {
    private static int assertions;
    private static void check(boolean value){assertions++;if(!value)throw new AssertionError("check "+assertions);}
    public static void main(String[] args){
        GallerySelection multi=new GallerySelection(5);
        for(String key:Arrays.asList("a","b","c","d","e"))check(multi.toggle(key));
        check(!multi.toggle("f"));check(multi.size()==5);check(multi.number("f")==0);
        check(multi.toggle("b"));check(multi.number("c")==2);check(multi.toggle("f"));
        check(multi.values().equals(Arrays.asList("a","c","d","e","f")));
        GallerySelection rest=new GallerySelection(2);check(rest.toggle("a"));check(rest.toggle("b"));check(!rest.toggle("c"));
        GallerySelection cover=new GallerySelection(1);check(cover.toggle("a"));check(cover.toggle("b"));check(cover.values().equals(Arrays.asList("b")));check(cover.toggle("b"));check(cover.size()==0);
        multi.restore(Arrays.asList("c","c","b","a","e","f","g"));check(multi.values().equals(Arrays.asList("c","b","a","e","f")));
        multi.retain(Arrays.asList("a","b","c"));check(multi.values().equals(Arrays.asList("c","b","a")));check(multi.number("a")==3);
        multi.values().clear();check(multi.size()==3);check(!multi.toggle(null));check(!multi.toggle(""));
        check(new GallerySelection(90).limit==5);check(new GallerySelection(0).limit==1);
        System.out.println("Passed "+assertions+" gallery checks: limits, remaining slots, single-cover replacement, order, restore, duplicates, revoked access.");
    }
}
