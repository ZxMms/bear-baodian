package com.xiongxiong.calendar;
public final class RecipeLinksTest {
    static int count;
    static void check(boolean result){count++;if(!result)throw new AssertionError("case "+count);}
    public static void main(String[] args){
        for(String link:new String[]{"https://xhslink.cn/o/6h4iE3fU9LQ","http://xhslink.com/a/test","https://www.xiaohongshu.com/explore/id?xsec_token=a%2Bb&source=share"}){java.net.URI uri=RecipeLinks.webUri(link);check(uri!=null);check("com.xingin.xhs".equals(RecipeLinks.preferredPackage(uri)));check(link.equals(uri.toString()));}
        check(RecipeLinks.webUri("https://example.com/future-format?a=1")!=null);
        check(RecipeLinks.preferredPackage(RecipeLinks.webUri("https://xiaohongshu.com.example.com/"))==null);
        for(String bad:new String[]{null,"javascript:alert(1)","file:///private/data","intent://anything","https://user@xhslink.cn/a","not a url"})check(RecipeLinks.webUri(bad)==null);
        System.out.println("Passed "+count+" link checks: cn/com short URLs, query preservation, preferred XHS package and web fallback.");
    }
}
