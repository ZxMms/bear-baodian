package com.xiongxiong.calendar;

import org.json.JSONArray;
import org.json.JSONObject;

/** Runs the exact geocoder-to-alert metadata rules without an Android location service. */
public final class WeatherAlertAreaTest {
    private static int checks;
    private static void check(boolean ok, String note) { checks++; if (!ok) throw new AssertionError(note); }
    private static JSONObject row(String code, String city, String province) throws Exception {
        return new JSONObject().put("code", code).put("city", city).put("province", province).put("url", "/publish/forecast/TEST/" + code + ".html");
    }
    private static JSONObject area(NmcCities cities, JSONObject station, String country, String admin, String locality, String subAdmin, String subLocality, double accuracy) {
        return WeatherAlertArea.fromGeocoder(cities, station, country, admin, locality, subAdmin, subLocality, accuracy);
    }
    public static void main(String[] args) throws Exception {
        JSONArray rows = new JSONArray().put(row("XIANN", "西安", "陕西省")).put(row("YANTA", "雁塔", "陕西省"))
            .put(row("XIANY", "咸阳", "陕西省")).put(row("XINGP", "兴平", "陕西省"))
            .put(row("BEIJI", "北京", "北京市")).put(row("CHAOY", "朝阳", "北京市"))
            .put(row("HENAN", "郑州", "河南省")).put(row("LIAON", "朝阳", "辽宁省"))
            .put(row("DUPLA", "重名", "陕西省")).put(row("DUPLB", "重名", "陕西省"));
        NmcCities cities = new NmcCities(new JSONObject().put("cities", rows).toString());
        JSONObject station = cities.resolve("陕西省", "雁塔区");
        JSONObject a = area(cities, station, "CN", "陕西省", "西安市", "西安市", "雁塔区", 800);
        check(a != null && "陕西省".equals(a.getString("province")), "province is the canonical station province");
        check("西安市".equals(a.getString("city")) && "雁塔区".equals(a.getString("district")), "same geocoder city's and district's original suffixes retained");
        check("geocoder".equals(a.getString("source")), "source explicitly identified");
        check(a.optBoolean("districtUnique"), "district has explicit same-province unique match evidence");
        check(!station.has("alertArea"), "helper never mutates shared catalogue row");
        a = area(cities, station, "CN", "Shaanxi", "西安市", null, "雁塔区", 5000);
        check(a != null && "雁塔区".equals(a.getString("district")), "canonical province aliases and exact 5 km boundary supported");
        a = area(cities, station, "CN", "陕西省", "西安市", null, "雁塔区", 5000.01);
        check(a != null && a.getString("district").isEmpty() && "西安市".equals(a.getString("city")), "broad location keeps only city");
        check(!a.has("districtUnique"), "no district evidence flag on city-only metadata");
        a = area(cities, station, "CN", "陕西省", "西安市", null, "雁塔区", Double.NaN);
        check(a != null && a.getString("district").isEmpty(), "unknown accuracy never becomes district certainty");
        check(area(cities, station, "US", "陕西省", "西安市", null, "雁塔区", 100) == null, "foreign address cannot produce domestic scope");
        check(area(cities, station, "CN", "河南省", "郑州市", null, null, 100) == null, "mismatched geocoder province rejected");
        check(area(cities, null, "CN", "陕西省", "西安市", null, "雁塔区", 100) == null, "missing uniquely resolved station gives no inferred area");
        a = area(cities, station, "CN", "陕西省", null, null, "雁塔区", 100);
        check(a != null && a.getString("city").isEmpty() && "雁塔区".equals(a.getString("district")), "district can remain without invented parent city");
        check(area(cities, station, "CN", "陕西省", null, null, "雁塔区", 6000) == null, "wide district-only address does not infer city");
        check(area(cities, station, "CN", "陕西省", "未核实市", null, "未核实区", 100) == null, "unrecognized names do not leak into trusted metadata");
        check(area(cities, station, "CN", "陕西省", null, null, "重名区", 100) == null, "ambiguous directory names rejected");
        a = area(cities, station, "CN", "陕西省", "西安市", "西安市", "西安市", 100);
        check(a != null && a.getString("district").isEmpty(), "city repeated in sublocality is not a district");
        a = area(cities, cities.resolve("陕西省", "兴平市"), "CN", "陕西省", "兴平市", "咸阳市", null, 100);
        check(a != null && "咸阳市".equals(a.getString("city")) && "兴平市".equals(a.getString("district")), "county-level city preserves provided parent hierarchy");
        a = area(cities, cities.resolve("北京市", "朝阳区"), "cn", "北京市", "朝阳区", null, null, 100);
        check(a != null && "北京市".equals(a.getString("city")) && "朝阳区".equals(a.getString("district")), "municipality recognized without inventing a separate parent");
        a = area(cities, station, "CN", "陕西省", "雁塔区", "西安市", null, 100);
        check(a != null && "西安市".equals(a.getString("city")) && "雁塔区".equals(a.getString("district")), "locality district can use the actual subadmin city");
        check(area(cities, station, "CN", "陕西省", "<西安市>", null, "雁塔区<script>", 100) == null, "malformed component text is not trusted");
        System.out.println("Weather alert location metadata: " + checks + " assertions passed");
    }
}
