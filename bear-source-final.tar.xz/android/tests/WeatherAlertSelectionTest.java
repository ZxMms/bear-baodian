package com.xiongxiong.calendar;

import java.nio.file.Files;
import java.nio.file.Path;
import org.json.JSONObject;

/** Exercises saved-location upgrades and real directory ambiguities through production rules. */
public final class WeatherAlertSelectionTest {
    private static int checks;
    private static void check(boolean ok, String note) { checks++; if (!ok) throw new AssertionError(note); }
    private static JSONObject copy(JSONObject data) throws Exception { return new JSONObject(data.toString()); }
    public static void main(String[] args) throws Exception {
        NmcCities cities = new NmcCities(Files.readString(Path.of(args.length == 0 ? "web/nmc-cities.json" : args[0])));
        JSONObject xian = cities.canonical("RfjCI");
        check(!WeatherAlertSelection.ambiguousName(cities, copy(xian).put("source", "city")), "ordinary Xian selected city has an unambiguous name");
        for (String code : new String[]{"DXKse", "wVmjo"}) {
            JSONObject huaian = cities.canonical(code).put("source", "city");
            check("淮安".equals(huaian.getString("name")), "real Jiangsu catalogue ambiguity fixture still matches");
            check(WeatherAlertSelection.ambiguousName(cities, huaian), "both Huaian station IDs must not infer city vs district from the same display name");
        }
        check(!WeatherAlertSelection.ambiguousName(cities, copy(xian).put("source", "location")), "location metadata uses separately verified geocoder hierarchy");
        check(!WeatherAlertSelection.ambiguousName(cities, new JSONObject().put("source", "city").put("name", "Unknown")), "unknown station cannot be classified as a known duplicate");
        JSONObject saved = copy(xian).put("source", "location").put("latitude", 34.26).put("longitude", 108.94).put("geoTried", true);
        check(WeatherAlertSelection.needsAreaLookup(saved, xian), "2.2.5 saved resolved location gets one metadata-only lookup despite geoTried");
        check(!WeatherAlertSelection.needsAreaLookup(copy(saved).put("source", "city"), xian), "manual city selection does not start geocoding");
        check(!WeatherAlertSelection.needsAreaLookup(saved, null), "new unresolved location retains normal geocoder path");
        check(!WeatherAlertSelection.needsAreaLookup(copy(saved).put("latitude", JSONObject.NULL), xian), "missing saved coordinates cannot start metadata lookup");
        JSONObject area = new JSONObject().put("province", "陕西省").put("city", "西安市").put("district", "").put("source", "geocoder");
        check(!WeatherAlertSelection.needsAreaLookup(copy(saved).put("alertArea", area), xian), "existing metadata does not repeat lookup");
        JSONObject failed = copy(saved);
        WeatherAlertSelection.completeAreaLookup(failed, xian, null);
        check(failed.optBoolean("alertAreaChecked") && !WeatherAlertSelection.needsAreaLookup(failed, xian), "failed attempt records completion instead of repeating a four-second lookup");
        check(!failed.has("alertArea"), "failed lookup cannot invent alert hierarchy");
        JSONObject identified = copy(xian).put("alertArea", area);
        JSONObject success = copy(saved);
        WeatherAlertSelection.completeAreaLookup(success, xian, identified);
        check("西安市".equals(success.getJSONObject("alertArea").getString("city")), "matching station and province accepts the discovered hierarchy");
        check("RfjCI".equals(success.getString("nmcCode")) && saved.getString("name").equals(success.getString("name")), "upgrade never changes weather station or its selected name");
        area.put("city", "changed");
        check("西安市".equals(success.getJSONObject("alertArea").getString("city")), "accepted metadata is detached from mutable geocoder result");
        JSONObject wrongStation = copy(saved);
        WeatherAlertSelection.completeAreaLookup(wrongStation, xian, copy(identified).put("nmcCode", "DXKse"));
        check(!wrongStation.has("alertArea") && wrongStation.optBoolean("alertAreaChecked"), "different geocoder station does not replace the saved region");
        JSONObject wrongProvince = copy(saved);
        WeatherAlertSelection.completeAreaLookup(wrongProvince, xian, copy(identified).put("admin1", "江苏省"));
        check(!wrongProvince.has("alertArea"), "different station province is rejected");
        JSONObject wrongArea = copy(saved);
        WeatherAlertSelection.completeAreaLookup(wrongArea, xian, copy(xian).put("alertArea", new JSONObject().put("province", "江苏省")));
        check(!wrongArea.has("alertArea"), "mismatched metadata province is rejected");
        System.out.println("Weather alert selection upgrades: " + checks + " assertions passed");
    }
}
