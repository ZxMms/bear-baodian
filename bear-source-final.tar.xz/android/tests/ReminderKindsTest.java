package com.xiongxiong.calendar;

public final class ReminderKindsTest {
    private static int assertions;
    private static void equal(Object expected, Object actual) {
        assertions++;
        if (!expected.equals(actual)) throw new AssertionError("Expected " + expected + ", got " + actual);
    }
    private static void rejectsLabel(String kind) {
        assertions++;
        try { ReminderKinds.label(kind); }
        catch (IllegalArgumentException expected) { return; }
        throw new AssertionError("Unknown reminder kind was labeled: " + kind);
    }
    public static void main(String[] args) {
        // Adding a capsule alongside existing reminders must keep the whole batch valid.
        String[][] supported = {{"memo", "备注"}, {"event", "活动"}, {"anniversary", "纪念日"}, {"capsule", "时光胶囊"}};
        for (String[] kind : supported) {
            equal(true, ReminderKinds.allowed(kind[0]));
            equal(kind[1], ReminderKinds.label(kind[0]));
        }
        // No unknown type may be silently treated as a memo in notifications.
        for (String kind : new String[]{null, "", "journal", "CAPSULE", "capsule ", "memo\n", "expense"}) {
            equal(false, ReminderKinds.allowed(kind));
            rejectsLabel(kind);
        }
        System.out.println("Passed " + assertions + " reminder kind assertions: capsule, existing kinds, and unknown/null rejection");
    }
}
