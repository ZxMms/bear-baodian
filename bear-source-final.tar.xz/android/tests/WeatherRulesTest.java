package com.xiongxiong.calendar;

public final class WeatherRulesTest {
    private static int assertions;
    private static void check(boolean value, String note) { assertions++; if (!value) throw new AssertionError(note); }
    public static void main(String[] args) {
        long now = 1_800_000_000_000L;
        check(WeatherRules.fresh(now, now), "a just completed result is reusable");
        check(WeatherRules.fresh(now - 10 * 60 * 1000L, now), "10 minute check boundary stays reusable");
        check(!WeatherRules.fresh(now - 10 * 60 * 1000L - 1, now), "older data triggers background refresh");
        check(!WeatherRules.fresh(0, now), "missing cache timestamp cannot be fresh");
        check(WeatherRules.fresh(now + 5 * 60 * 1000L, now), "small clock correction tolerated");
        check(!WeatherRules.fresh(now + 5 * 60 * 1000L + 1, now), "clock rollback cannot freeze a future cache");
        check(WeatherRules.retryDue(-1, 0), "first automatic request starts immediately");
        check(!WeatherRules.retryDue(1000, 60999), "resume storms do not repeatedly hit a failed service");
        check(WeatherRules.retryDue(1000, 61000), "retry window eventually opens");
        check(WeatherRules.retryDue(1000, 500), "monotonic clock reset does not block requests");
        check(WeatherRules.validCoordinates(-90, 180), "coordinate boundaries accepted");
        check(!WeatherRules.validCoordinates(90.1, 0), "invalid latitude rejected");
        check(!WeatherRules.validCoordinates(0, -181), "invalid longitude rejected");
        check(!WeatherRules.validCoordinates(Double.NaN, 120), "NaN cannot identify a city");
        check(!WeatherRules.validCoordinates(30, Double.POSITIVE_INFINITY), "infinite coordinate rejected");
        check(WeatherRules.placeKey(39.9042, 116.4074).equals("3990:11641"), "city identity uses the same coarse precision as requests");
        check(WeatherRules.placeKey(39.901, 116.411).equals(WeatherRules.placeKey(39.904, 116.412)), "same coarse city can share cache");
        check(!WeatherRules.placeKey(39.9, 116.41).equals(WeatherRules.placeKey(31.23, 121.47)), "switching city cannot reuse another city forecast");
        check(WeatherRules.placeKey(0.0, 0).equals(WeatherRules.placeKey(-0.0, 0)), "signed zero does not create duplicate cache entries");
        check(WeatherRules.placeKey(Double.NaN, 0).isEmpty(), "invalid identity is empty");
        check(WeatherRules.usableLocation(1, 1), "fresh location reused immediately");
        check(WeatherRules.usableLocation(1, 120_000_000_001L), "2 minute location cache boundary");
        check(!WeatherRules.usableLocation(1, 120_000_000_002L), "stale location not silently reused");
        check(!WeatherRules.usableLocation(10, 9), "future monotonic location rejected");
        check(!WeatherRules.usableLocation(0, 1), "missing location timestamp rejected");
        check(WeatherRules.usableLocation(1, 120_000_000_001L, 20000), "coarse 20km maximum and 2-minute age accepted with disclosed accuracy");
        check(!WeatherRules.usableLocation(1, 120_000_000_002L, 10), "accurate but stale fix rejected");
        check(!WeatherRules.usableLocation(1, 1, 20000.01), "too broad network fix cannot be used even as city weather");
        check(!WeatherRules.usableLocation(1, 1, -1), "negative accuracy rejected");
        check(!WeatherRules.usableLocation(1, 1, Double.NaN), "unknown accuracy rejected");
        check(!WeatherRules.usableLocation(1, 1, Double.POSITIVE_INFINITY), "infinite accuracy rejected");
        check(!WeatherRules.usableLocation(1, 1, 0), "zero accuracy is not useful weather-location confidence");
        check(WeatherRules.wind(0, false) == 0, "calm wind is a real zero, not missing");
        check(WeatherRules.wind(12.4, false) == 12.4, "wind speed preserves m/s precision");
        check(WeatherRules.wind(359.9, true) == 359.9, "northwest direction accepted");
        check(WeatherRules.wind(360, true) == 360, "north at 360 accepted");
        check(WeatherRules.wind(-1, false) == null, "negative speed stays unavailable");
        check(WeatherRules.wind(Double.NaN, false) == null, "missing speed stays unavailable, never zero");
        check(WeatherRules.wind(Double.POSITIVE_INFINITY, false) == null, "infinite gust rejected");
        check(WeatherRules.wind(151, false) == null, "corrupted wind speed rejected");
        check(WeatherRules.wind(361, true) == null, "invalid direction rejected");
        System.out.println("Weather cache and wind rules: " + assertions + " assertions passed");
    }
}
