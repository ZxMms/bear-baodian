package com.xiongxiong.calendar;

import java.io.*;
import java.net.*;
import java.security.cert.Certificate;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import javax.net.ssl.*;

/** Executes the actual bounded transport with deterministic HTTPS connections; never needs the network. */
public final class WeatherNetworkTest {
    static int checks;
    static void check(boolean result,String note) { checks++; if(!result) throw new AssertionError(note); }
    static final String PRIMARY="https://www.nmc.cn/rest/real/54511", SECONDARY="https://api.open-meteo.com/v1/forecast?latitude=39.9&longitude=116.4";
    static class Fake extends HttpsURLConnection {
        int status=200; byte[] bytes="{\"temperature\":12}".getBytes(java.nio.charset.StandardCharsets.UTF_8); IOException failure; long delay; volatile boolean closed;
        Fake(URL url) {super(url);}
        @Override public int getResponseCode() throws IOException { if(failure!=null)throw failure; if(delay>0)try{Thread.sleep(delay);}catch(InterruptedException ex){throw new IOException("interrupted",ex);} return status; }
        @Override public InputStream getInputStream(){return new ByteArrayInputStream(bytes);}
        @Override public void disconnect(){closed=true;}
        @Override public boolean usingProxy(){return false;}
        @Override public void connect(){}
        @Override public String getCipherSuite(){return "TLS_FAKE";}
        @Override public Certificate[] getLocalCertificates(){return null;}
        @Override public Certificate[] getServerCertificates(){return new Certificate[0];}
    }
    public static void main(String[] args) throws Exception {
        // First-use JVM trust-store initialization can exceed the fake request's
        // 500 ms budget on a busy host. Initialize TLS before timed transport checks;
        // the separate delayed-response and cancellation deadlines remain unchanged.
        HttpsURLConnection.getDefaultSSLSocketFactory();
        WeatherNetwork success=new WeatherNetwork(Fake::new);
        try {
            check(success.get(PRIMARY,success.operation(),500).contains("temperature"),"valid HTTPS body preserved");
            check(WeatherNetwork.checked("https://www.nmc.cn/rest/real/A1234").getPath().endsWith("A1234"),"catalogue alphanumeric station supported");
            for(String url:new String[]{"http://www.nmc.cn/rest/real/54511","https://www.nmc.cn.evil.test/rest/real/54511","https://www.nmc.cn:444/rest/real/54511","https://user@www.nmc.cn/rest/real/54511","https://www.nmc.cn/rest/real/54511?redirect=evil","https://www.nmc.cn/rest/real/../54511","https://api.open-meteo.com/private"}) {
                boolean rejected=false;try{success.get(url,success.operation(),500);}catch(IllegalArgumentException expected){rejected=true;}check(rejected,"untrusted source rejected");
            }
            WeatherNetwork.Operation cancelled=success.operation(); cancelled.cancel();
            boolean rejected=false;try{success.get(PRIMARY,cancelled,500);}catch(InterruptedException expected){rejected=true;}check(rejected,"cancelled operation never starts");
        }finally{success.destroy();}
        AtomicInteger originVersion = new AtomicInteger();
        AtomicReference<Fake> observedConnection = new AtomicReference<>();
        WeatherNetwork revalidate = new WeatherNetwork(url -> {
            Fake connection = new Fake(url) {
                @Override public InputStream getInputStream() {
                    // Model a platform cache that would otherwise keep returning an old result.
                    String body = getUseCaches() ? "cached-observation" : "origin-observation-" + originVersion.incrementAndGet();
                    return new ByteArrayInputStream(body.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                }
            };
            connection.setIfModifiedSince(123456789L);
            observedConnection.set(connection);
            return connection;
        });
        try {
            WeatherNetwork.Operation operation = revalidate.operation();
            check("origin-observation-1".equals(revalidate.get(PRIMARY, operation, 500)), "network fetch bypasses a platform cached observation");
            Fake connection = observedConnection.get();
            check(!connection.getUseCaches(), "platform response caching is disabled before connection");
            check("no-cache, no-store".equals(connection.getRequestProperty("Cache-Control")), "intermediaries asked to revalidate and not store observations");
            check("no-cache".equals(connection.getRequestProperty("Pragma")), "legacy intermediaries also receive revalidation request");
            check(connection.getIfModifiedSince() == 0, "refresh does not conditionally reuse a modified-since response");
            check("origin-observation-2".equals(revalidate.get(PRIMARY, operation, 500)), "a later request obtains a new origin result rather than first response cache");
        } finally { revalidate.destroy(); }
        AtomicInteger attempted=new AtomicInteger();
        WeatherNetwork fallback=new WeatherNetwork(url->{Fake f=new Fake(url);attempted.incrementAndGet();if(url.getHost().equals("www.nmc.cn"))f.status=503;return f;});
        try {
            WeatherNetwork.Operation operation=fallback.operation(); String data=""; String failure="";
            try{data=fallback.get(PRIMARY,operation,500);}catch(Exception ex){failure=WeatherNetwork.errorCode(ex); data=fallback.get(SECONDARY,operation,500);}
            check("HTTP_503".equals(failure),"server refusal classified separately");check(data.contains("temperature")&&attempted.get()==2,"same operation can use backup after primary503");
        }finally{fallback.destroy();}
        WeatherNetwork timed=new WeatherNetwork(url->{Fake f=new Fake(url);if(url.getHost().equals("www.nmc.cn"))f.delay=1000;return f;});
        try {
            WeatherNetwork.Operation op=timed.operation();long start=System.nanoTime();String failure="";
            try{timed.get(PRIMARY,op,40);}catch(Exception ex){failure=WeatherNetwork.errorCode(ex);}
            check("TIMEOUT".equals(failure),"primarydeadline classified");check((System.nanoTime()-start)/1000000<800,"deadline returns without waiting for socket");
            check(timed.get(SECONDARY,op,500).contains("temperature"),"attempttimeoutdoesnotcancelindependentbackup");
        }finally{timed.destroy();}
        WeatherNetwork bothFail=new WeatherNetwork(url->{Fake f=new Fake(url);f.status=503;return f;});
        try {
            WeatherNetwork.Operation op=bothFail.operation();String prior="cached weather";int failed=0;
            for(String url:new String[]{PRIMARY,SECONDARY})try{prior=bothFail.get(url,op,500);}catch(Exception ex){failed++;}
            check(failed==2&&"cached weather".equals(prior),"failed endpoints never replace cached data with empty success");
        }finally{bothFail.destroy();}
        WeatherNetwork huge=new WeatherNetwork(url->{Fake f=new Fake(url);f.bytes=new byte[262145];return f;});
        try {boolean rejected=false;try{huge.get(PRIMARY,huge.operation(),500);}catch(IOException expected){rejected=true;}check(rejected,"oversized response rejected");}finally{huge.destroy();}
        check("DNS".equals(WeatherNetwork.errorCode(new UnknownHostException())),"DNSclassified");
        check("TLS".equals(WeatherNetwork.errorCode(new SSLHandshakeException("certificate"))),"TLSclassified");
        check("STALE_DATA".equals(WeatherNetwork.errorCode(new IllegalArgumentException("STALE_DATA"))),"staleobservationclassified");
        check("INVALID_RESPONSE".equals(WeatherNetwork.errorCode(new IllegalArgumentException("bad JSON"))),"badresponseclassified");
        System.out.println("Weather transport: "+checks+" checks passed (primary503/timeout, backup, cancellation, URLs, response limits, error types)");
    }
}
