package com.xiongxiong.calendar;

import java.nio.file.Files;
import java.nio.file.Path;
import org.json.JSONObject;

public final class WeatherDistrictRulesTest {
    static int checks;
    static void check(boolean ok,String label) { if(!ok)throw new AssertionError(label);checks++; }
    public static void main(String[] args) throws Exception {
        NmcCities cities=new NmcCities(Files.readString(Path.of("web/nmc-cities.json")));
        BeijingDistricts bj=new BeijingDistricts(new JSONObject(Files.readString(Path.of("web/beijing-districts.json"))));
        JSONObject old=cities.resolve("北京市","北京").put("source","location").put("geoTried",true).put("alertAreaChecked",true)
            .put("latitude",39.86).put("longitude",116.29).put("accuracyMeters",40)
            .put("alertArea",new JSONObject().put("province","北京市").put("city","北京市").put("district","").put("source","district-boundary"));
        check(WeatherDistrictRules.needsLookup(old),"city-only saved 2.2.9 result must retry district lookup despite old checked flags");
        check(!WeatherDistrictRules.needsLookup(new JSONObject(old.toString()).put("source","city")),"never geocode user's manual district");
        JSONObject fix=new JSONObject().put("source","location");
        WeatherDistrictRules.coordinates(fix,39.858612,116.286823,true);
        check(fix.getDouble("latitude")==39.85861 && fix.getDouble("longitude")==116.28682,"retain fix precision for district resolution");
        check(WeatherDistrictRules.margin(fix)==150 && WeatherDistrictRules.margin(old)==850,"old rounded coordinates still have their uncertainty margin");
        check("丰台区".equals(bj.district(fix.getDouble("latitude"),fix.getDouble("longitude"),40,WeatherDistrictRules.margin(fix))),"fresh fix retains Fengtai district");
        check("丰台区".equals(bj.district(39.82,116.20,40,150)) && "".equals(bj.district(39.82,116.20,40,850)),"fresh fix is not downgraded by the old blanket rounded-coordinate margin");
        check(bj.compatible("丰台区",39.85861,116.28682,40,150),"accept compatible Fengtai geocoder result");
        check(!bj.compatible("昌平区",39.85861,116.28682,40,150),"reject distant Changping name at Fengtai coordinates");
        check(!bj.compatible("丰台区",40.22,116.23,40,150),"reject Fengtai name at Changping coordinates");
        check(!bj.compatible("丰台区",39.85861,116.28682,9000,150),"broad fix cannot acquire a district from address alone");
        JSONObject found=cities.resolve("北京市","丰台").put("alertArea",new JSONObject().put("province","北京市").put("city","北京市").put("district","丰台区").put("source","geocoder").put("districtUnique",true));
        JSONObject chosen=new JSONObject(old.toString());
        JSONObject selected=WeatherDistrictRules.apply(chosen,cities.resolve("北京市","北京"),found);
        check("WgwUa".equals(selected.optString("nmcCode")) && "WgwUa".equals(chosen.optString("nmcCode")),"district lookup switches broad Beijing station to the verified Fengtai station");
        check("北京市 · 丰台区".equals(chosen.optString("name")),"district label is ready before weather response");
        check("丰台区".equals(chosen.getJSONObject("alertArea").getString("district")),"weather and alerts share the same district");
        check(!WeatherDistrictRules.needsLookup(chosen),"confirmed district is not erased by repeated metadata lookups");
        JSONObject failed=new JSONObject(old.toString());
        WeatherDistrictRules.apply(failed,cities.resolve("北京市","北京"),null);
        check(!WeatherDistrictRules.needsLookup(failed),"failed lookup is bounded for the same fix");
        check(WeatherDistrictRules.needsLookup(new JSONObject().put("source","location").put("latitude",39.86).put("longitude",116.29)),"new fix retries even at the same coordinates");
        JSONObject bad=new JSONObject(found.toString()).put("admin1","河北省"),safe=new JSONObject(old.toString());
        check(WeatherDistrictRules.apply(safe,null,bad)==null && !WeatherDistrictRules.hasDistrict(safe),"conflicting hierarchy is rejected");
        check("北京市 · 丰台区".equals(cities.resolve("北京市","丰台区").getString("displayName")),"manual search retains complete district label");
        check("WgwUa".equals(cities.search("丰台区").getJSONObject(0).getString("nmcCode")),"Fengtai search targets its actual station");
        check(!"WgwUa".equals(cities.resolve("北京市","昌平区").getString("nmcCode")),"adjacent district station is distinct");
        check("丰台".equals(cities.resolve("北京市","丰台区").getString("name")),"display label does not break station matching and alert filtering");
        System.out.println(checks+" district resolution checks passed");
    }
}
