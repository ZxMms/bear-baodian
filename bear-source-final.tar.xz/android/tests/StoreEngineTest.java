package com.xiongxiong.calendar;

import org.json.*;
import java.io.*;
import java.nio.file.*;
import java.sql.*;
import java.util.*;
import java.util.zip.*;

public final class StoreEngineTest {
    static int assertions;
    static void check(boolean condition,String name){assertions++;if(!condition)throw new AssertionError(name);}
    static final class Jdbc implements SqlAccess,AutoCloseable {
        final Connection connection;int failAfter=-1;
        Jdbc(File path)throws Exception{connection=DriverManager.getConnection("jdbc:sqlite:"+path);}
        public void execute(String sql,Object...args)throws Exception{
            if((sql.startsWith("INSERT")&&sql.contains("INTO records"))&&failAfter>=0&&failAfter--==0)throw new IOException("simulated disk failure");
            try(PreparedStatement statement=connection.prepareStatement(sql)){for(int i=0;i<args.length;i++)statement.setObject(i+1,args[i]);statement.executeUpdate();}
        }
        public List<JSONObject> query(String sql,Object...args)throws Exception{List<JSONObject> out=new ArrayList<>();try(PreparedStatement statement=connection.prepareStatement(sql)){for(int i=0;i<args.length;i++)statement.setObject(i+1,args[i]);try(ResultSet result=statement.executeQuery()){while(result.next()){JSONObject row=new JSONObject();for(int i=1;i<=result.getMetaData().getColumnCount();i++)row.put(result.getMetaData().getColumnLabel(i),result.getObject(i)==null?JSONObject.NULL:result.getObject(i));out.add(row);}}}return out;}
        public void begin()throws Exception{connection.setAutoCommit(false);}
        public void commit()throws Exception{connection.commit();connection.setAutoCommit(true);}
        public void rollback()throws Exception{connection.rollback();connection.setAutoCommit(true);}
        public void close()throws Exception{connection.close();}
    }
    static JSONObject request(String op){return new JSONObject().put("op",op);}
    static JSONObject counts(){JSONObject c=new JSONObject();for(String name:StoreEngine.STORES)c.put(name,0);return c;}
    static JSONObject row(String store,String key,Object value){return new JSONObject().put("store",store).put("key",key).put("value",value);}
    static void prepare(StoreEngine engine,List<JSONObject> rows)throws Exception{JSONObject c=counts();for(JSONObject row:rows)c.put(row.getString("store"),c.getInt(row.getString("store"))+1);engine.request(request("migration-start").put("counts",c));for(JSONObject row:rows)engine.request(new JSONObject(row.toString()).put("op","migration-row"));}
    static void initialize(StoreEngine engine,List<JSONObject> rows)throws Exception{prepare(engine,rows);engine.request(request("migration-finish"));}
    static JSONObject get(StoreEngine engine,String store,String key)throws Exception{return engine.request(request("get").put("store",store).put("key",key));}
    static String imageData(String text)throws Exception{return "data:image/jpeg;base64,"+Base64.getEncoder().encodeToString(text.getBytes("UTF-8"));}
    static void fails(Throwing code,String name)throws Exception{boolean failed=false;try{code.run();}catch(Exception expected){failed=true;}check(failed,name);}
    interface Throwing{void run()throws Exception;}
    static byte[] modifiedZip(byte[] archive,String replacement,byte[] bytes)throws Exception{ByteArrayOutputStream out=new ByteArrayOutputStream();try(ZipInputStream input=new ZipInputStream(new ByteArrayInputStream(archive));ZipOutputStream zip=new ZipOutputStream(out)){ZipEntry e;while((e=input.getNextEntry())!=null){zip.putNextEntry(new ZipEntry(e.getName()));zip.write(e.getName().equals(replacement)?bytes:StoreEngine.bounded(input,StoreEngine.MAX_BACKUP));zip.closeEntry();}}return out.toByteArray();}
    public static void main(String[] args)throws Exception{
        Class.forName("org.sqlite.JDBC");File root=Files.createTempDirectory("bear-storage-tests-").toFile();
        String photo="data:image/png;base64,"+Base64.getEncoder().encodeToString(new byte[]{(byte)137,80,78,71,1,2,3,4});
        String audio="data:audio/wav;base64,"+Base64.getEncoder().encodeToString("RIFF-test-audio".getBytes("UTF-8"));
        List<JSONObject> rows=Arrays.asList(
          row("entries","entry-one",new JSONObject().put("id","entry-one").put("date","2026-11-16").put("title","中文🙂手账").put("note","多行\n原样保留").put("photos",new JSONArray(Arrays.asList(photo,photo,photo,photo,photo)))),
          row("recipes","recipe-one",new JSONObject().put("id","recipe-one").put("title","面条").put("photos",new JSONArray().put(photo))),
          row("moods","2026-11-16",new JSONObject().put("date","2026-11-16").put("mood","happy")),
          row("ledger","bill-one",new JSONObject().put("id","bill-one").put("date","2026-11-16").put("type","expense").put("cents",4560).put("category","category-1").put("receipt",photo)),
          row("ledgerCategories","category-1",new JSONObject().put("id","category-1").put("name","买菜").put("type","expense")),
          row("settings","sound",false),
          row("settings","audio-profile",new JSONObject().put("volume",0.3).put("clips",new JSONObject().put("tap",new JSONObject().put("data",audio).put("duration",1.0).put("start",0).put("length",0.3))))
        );
        File dbFile=new File(root,"main.db"),media=new File(root,"media");byte[] backup;String ref;
        try(Jdbc db=new Jdbc(dbFile)){
            StoreEngine engine=new StoreEngine(db,media);check(!engine.request(request("status")).getBoolean("ready"),"fresh database");
            prepare(engine,rows);check(!engine.request(request("status")).getBoolean("ready"),"staged migration does not switch prematurely");
            db.failAfter=2;fails(()->engine.request(request("migration-finish")),"failed SQL migration");db.failAfter=-1;
            check(db.query("SELECT * FROM records").isEmpty(),"transaction rolled back all partial rows");check(!engine.request(request("status")).getBoolean("ready"),"failed migration remains retryable");
            engine.request(request("migration-finish"));check(engine.request(request("status")).getBoolean("ready"),"migration committed");
            JSONObject entry=get(engine,"entries","entry-one").getJSONObject("value");check(entry.getString("title").equals("中文🙂手账"),"Unicode preserved");check(entry.getString("note").equals("多行\n原样保留"),"newlines preserved");check(entry.getJSONArray("photos").length()==5,"all five photos retained");
            ref=entry.getJSONArray("photos").getString(0);check(ref.startsWith("media/"),"binary file reference");check(engine.request(request("stats")).getInt("attachments")==2,"duplicate binary files deduplicated");check(engine.file(ref).length()==8,"photo bytes unchanged");
            check(db.query("SELECT * FROM records WHERE payload LIKE '%base64%'").isEmpty(),"no Base64 attachments in SQLite");
            check(db.query("SELECT cents FROM records WHERE store='ledger'").get(0).getInt("cents")==4560,"integer cents indexed");
            fails(()->engine.request(request("put").put("store","moods").put("key","2026-11-16").put("value",rows.get(2).get("value")).put("add",true)),"daily mood uniqueness");
            check(!get(engine,"settings","sound").getBoolean("value"),"false preference preserved");
            fails(()->engine.request(request("cleanup-files")),"cleanup gated by completed export");
            ByteArrayOutputStream out=new ByteArrayOutputStream();engine.backup(out);backup=out.toByteArray();check(backup.length>0,"backup written");check(!engine.request(request("status")).isNull("lastBackup"),"backup completion recorded");
            String orphan=engine.attachment("data:image/png;base64,"+Base64.getEncoder().encodeToString("orphan".getBytes("UTF-8")));
            check(engine.request(request("cleanup-files")).getLong("freedBytes")==6,"unused file reclaimed");check(engine.file(ref).exists(),"live attachment retained during cleanup");fails(()->engine.file(orphan),"orphan deleted");
        }
        try(Jdbc db=new Jdbc(dbFile)){StoreEngine engine=new StoreEngine(db,media);check(engine.request(request("status")).getBoolean("ready"),"reopen preserves native backend selection");check(get(engine,"entries","entry-one").getJSONObject("value").getJSONArray("photos").length()==5,"reopen retains attachments");}
        try(Jdbc db=new Jdbc(new File(root,"restore.db"))){
            StoreEngine engine=new StoreEngine(db,new File(root,"restore-media"));
            initialize(engine,Arrays.asList(row("entries","entry-one",new JSONObject().put("id","entry-one").put("title","较新的本机修改").put("photos",new JSONArray()))));
            StoreEngine.PreparedBackup prepared=engine.inspectBackup(new ByteArrayInputStream(backup),new File(root,"valid"));
            check(engine.request(request("stats")).getJSONObject("counts").getInt("ledger")==0,"preview does not modify database");
            JSONObject result=engine.mergeBackup(prepared);check(result.getInt("added")==6&&result.getInt("kept")==1,"merge counts and conflicts");check(get(engine,"entries","entry-one").getJSONObject("value").getString("title").equals("较新的本机修改"),"local edit never overwritten");check(get(engine,"ledger","bill-one").getJSONObject("value").getInt("cents")==4560,"restored money correct");
            check(engine.mergeBackup(prepared).getInt("added")==0,"restore is idempotent");
            byte[] broken=modifiedZip(backup,ref,"corrupt".getBytes("UTF-8"));fails(()->engine.inspectBackup(new ByteArrayInputStream(broken),new File(root,"corrupt")),"corrupt attachment rejected");check(get(engine,"ledger","bill-one").getJSONObject("value").getInt("cents")==4560,"bad backup leaves data unchanged");
            ByteArrayOutputStream attack=new ByteArrayOutputStream();try(ZipOutputStream zip=new ZipOutputStream(attack)){zip.putNextEntry(new ZipEntry("../escape.txt"));zip.write(1);zip.closeEntry();}
            fails(()->engine.inspectBackup(new ByteArrayInputStream(attack.toByteArray()),new File(root,"attack")),"zip traversal rejected");check(!new File(root,"escape.txt").exists(),"zip cannot escape private staging");
            fails(()->engine.file("media/../main.db"),"attachment traversal rejected");
        }
        try(Jdbc db=new Jdbc(new File(root,"food.db"))){
            StoreEngine engine=new StoreEngine(db,new File(root,"food-media"));initialize(engine,Collections.emptyList());
            JSONArray rowsToSave=new JSONArray().put(row("entries","food-1",new JSONObject().put("id","food-1").put("kind","meal").put("recipeId","recipe-1").put("note","media/"+String.join("",Collections.nCopies(64,"0"))+".jpg").put("photos",new JSONArray().put(photo)))).put(row("recipes","recipe-1",new JSONObject().put("id","recipe-1").put("title","美食").put("xhsUrl","https://xhslink.com/a/test").put("photos",new JSONArray().put(photo))));
            db.failAfter=1;fails(()->engine.request(request("put-batch").put("rows",rowsToSave)),"food and recipe partial write failure");db.failAfter=-1;
            check(db.query("SELECT * FROM records").isEmpty(),"food and recipe rollback together");
            engine.request(request("put-batch").put("rows",rowsToSave));check(engine.request(request("stats")).getInt("attachments")==1,"shared cover deduped; ordinary text not treated as an attachment");
            check(get(engine,"entries","food-1").getJSONObject("value").getString("recipeId").equals("recipe-1"),"saved food links to recipe");
            check(get(engine,"recipes","recipe-1").getJSONObject("value").getString("xhsUrl").equals("https://xhslink.com/a/test"),"Xiaohongshu link persisted");
        }
        // A legacy receipt-only bill gains an independent five-photo album.
        File billDb=new File(root,"bill-photos.db"),billMedia=new File(root,"bill-media");
        byte[] billBackup;List<String> billRefs=new ArrayList<>();String receiptRef;
        try(Jdbc db=new Jdbc(billDb)){
            StoreEngine engine=new StoreEngine(db,billMedia);
            JSONObject oldBill=new JSONObject().put("id","bill-photo").put("date","2026-11-17").put("type","expense").put("cents",8800).put("receipt",photo);
            initialize(engine,Arrays.asList(row("ledger","bill-photo",oldBill)));
            JSONObject bill=get(engine,"ledger","bill-photo").getJSONObject("value");
            check(!bill.has("photos"),"legacy receipt-only bill remains readable");receiptRef=bill.getString("receipt");
            JSONArray album=new JSONArray();for(int i=0;i<5;i++)album.put("data:image/jpeg;base64,"+Base64.getEncoder().encodeToString(("spending-photo-"+i).getBytes("UTF-8")));
            bill.put("photos",album);
            JSONObject saved=engine.request(request("put").put("store","ledger").put("key","bill-photo").put("value",bill)).getJSONObject("value");
            check(saved.getJSONArray("photos").length()==5&&saved.getString("receipt").equals(receiptRef),"five consumption photos coexist with separate receipt");
            for(int i=0;i<5;i++){String value=saved.getJSONArray("photos").getString(i);billRefs.add(value);check(new String(Files.readAllBytes(engine.file(value).toPath()),"UTF-8").equals("spending-photo-"+i),"photo order and binary content retained "+i);}
            check(engine.request(request("stats")).getInt("attachments")==6,"receipt and five distinct photos tracked");
            check(db.query("SELECT * FROM records WHERE payload LIKE '%base64%'").isEmpty(),"bill photos externalized from SQLite payload");
            JSONObject tooMany=new JSONObject(saved.toString());tooMany.getJSONArray("photos").put(photo);
            fails(()->engine.request(request("put").put("store","ledger").put("key","bill-photo").put("value",tooMany)),"six consumption photos rejected");
            JSONObject malformed=new JSONObject(saved.toString()).put("photos","invalid");
            fails(()->engine.request(request("put").put("store","ledger").put("key","bill-photo").put("value",malformed)),"invalid consumption album rejected");
            check(get(engine,"ledger","bill-photo").getJSONObject("value").getJSONArray("photos").length()==5,"invalid edit preserves original album");
            ByteArrayOutputStream out=new ByteArrayOutputStream();engine.backup(out);billBackup=out.toByteArray();
            check(engine.request(request("cleanup-files")).getLong("freedBytes")==0,"cleanup retains all live consumption photos");
        }
        try(Jdbc db=new Jdbc(billDb)){
            StoreEngine engine=new StoreEngine(db,billMedia);JSONObject bill=get(engine,"ledger","bill-photo").getJSONObject("value");
            check(bill.getJSONArray("photos").length()==5,"reopen retains consumption album");
            bill.put("photos",new JSONArray());engine.request(request("put").put("store","ledger").put("key","bill-photo").put("value",bill));
            JSONObject edited=get(engine,"ledger","bill-photo").getJSONObject("value");
            check(edited.getInt("cents")==8800&&edited.getString("receipt").equals(receiptRef),"removing consumption photos keeps amount and receipt");
            check(engine.request(request("cleanup-files")).getLong("freedBytes")>0,"removed consumption photos become cleanable");
            check(engine.file(receiptRef).exists(),"receipt survives album removal and cleanup");
        }
        try(Jdbc db=new Jdbc(new File(root,"bill-photo-restore.db"))){
            StoreEngine engine=new StoreEngine(db,new File(root,"bill-photo-restore-media"));initialize(engine,Collections.emptyList());
            StoreEngine.PreparedBackup prepared=engine.inspectBackup(new ByteArrayInputStream(billBackup),new File(root,"bill-photo-backup"));engine.mergeBackup(prepared);
            JSONObject restored=get(engine,"ledger","bill-photo").getJSONObject("value");
            check(restored.getJSONArray("photos").length()==5&&restored.getString("receipt").equals(receiptRef),"backup restores separate receipt and five consumption photos");
            for(int i=0;i<5;i++)check(new String(Files.readAllBytes(engine.file(restored.getJSONArray("photos").getString(i)).toPath()),"UTF-8").equals("spending-photo-"+i),"restored photo bytes and order "+i);
            byte[] broken=modifiedZip(billBackup,billRefs.get(4),"broken".getBytes("UTF-8"));fails(()->engine.inspectBackup(new ByteArrayInputStream(broken),new File(root,"broken-bill-photo")),"corrupt consumption photo backup rejected");
        }
        // Drafts and feature documents protect their named images without interpreting free text.
        File draftDb=new File(root,"drafts.db"),draftMedia=new File(root,"draft-media");byte[] draftBackup;Set<String> draftRefs=new HashSet<>();
        String ordinaryText="media/"+String.join("",Collections.nCopies(64,"0"))+".jpg";
        try(Jdbc db=new Jdbc(draftDb)){
            StoreEngine engine=new StoreEngine(db,draftMedia);initialize(engine,Collections.emptyList());
            JSONObject draft=new JSONObject().put("_type","draft").put("draftId","entry").put("savedAt",1000)
                .put("photos",new JSONArray().put(imageData("draft-original-1")).put(imageData("draft-original-2")))
                .put("foodRecipeCover",imageData("draft-cover"))
                .put("fields",new JSONArray().put(new JSONObject().put("name","note").put("value",ordinaryText)))
                .put("form",new JSONObject().put("note",ordinaryText))
                .put("context",new JSONObject().put("receipt",imageData("draft-receipt")).put("nested",new JSONObject().put("photo",imageData("draft-import"))));
            JSONObject saved=engine.request(request("put").put("store","settings").put("key","draft:entry").put("value",draft)).getJSONObject("value");
            draftRefs.add(saved.getJSONArray("photos").getString(0));draftRefs.add(saved.getJSONArray("photos").getString(1));draftRefs.add(saved.getString("foodRecipeCover"));draftRefs.add(saved.getJSONObject("context").getString("receipt"));draftRefs.add(saved.getJSONObject("context").getJSONObject("nested").getString("photo"));
            check(draftRefs.size()==5&&draftRefs.stream().allMatch(value->value.startsWith("media/")),"draft originals, cover and nested receipt normalized independently");
            check(saved.getJSONArray("fields").getJSONObject(0).getString("value").equals(ordinaryText)&&saved.getJSONObject("form").getString("note").equals(ordinaryText),"form text resembling a file remains untouched");
            check(engine.request(request("stats")).getInt("attachments")==5,"draft-only files protected by reference accounting");
            check(db.query("SELECT * FROM records WHERE payload LIKE '%base64%'").isEmpty(),"draft images not embedded in SQLite JSON");
            engine.request(request("put").put("store","settings").put("key","feature:test").put("value",new JSONArray().put(new JSONObject().put("photos",new JSONArray().put(saved.getString("foodRecipeCover"))))));
            ByteArrayOutputStream out=new ByteArrayOutputStream();engine.backup(out);draftBackup=out.toByteArray();
            check(engine.request(request("cleanup-files")).getLong("freedBytes")==0,"cleanup retains draft and feature attachments");
            for(String file:draftRefs)check(engine.file(file).exists(),"draft attachment remains usable after cleanup");
            JSONObject invalid=new JSONObject(saved.toString()).put("foodRecipeCover",ordinaryText);
            fails(()->engine.request(request("put").put("store","settings").put("key","draft:entry").put("value",invalid)),"missing actual draft attachment rejected");
            check(get(engine,"settings","draft:entry").getJSONObject("value").getString("foodRecipeCover").equals(saved.getString("foodRecipeCover")),"failed draft write preserves previous draft");
        }
        try(Jdbc db=new Jdbc(draftDb)){
            StoreEngine engine=new StoreEngine(db,draftMedia);check(get(engine,"settings","draft:entry").getJSONObject("value").getJSONArray("photos").length()==2,"draft survives process restart");
        }
        try(Jdbc db=new Jdbc(new File(root,"draft-restore.db"))){
            StoreEngine engine=new StoreEngine(db,new File(root,"draft-restore-media"));initialize(engine,Collections.emptyList());
            engine.mergeBackup(engine.inspectBackup(new ByteArrayInputStream(draftBackup),new File(root,"draft-restore-staging")));
            JSONObject draft=get(engine,"settings","draft:entry").getJSONObject("value");
            check(draft.getJSONArray("fields").getJSONObject(0).getString("value").equals(ordinaryText),"draft ordinary text preserved by backup restore");
            check(engine.request(request("stats")).getInt("attachments")==5,"backup restores nested draft and feature files");
            for(String file:draftRefs)check(engine.file(file).exists(),"restored draft attachment is readable");
            engine.request(request("remove").put("store","settings").put("key","draft:entry"));
            ByteArrayOutputStream out=new ByteArrayOutputStream();engine.backup(out);
            check(engine.request(request("cleanup-files")).getLong("freedBytes")>0,"clearing draft releases files no longer referenced");
            check(engine.request(request("stats")).getInt("attachments")==1,"feature document still protects its shared cover");
        }
        // A bill and its linked memory commit together, and both can be restored independently.
        File trashDb=new File(root,"trash.db"),trashMedia=new File(root,"trash-media");byte[] trashBackup;long deletedAt=1700000000000L;
        try(Jdbc db=new Jdbc(trashDb)){
            StoreEngine engine=new StoreEngine(db,trashMedia);initialize(engine,Collections.emptyList());
            JSONArray linked=new JSONArray()
                .put(row("ledger","linked-bill",new JSONObject().put("id","linked-bill").put("date","2026-11-17").put("type","expense").put("cents",3500).put("entryId","linked-entry").put("photos",new JSONArray().put(imageData("linked-bill-photo")))))
                .put(row("entries","linked-entry",new JSONObject().put("id","linked-entry").put("date","2026-11-17").put("kind","life").put("ledgerId","linked-bill").put("photos",new JSONArray().put(imageData("linked-memory-photo")))));
            db.failAfter=1;fails(()->engine.request(request("put-batch").put("rows",linked)),"linked bill and memory injected failure");db.failAfter=-1;
            check(db.query("SELECT * FROM records").isEmpty(),"linked bill and memory rollback leaves neither side");
            engine.request(request("put-batch").put("rows",linked));
            check(get(engine,"ledger","linked-bill").getJSONObject("value").getString("entryId").equals("linked-entry")&&get(engine,"entries","linked-entry").getJSONObject("value").getString("ledgerId").equals("linked-bill"),"linked bill and memory commit both references");
            fails(()->engine.request(request("put-batch").put("rows",new JSONArray().put(linked.get(0)).put(linked.get(0)))),"duplicate keys rejected before batch commit");
            db.failAfter=0;fails(()->engine.request(request("soft-delete").put("store","ledger").put("key","linked-bill").put("now",deletedAt)),"failed soft delete");db.failAfter=-1;
            check(!get(engine,"ledger","linked-bill").getJSONObject("value").has("_deletedAt"),"failed delete leaves active record intact");
            JSONObject removed=engine.request(request("soft-delete").put("store","ledger").put("key","linked-bill").put("now",deletedAt)).getJSONObject("value");
            check(removed.getLong("_deleteExpiresAt")==deletedAt+StoreEngine.TRASH_LIFETIME,"trash retention is thirty days");
            engine.request(request("soft-delete").put("store","ledger").put("key","linked-bill").put("now",deletedAt+10000));
            check(get(engine,"ledger","linked-bill").getJSONObject("value").getLong("_deletedAt")==deletedAt,"repeat delete does not reset retention");
            JSONObject stats=engine.request(request("stats"));check(stats.getJSONObject("counts").getInt("ledger")==0&&stats.getJSONObject("counts").getInt("entries")==1&&stats.getInt("trashCount")==1,"trash excluded from active statistics without deleting linked memory");
            check(stats.getInt("attachments")==2,"trash images retained for recovery");
            ByteArrayOutputStream out=new ByteArrayOutputStream();engine.backup(out);trashBackup=out.toByteArray();
            check(engine.request(request("cleanup-files")).getLong("freedBytes")==0,"file cleanup does not purge expired trash files");
            check(!get(engine,"ledger","linked-bill").isNull("value"),"expired record remains until explicit purge");
            db.failAfter=0;fails(()->engine.request(request("restore").put("store","ledger").put("key","linked-bill")),"failed restore");db.failAfter=-1;
            check(get(engine,"ledger","linked-bill").getJSONObject("value").has("_deletedAt"),"failed restore keeps recoverable record");
            JSONObject restored=engine.request(request("restore").put("store","ledger").put("key","linked-bill")).getJSONObject("value");
            check(!restored.has("_deletedAt")&&!restored.has("_deleteExpiresAt")&&restored.getInt("cents")==3500,"restore keeps original bill and clears only deletion metadata");
            check(engine.request(request("stats")).getJSONObject("counts").getInt("ledger")==1,"restored bill counted again");
            fails(()->engine.request(request("purge-trash-item").put("store","ledger").put("key","linked-bill")),"active record cannot be purged via trash API");
            fails(()->engine.request(request("soft-delete").put("store","moods").put("key","2026-11-17")),"only supported content types use trash");
            engine.request(request("soft-delete").put("store","ledger").put("key","linked-bill").put("now",deletedAt));
            engine.request(request("soft-delete").put("store","entries").put("key","linked-entry").put("now",deletedAt+StoreEngine.TRASH_LIFETIME));
            JSONObject purged=engine.request(request("purge-trash").put("now",deletedAt+StoreEngine.TRASH_LIFETIME));
            check(purged.getInt("removed")==1&&get(engine,"ledger","linked-bill").isNull("value")&&!get(engine,"entries","linked-entry").isNull("value"),"explicit expired cleanup leaves newer deleted record recoverable");
            check(engine.request(request("purge-trash").put("expiredOnly",false)).getInt("removed")==1,"explicit clear-all removes remaining trash only");
        }
        try(Jdbc db=new Jdbc(new File(root,"trash-restore.db"))){
            StoreEngine engine=new StoreEngine(db,new File(root,"trash-restore-media"));initialize(engine,Collections.emptyList());
            engine.mergeBackup(engine.inspectBackup(new ByteArrayInputStream(trashBackup),new File(root,"trash-restore-staging")));
            check(get(engine,"ledger","linked-bill").getJSONObject("value").getLong("_deletedAt")==deletedAt,"backup restores deletion status without auto-purge");
            check(engine.request(request("stats")).getInt("trashCount")==1&&engine.request(request("stats")).getInt("attachments")==2,"restored trash attachment remains protected");
            JSONObject restored=engine.request(request("restore").put("store","ledger").put("key","linked-bill")).getJSONObject("value");
            check(engine.file(restored.getJSONArray("photos").getString(0)).exists(),"deleted bill image restored through backup remains usable");
        }
        System.out.println("Passed "+assertions+" assertions using real SQLite: atomic migration/batches, draft and trash persistence, attachment deduplication/protection, explicit purge, backups, safe merge, corruption/path rejection and injected write-failure recovery.");
    }
}
