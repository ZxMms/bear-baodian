import { initWeatherAlerts, alertsSection, alertSummary, alertsClick, syncAlertsPlace, clearWeatherAlerts, paintWeatherAlerts, refreshAlertsNow } from './weather-alerts.js?v=35';

export function weatherLook(code, isDay = true) {
  if ([71, 73, 75, 77, 85, 86].includes(code)) return { kind: "snow", icon: "❄", label: "下雪" };
  if ([95, 96, 99].includes(code)) return { kind: "rain", icon: "ϟ", label: "雷阵雨" };
  if ([51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82].includes(code)) return { kind: "rain", icon: "☂", label: "有雨" };
  if ([45, 48].includes(code)) return { kind: "fog", icon: "≋", label: "有雾" };
  if (code === 3) return { kind: "cloud", icon: "☁", label: "阴天" };
  if ([1, 2].includes(code)) return { kind: "cloud", icon: isDay ? "⛅" : "☾", label: "多云" };
  if (code === 0) return { kind: "clear", icon: isDay ? "☀" : "☾", label: "晴" };
  return { kind: "unknown", icon: "◌", label: "晴雨数据暂缺" };
}
export function weatherSymbol(kind, day) {
  const paths = {
    clear: day ? '<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5"/>' : '<path d="M20.5 14a8.5 8.5 0 0 1-10.6-10A8.6 8.6 0 1 0 20.5 14Z"/>',
    cloud: '<path d="M6.2 18a4.2 4.2 0 0 1-.6-8.4A6 6 0 0 1 17 8.7 4.7 4.7 0 0 1 18 18Z"/>',
    rain: '<path d="M6 15a4 4 0 0 1-.5-7.9A5.4 5.4 0 0 1 16 6.5 4.2 4.2 0 1 1 18 15M8 17l-1 3m6-3-1 3m6-3-1 3"/>',
    snow: '<path d="M12 2v20M3.4 7l17.2 10M3.4 17 20.6 7M9.5 4.5 12 7l2.5-2.5M9.5 19.5 12 17l2.5 2.5M4 10l3.6-.6-.8-3.5M20 14l-3.6.6.8 3.5M4 14l3.6.6-.8 3.5M20 10l-3.6-.6.8-3.5"/>',
    fog: '<path d="M5 9h14M3 13h16M6 17h15"/>',
    unknown: '<path d="M10 5a2 2 0 0 1 4 0v8.7a4.5 4.5 0 1 1-4 0Z"/><path d="M12 9v8"/>'
  };
  return `<svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round">${paths[kind] || paths.unknown}</svg>`;
}
export function isWeatherStale(weather, now = Date.now()) {
  const time = weather?.provider === 'nmc' || Number.isFinite(weather?.observedAt) ? weather?.observedAt : weather?.updatedAt;
  return !weather || !Number.isFinite(time) || now - time > 7200000 || time > now + 300000;
}
export function windDirectionLabel(value) {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0 || value > 360) return '未提供风向';
  return ['北风', '东北风', '东风', '东南风', '南风', '西南风', '西风', '西北风'][Math.round(value / 45) % 8];
}
export function windValue(value) {
  return typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= 150 ? value.toFixed(1) : null;
}
// GB/T 28591—2012, 10 m wind speed in m/s. Use the displayed 0.1 m/s
// precision at boundaries; missing data must never become a calm-wind report.
// https://www.cma.gov.cn/zfxxgk/gknr/flfgbz/bz/202209/P020220921551843068981.pdf
export function windPowerInfo(data = {}) {
  const published = typeof data?.windPower === 'string' ? data.windPower.trim() : '';
  if (/^(?:微风|静风|(?:[0-9]|1[0-7])(?:[~～-](?:[0-9]|1[0-7]))?级)$/.test(published))
    return {label:published,estimated:false,scale:null};
  const speed = windValue(data?.windSpeed);
  if (speed === null) return {label:'',estimated:false,scale:null};
  const lowerBounds = [0.3,1.6,3.4,5.5,8,10.8,13.9,17.2,20.8,24.5,28.5,32.7,37,41.5,46.2,51,56.1];
  const scale = lowerBounds.filter(boundary => Number(speed) >= boundary).length;
  return {label:`${scale}级`,estimated:true,scale};
}
function windSummary(data) {
  const speed = windValue(data?.windSpeed), power = windPowerInfo(data);
  const strength = power.label ? `${power.estimated ? '约' : ''}${escape(power.label)}` : '';
  if (speed !== null) return `${power.scale === 0 ? '静风' : windLabel(data)} ${speed} m/s${strength ? ` · ${strength}` : ''}`;
  return strength ? `${windLabel(data)} ${strength}` : '';
}
function windLabel(data) { return data?.windDirectionText ? escape(data.windDirectionText) : windDirectionLabel(data?.windDirection); }
function windDetails(data) {
  if (!data) return '';
  const power = windPowerInfo(data), speed = windValue(data.windSpeed), gust = windValue(data.windGust);
  return `<div class="weather-wind-grid" aria-label="风向、风力与风速"><div><span>风力</span><strong class="wind-power">${power.label ? escape(power.label) : '—'}</strong><p>${power.scale === 0 ? '静风' : windLabel(data)}</p><small class="wind-method">${power.label ? (power.estimated ? '按 10 米风速换算' : '天气来源发布') : '当前来源暂未提供'}</small></div><div><span>风速${data.provider === 'nmc' ? '' : ' · 10 米高度'}</span><strong>${speed ?? '—'}${speed === null ? '' : ' <small>m/s</small>'}</strong><p>${speed === null ? '当前来源暂未提供' : '当前风速'}</p><small class="wind-method">${gust === null ? '阵风暂未提供' : `阵风 ${gust} m/s`}</small></div></div>`;
}
export function weatherSourceUrl(value) {
  try { const url = new URL(value); return url.protocol === 'https:' && url.hostname === 'www.nmc.cn' && !url.username && !url.password && !url.port && !url.search && !url.hash && (url.pathname === '/publish/forecast.html' || /^\/publish\/forecast\/[A-Z0-9]+\/[A-Za-z0-9_-]+\.html$/.test(url.pathname)) ? url.href : null; } catch { return null; }
}
function weatherCredit() {
  const data = state.weather;
  return data?.provider === 'nmc' ? `天气 / 风力：中央气象台 · 城市站点资料${weatherSourceUrl(data.sourceUrl) ? `<br><button type="button" class="text-button" data-weather-source-url="${escape(data.sourceUrl)}">查看官方天气页面 ↗</button>` : ''}` : '天气备用来源：Open-Meteo 模型数据 · CC BY 4.0<br>国内城市目录：中央气象台；海外城市搜索：GeoNames / Open-Meteo';
}
export function weatherFailureReason(code) {
  if (!code || typeof code !== 'string') return '';
  const reasons = [];
  for (const item of code.split('/')) {
    const source = item.startsWith('NMC_') ? '国内来源' : item.startsWith('OPEN_METEO_') ? '备用来源' : '天气查询';
    const type = item.replace(/^(NMC_|OPEN_METEO_)/, '');
    let reason = {TIMEOUT:'连接超时',DNS:'地址解析失败',TLS:'安全连接未建立',INVALID_RESPONSE:'返回资料暂不可用',STALE_DATA:'观测资料尚未更新',NETWORK:'连接暂时中断'}[type];
    if (/^HTTP_\d{3}$/.test(type)) reason = `服务暂不可用（${type.slice(5)}）`;
    if (typeof reason === 'string' && reason) reasons.push(`${source}：${reason}`);
  }
  return reasons.join('；');
}
const escape = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
const popular = [
  ["北京", 39.90, 116.40], ["上海", 31.23, 121.47], ["广州", 23.13, 113.26], ["深圳", 22.54, 114.06],
  ["西安", 34.26, 108.94], ["成都", 30.66, 104.07], ["杭州", 30.27, 120.15], ["武汉", 30.59, 114.31],
].map(([name, latitude, longitude], index) => ({ name, latitude, longitude, region: "常用城市", countryCode: 'CN', nmcCode: ['Wqsps','WwcJd','DwzZf','AhpEU','RfjCI','yGYHR','HIieJ','bSpCz'][index], admin1: ['北京市','上海市','广东省','广东省','陕西省','四川省','浙江省','湖北省'][index] }));
let state = { native: false, place: null, weather: null, loading: false, error: "" };
let effects = true, ui, cities = [], activeQuery = "", searchTimer, refreshTimer;
export function initWeather(callbacks) {
  ui = callbacks;
  try { effects = localStorage.getItem("bear-weather-effects") !== "off"; } catch { }
  if (window.BearWeather) {
    try { state = JSON.parse(window.BearWeather.state()); } catch { state.native = true; }
  }
  initWeatherAlerts({ ...ui, backWeather: showWeather, repaint: paintWeather });
  syncAlertsPlace(state.place);
  window.bearWeatherChanged = (payload) => {
    try { state = JSON.parse(payload); } catch { return; }
    syncAlertsPlace(state.place);
    paintWeather();
    const locationHelp = document.querySelector('#weather-location-help');
    if (locationHelp) locationHelp.hidden = state.place?.source !== 'location';
    for (const button of document.querySelectorAll('[data-weather-action="locate"], [data-weather-action="refresh"], [data-weather-action="refresh-saved"]')) button.disabled = state.loading || locationPending() || (button.dataset.weatherAction !== 'locate' && !state.place);
    const refresh = document.querySelector('[data-weather-action="refresh"]');
    if (refresh) refresh.textContent = state.loading || locationPending() ? '查询中…' : refreshLabel();
    const disable = document.querySelector('[data-weather-action="disable"]');
    if (disable) disable.hidden = !state.place;
    ui.onWeatherUpdated?.();
  };
  window.bearWeatherCities = (payload) => {
    let response;
    try { response = JSON.parse(payload); } catch { return; }
    if (response.query !== activeQuery || !document.querySelector("#weather-city-results")) return;
    clearTimeout(searchTimer);
    cities = response.results;
    document.querySelector("#weather-city-results").innerHTML = response.error ? `<p class="weather-error">${escape(response.error)}</p>` : cities.length ? `${cityRows(cities, "result")}${cities.length >= 40 ? '<p class="weather-help">结果较多，可输入更完整的市县名继续查找。</p>' : ''}` : '<p class="weather-help">没有找到这个城市，可尝试不带“市”或输入拼音。</p>';
    const button = document.querySelector('[data-form="weather-search"] button');
    if (button) button.disabled = false;
  };
  document.addEventListener("visibilitychange", () => {
    document.body.classList.toggle("app-asleep", document.hidden);
    if (!document.hidden) paintWeather();
  });
  clearInterval(refreshTimer);
  refreshTimer = setInterval(() => {
    if (document.hidden) return;
    paintWeather();
  }, 60000);
}
function refreshLabel() { return state.place?.source === 'location' ? '重新定位并刷新' : '刷新天气'; }
const validTime = value => typeof value === 'number' && Number.isFinite(value) && value > 0 && value <= Date.now() + 300000;
function weatherTime(value, compact = false) {
  if (!validTime(value)) return '无时间记录';
  const date = new Date(value);
  const zone = {timeZone:'Asia/Shanghai'};
  const todayInChina = compact && date.toLocaleDateString('zh-CN', zone) === new Date().toLocaleDateString('zh-CN', zone);
  return date.toLocaleString('zh-CN', {...zone, ...(todayInChina ? {} : {month:'numeric',day:'numeric'}),hour:'2-digit',minute:'2-digit'});
}
export function weatherLocationInfo(place) {
  if (place?.source !== 'location') return '';
  const time = validTime(place.locatedAt) ? `${weatherTime(place.locatedAt)} 定位` : '未记录定位时间';
  const meters = place.accuracyMeters;
  const source = ({gps:'GPS 定位',network:'网络定位',fused:'融合定位'}[place.fixProvider] || '大致定位');
  const accuracy = typeof meters === 'number' && Number.isFinite(meters) && meters > 0 && meters <= 100000 ? ` · ${source}，手机报告精度约 ${meters < 1000 ? `${Math.max(1, Math.round(meters))} 米` : `${(meters / 1000).toFixed(1)} 公里`}` : ' · 大致位置';
  return `${time}${accuracy}`;
}
function weatherPlaceLabel(place) {
  if (!place) return '今日天气';
  const area=place.alertArea;
  if (place.source==='location' && ['geocoder','district-boundary'].includes(area?.source) && area.province===place.admin1 && area.district)
    return `${area.city || area.province} · ${area.district}`;
  return place.displayName || place.name || '定位附近';
}
// Read-only, session-only snapshot for sharing; no new weather cache or location request.
export function sharingWeatherState() {
  return {native:state.native,place:state.place,placeLabel:weatherPlaceLabel(state.place),weather:state.weather,loading:state.loading,error:state.error,locationPending:locationPending()};
}
export function refreshSharingWeather() {
  if (!state.native || !state.place || state.loading || locationPending() || !window.BearWeather?.refreshNow) return false;
  window.BearWeather.refreshNow();
  return true;
}
function districtRecovery() {
  if (state.place?.source!=='location' || locationPending()) return '';
  const confirmed=Boolean(state.place.alertArea?.district);
  if (confirmed) return '';
  return `<div class="weather-district-recovery"><div><strong>区县还未识别</strong><p>${state.loading ? '正在核对地区，天气会继续查询。' : '可直接选择所在区县，按该地区重新查询天气与预警。'}</p></div><button type="button" data-weather-action="cities">选择区县 <span aria-hidden="true">›</span></button></div>`;
}
function weatherProvenance(data) {
  if (!data) return '';
  const published = validTime(data.observedAt) ? weatherTime(data.observedAt) : '来源未提供时间';
  const checked = validTime(state.checkedAt) ? state.checkedAt : data.checkedAt;
  const station = data.stationName || data.city;
  const source = data.provider === 'nmc' ? `中央气象台${station ? ` · ${escape(station)}` : ''}区域资料` : data.provider === 'open-meteo' ? 'Open-Meteo · 所选位置的模型天气' : '本次会话取得的天气资料';
  return `<div class="weather-provenance"><p>${source}</p><dl><div><dt>${state.place?.source === 'location' ? '定位地区' : '手选地区'}</dt><dd>${escape(weatherPlaceLabel(state.place))}</dd></div><div><dt>天气资料时间</dt><dd>${published}</dd></div><div><dt>${validTime(checked) ? '最近查询成功' : '资料获取时间'}</dt><dd>${weatherTime(validTime(checked) ? checked : data.updatedAt)}</dd></div></dl><small>时间均为北京时间${data.provider === 'nmc' ? ' · 区域站点资料会与具体位置有差异' : ''}</small></div>`;
}
function refreshFeedback() {
  if (state.loading) return `<p class="weather-progress" role="status">${escape(state.phase || '正在更新天气…')}${state.weather ? '<br><small>本次查询完成前保留当前画面</small>' : ''}</p>`;
  if (state.refreshNotice) return `<p class="weather-refresh-note ${state.refreshOutcome === 'failed' ? 'is-warning' : ''}" role="status">${escape(state.refreshNotice)}</p>`;
  if (state.weather && isWeatherStale(state.weather)) return '<p class="weather-refresh-note is-warning">资料较早，刷新可检查来源是否有更新。</p>';
  return '';
}
export function recentLocationCandidate(status, now = Date.now()) {
  const fix = status?.candidate;
  if (!fix || typeof fix.locatedAt !== 'number' || !Number.isFinite(fix.locatedAt)) return null;
  const age = now - fix.locatedAt;
  if ((age <= 120000 && fix.selectable !== true && !fix.awaitedGps) || age < 0 || age > 600000 || typeof fix.accuracyMeters !== 'number' || !Number.isFinite(fix.accuracyMeters) || fix.accuracyMeters <= 0 || fix.accuracyMeters > 20000) return null;
  return { ...fix, minutes: Math.max(0, Math.floor(age / 60000)) };
}
function locationPending() { return state.locationStatus?.status === 'permission-pending' || state.locationStatus?.phase === 'locating'; }
function canChooseCandidate() {
  const status = state.locationStatus;
  if (!status || !['waiting','timeout','providers-failed','cancelled'].includes(status.status)) return false;
  return !state.loading || (status.phase === 'locating' && status.status === 'waiting');
}
function locationStatusPanel() {
  const status = state.locationStatus;
  if (!state.native || !status || !status.phase || status.phase === 'idle') return '';
  const pending = locationPending(), candidate = recentLocationCandidate(status);
  const providerNames = new Map([['gps','GPS'], ['network','网络定位'], ['fused','融合定位']]);
  const permissionLabels = {none:'尚未允许位置权限', approximate:'已允许大致位置', precise:'已允许精确位置'};
  const permission = Object.prototype.hasOwnProperty.call(permissionLabels, status.permission) ? permissionLabels[status.permission] : '位置权限待确认';
  const titles = {
    'permission-pending':'等待位置授权', 'permission-denied':'尚未取得位置权限', preparing:'正在准备定位', waiting:'正在等待手机返回位置',
    'checking-candidate':'正在确认所选位置', current:'已获取位置', recent:'正在使用近期位置', timeout:'手机暂未返回新位置', 'service-off':'手机定位服务未开启',
    'no-provider':'暂时没有可用的定位方式', 'providers-failed':'暂时无法获取位置', cancelled:'已暂停定位', idle:'位置状态'
  };
  const title = Object.prototype.hasOwnProperty.call(titles, status.status) ? titles[status.status] : '位置状态';
  const service = typeof status.serviceEnabled === 'boolean' ? `手机定位${status.serviceEnabled ? '已开启' : '未开启'}` : '手机定位状态待确认';
  const recovery = !pending && !['ready', 'idle'].includes(status.phase);
  return `<section class="weather-location-status" aria-label="位置状态"><div class="weather-location-heading"><span class="weather-location-dot ${pending ? 'is-waiting' : ''}" aria-hidden="true"></span><strong>${title}</strong></div><p class="weather-location-checks">${permission} · ${service}</p>${status.detail ? `<p class="weather-location-detail">${escape(status.detail)}</p>` : ''}
    ${status.phase === 'locating' ? '<button type="button" class="text-button" data-weather-action="cancel-locate">停止等待</button>' : ''}
    ${candidate && canChooseCandidate() ? `<button type="button" class="weather-recovery" data-weather-action="use-recent-location" data-weather-candidate="${escape(candidate.id || '')}">${candidate.district ? `查看${escape(candidate.district)}的天气` : '用这个位置查天气'} <span aria-hidden="true">›</span></button><p class="weather-location-hint">${candidate.minutes ? `${candidate.minutes} 分钟前` : '刚刚'} · ${providerNames.get(candidate.provider) || '手机位置'} · 误差约 ${candidate.accuracyMeters < 1000 ? Math.round(candidate.accuracyMeters) + ' 米' : (candidate.accuracyMeters / 1000).toFixed(1) + ' 公里'}</p>` : ''}
    ${recovery && status.permission === 'none' ? '<button type="button" class="weather-recovery" data-weather-action="permissions">打开位置权限设置 ›</button>' : ''}
    ${recovery && status.permission !== 'none' && status.serviceEnabled !== false ? `<button type="button" class="weather-recovery" data-weather-action="locate-precise" ${state.loading ? 'disabled' : ''}>用 GPS 再试 <span aria-hidden="true">›</span></button><p class="weather-location-hint">点此可授权前台精确位置；靠近窗边或在室外更容易取得 GPS 位置。</p>` : ''}
    ${recovery && status.serviceEnabled === false ? '<button type="button" class="weather-recovery" data-weather-action="location-settings">手机定位设置 <span aria-hidden="true">›</span></button>' : ''}</section>`;
}
function weatherStatus() {
  const data = state.weather, look = data && weatherLook(data.code, data.isDay);
  const stale = isWeatherStale(data) || Boolean(state.error);
  const findingPlace = !data && locationPending();
  return `${data ? `<div class="weather-now"><span aria-hidden="true">${weatherSymbol(look.kind, data.isDay)}</span><strong>${Math.round(data.temperature)}<small>°C</small></strong><div><b>${escape(weatherPlaceLabel(state.place))}</b><p>${escape(data.conditionText || look.label)} · ${data.isDay ? "白天" : "夜晚"}</p></div></div>${stale ? '<p class="weather-help">上次获取的天气，请留意下方资料时间</p>' : ''}` : `<div class="weather-welcome"><span aria-hidden="true">${weatherSymbol('unknown')}</span><h3>${findingPlace ? "正在定位" : state.place ? escape(weatherPlaceLabel(state.place)) : "今日天气"}</h3><p>${findingPlace ? "取得位置后会自动查询天气" : state.place ? '查看所选地区的气温与风况' : '用当前位置或选一个城市查天气'}</p></div>`}
    ${state.place?.source === 'location' && !findingPlace ? `<p class="weather-location-meta">${escape(weatherLocationInfo(state.place))}</p>` : ''}${districtRecovery()}${weatherProvenance(data)}${data?.skyUnavailable ? '<p class="weather-help">站点只返回了部分实况，备用来源也未能补上晴雨。可以稍后刷新。</p>' : ''}${refreshFeedback()}${locationStatusPanel()}${windDetails(data)}${state.error ? `<p class="weather-error" role="status">${escape(state.error)}${weatherFailureReason(state.errorCode) ? `<br><small>${escape(weatherFailureReason(state.errorCode))}</small>` : ''}</p>${state.place?.source === 'location' ? '<button type="button" class="weather-recovery" data-weather-action="refresh-saved">仅按上次位置更新天气 <span aria-hidden="true">›</span></button>' : ''}` : ""}`;
}
export function weatherStrip() {
  const data = state.weather;
  const localDay = new Date().getHours() >= 6 && new Date().getHours() < 18;
  const look = data ? weatherLook(data.code, data.isDay) : { kind: 'unknown' };
  const old = isWeatherStale(data) || Boolean(state.error);
  const title = data ? `${escape(weatherPlaceLabel(state.place))} · ${Math.round(data.temperature)}°` : "今日天气";
  const description = data ? `${escape(data.conditionText || look.label)} · ${old ? '上次天气' : windSummary(data) || (data.isDay ? '白天' : '夜晚')}${state.loading ? ' · 更新中' : old ? '，轻点刷新' : ''}` : locationPending() ? '正在等待手机定位' : state.loading ? escape(state.phase || "正在查询天气…") : state.error ? "暂未获取天气 · 点此查看原因" : state.place ? `${escape(weatherPlaceLabel(state.place))} · 点此查询天气` : "开启定位，看看身边的晴雨";
  const waiting = state.loading || locationPending();
  const homeAction = state.place ? 'refresh-home' : 'locate-home';
  const homeLabel = waiting ? '查询中…' : state.place ? refreshLabel() : '定位看天气';
  return `<section class="weather-card ${old && data ? "is-stale" : ""}" aria-label="今日天气"><button type="button" class="weather-card-main" data-weather-action="open"><span class="weather-strip-icon" aria-hidden="true">${weatherSymbol(look.kind, data?.isDay ?? localDay)}</span><span><strong>${title}</strong><small>${description}</small>${data ? `<span class="weather-card-meta">${validTime(data.observedAt) ? `${weatherTime(data.observedAt, true)} 资料` : '来源未提供时间'}${state.loading ? ' · 显示上次资料' : !state.error && state.refreshOutcome === 'same' ? ' · 已查询，数据未变' : ''}</span>` : ''}</span><b aria-hidden="true">›</b></button>${alertSummary()}${!data ? `<div class="weather-card-actions"><button type="button" class="weather-enable" data-weather-action="${homeAction}" ${waiting ? "disabled" : ""}>${homeLabel}</button><button type="button" class="weather-city-link" data-weather-action="cities">手动选城市</button></div>` : ""}</section>`;
}
const paintedMarkup = new WeakMap();
function updateMarkup(element, markup) {
  if (paintedMarkup.get(element) === markup) return;
  element.innerHTML = markup;
  paintedMarkup.set(element, markup);
}
export function paintWeather() {
  const strip = document.querySelector("#weather-strip");
  if (strip) updateMarkup(strip, weatherStrip());
  const status = document.querySelector('#weather-status');
  if (status) updateMarkup(status, weatherStatus());
  const actions = document.querySelector('#weather-actions');
  if (actions) updateMarkup(actions, weatherActions());
  const credit = document.querySelector('#weather-credit');
  if (credit) updateMarkup(credit, weatherCredit());
  paintWeatherAlerts();
  const scene = document.querySelector(".mood-hero, .hero");
  if (!scene) return;
  const fresh = state.weather && !isWeatherStale(state.weather) && !state.error;
  const day = fresh ? state.weather.isDay : new Date().getHours() >= 6 && new Date().getHours() < 18;
  const look = fresh ? weatherLook(state.weather.code, day) : { kind: "none" };
  scene.classList.toggle("scene-night", !day);
  scene.dataset.weather = look.kind;
  const old = scene.querySelector(".weather-scene");
  const signature = `${effects}-${look.kind}-${day}`;
  if (old?.dataset.scene === signature) return;
  old?.remove();
  const layer = document.createElement("span");
  layer.className = `weather-scene weather-${look.kind} ${effects ? "" : "effects-off"}`;
  layer.dataset.scene = signature;
  layer.setAttribute("aria-hidden", "true");
  layer.innerHTML = `${['unknown','none'].includes(look.kind) ? '' : `<span class="sky-symbol">${["cloud","rain","snow","fog"].includes(look.kind) ? "☁" : day ? "☀" : "☾"}</span>`}${effects && ["rain", "snow"].includes(look.kind) ? Array.from({ length: 10 }, (_, index) => `<i style="--i:${index}">${look.kind === "snow" ? "✧" : ""}</i>`).join("") : effects && ["cloud", "fog"].includes(look.kind) ? '<span class="sky-cloud">☁</span>' : ""}`;
  scene.append(layer);
}
function weatherActions() {
  const action = state.place ? 'refresh' : 'locate';
  const label = state.place ? refreshLabel() : '定位看天气';
  const waiting = state.loading || locationPending();
  return `<div class="weather-actions"><button type="button" class="primary" data-weather-action="${action}" ${waiting ? 'disabled' : ''}>${waiting ? '查询中…' : label}</button><button type="button" class="secondary" data-weather-action="cities">选择区县</button></div>${state.place?.source === 'city' ? '<button type="button" class="text-button weather-switch-location" data-weather-action="locate">使用当前位置</button>' : state.place?.source === 'location' && !waiting ? '<button type="button" class="text-button weather-switch-location" data-weather-action="locate-precise">位置不准？用 GPS 重新定位</button>' : ''}`;
}
function showWeather(refresh = true) {
  ui.open("今日天气", `<div id="weather-status">${weatherStatus()}</div>
    <div id="weather-actions">${weatherActions()}</div>
    <div id="weather-alerts" tabindex="-1" aria-label="气象预警">${alertsSection()}</div>
    <details class="weather-settings"><summary>天气设置与数据来源</summary>
    <p class="weather-help">国内优先查中央气象台。站点缺少晴雨资料时，按该位置查询 Open-Meteo 的当前模型天气。默认使用大致位置，点“用 GPS 再试”时可授权前台精确位置；记录和照片不会发送给天气服务。北京区县边界取自 geoBoundaries / OpenStreetMap（ODbL 1.0）。</p>
    <p id="weather-location-help" class="weather-help" ${state.place?.source === 'location' ? '' : 'hidden'}>点“重新定位并刷新”会重新获取位置并联网查询。再次打开天气时会重新联网；定位已超过两分钟时会先重新定位。天气数据不保存在本机，来源资料可能不会随每次查询改变。</p>
    ${!state.native ? '<p class="weather-preview">浏览器仅预览界面。请安装安卓 App 使用定位、城市搜索和真实天气。</p>' : ""}
    <div class="weather-options"><button type="button" class="text-button" data-weather-action="permissions">位置权限设置</button><button type="button" class="text-button" data-weather-action="location-settings">手机定位设置</button></div>
    <button type="button" class="weather-toggle" data-weather-action="effects" role="switch" aria-checked="${effects}"><span><strong>天气氛围动效</strong><small>仅在顶部播放雨、雪和云朵</small></span><i aria-hidden="true"></i></button>
    <p id="weather-credit" class="weather-credit">${weatherCredit()}</p>
    <button type="button" class="text-button reminder-system" data-weather-action="disable" ${state.place ? "" : "hidden"}>关闭天气并清除已保存位置</button></details>`);
  if (refresh && state.native) { window.BearWeather.refreshNow?.(); refreshAlertsNow(); }
}
function cityRows(rows, type) {
  return rows.map((city, index) => `<button type="button" class="city-row" data-weather-city="${type}" data-city-index="${index}"><span><strong>${escape(city.districtName || city.name)}</strong><small>${escape(city.region)}</small></span><b aria-hidden="true">›</b></button>`).join("");
}
function showCities() {
  activeQuery = "";
  const region=state.place?.countryCode==='CN' ? state.place?.admin1 || '' : '';
  ui.open("选择城市或区县", `<p class="weather-help">${region ? `先显示${escape(region)}的可查询地区，可输入区县名继续查找。` : '输入城市或区县名查找，请留意同名地区的省份。'}选好后将改为手选地区，不再随定位自动切换。</p><form data-form="weather-search"><label for="weather-city">城市或区县</label><div class="city-search"><input id="weather-city" name="city" maxlength="80" minlength="2" placeholder="如：丰台区、昌平区、西安" required><button type="submit" class="secondary">搜索</button></div><p class="form-error" role="alert"></p></form><div id="weather-city-results" aria-live="polite"></div><p class="weather-help">常用城市</p><div class="popular-cities">${cityRows(popular, "popular")}</div><button type="button" class="text-button reminder-system" data-weather-action="open">‹ 返回天气</button>`);
  if (region && state.native) weatherSearch({elements:{city:{value:region}}});
}
export function weatherSearch(form) {
  if (!state.native) { ui.announce("安装安卓 App 后即可搜索城市并查询天气"); return; }
  activeQuery = form.elements.city.value.trim();
  const query = activeQuery;
  document.querySelector("#weather-city-results").innerHTML = '<p class="weather-progress">正在寻找城市…</p>';
  window.BearWeather.search(activeQuery);
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => {
    const results = document.querySelector("#weather-city-results");
    if (results && activeQuery === query) results.innerHTML = '<p class="weather-error">搜索较慢，请稍后重试或选择常用城市。</p>';
  }, 12000);
}
export function weatherClick(data) {
  if (data.weatherSourceUrl) {
    const url = weatherSourceUrl(data.weatherSourceUrl);
    if (!url) ui.announce('来源链接不可用');
    else if (window.BearApp?.openRecipeLink) { if (!window.BearApp.openRecipeLink(url)) ui.announce('暂时无法打开官方页面'); }
    else window.open(url, '_blank', 'noopener,noreferrer');
    return true;
  }
  if (alertsClick(data)) return true;
  if (data.weatherCity) {
    const city = (data.weatherCity === "popular" ? popular : cities)[Number(data.cityIndex)];
    if (!state.native) { ui.announce("请在安卓 App 中选择城市查询真实天气"); return true; }
    if (city) {
      const latitude = Number.isFinite(city.latitude) ? Math.round(city.latitude * 100) / 100 : undefined, longitude = Number.isFinite(city.longitude) ? Math.round(city.longitude * 100) / 100 : undefined;
      const same = city.nmcCode ? state.place?.nmcCode === city.nmcCode : Number.isFinite(latitude) && Number.isFinite(longitude) && state.place?.latitude === latitude && state.place?.longitude === longitude;
      state = { ...state, place: { ...city, latitude, longitude, source: 'city' }, locationStatus: null, weather: same ? state.weather : null, checkedAt: same ? state.checkedAt : 0, refreshNotice:'', refreshOutcome:'', loading: true, error: '', phase: '正在更新天气…' };
      syncAlertsPlace(state.place);
      window.BearWeather.select(JSON.stringify(city)); showWeather(false);
    }
    return true;
  }
  const action = data.weatherAction;
  if (!action) return false;
  if (action === "view-alerts") {
    showWeather();
    const panel = document.querySelector('#weather-alerts');
    panel?.focus({preventScroll:true});
    panel?.scrollIntoView({block:'start'});
  } else if (action === "open") showWeather();
  else if (action === "locate-home" || action === "refresh-home") {
    showWeather(false);
    if (state.loading || locationPending()) return true;
    if (state.native) {
      if (action === "refresh-home" && state.place) { window.BearWeather.refresh(); refreshAlertsNow(); }
      else window.BearWeather.locate();
    } else ui.announce("请在安卓 App 中授权定位，浏览器这里只展示界面");
  }
  else if (action === "cities") showCities();
  else if (action === "effects") {
    effects = !effects;
    try { localStorage.setItem("bear-weather-effects", effects ? "on" : "off"); } catch { }
    document.querySelector('[data-weather-action="effects"]')?.setAttribute("aria-checked", String(effects));
    paintWeather();
  } else if (!state.native) ui.announce("请安装安卓 App 使用定位和天气功能");
  else if (['locate', 'locate-precise', 'refresh', 'refresh-saved'].includes(action) && (state.loading || locationPending())) return true;
  else if (action === "locate") window.BearWeather.locate();
  else if (action === 'locate-precise') window.BearWeather.locatePrecise?.();
  else if (action === 'use-recent-location') {
    const candidate = recentLocationCandidate(state.locationStatus);
    if (!candidate) {
      ui.announce('这个位置已过时，请重新定位'); paintWeather();
    } else if (data.weatherCandidate && data.weatherCandidate !== candidate.id) {
      ui.announce('手机刚更新了位置，请查看新的位置'); paintWeather();
    } else if (canChooseCandidate()) {
      if (typeof window.BearWeather.useLocationCandidate === 'function') window.BearWeather.useLocationCandidate(candidate.id || '');
      else window.BearWeather.useRecentLocation?.();
    }
  }
  else if (action === 'cancel-locate') window.BearWeather.cancelLocate?.();
  else if (action === 'location-settings') window.BearWeather.locationSettings?.();
  else if (action === "refresh") window.BearWeather.refresh();
  else if (action === 'refresh-saved') window.BearWeather.refreshSavedPlace?.();
  else if (action === "permissions") window.BearWeather.settings();
  else if (action === "disable") { clearWeatherAlerts(); window.BearWeather.disable(); ui.announce("天气已关闭，已清除保存的位置和预警地区"); }
  return true;
}
