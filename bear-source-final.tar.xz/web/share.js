import { selectShareContent, shareText, normalizeShareSource } from "./share-core.js?v=38";
import { artMeta } from "./illustrations.js?v=38";
import {shareWeatherForDate} from './share-weather.js?v=38';
import {weatherSymbol} from './weather.js?v=38';
import {wrapShareText as wrapText,drawShareHeading,drawShareWeather} from './share-card-layout.js?v=38';
let ui, source, selection, prepared = null, currentPage = 0;
let weatherRequestPending=false,weatherRefreshFailed=false,weatherRequestTimer;
const escape = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[char]);
export function initSharing(callbacks) {
  ui = callbacks;
  window.bearShareResult = (message) => ui.announce(message);
  ui.sheet.addEventListener('change',event=>{
    if(event.target?.name!=='sharePhotos')return;
    const choices=ui.sheet.querySelector('[data-share-ledger-photos]');
    if(choices)choices.hidden=!event.target.checked;
  });
}
function currentWeather() {
  const status=shareWeatherForDate(source?.date,ui.weatherState?.() || {});
  if (weatherRequestPending) return {...status,report:null,reason:'正在查询天气；可以稍等，或直接分享记录。',canRefresh:false,loading:true};
  if (weatherRefreshFailed) return {...status,report:null,reason:'这次天气查询没有完成，可以重试或直接分享。',canRefresh:true,loading:false};
  return status;
}
function weatherStatusMarkup() {
  const status=currentWeather(),report=status.report;
  return `${report?`<div class="share-weather-detail"><p class="share-weather-location">${escape(report.location)}</p><div class="share-weather-overview"><span class="share-weather-symbol" aria-hidden="true">${weatherSymbol(report.kind,report.isDay)}</span>${report.temperature?`<strong>${escape(report.temperature)}</strong>`:''}<span>${escape(report.condition)}</span></div>${report.wind?`<p class="share-weather-wind">${escape(report.wind)}</p>`:''}<small>${escape(report.meta)}</small></div>`:''}<p class="photo-hint" role="status">${escape(status.reason)}</p>${status.canRefresh||status.loading?`<button type="button" class="text-button" data-share-action="weather-refresh" ${status.loading?'disabled':''}>${status.loading?'查询中…':report?'重新查询':'查询天气'}</button>`:''}`;
}
export function sharingWeatherChanged() {
  clearTimeout(weatherRequestTimer);weatherRequestPending=false;weatherRefreshFailed=false;
  const panel=ui?.sheet?.querySelector?.('[data-share-weather-status]');
  if (ui?.sheet?.open && ui.sheet.dataset.view==='share-options' && panel) panel.innerHTML=weatherStatusMarkup();
}
function requestShareWeather() {
  if(source?.mode!=='day'||!currentWeather().canRefresh)return;
  weatherRequestPending=true;weatherRefreshFailed=false;
  const panel=ui.sheet.querySelector('[data-share-weather-status]');if(panel)panel.innerHTML=weatherStatusMarkup();
  clearTimeout(weatherRequestTimer);
  const active=source;
  weatherRequestTimer=setTimeout(()=>{
    if(source!==active||!weatherRequestPending)return;
    weatherRequestPending=false;weatherRefreshFailed=true;
    const panel=ui.sheet.querySelector('[data-share-weather-status]');if(panel)panel.innerHTML=weatherStatusMarkup();
  },20000);
  try { if(!ui.refreshWeather?.()){clearTimeout(weatherRequestTimer);weatherRequestPending=false;weatherRefreshFailed=true;if(panel)panel.innerHTML=weatherStatusMarkup();} }
  catch {clearTimeout(weatherRequestTimer);weatherRequestPending=false;weatherRefreshFailed=true;if(panel)panel.innerHTML=weatherStatusMarkup();}
}
export function showShareOptions(data, previousSelection = null) {
  clearTimeout(weatherRequestTimer);weatherRequestPending=false;weatherRefreshFailed=false;
  data=normalizeShareSource(data);
  source = data; prepared = null;
  const photoBills=(data.ledger||[]).filter(item=>item.id&&item.photos?.length);
  selection = previousSelection ? {ledgerPhotoIds:[],...previousSelection} : {ids:data.entries.map(item=>item.id),mood:Boolean(data.mood),photos:true,ledger:false,ledgerPhotoIds:photoBills.map(item=>item.id),recipes:false,weather:data.mode==='day'};
  ui.open(data.mode === "recipe" ? "分享这道菜" : "分享这一天", `${data.mode==='day'?`<div class="share-day-heading"><strong>${escape(data.date)}</strong><span class="share-weekday">${escape(data.weekday)}</span></div><p class="share-subtitle">${escape(data.subtitle)}</p>`:`<p class="share-subtitle">${escape(data.title)}<br>${escape(data.subtitle)}</p>`}<p class="mood-rule">选好内容，先看看卡片长什么样。</p><form data-form="share-options">
    ${data.mode==='day'?`<section class="share-weather-option"><label class="checkbox"><input type="checkbox" name="shareWeather" ${selection.weather?'checked':''}>附上当天的天气与风况</label><div data-share-weather-status>${weatherStatusMarkup()}</div></section>`:''}
    ${data.mood ? `<label class="share-check"><input type="checkbox" name="shareMood" ${selection.mood ? "checked" : ""}><span><strong>这一天的心情 · ${escape(data.mood.name)}</strong><small>${escape(data.mood.copy)}</small></span></label>` : ""}
    ${data.entries.map(item=>`<label class="share-check"><input type="checkbox" name="shareEntry" value="${item.id}" ${selection.ids.includes(item.id) ? "checked" : ""}><span><strong>${escape(item.title)}</strong><small>${escape(item.label)}${item.photos?.length ? " · " + item.photos.length + " 张照片" : ""}</small></span></label>`).join("")}
    <div class="share-options"><label class="checkbox"><input type="checkbox" name="sharePhotos" ${selection.photos ? "checked" : ""}>包含所选记录与账单的生活照片</label>${data.entries.some(item=>item.recipe) ? `<label class="checkbox"><input type="checkbox" name="shareRecipes" ${selection.recipes ? "checked" : ""}>附上关联菜谱的食材和做法</label>` : ""}</div>
    ${photoBills.length?`<section class="share-ledger-photos" data-share-ledger-photos aria-labelledby="share-ledger-photos-title" ${selection.photos?'':'hidden'}><h3 id="share-ledger-photos-title">账单里的生活照片</h3><p class="photo-hint">吃过的美食、买到的喜欢，都能一起晒。每笔可单独选择，最多 5 张；只选照片不会附上金额和备注。</p>${photoBills.map(item=>`<label class="share-check share-bill-photo-choice"><input type="checkbox" name="shareLedgerPhotos" value="${escape(item.id)}" ${selection.ledgerPhotoIds.includes(item.id)?'checked':''}><span><strong>${escape(item.photoTitle||'生活照片')}</strong><small>${item.photos.length} 张照片</small><span class="share-bill-thumbnails" aria-hidden="true">${item.photos.slice(0,5).map(photo=>`<img src="${escape(photo)}" alt="" loading="lazy">`).join('')}</span></span></label>`).join('')}</section>`:''}
    ${data.ledger?.length?`<div class="share-options"><label class="checkbox share-money-option"><input type="checkbox" name="shareLedger" ${selection.ledger ? "checked" : ""}>附上当天 ${data.ledger.length} 笔账单明细</label><p class="photo-hint">金额和备注默认不分享；勾选后才会附上。交易截图凭证不会分享。</p></div>`:''}
    <p class="photo-hint">只生成你选择的内容；长内容自动分成多张卡片，最多 9 张。分享图片不会让对方访问你的本机数据。</p><p class="form-error" role="alert"></p><button type="submit" class="primary">生成分享预览</button></form>`);
  ui.sheet.dataset.view = "share-options";
  if(!previousSelection)requestShareWeather();
}
const loadImage = (url) => new Promise((resolve,reject) => { const image = new Image(); image.onload = () => resolve(image); image.onerror = () => reject(new Error("有一张照片未能生成，请取消包含照片后重试")); image.src = url; });
async function makeCards(content) {
  const pages = [], WIDTH = 720, MAX = 1800, PAD = 46;
  const art = artMeta(source.mode === "recipe" ? "kitchen" : "moments",source.title,source.mode === "recipe" ? 10 : null);
  const weatherSvg=content.weather?weatherSymbol(content.weather.kind,content.weather.isDay).replace('<svg ','<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" ').replaceAll('currentColor','#ab8051'):'';
  const [bears,symbol] = await Promise.all([loadImage(art.src),weatherSvg?loadImage('data:image/svg+xml;base64,'+btoa(weatherSvg)).catch(()=>null):Promise.resolve(null)]);
  let canvas, ctx, y;
  let footerLines=[],footerHeight=78,bodyLimit=MAX-96;
  function begin() {
    if (pages.length >= 9) throw new Error("内容超过 9 张卡片，请减少勾选的记录后重试");
    canvas = document.createElement("canvas"); canvas.width = WIDTH; canvas.height = MAX; ctx = canvas.getContext("2d");
    ctx.fillStyle = "#fff8ec"; ctx.fillRect(0,0,WIDTH,MAX);
    ctx.fillStyle = "#efd8be"; ctx.fillRect(0,0,WIDTH,12);
    y=drawShareHeading(ctx,content,bears,art);
    if(content.weather)y=drawShareWeather(ctx,content.weather,symbol,y);
    else {y+=10;ctx.strokeStyle='#e9ddce';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(PAD,y);ctx.lineTo(WIDTH-PAD,y);ctx.stroke();y+=26;}
    ctx.font='15px sans-serif';footerLines=content.weather?wrapText(ctx,'天气 · '+content.weather.meta,WIDTH-2*PAD):[];
    footerHeight=76+footerLines.length*22;bodyLimit=MAX-footerHeight-18;y+=15;
  }
  function end() {
    const height = Math.min(MAX,Math.max(410,y+footerHeight));
    ctx.fillStyle='#947e69';ctx.font='15px sans-serif';footerLines.forEach((line,index)=>ctx.fillText(line,PAD,height-footerHeight+30+index*22));
    ctx.fillStyle = "#a7896e"; ctx.font = "16px sans-serif"; ctx.fillText("熊熊宝典  ·  把小日子收好",PAD,height-31);
    ctx.textAlign = "right";ctx.fillText(String(pages.length+1),WIDTH-PAD,height-31);ctx.textAlign = "left";
    const result = document.createElement("canvas");result.width=WIDTH;result.height=height;result.getContext("2d").drawImage(canvas,0,0);
    pages.push(result.toDataURL("image/png")); canvas.width=0;canvas.height=0;
  }
  function space(height) { if(y+height>bodyLimit){end();begin();} }
  begin();
  for (const section of content.sections) {
    space(125); ctx.font="bold 25px sans-serif";
    const headings=wrapText(ctx,section.title,WIDTH-2*PAD);
    for (const line of headings) {space(35);ctx.font="bold 25px sans-serif";ctx.fillStyle="#805137";ctx.fillText(line,PAD,y);y+=35;}
    y+=5;ctx.font="22px sans-serif";
    const lines = section.text ? wrapText(ctx,section.text,WIDTH-2*PAD) : [];
    for(const line of lines) {space(34);ctx.font="22px sans-serif";ctx.fillStyle="#654a39";ctx.fillText(line,PAD,y);y+=34;}
    const photos=section.photos || [];
    for(let i=0;i<photos.length;i+=3) {
      space(205);const row=photos.slice(i,i+3), size=(WIDTH-2*PAD-20)/3;
      for(let j=0;j<row.length;j++) {
        const photo=await loadImage(row[j]), scale=Math.min(size/photo.width,178/photo.height), width=photo.width*scale,height=photo.height*scale,x=PAD+j*(size+10);
        ctx.save();ctx.beginPath();ctx.rect(x,y,size,178);ctx.clip();ctx.drawImage(photo,x+(size-width)/2,y+(178-height)/2,width,height);ctx.restore();
      }
      y+=192;
    }
    y+=22;if(y<bodyLimit-40){ctx.strokeStyle="#edddca";ctx.beginPath();ctx.moveTo(PAD,y);ctx.lineTo(WIDTH-PAD,y);ctx.stroke();y+=32;}
  }
  end();return pages;
}
export async function submitShare(form) {
  const values = new FormData(form);
  selection = {ids:values.getAll("shareEntry"),mood:values.has("shareMood"),photos:values.has("sharePhotos"),ledger:values.has("shareLedger"),ledgerPhotoIds:values.getAll('shareLedgerPhotos'),recipes:values.has("shareRecipes"),weather:values.has('shareWeather')};
  const content = selectShareContent({...source,weather:source.mode==='day'?currentWeather().report:null}, selection);
  if (!content.sections.length) throw new Error("至少选择一项要分享的内容");
  const button=form.querySelector('[type="submit"]');button.textContent="正在整理分享卡…";
  try {
    const pages = await makeCards(content), text = shareText(content);
    let token = "";
    if (window.BearShare) {
      const result=JSON.parse(window.BearShare.prepare(JSON.stringify(pages)));
      if(!result.ok) throw new Error(result.error || "分享图片暂时未能准备好");
      token=result.token;
    }
    const ledgerPhotoCount=selection.photos?(source.ledger||[]).filter(item=>selection.ledgerPhotoIds.includes(item.id)).reduce((sum,item)=>sum+Math.min(5,item.photos?.length||0),0):0;
    prepared={pages,text,token,weather:content.weather,ledgerPhotoCount};currentPage=0;showPreview();
  } finally {button.textContent="生成分享预览";}
}
function showPreview() {
  const native=Boolean(window.BearShare), count=prepared.pages.length;
  const albumAvailable=Boolean(window.BearShare?.saveToAlbum)&&(!window.BearShare.canSaveToAlbum||window.BearShare.canSaveToAlbum());
  ui.open("分享前看一眼", `<button type="button" class="day-back text-button" data-share-action="options">‹ 重新选择内容</button><p class="share-preview-note">${count > 1 ? `内容已分成 ${count} 张，分享时一起发送。` : "这就是对方会看到的分享卡。"}${prepared.ledgerPhotoCount?` 已包含 ${prepared.ledgerPhotoCount} 张账单生活照片。`:""}${selection.ledger ? " 已包含账单金额和备注。" : " 未包含账单金额和备注。"}${source.mode==='day'?(prepared.weather?' 已附天气和资料时间。':selection.weather?' 这次没有可用的当天资料，未附天气。':' 未附天气。'):''}</p>${source.mode==='day'?`<div class="share-day-heading share-preview-date"><strong>${escape(source.date)}</strong><span class="share-weekday">${escape(source.weekday)}</span></div>`:''}<div class="share-preview-frame"><img class="share-preview-image" src="${prepared.pages[currentPage]}" alt="${escape(source.title)}分享卡，第${currentPage+1}张"></div>
    ${count > 1 ? `<div class="photo-controls"><button type="button" class="secondary" data-share-action="previous" ${currentPage===0?"disabled":""}>‹ 上一张</button><span>${currentPage+1} / ${count}</span><button type="button" class="secondary" data-share-action="next" ${currentPage===count-1?"disabled":""}>下一张 ›</button></div>` : ""}
    <button type="button" class="primary share-send" data-share-action="send" ${native?"":"disabled"}>分享${count>1?`这 ${count} 张图片`:"图片"} · 选择微信</button><div class="share-secondary"><button type="button" class="secondary" data-share-action="save">${count>1?"保存当前这一张":"保存图片"}</button><button type="button" class="secondary" data-share-action="copy">复制文字</button></div>${albumAvailable?`<section class="share-status-help"><strong>想设为微信状态？</strong><p>先把${count>1?'当前这一张':'卡片'}存到相册，再到微信状态里从相册选择。若直接分享提示“获取资源失败”，请使用这个方式。</p><button type="button" class="secondary" data-share-action="album">保存到相册 · 用于微信状态</button><small>仅保存图片，不会替你发布状态。</small></section>`:''}<p class="photo-hint">${native?"将在系统分享面板中选择应用和联系人；如果没有微信，可保存图片后在微信发送。":"浏览器可预览、保存图片和复制文字；选择微信需要安装安卓 App。"}</p><details class="share-text"><summary>查看分享文字</summary><pre>${escape(prepared.text)}</pre></details>`);
  ui.sheet.dataset.view="share-preview";
}
export async function sharingClick(data) {
  const action=data.shareAction;
  if(!action) return false;
  if(action==='weather-refresh'){requestShareWeather();return true;}
  if(action==="options") {showShareOptions(source,selection);return true;}
  if(!prepared) return true;
  if(action==="previous"||action==="next") {currentPage=Math.max(0,Math.min(prepared.pages.length-1,currentPage+(action==="next"?1:-1)));showPreview();}
  if(action==="send" && window.BearShare) window.BearShare.share(prepared.token);
  if(action==='album' && window.BearShare?.saveToAlbum) window.BearShare.saveToAlbum(prepared.token,currentPage);
  if(action==="save") {
    if(window.BearShare) window.BearShare.save(prepared.token,currentPage);
    else {const link=document.createElement("a");link.href=prepared.pages[currentPage];link.download=`熊熊分享卡_${currentPage+1}.png`;link.click();}
  }
  if(action==="copy") {
    if(window.BearShare) window.BearShare.copy(prepared.text);
    else {await navigator.clipboard.writeText(prepared.text);ui.announce("分享文字已复制");}
  }
  return true;
}
