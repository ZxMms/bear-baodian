import {initGoldPrices,goldPricesClicked,refreshGoldPricesView} from './gold-prices.js?v=38';
import {pickImage} from './image-picker.js?v=38';
import {initSheetExperience,clearFormErrors,reportFormError} from './form-experience.js?v=38';
import {initRecipeImport,openRecipeImport,recipeImageChanged,recipeImportClicked,cancelRecipeImport} from './recipe-import.js?v=38';
import {xhsLink,recipeFromMeal,seasonalContext} from './food-core.js?v=38';
import {initStorageSettings,storageClicked,showStorageSettings} from './storage-settings.js?v=38';
import {icon} from './icons.js?v=38';
import {showExitConfirmation,exitConfirmationBack,destroyExitConfirmation} from './exit-confirm.js?v=38';
import {initMascotMotion} from './mascot-motion.js?v=38';
import {parseAmount} from './ledger-core.js?v=38';
import {initWorkbench,openSettings,openTools,openSearch,workbenchClicked,workbenchSubmitted,getPreferences,offerUndo,backupReminder} from './workbench.js?v=38';
import {initKitchen,kitchenClicked,kitchenSubmitted,kitchenChanged,openCooking,openMealPlanner,openCookingHistory,refreshKitchen,getMealPlan,addShoppingItems,mountKitchenTimer,refreshKitchenTimer} from './kitchen.js?v=38';
import {initPantry,openPantry,openEasyMeals,openPantryIntake,pantryClicked,pantrySubmitted,pantryChanged,refreshPantry,editorMarkup as effortEditor,readRecipeEffort,displaySummary as effortSummary} from './pantry.js?v=38';
import {initHappyBox,openHappyBox,openHappyBoxPicker,happyBoxClicked,happyBoxSubmitted,happyBoxChanged,refreshHappyBox} from './happy-box.js?v=38';
import {initGold,goldClicked,goldSubmitted,refreshGold,openGoldPurchase,refreshGoldView} from './gold.js?v=38';
import {initWishes,openWishes,wishesClicked,wishesSubmitted,wishesChanged,refreshWishes} from './wishes.js?v=38';
import {initMemories,openMagazine,openCapsules,openCapsule,editCapsule,openMemories,memoriesClicked,memoriesSubmitted,memoriesChanged,memoriesBack,capsuleIsHidden} from './memories.js?v=38';
import {initPhotoExperience,showPhotoViewer as fullscreenPhotos,photoExperienceBack,decoratePhotoEditor,photoExperienceClicked,photoExperienceChanged,photoData as preparePhoto,getPhotoQualityMode,coverStyle,openCoverFocusEditor} from './photo-experience.js?v=38';
import {initAudio, playEffect, openAudioSettings, audioClicked, submitAudio, audioHasChanges, stopAudio} from './audio-settings.js?v=38';
import {initReceipts, openReceipt, receiptChanged, receiptClick, cancelReceipt} from './receipt.js?v=38';
import {
  kinds, categories, foodIcons, moods, saveDailyMood, dateKey, fromKey, onDate, nextOccurrence,
  rankRecipes, openStore, loadAll, saveItem, saveMealWithRecipe, removeItem, getSound, setSound, getDateSettings, saveDateSettings,
  saveItemsAtomically,saveDraft,clearDraft,
} from "./model.js?v=38";
import { holidays, holidaySources, workModes, dayPolicy, lunarLabel, nextHoliday, daysBetween, countdownParts, repeatTypes, recurrenceFor, monthOccurrence, nextScheduledDate, ruleDescription, knownWorkDates } from "./calendar-tools.js?v=38";
import {holidayPickerMarkup,applyHolidayChoice,setHolidayMode,syncHolidayPicker,savedHolidayId} from './holiday-picker.js?v=38';
import { initWeather, weatherStrip, paintWeather, weatherClick, weatherSearch } from "./weather.js?v=38";
import { bindCalendarSwipe } from "./calendar-swipe.js?v=38";
import { initLedger, ledgerMarkup, dayLedgerMarkup, hasLedgerOn, ledgerOn, ledgerShareEntries, editLedger, ledgerChange, ledgerClick, ledgerBack, submitLedger,getLedgerRows,getLedgerCategories,reloadLedger,openLedger,ledgerGoodsReminders,ledgerReminderTarget,getLedgerDraftContext,refreshLedgerForm } from "./ledger.js?v=38";
import { initSharing, showShareOptions, sharingClick, submitShare, sharingWeatherChanged } from "./share.js?v=38";
import {shareDateLabel} from './share-core.js?v=38';
import {sharingWeatherState,refreshSharingWeather} from './weather.js?v=38';
import { bearArt, moodArt, bearScenes } from "./illustrations.js?v=38";
const APP_VERSION = "2.2.18";
const APP_BUILD = 38;

const app = document.querySelector("#app");
const sheet = document.querySelector("#sheet");
const toast = document.querySelector("#toast");
initSheetExperience(sheet);
const fmt = (date, options) => fromKey(date).toLocaleDateString("zh-CN", options);
const fullDate = (date) => fmt(date, { month: "long", day: "numeric", weekday: "long" });
const shortDate = (date) => fmt(date, { month: "numeric", day: "numeric" });
const today = () => dateKey();
const html = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
})[char]);
const newId = () => globalThis.crypto && crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2);

let page = "calendar";
let chosen = today();
let month = chosen.slice(0, 7);
let journalFilter = "all";
let foodFilter = "全部";
let entries = [];
let recipes = [];
let soundEnabled = true;
let formPhotos = [];
let busy = false;
let uploadTask = null;
let foodRecipeCover = "";
let recipeImportPhoto = "";
let toastTimer;
let recommendationOffset = 0;
let moodHistory = [];
let pendingMood = "";
let pendingMoodDate = "";
let lastToday = today();
let appReady = false;
let dateSettings = { paydayEnabled: true, paydayType: "last-workday", paydayDay: 25, paydayOverflow: "last", paydayTime: "09:00", holidayTime: "09:00", paydayMode: "official", paydayReminder: "off", holidayReminder: "off" };
let countdownTimer;
let initialDraft;
let lastEditorFocus=null;
let sheetOpener=null;
let dayScroll = 0;
let recipeDate=today(),formCoverFocus={x:50,y:50},photoQualityMode='standard',journalLimit=30,backupMarkup='';
let recipeImportContext=null,draftTimer,draftQueue=Promise.resolve(),restoringDraft=false;
const draftGenerations=new Map();
const pageScroll=new Map(),sheetHistory=[];
let returningSheet=false;
let moodResponseTimer;
let mascotMotion;
const reminderKinds = ["memo", "event", "anniversary", "capsule"];
const reminderChoices = [["off", "不提醒"], ["0", "当天"], ["1", "提前 1 天"], ["3", "提前 3 天"], ["7", "提前 7 天"]];

function reminderStatus() {
  try { return window.BearReminders ? JSON.parse(window.BearReminders.status()) : { native: false, enabled: false }; }
  catch { return { native: true, enabled: false, error: "暂时无法读取提醒状态" }; }
}
function syncReminders() {
  if (!window.BearReminders) return { native: false };
  try {
    const scheduled = entries.filter((item) => reminderKinds.includes(item.kind) && item.reminder).map((item) => ({
      id: item.id, kind: item.kind, title: item.title, date: item.date, ...nativeRule(recurrenceFor(item), item.date),
      days: item.reminder.days, time: item.reminder.time,
    }));
    scheduled.push(...automaticReminders(),...ledgerGoodsReminders());
    return JSON.parse(window.BearReminders.sync(JSON.stringify(scheduled)));
  } catch { return { error: "记录已保存，提醒未能设置，请重新打开应用" }; }
}
function reminderDescription(item) {
  if (!item.reminder) return "";
  return `${item.reminder.days ? `提前 ${item.reminder.days} 天` : "当天"} ${item.reminder.time} 提醒`;
}
function showReminderSettings() {
  const state = reminderStatus();
  open("熊熊提醒", `<div class="reminder-intro"><span aria-hidden="true">♧</span><h3>重要的小事，熊熊帮你记着</h3><p>纪念日、活动和备注可以设置通知栏提醒。</p></div>
    ${state.native ? `<div class="reminder-status"><strong>${state.enabled ? "通知已开启" : "通知尚未开启"}</strong><p>${state.enabled ? `已安排 ${state.scheduled || 0} 条提醒` : "允许通知后，才能在手机通知栏收到提醒。"}</p>
      ${!state.enabled ? '<button type="button" class="primary" data-action="enable-reminders">允许通知</button>' : ""}</div>
      <div class="reminder-status"><strong>${state.exact ? "按设定时间提醒" : "当前为普通提醒"}</strong><p>${state.exact ? "提醒使用手机本地时间，不需要联网。" : "普通提醒可能延后。允许“闹钟和提醒”后可按设定时间提醒。"}</p>
      ${!state.exact ? '<button type="button" class="secondary" data-action="exact-reminders">设置准时提醒</button>' : ""}</div>
      <p class="form-error">${html(state.error || "")}</p><button type="button" class="primary" data-action="test-reminder">发送测试通知</button>
      <button type="button" class="text-button reminder-system" data-action="reminder-system">系统通知设置 · 声音与显示</button>
      <p class="reminder-footnote">若收不到提醒，请检查手机的自启动和省电限制。强行停止应用后，需要重新打开一次。</p>` :
      '<p class="reminder-status">通知栏提醒需要安装安卓 App。这里可以预览界面、保存提醒设置，浏览器预览不会发送系统提醒。</p>'}`);
  sheet.dataset.view = "reminders";
}
function moodSprite(mood, date = null) {
  if (date) return moodArt(mood, date);
  return `<span class="mood-sprite mood-${mood}" role="img" aria-label="一二布布${moods[mood].name}的表情"></span>`;
}
function moodOn(date) { return moodHistory.find((item) => item.date === date); }
function moodRecord(date) {
  const item = moodOn(date);
  if (!item || !moods[item.mood]) return "";
  return `<button type="button" class="mood-record mood-bg-${item.mood}" data-mood-date="${date}">${moodSprite(item.mood, date)}<span><strong>${moods[item.mood].name}的一天</strong><small>${html(moods[item.mood].copy)}</small></span><span aria-hidden="true">›</span></button>`;
}
function showMood(date = today(), returnDate = "") {
  const item = moodOn(date);
  if (item) {
    open(`${date === today() ? "今天" : shortDate(date)}的心情`, `${returnDate ? `<button class="day-back text-button" type="button" data-day-back="${returnDate}">‹ 返回当天概览</button>` : ""}<div class="mood-detail mood-bg-${item.mood}"><button type="button" class="mood-companion" data-action="mood-response" aria-label="让熊熊回应一下">${moodSprite(item.mood, date)}<span class="mood-reply" aria-hidden="true">♡</span></button><h3>${moods[item.mood].name}</h3><p>${moods[item.mood].copy}</p><small>${date} · 已记录</small></div><p class="mood-rule">${date === today() ? "今天的心情已经收好，明天再来选一次吧。" : "这一天的心情，已经留在熊熊手账里。"} 轻点熊熊，它会回应你。</p>`);
    sheet.dataset.view = "mood";
    sheet.dataset.returnDay = returnDate;
    return;
  }
  if (date !== today()) { announce("只能记录今天的心情"); return; }
  pendingMood = "";
  pendingMoodDate = date;
  open("今天是什么心情？", `<p class="mood-rule">每天记录一次，确认后今天不能重选。</p><div class="mood-choices">${Object.entries(moods).map(([key, mood]) => `<button type="button" class="mood-choice" data-pick-mood="${key}" aria-pressed="false">${moodSprite(key)}<strong>${mood.name}</strong></button>`).join("")}</div>
    <p class="mood-selection" role="status">选一个最贴近此刻的心情吧。</p><p class="form-error" role="alert"></p><button type="button" class="primary" data-action="save-mood" disabled>确认并记录今天的心情</button>`);
}
async function confirmMood() {
  if (!pendingMood || busy) return;
  busy = true;
  const button = sheet.querySelector('[data-action="save-mood"]');
  button.disabled = true;
  try {
    const item = await saveDailyMood(pendingMoodDate, pendingMood);
    moodHistory = [...moodHistory, item];
    close(); render(); play("saved"); announce("今天的心情，熊熊收好啦", true);
    moodResponse();
  } catch (error) {
    if (error.name === "ConstraintError") {
      moodHistory = await loadAll("moods"); close(); render(); syncWidgets(); showMood(today());
    } else {
      sheet.querySelector(".form-error").textContent = error.message || "心情未能保存，请重试";
      button.disabled = false;
    }
  } finally { busy = false; }
}
function moodResponse() {
  const target = sheet.open ? sheet.querySelector(".mood-companion") : app.querySelector(".mood-companion");
  if (!target) return;
  clearTimeout(moodResponseTimer);
  target.classList.remove("is-responding");
  requestAnimationFrame(() => target.classList.add("is-responding"));
  moodResponseTimer = setTimeout(() => target.classList.remove("is-responding"), 1100);
}

function appInfo() {
  try { return window.BearApp ? JSON.parse(window.BearApp.info()) : null; } catch { return null; }
}
function showAbout() {
  const native = appInfo();
  open("关于熊熊宝典", `<div class="about-intro"><img src="assets/app-icon.png" class="app-identity-icon" alt="一二布布抱着手账本" width="68" height="68"><h3>熊熊宝典 ${APP_VERSION}</h3><p>把小日子，一页一页收好。</p></div><dl class="about-versions"><dt>安装版本</dt><dd>${native ? html(native.version) : "浏览器预览"}</dd><dt>界面版本</dt><dd>${APP_VERSION}</dd></dl>${native && native.build !== APP_BUILD ? '<p class="form-error">安装版本与界面版本不一致，请刷新界面后检查。</p>' : ''}<div class="kind-list about-shortcuts"><button type="button" data-storage-action="open">数据与备份<span aria-hidden="true">›</span></button><button type="button" data-action="audio-settings">熊熊音效 · 开关与试听<span aria-hidden="true">›</span></button><button type="button" data-action="bear-gallery">熊熊图库 · 36 幅插画<span aria-hidden="true">›</span></button><button type="button" data-weather-action="open">今日天气<span aria-hidden="true">›</span></button><button type="button" data-action="dates">假期、发薪与倒计时<span aria-hidden="true">›</span></button><button type="button" data-action="reminders">通知提醒<span aria-hidden="true">›</span></button></div><p class="weather-help">点击日历日期，可以查看当天手账正文、照片和心情。记录保存在本机。</p><button type="button" class="secondary" data-action="refresh-interface">刷新界面</button><p class="photo-hint">只重新加载界面，不清除记录、照片或心情。</p>`);
}

function paydayRule(settings = dateSettings) {
  return { type: settings.paydayType, day: Number(settings.paydayDay), overflow: settings.paydayOverflow, workMode: settings.paydayMode };
}
function nativeRule(rule, start) {
  return { annual: rule.type === "yearly", recurrence: rule.type, monthDay: rule.day || Number(start.slice(8)),
    overflow: rule.overflow || "last", workMode: rule.workMode || "official",
    workDates: rule.type === "last-workday" && rule.workMode !== "weekdays" ? knownWorkDates(start, rule.workMode || "official") : [] };
}
function automaticReminders() {
  const list = [];
  if (dateSettings.holidayReminder !== "off") for (const item of holidays.filter((item) => item.start >= today())) {
    list.push({ id: item.id, kind: "event", title: `${item.name}假期`, date: item.start, annual: false, days: Number(dateSettings.holidayReminder), time: dateSettings.holidayTime });
  }
  if (dateSettings.paydayEnabled && dateSettings.paydayReminder !== "off") {
    list.push({ id: "auto-payday", kind: "event", title: "发薪日", date: "1900-01-01", ...nativeRule(paydayRule(), "1900-01-01"), days: Number(dateSettings.paydayReminder), time: dateSettings.paydayTime });
  }
  return list;
}
function nextEntryDate(item) {
  let date = nextOccurrence(item, today());
  if (date === today() && item.countdown && recurrenceFor(item).type !== "none" && countdownParts(date, item.time || "00:00").done) {
    const tomorrow = fromKey(today()); tomorrow.setDate(tomorrow.getDate() + 1);
    date = nextOccurrence(item, dateKey(tomorrow));
  }
  return date;
}
function dateCards() {
  const cards = [];
  const holiday = nextHoliday(today());
  if (holiday) cards.push({ id: holiday.id, kind: "holiday", title: `${holiday.name}假期`, date: holiday.start, end: holiday.end, icon: "✦", caption: `${shortDate(holiday.start)}—${shortDate(holiday.end)} · 放假 ${daysBetween(holiday.start, holiday.end) + 1} 天` });
  else cards.push({ id: "holiday-unknown", kind: "unknown", title: "下一次法定假期", caption: "需更新下一年度放假安排", icon: "✦" });
  if (dateSettings.paydayEnabled) {
    const date = nextScheduledDate("1900-01-01", paydayRule(), today());
    cards.push({ id: date ? `auto-pay-${date.slice(0, 7)}` : "pay-unknown", kind: date ? "payday" : "unknown", title: "发薪日", date, icon: "¥", caption: date ? `${shortDate(date)} · ${ruleDescription(paydayRule())}` : "需更新调休数据后计算" });
  }
  const planned = entries.filter((item) => ["anniversary", "event"].includes(item.kind))
    .map((item) => ({ item, date: nextEntryDate(item) })).filter((item) => item.date)
    .sort((a, b) => a.date.localeCompare(b.date) || (a.item.time || "").localeCompare(b.item.time || ""));
  for (const { item, date } of planned) cards.push({ id: item.id, kind: "entry", title: item.title, date, time: item.time || "00:00", countdown: Boolean(item.countdown), icon: kinds[item.kind].icon, caption: `${shortDate(date)}${item.time ? " · " + item.time : ""} · ${kinds[item.kind].name}` });
  return cards;
}
function briefCountdown(card) {
  if (!card.date) return "待更新";
  if (card.kind === "holiday" && card.end < today()) return "假期已结束";
  if (card.kind === "holiday" && card.date <= today()) return `假期中 · 余 ${daysBetween(today(), card.end) + 1} 天`;
  if (card.countdown) {
    const parts = countdownParts(card.date, card.time);
    if (parts.done) return "已到时间";
    return parts.days ? `还有 ${parts.days} 天` : parts.hours ? `还有 ${parts.hours} 小时` : "不到 1 小时";
  }
  const gap = daysBetween(today(), card.date);
  return gap === 0 ? "就是今天" : gap < 0 ? `已经过去 ${-gap} 天` : `还有 ${gap} 天`;
}
function entryCountdown(item) {
  return item ? { id: item.id, kind: "entry", title: item.title, date: item.date, time: item.time || "00:00", countdown: Boolean(item.countdown), icon: kinds[item.kind].icon, caption: `${item.date}${item.time ? " · " + item.time : ""}` } : null;
}
function dateCardMarkup(card) {
  return `<button type="button" class="date-card" data-count-card="${card.id}"><span class="date-card-icon ${card.kind}" aria-hidden="true">${card.icon}</span><span><strong>${html(card.title)}</strong><small>${html(card.caption)}</small></span><b>${briefCountdown(card)}</b></button>`;
}
function showAllDates() {
  open("接下来，值得期待", `<div class="date-card-list">${dateCards().map(dateCardMarkup).join("")}</div><button type="button" class="primary day-add" data-action="new-countdown">＋ 新建倒计时</button><button type="button" class="text-button reminder-system" data-action="date-settings">发薪规则与假期提醒设置</button>`);
}
function showCountdown(card) {
  if (!card || card.kind === "unknown") { showDateSettings(); return; }
  const item = entryById(card.id);
  const precise = card.countdown;
  const holiday = holidays.find((value) => value.id === card.id);
  open(card.title, `<div class="countdown-detail"><span class="countdown-symbol" aria-hidden="true">${card.icon}</span><p>${html(card.caption)}</p><div id="countdown-value" class="countdown-value"></div><p>${card.kind === "payday" ? html(ruleDescription(paydayRule())) + (dateSettings.paydayType === "last-workday" ? " · " + html(workModes[dateSettings.paydayMode]) : "，固定日期不按节假日顺延") : holiday ? "按国务院公布的放假调休安排计算" : precise ? "按手机本地时间倒计时" : "记得留一点时间给这一天"}</p></div>
    ${card.kind === "payday" || holiday ? '<button type="button" class="secondary" data-action="date-settings">调整规则与通知提醒</button>' : `<button type="button" class="secondary" data-entry="${card.id}" data-occurrence="${card.date}">查看记录详情</button>`}
    ${item ? `<button type="button" class="text-button reminder-system" data-edit-entry="${item.id}">编辑日期与重复规则</button>` : ""}`);
  sheet.dataset.view = "countdown";
  const tick = () => {
    const value = sheet.querySelector("#countdown-value");
    if (!value) return;
    if (!precise) { value.textContent = briefCountdown(card); return; }
    const parts = countdownParts(card.date, card.time);
    value.innerHTML = parts.done ? "时间到啦" : `<strong>${parts.days}</strong>天 <strong>${String(parts.hours).padStart(2, "0")}</strong>时 <strong>${String(parts.minutes).padStart(2, "0")}</strong>分 <strong>${String(parts.seconds).padStart(2, "0")}</strong>秒`;
  };
  tick();
  if (precise) countdownTimer = setInterval(tick, 1000);
}
function ruleFields(rule, start, payday = false) {
  const types = payday ? { monthly: repeatTypes.monthly, "last-workday": repeatTypes["last-workday"] } : repeatTypes;
  return `<div class="repeat-fields" data-rule-fields><label for="repeat-type">${payday ? "发薪规则" : "重复规则"}</label><select id="repeat-type" name="repeatType">${Object.entries(types).map(([value, label]) => `<option value="${value}" ${rule.type === value ? "selected" : ""}>${label}</option>`).join("")}</select>
    <div data-rule-monthly ${rule.type !== "monthly" ? "hidden" : ""}><div class="form-row"><div><label for="month-day">每月几号</label><select id="month-day" name="monthDay">${Array.from({length:31}, (_,i) => `<option value="${i+1}" ${(rule.day || Number(start.slice(8))) === i+1 ? "selected" : ""}>${i+1} 号</option>`).join("")}</select></div><div><label for="month-overflow">当月没有这一天</label><select id="month-overflow" name="monthOverflow"><option value="last" ${rule.overflow !== "skip" ? "selected" : ""}>改为当月最后一天</option><option value="skip" ${rule.overflow === "skip" ? "selected" : ""}>跳过这个月</option></select></div></div><p class="photo-hint">固定日期不按节假日顺延。</p></div>
    <div data-rule-workday ${rule.type !== "last-workday" ? "hidden" : ""}><label for="work-mode">工作日怎么算</label><select id="work-mode" name="workMode">${Object.entries(workModes).map(([value, label]) => `<option value="${value}" ${(rule.workMode || "official") === value ? "selected" : ""}>${label}</option>`).join("")}</select><p class="photo-hint">国家调休计入周末补班；固定双休不计入补班；仅周一至周五不扣除节假日。按公司实际安排选择。</p></div>
    <p class="rule-preview" data-rule-preview role="status"></p></div>`;
}
function readRule(form) {
  return { type: form.elements.repeatType?.value || "none", day: Number(form.elements.monthDay?.value || 1), overflow: form.elements.monthOverflow?.value || "last", workMode: form.elements.workMode?.value || "official" };
}
function updateRulePreview(form) {
  if (!form?.elements.repeatType) return;
  const rule = readRule(form), start = form.dataset.form === "date-settings" ? "1900-01-01" : form.elements.date.value;
  form.querySelector('[data-rule-monthly]').hidden = rule.type !== "monthly";
  form.querySelector('[data-rule-workday]').hidden = rule.type !== "last-workday";
  const dateLabel = form.querySelector('label[for="date"]');
  if (dateLabel) dateLabel.textContent = ["monthly", "last-workday"].includes(rule.type) ? "从这一天起" : "日期";
  const dates = [];
  let from = today();
  for (let i = 0; i < 3; i++) {
    const date = nextScheduledDate(start, rule, from);
    if (!date) break;
    dates.push(date);
    const following = fromKey(date); following.setDate(following.getDate() + 1); from = dateKey(following);
    if (rule.type === "none") break;
  }
  const suffix = rule.type === "yearly" && start.endsWith("02-29") ? "；2 月 29 日只在闰年重复" : "";
  form.querySelector('[data-rule-preview]').textContent = dates.length ? `接下来：${dates.map((date) => date.replaceAll("-", "/")).join(" · ")}${suffix}` : rule.type === "last-workday" && rule.workMode !== "weekdays" ? "该年份调休安排未内置，更新后才能计算。" : "这个日期已过去，可以作为记录保存。";
}
function showDateSettings() {
  const options = (selected) => reminderChoices.map(([value, title]) => `<option value="${value}" ${String(selected) === value ? "selected" : ""}>${title}</option>`).join("");
  open("日子的小设置", `<form data-form="date-settings"><label class="checkbox"><input name="paydayEnabled" type="checkbox" ${dateSettings.paydayEnabled ? "checked" : ""}>显示发薪倒计时</label>
    ${ruleFields(paydayRule(), today(), true)}
    <div class="reminder-fields"><h3>发薪日提醒</h3><div class="form-row"><div><label for="pay-remind">提前多久</label><select id="pay-remind" name="paydayReminder">${options(dateSettings.paydayReminder)}</select></div><div><label for="pay-time">通知时间</label><input id="pay-time" name="paydayTime" type="time" value="${dateSettings.paydayTime}" required></div></div></div>
    <div class="reminder-fields"><h3>假期开始提醒</h3><div class="form-row"><div><label for="holiday-remind">提前多久</label><select id="holiday-remind" name="holidayReminder">${options(dateSettings.holidayReminder)}</select></div><div><label for="holiday-time">通知时间</label><input id="holiday-time" name="holidayTime" type="time" value="${dateSettings.holidayTime}" required></div></div></div>
    <p class="photo-hint">只在设置的提醒日通知，不会每天打扰。纪念日和其他活动可在各自的记录里设置重复规则。</p>
    <div class="calendar-source"><strong>已内置 2026、2027 年官方放假与补班安排</strong><p>来源：国务院办公厅 ${holidaySources[2026].document}、${holidaySources[2027].document}。未内置年份会提示更新，不推测调休日期。</p></div>
    <p class="form-error" role="alert"></p><button type="submit" class="primary">保存设置</button></form>`);
  updateRulePreview(sheet.querySelector("form"));
  initialDraft = draftSnapshot();
}
async function submitDateSettings(form) {
  const values = new FormData(form), rule = readRule(form);
  if (!["monthly", "last-workday"].includes(rule.type) || !workModes[rule.workMode]) throw new Error("请选择发薪日计算规则");
  const next = { paydayEnabled: values.has("paydayEnabled"), paydayType: rule.type, paydayDay: rule.day, paydayOverflow: rule.overflow, paydayMode: rule.workMode, paydayReminder: values.get("paydayReminder"), holidayReminder: values.get("holidayReminder"), paydayTime: values.get("paydayTime"), holidayTime: values.get("holidayTime") };
  if (![next.paydayReminder, next.holidayReminder].every((value) => reminderChoices.some(([key]) => key === value))) throw new Error("请选择正确的提醒方式");
  if (![next.paydayTime, next.holidayTime].every((value) => /^([01]\d|2[0-3]):[0-5]\d$/.test(value))) throw new Error("请填写正确的通知时间");
  await saveDateSettings(next);
  dateSettings = next;
  const result = syncReminders();syncWidgets();
  const enabled = (next.paydayEnabled && next.paydayReminder !== "off") || next.holidayReminder !== "off";
  close(); render(); showAllDates(); announce(result.error || (enabled && !result.native ? "设置已保存；系统通知需在安卓 App 中使用" : "日子的小设置已保存"));
  if (result.native && !result.enabled && !result.error && enabled) window.BearReminders.requestPermission();
}

function play(name) { playEffect(name); }
function announce(message, celebrated = false) {
  // Native dialog top layers cover body-level toasts, regardless of z-index.
  (sheet.open ? sheet : document.body).append(toast);
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2200);
  if (celebrated) {
    const heart = document.createElement("span");
    heart.className = "pop-heart";
    heart.textContent = "♥";
    heart.setAttribute("aria-hidden", "true");
    document.body.append(heart);
    setTimeout(() => heart.remove(), 780);
  }
}
function durableForm(){return sheet.querySelector('[data-form="entry"],[data-form="recipe"],[data-form="ledger"],[data-form="capsule"]');}
function durableKey(form=durableForm()){if(!form)return '';if(!form.dataset.draftKey)form.dataset.draftKey=`${form.dataset.form}:${form.dataset.id||newId()}`;return form.dataset.draftKey;}
function captureDurableDraft(){const form=durableForm();if(!form)return null;return {form:{...form.dataset},fields:[...form.elements].filter(x=>x.name&&x.type!=='file'&&!['submit','button'].includes(x.type)).map(x=>({name:x.name,type:x.type,value:x.value,checked:x.checked})),photos:[...formPhotos],foodRecipeCover,coverFocus:{...formCoverFocus},qualityMode:getPhotoQualityMode(form),context:form.dataset.form==='ledger'?getLedgerDraftContext():recipeImportContext,expanded:[...form.querySelectorAll('details')].map(x=>x.open),savedAt:Date.now()};}
function hasDraftChanges(){const next=draftSnapshot();return Boolean(initialDraft&&next&&JSON.stringify(initialDraft)!==JSON.stringify(next));}
function flushDurableDraft(){clearTimeout(draftTimer);if(restoringDraft||!hasDraftChanges())return Promise.resolve(true);const key=durableKey(),draft=captureDurableDraft(),generation=draftGenerations.get(key)||0;if(!draft)return Promise.resolve(true);const save=draftQueue.catch(()=>{}).then(async()=>{if(generation===(draftGenerations.get(key)||0))await saveDraft(key,draft);return true;});draftQueue=save.catch(()=>false);return save.catch(()=>{announce('草稿暂未写入，请先保存记录');return false;});}
function scheduleDraft(){clearTimeout(draftTimer);draftTimer=setTimeout(flushDurableDraft,550);}
async function clearCurrentDraft(form=durableForm()){clearTimeout(draftTimer);const key=durableKey(form);if(key)draftGenerations.set(key,(draftGenerations.get(key)||0)+1);await draftQueue;if(key)await clearDraft(key);initialDraft=null;}

async function restoreDurableDraft(draft){restoringDraft=true;try{const f=draft.form||{},old=f.id&&(f.form==='recipe'?recipeById(f.id):f.form==='ledger'?getLedgerRows().find(x=>x.id===f.id):entryById(f.id));if(f.id&&!old){announce('原记录已移入最近删除，请先恢复原记录再继续草稿');return;}if(f.form==='entry')editEntry(f.kind,old,null,false,f.returnDay||'');else if(f.form==='recipe')editRecipe(old,draft.context);else if(f.form==='ledger')editLedger(draft.context||old||null,draft.fields?.find(x=>x.name==='ledgerDate')?.value||today(),f.returnDay||'');else if(f.form==='capsule')editCapsule(old);else return;const form=durableForm();if(!form)return;Object.assign(form.dataset,f,{draftKey:draft.draftId});for(const desc of draft.fields||[]){if(!['ledgerType','type'].includes(desc.name))continue;for(const input of form.querySelectorAll(`[name="${CSS.escape(desc.name)}"]`)){if(input.type==='radio'||input.type==='checkbox')input.checked=input.value===desc.value&&desc.checked;else input.value=desc.value;if(input.checked||input.type!=='radio')ledgerChange(input);}}for(const desc of draft.fields||[]){for(const input of form.querySelectorAll(`[name="${CSS.escape(desc.name)}"]`)){if(input.type==='radio'){if(input.value===desc.value)input.checked=desc.checked;}else if(input.type==='checkbox')input.checked=desc.checked;else input.value=desc.value;}}formPhotos=[...(draft.photos||[])];foodRecipeCover=draft.foodRecipeCover||'';formCoverFocus=draft.coverFocus||{x:50,y:50};photoQualityMode=draft.qualityMode||'standard';showPhotoFields();if(form.elements.photoQuality)form.elements.photoQuality.value=photoQualityMode;updateFoodRecipeFields();updateRulePreview(form);syncHolidayPicker(form,today());updateCountdownFields(form);updateEntryDateContext(form);refreshLedgerForm(form);updateEntryLinkFields();[...form.querySelectorAll('details')].forEach((x,i)=>x.open=Boolean(draft.expanded?.[i]));if(form.elements.reminderDays&&form.elements.reminderTime)form.elements.reminderTime.disabled=form.elements.reminderDays.value==='off';initialDraft=null;announce('草稿已接着打开');}finally{restoringDraft=false;initialDraft=draftSnapshot();}}
async function refreshData(){const saved=await Promise.all([loadAll('entries'),loadAll('recipes'),loadAll('moods'),reloadLedger(),refreshGold()]);[entries,recipes,moodHistory]=saved;render();syncReminders();syncWidgets();}
function syncWidgets(){
  if(!appReady||!window.BearApp?.updateWidgets)return false;
  try{
    const base=today(),clean=(value,limit)=>String(value||'').replace(/[\u0000-\u001f\u007f]/g,' ').trim().slice(0,limit);
    const cards=dateCards().filter(card=>card.date),pinned=getPreferences().pinnedCountdownId;
    const paydayPinned=pinned==='auto-payday'||/^auto-pay-\d{4}-\d{2}$/.test(pinned||'');
    const selected=cards.find(card=>card.id===pinned||(paydayPinned&&card.kind==='payday'));
    const candidates=[],seen=new Set();
    const add=(card,date)=>{
      if(!date||date<base)return;
      const key=`${card.id||card.title}\0${date}`;if(seen.has(key))return;seen.add(key);
      candidates.push({id:String(card.id||''),title:clean(card.title,50),date,time:clean(card.time,8)});
    };
    // An automatic widget compares all upcoming series. Pinning limits it to one.
    for(const card of selected?[selected]:cards){
      add(card,card.date);
      const entry=entryById(card.id),repeat=entry&&recurrenceFor(entry).type!=='none';
      if(!repeat&&card.kind!=='payday')continue;
      let cursor=fromKey(card.date);
      for(let i=0;i<11;i++){
        cursor.setDate(cursor.getDate()+1);
        const next=repeat?nextOccurrence(entry,dateKey(cursor)):nextScheduledDate('1900-01-01',paydayRule(),dateKey(cursor));
        if(!next)break;add(card,next);cursor=fromKey(next);
      }
    }
    if(!selected)for(const holiday of holidays)add({id:holiday.id,title:`${holiday.name}假期`},holiday.start);
    candidates.sort((a,b)=>a.date.localeCompare(b.date)||a.time.localeCompare(b.time)||a.id.localeCompare(b.id));
    const countdowns=candidates.slice(0,selected?12:64).map(({title,date})=>({title,date}));
    const countdown=countdowns[0]||(selected?{title:clean(selected.title,50),date:selected.date}:null),days=[];
    for(let i=0;i<40;i++){
      const day=fromKey(base);day.setDate(day.getDate()+i);const date=dateKey(day);
      const items=entries.filter(entry=>onDate(entry,date)).map(entry=>({id:clean(entry.id,100),title:entry.kind==='capsule'?'时光胶囊到时间啦':clean(entry.title,60),time:clean(entry.time,8)}))
        .sort((a,b)=>a.time.localeCompare(b.time)||a.id.localeCompare(b.id)).slice(0,20);
      const lunar=lunarLabel(date),season=seasonalContext(date),dailyMood=moodHistory.find(item=>item.date===date);
      days.push({date,items,lunarLabel:clean(lunar.full.replace(/^农历.*?年\s*/,''),24),seasonLabel:season?`${season.name}${season.isTermDay?'':'时节'}`:'',moodLabel:moods[dailyMood?.mood]?.name||'',recordCount:Math.min(9999,entries.filter(entry=>onDate(entry,date)).length)});
    }
    const snapshot={countdown,countdowns,days,widgetTheme:getPreferences().widgetTheme||'cream'};let payload=JSON.stringify(snapshot);
    // Imported strings can expand when escaped; enforce the native bridge limit too.
    for(let limit=19;payload.length>190000&&limit>=0;limit--){for(const day of days)day.items=day.items.slice(0,limit);payload=JSON.stringify(snapshot);}
    const result=window.BearApp.updateWidgets(payload);
    return !result||JSON.parse(result).ok!==false;
  }catch{return false;}
}
async function widgetAction(action){if(!appReady||!action)return;if(busy||uploadTask){setTimeout(()=>widgetAction(action),250);return;}if(typeof action==='string'){try{action=JSON.parse(action);}catch{return;}}if(hasDraftChanges()){if(!durableForm()){requestClose(()=>widgetAction(action));return;}if(!await flushDurableDraft())return;announce('当前编辑已保存为草稿');}close();if(action.type==='entry'){chosen=today();editEntry('life');}else if(action.type==='weather')weatherClick({weatherAction:'open'});else if(action.type==='ledger')editLedger(null,today());else if(action.type==='cooking'){const r=recipeById(action.recipeId);if(r)openCooking(r);else announce('这道菜已移除，计时已结束');}else{switchPage('calendar');chosen=today();month=chosen.slice(0,7);render();showDaySheet();}}
function celebrate(kind){if(getPreferences().reducedMotion||matchMedia('(prefers-reduced-motion: reduce)').matches)return;document.querySelector('.save-celebration')?.remove();const el=document.createElement('div');el.className='save-celebration';el.innerHTML=bearArt(kind==='meal'?'kitchen':kind==='anniversary'?'moments':'daily',Date.now().toString(),'')+`<span>${kind==='meal'?'今天也有好好吃饭':kind==='anniversary'?'重要的日子，收好啦':'这件小事，熊熊记住啦'}</span>`;document.body.append(el);setTimeout(()=>el.remove(),1300);}
function entryLinkFields(item){if(item&&!['life','meal'].includes(item.kind))return '';const bill=getLedgerRows().find(x=>x.id===item?.ledgerId),missing=item?.ledgerId&&!bill;if(bill?.type==='income')return '<p class="entry-link-detail">已关联一笔收入。日期会同步，金额和分类请在账单详情里编辑。</p>';return `<section class="entry-link-fields">${missing?'<p class="photo-hint">关联账单在最近删除中。恢复后仍会关联；这次仅保存手账。</p>':`<label class="checkbox"><input type="checkbox" name="linkLedger" ${bill?'checked':''}>${bill?'同时更新关联花费':'同时记一笔花费'}</label><fieldset class="entry-ledger-inputs" ${bill?'':'hidden disabled'}><div class="form-row"><div><label>金额<input name="linkedAmount" type="text" inputmode="decimal" value="${bill?(bill.cents/100).toFixed(2):''}" placeholder="0.00"></label></div><div><label>分类<select name="linkedCategory">${getLedgerCategories().filter(c=>c.type==='expense').map(c=>`<option value="${c.id}" ${bill?.category===c.id?'selected':''}>${html(c.name)}</option>`).join('')}</select></label></div></div><p class="photo-hint">${bill?'金额只在账本计入一次。取消勾选会保留原账单；文字和照片分别编辑，日期保持一致。':'保存时一并创建账单，首次共用这组照片。金额只计入账本一次。'}</p></fieldset>`}</section>`;}
function updateEntryLinkFields(){const field=sheet.querySelector('.entry-ledger-inputs'),box=sheet.querySelector('[name="linkLedger"]');if(field&&box){field.hidden=!box.checked;field.disabled=!box.checked;}}
function head() {
  const sections = {
    calendar: ["熊熊宝典", "一二布布的日常手账"],
    journal: ["熊熊手账", "好日子和小事情"],
    recipes: ["熊熊厨房", "今天做什么好吃的"],
    ledger: ["熊熊账本", "把生活，记得明明白白"],
  };
  return `<header class="top"><div class="wordmark"><span class="brand">${icon('heart')}</span>
    <div><p>${sections[page][1]}</p><div class="title-row"><h1>${sections[page][0]}</h1></div></div></div>
    <div class="top-actions"><button type="button" class="sound" data-work-action="search" aria-label="搜索记录">${icon('search')}</button><button class="sound reminder-button" data-action="sound" aria-label="${soundEnabled ? "关闭音效" : "开启音效"}" aria-pressed="${soundEnabled}"><svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M11 4 5 8H2v8h3l6 4Z"/>${soundEnabled ? '<path d="M15 8a6 6 0 0 1 0 8M18 5a10 10 0 0 1 0 14"/>' : '<path d="m16 9 6 6m0-6-6 6"/>'}</svg></button><button type="button" class="sound" data-work-action="settings" aria-label="设置">${icon('settings')}</button></div>
  </header>`;
}
function navigation() {
  const links = [["calendar", "日历"], ["journal", "手账"], ["recipes", "菜谱"], ["ledger", "记账"]];
  return `<nav class="tabs" aria-label="主导航">${links.map(([key,title]) => `<button data-page="${key}" ${page === key ? 'aria-current="page"' : ""}><span>${icon(key)}</span>${title}</button>`).join("")}<button class="quick" data-action="${page === "recipes" ? "add-recipe" : page === "ledger" ? "add-ledger" : "choose-kind"}" aria-label="${page === "recipes" ? "新建菜谱" : page === "ledger" ? "添加账单" : "添加记录"}">${icon('plus')}</button></nav>`;
}
function empty(icon, title, copy) {
  return `<div class="empty"><span aria-hidden="true">${icon}</span><strong>${title}</strong><p>${copy}</p></div>`;
}
function imageMarkup(src, css, alt = "记录照片") {
  return (/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(src || "") || /^media\/[a-f0-9]{64}\.(jpg|png|webp|gif)$/.test(src || "")) ? `<img class="${css}" loading="lazy" src="${src}" alt="${alt}">` : "";
}
function kindIcon(kind){return icon({life:'journal',meal:'recipes',memo:'draft',anniversary:'heart',event:'calendar',capsule:'capsule'}[kind]||'heart');}
function entryCard(entry, occurrence = entry.date) {
  const kind = kinds[entry.kind];
  const hidden=capsuleIsHidden(entry);
  return `<button class="entry-card" data-entry="${entry.id}" data-occurrence="${occurrence}">
    <span class="entry-icon ${kind.color}" aria-hidden="true">${kindIcon(entry.kind)}</span>
    <span class="entry-text"><strong>${html(entry.title)}</strong><small>${[kind.name, entry.time, recurrenceFor(entry).type !== "none" ? ruleDescription(recurrenceFor(entry), entry.date) : "", entry.reminder ? "已设提醒" : ""].filter(Boolean).join(" · ")}</small></span>
    ${hidden?"":imageMarkup(entry.photos?.[0], "entry-thumb")}
    <span class="arrow" aria-hidden="true">›</span>
  </button>`;
}
function importantDays() {
  const all=dateCards(),pinned=all.find(x=>x.id===getPreferences().pinnedCountdownId||(getPreferences().pinnedCountdownId==='auto-payday'&&x.kind==='payday'));
  const cards = (pinned?[pinned,...all.filter(x=>x.id!==pinned.id&&["holiday","payday","unknown"].includes(x.kind))]:all.filter((card) => ["holiday", "payday", "unknown"].includes(card.kind))).slice(0, 2);
  return `<section class="important-days" aria-label="重要日子">${cards.map((card) => `<button type="button" data-count-card="${card.id}"><span>${card.kind === "payday" || card.id === "pay-unknown" ? "发薪日" : card.kind === "holiday" ? "下个假期" : html(card.title)}</span><strong>${briefCountdown(card).replace("还有 ", "").replace("假期中 · ", "")}</strong></button>`).join("")}<button type="button" data-action="dates"><span>我的倒计时</span><strong>查看 / 添加 ›</strong></button></section>`;
}
function monthCalendarMarkup() {
  const [year, monthNumber] = month.split("-").map(Number);
  const first = fromKey(month + "-01");
  const offset = (first.getDay() + 6) % 7;
  const days = new Date(year, monthNumber, 0).getDate();
  const markers = Array.from({ length: days }, (_, index) => {
    const key = month + "-" + String(index + 1).padStart(2, "0");
    const matches = entries.filter((entry) => onDate(entry, key));
    const pay = isPayday(key), money = hasLedgerOn(key);
    const colors = [...new Set([...matches.map((entry) => kinds[entry.kind].color), ...(pay ? ["amber"] : [])])].slice(0, 3);
    const highlight = key === chosen ? "selected" : key === today() ? "today" : "";
    const mood = moodOn(key);
    const lunar = lunarLabel(key), policy = dayPolicy(key);
    return `<button class="day ${highlight}" data-date="${key}" aria-haspopup="dialog" aria-pressed="${key === chosen}" aria-label="${fullDate(key)}，${lunar.full}${policy.holiday ? '，放假' : policy.work ? '，补班' : ''}${matches.length ? "，" + matches.length + "条记录" : ""}${pay ? "，发薪日" : ""}${money ? "，有账单" : ""}${mood ? "，心情" + moods[mood.mood].name : ""}">
      <span>${index + 1}</span><small class="lunar-day ${lunar.term ? 'solar-term' : ''}">${lunar.short}</small>${policy.holiday || policy.work ? `<i class="day-policy ${policy.work ? 'work' : ''}" aria-hidden="true">${policy.work ? '班' : '休'}</i>` : ''}<span class="dots" aria-hidden="true">${mood ? `<b class="mood-dot">${moods[mood.mood].icon}</b>` : ""}${money ? '<b class="ledger-dot">¥</b>' : ""}${colors.map((color) => `<i class="${color}"></i>`).join("")}</span>
    </button>`;
  }).join("");
  return `<section class="calendar card" aria-label="月历">
    <div class="calendar-head"><div><h2>${year} 年 ${monthNumber} 月</h2><button class="today-link" data-action="today">回到今天</button></div>
      <div class="month-controls"><button data-action="month-prev" aria-label="上个月">${icon("back")}</button><button data-action="month-next" aria-label="下个月">${icon("back","icon-forward")}</button></div>
    </div>
    <div class="week" aria-hidden="true">${["一", "二", "三", "四", "五", "六", "日"].map((day) => "<span>" + day + "</span>").join("")}</div>
    <div class="day-grid">${"<span></span>".repeat(offset)}${markers}${'<span class="day-empty" aria-hidden="true"></span>'.repeat(42 - offset - days)}</div>
    <p class="calendar-help">左右滑动切换月份 · 点日期查看记录</p>
  </section>`;
}
function calendarMarkup() {
  const daily = moodOn(today());
  return `<section class="mood-hero compact-hero page-hero ${daily?"mood-recorded":""} mood-bg-${daily?.mood || "calm"}"><div><p class="hero-tag">${fullDate(today())}</p><h2>${daily ? moods[daily.mood].name + "的一天" : "慢慢收集小日子"}</h2><p>${daily ? moods[daily.mood].copy : "今天的心情，也值得被记住。"}</p><button type="button" class="pill" ${daily ? `data-mood-date="${today()}"` : 'data-action="choose-mood"'}>${daily ? "今日心情 · 已记录 ›" : "选一个今日心情 ›"}</button></div><button type="button" class="mood-companion" data-action="mood-response" aria-label="让熊熊回应一下">${moodSprite(daily?.mood || "calm", today())}<span class="mood-reply" aria-hidden="true">♡</span></button></section>
  <div id="weather-strip">${weatherStrip()}</div>
  ${importantDays()}
${monthCalendarMarkup()}<div class="calendar-bottom"><button type="button" class="secondary" data-action="open-today">查看今天的手账</button><button type="button" class="text-button" data-action="choose-kind">＋ 写记录</button></div><button type="button" class="home-tools" data-work-action="tools">${icon("tools")}<span><strong>熊熊生活馆</strong><small>冰箱 · 开心盒 · 愿望小罐 · 更多</small></span><b>›</b></button>${backupMarkup}`;
}

function dayEntryPreview(item) {
  const type = kinds[item.kind], hidden=capsuleIsHidden(item),photos = hidden?[]:item.photos || [], note = hidden?"这封信还未到开启时间，熊熊替你收好了。":item.note || "";
  return `<article class="day-entry-preview"><button type="button" class="day-entry-heading" data-entry="${item.id}" data-occurrence="${chosen}"><span class="entry-icon ${type.color}" aria-hidden="true">${kindIcon(item.kind)}</span><span><strong>${html(item.title)}</strong><small>${type.name}${item.time ? " · " + item.time : ""}${recurrenceFor(item).type !== "none" ? " · " + ruleDescription(recurrenceFor(item), item.date) : ""}${item.reminder ? " · 已设提醒" : ""}</small></span><b aria-hidden="true">›</b></button>${note ? `<p class="day-entry-note">${html(note.length > 180 ? note.slice(0, 180) + "…" : note)}</p>` : ""}${photos.length ? `<div class="day-entry-photos">${photos.map((photo, index) => `<button type="button" data-photo-entry="${item.id}" data-photo-index="${index}" data-return-day="${chosen}" aria-label="放大${html(item.title)}的第 ${index + 1} 张照片">${imageMarkup(photo, "day-photo", `${html(item.title)} · 照片 ${index + 1}`)}</button>`).join("")}</div>` : ""}<button type="button" class="day-entry-more" data-entry="${item.id}" data-occurrence="${chosen}">查看完整记录 ›</button></article>`;
}
function isPayday(date) {
  return dateSettings.paydayEnabled && monthOccurrence(Number(date.slice(0, 4)), Number(date.slice(5, 7)), paydayRule()) === date;
}
function showDaySheet(restoreScroll = false) {
  const items = entries.filter((item) => onDate(item, chosen))
    .sort((a, b) => (a.time || "").localeCompare(b.time || "") || b.created - a.created);
  const selectedMood = moodOn(chosen);
  const ledgerCount = ledgerOn(chosen).length;
  const meals = items.filter((item) => item.kind === "meal").length;
  const special = items.filter((item) => ["anniversary", "event"].includes(item.kind)).length;
  const policy = dayPolicy(chosen);
  open(fullDate(chosen), `<div class="day-summary"><span>${chosen}</span><p class="day-lunar">${lunarLabel(chosen).full}${policy.holiday ? ` · ${policy.holiday.name}假期` : policy.work ? " · 调休补班" : ""}</p><strong>${chosen === today() ? "今天的小日子" : chosen > today() ? "留给未来的小计划" : "翻开这一天"}</strong><p>${items.length ? `${items.length} 条记录${meals ? ` · ${meals} 份美食` : ""}${special ? ` · ${special} 件重要的事` : ""}` : ledgerCount ? `${ledgerCount} 笔账单${selectedMood ? " · 一份心情" : ""}` : selectedMood ? "这一天，留下了一份心情" : "这一页，等你慢慢写"}</p></div>
    <div class="day-quick-actions"><button type="button" class="primary day-add" data-action="choose-kind">${icon('plus')} ${chosen > today() ? "添加安排" : "写记录"}</button><button type="button" class="secondary day-share" data-share-day="${chosen}">分享这一天</button></div>
    ${isPayday(chosen) ? `<button type="button" class="day-payday" data-action="date-settings"><span aria-hidden="true">¥</span><span><strong>这天发工资</strong><small>${ruleDescription(paydayRule())} · 点击调整</small></span><b aria-hidden="true">›</b></button>` : ""}
    ${items.length ? `<div class="day-sheet-list">${items.map(dayEntryPreview).join("")}</div>` : ""}
    ${moodRecord(chosen)}
    <section class="day-menu-section" data-day-meal-plan="${chosen}" aria-label="当天菜单"><p class="day-menu-loading">正在翻开这天的菜单…</p></section>
    ${chosen === today() && !selectedMood ? '<button type="button" class="daily-mood-prompt" data-action="choose-mood"><span aria-hidden="true">♡</span><span><strong>记下今天的心情</strong><small>每天一次，一二布布陪着你</small></span><b aria-hidden="true">›</b></button>' : ""}

    ${items.length || ledgerCount ? "" : `<div class="day-sheet-empty">${bearArt("daily",chosen,"empty-bears")}<p>${selectedMood ? "也可以写下今天发生的小事。" : "生活、美食、备注，都可以记在这里。"}</p></div>`}
    ${dayLedgerMarkup(chosen)}
`);
  sheet.dataset.view = "day";
  if (restoreScroll) sheet.querySelector(".sheet-content").scrollTop = dayScroll;
  loadDayMealPlan(sheet.querySelector('[data-day-meal-plan]'),chosen);
}
async function loadDayMealPlan(target,date) {
  if(!target)return;
  try {
    const menu=await getMealPlan(date);
    if(!target.isConnected||target.dataset.dayMealPlan!==date)return;
    const plans=menu.plans||[];
    target.innerHTML=`<div class="day-menu-heading"><div><small>计划吃什么</small><h3>这天的菜单</h3></div><button type="button" class="text-button" data-kitchen-action="planner" data-kitchen-date="${date}">${plans.length?'调整菜单':'安排一餐'} ›</button></div>${plans.length?`<div class="day-menu-list">${plans.map(plan=>`<article class="day-menu-item"><div><span class="day-menu-slot">${html(plan.mealName||'一餐')}</span><strong>${html(plan.title)}</strong><small>${plan.recipeId?'来自我的菜谱':'手写菜单'}</small></div><div class="day-menu-actions">${plan.recipeId?`<button type="button" class="secondary" data-kitchen-plan-cook="${html(plan.id)}" data-kitchen-date="${date}">开始做</button>`:''}<button type="button" class="text-button" data-kitchen-plan-log="${html(plan.id)}" data-kitchen-date="${date}">记美食</button></div></article>`).join('')}</div>`:'<p class="day-menu-empty">有想吃的菜，先给这一天留个位置。</p>'}`;
  } catch {
    if(target.isConnected&&target.dataset.dayMealPlan===date)target.innerHTML=`<p class="day-menu-empty">菜单暂时没能打开。</p><button type="button" class="text-button" data-day-plan-retry="${date}">重新打开菜单</button>`;
  }
}

function journalMarkup() {
  const buttons = [["all", "全部"], ["mood", "心情"], ...Object.entries(kinds).map(([key, kind]) => [key, kind.name])];
  const filtered = entries.filter((item) => journalFilter === "all" || item.kind === journalFilter)
    .sort((a, b) => b.date.localeCompare(a.date) || b.created - a.created);
  const days = new Map();
  for (const item of filtered) {
    if (!days.has(item.date)) days.set(item.date, []);
    days.get(item.date).push(item);
  }
  if (["all", "mood"].includes(journalFilter)) for (const item of moodHistory) if (!days.has(item.date)) days.set(item.date, []);
  return `<section class="journal-intro page-hero"><div><h2>日子里的小事</h2><p>${entries.length} 条记录 · ${moodHistory.length} 天心情</p></div>${bearArt("daily",today()+"journal","journal-bears")}</section>
    <div class="chips" aria-label="记录分类">${buttons.map(([key, label]) => `<button class="chip ${key === journalFilter ? "active" : ""}" data-journal-filter="${key}" aria-pressed="${key === journalFilter}">${label}</button>`).join("")}</div>
    ${days.size ? [...days.entries()].sort(([a], [b]) => b.localeCompare(a)).slice(0,journalLimit).map(([day, values]) => `<div class="section-title journal-date"><h2>${day.slice(0, 4)} 年 ${fullDate(day)}</h2></div>${["all", "mood"].includes(journalFilter) ? moodRecord(day) : ""}<div class="entry-list">${values.map((item) => entryCard(item)).join("")}</div>`).join("") :
      (journalFilter === "all" ? empty("✎", "还没有手账", "点下方加号，写下第一条记录。") : empty("✎", "这个分类还没有记录", "") + '<button type="button" class="secondary empty-reset" data-journal-filter="all">查看全部记录</button>')}${days.size>journalLimit?'<button type="button" class="secondary" data-action="more-journal">继续翻看更早的日子</button>':""}`;
}

function recipeMarkup() {
  const ranked = rankRecipes(recipes, entries, foodFilter, recipeDate);
  const pick = ranked[recommendationOffset % ranked.length],season=seasonalContext(recipeDate);
  const visible = recipes.filter((recipe) => foodFilter === "全部" || recipe.category === foodFilter)
    .sort((a, b) => Number(a.starter) - Number(b.starter) || (b.created || 0) - (a.created || 0) || a.title.localeCompare(b.title, "zh-CN"));
  return `<section class="kitchen-hero page-hero">
    <div><p class="hero-tag"><span>✦</span> 熊熊推荐</p><h2>${recipeDate===today()?"今天吃什么？":"这天吃什么？"}</h2><p>按节气、分类和美食记录帮你选。</p></div>
    ${bearArt("kitchen",today()+foodFilter,"kitchen-bears")}
  </section>
  <div class="recipe-date-tools"><label for="recipe-for-date">推荐日期</label><input id="recipe-for-date" type="date" data-recipe-date min="1900-01-01" max="2100-12-31" value="${recipeDate}">${recipeDate!==today()?'<button type="button" class="text-button" data-action="recipe-today">回到今天</button>':''}<button type="button" class="text-button recipe-planner-link" data-kitchen-action="planner" data-kitchen-date="${recipeDate}">一周菜单 ›</button></div>
  <div class="kitchen-quick-tools"><button type="button" data-pantry-action="open" data-pantry-date="${recipeDate}">${icon('recipes')}<span><strong>熊熊冰箱</strong><small>看看家里有什么</small></span></button><button type="button" data-pantry-action="easy" data-pantry-date="${recipeDate}">${icon('clock')}<span><strong>今天想省点力</strong><small>按时间与厨具选菜</small></span></button></div>
  ${season ? `<section class="seasonal-note seasonal-context" aria-label="时令菜谱灵感"><div class="seasonal-context-heading"><div><small>${recipeDate===today()?'此刻的时令':'所选日期的时令'}</small><h3>${season.isTermDay?(recipeDate===today()?'今日 · ':'当日 · '):''}${season.name}${season.isTermDay?'':'时节'}</h3></div><span class="seasonal-symbol" aria-hidden="true">${icon('recipes')}</span></div><p>${season.hint}</p><div class="seasonal-context-footer"><span>${shortDate(season.startDate)}—${shortDate(season.endDate)}</span><span>${recipeDate===today()?'':shortDate(recipeDate)+'起 '}${season.daysUntilNext} 天后${season.nextName} · ${shortDate(season.nextDate)}</span></div></section>` : '<p class="photo-hint">这个日期暂无节气信息，仍可按分类和已做记录选菜。</p>'}
  <div class="chips" aria-label="菜谱分类">${["全部", ...categories].map((category) => `<button class="chip ${category === foodFilter ? "active" : ""}" data-food-filter="${category}" aria-pressed="${category === foodFilter}">${category}</button>`).join("")}</div>
  ${pick ? `<section class="recommend card"><div><p class="suggestion-label">${shortDate(recipeDate)} · 菜谱灵感</p>
    <button class="recommend-link" data-recipe="${pick.recipe.id}"><span aria-hidden="true">${foodIcons[pick.recipe.category]}</span> ${html(pick.recipe.title)} <span aria-hidden="true">↗</span></button>
    <p class="reason">${pick.reason}</p></div><button class="secondary" data-action="reroll" ${ranked.length < 2 ? "disabled" : ""}>换一道</button></section>` : ""}
  <div class="section-title"><div><h2>我的菜谱</h2><p>${visible.length} 道菜</p></div><div class="recipe-create-actions"><button class="text-button" data-recipe-import="open">图片录入</button><button class="text-button" data-action="add-recipe">＋ 新菜谱</button></div></div>
  ${visible.length ? `<div class="recipes">${visible.map((recipe) => `<button class="recipe-card" data-recipe="${recipe.id}">
    <span class="recipe-picture cat-${categories.indexOf(recipe.category)}" style="${coverStyle(recipe.coverFocus)}">${imageMarkup(recipe.photos[0], "food-photo", "成品照片").replace('<img ',`<img style="${coverStyle(recipe.coverFocus)}" `) || bearArt("kitchen",recipe.id,"recipe-bears")}</span>
    <span class="recipe-copy"><strong>${html(recipe.title)}</strong><small>${recipe.category}${recipe.starter ? " · 示例菜谱" : ""}</small></span></button>`).join("")}</div>` :
    empty("♨", "这类菜谱还空着", "加一道自己的拿手菜吧。")+(foodFilter!=="全部"?'<button type="button" class="secondary empty-reset" data-food-filter="全部">查看全部菜谱</button>':'')}`;
}

function render() {
  const chips=app.querySelector('.chips'),chipLabel=chips?.getAttribute('aria-label'),chipScroll=chips?.scrollLeft||0;
  app.innerHTML = head() + `<div class="screen">${{ calendar: calendarMarkup, journal: journalMarkup, recipes: recipeMarkup, ledger: ledgerMarkup }[page]()}</div>` + navigation();
  const nextChips=app.querySelector('.chips');
  if(nextChips&&nextChips.getAttribute('aria-label')===chipLabel)nextChips.scrollLeft=chipScroll;
  paintWeather();
  mascotMotion?.refresh();
}
function focusSheetTarget(target,saved=null){
  if(!target?.isConnected||target.disabled||target.closest?.('[hidden],[inert]')||typeof target.focus!=='function')return false;
  if(target.getClientRects&&!target.getClientRects().length)return false;
  try{
    target.focus({preventScroll:true});
    if(saved?.selection&&typeof target.setSelectionRange==='function'){
      try{target.setSelectionRange(...saved.selection);}catch{}
    }
    if(saved){target.scrollTop=saved.scrollTop||0;target.scrollLeft=saved.scrollLeft||0;}
    return document.activeElement===target;
  }catch{return false;}
}
function captureSheetFocus(target=document.activeElement){
  if(!target||target===sheet||!sheet.contains(target))return null;
  const path=[];let node=target;
  while(node!==sheet){const parent=node.parentElement;if(!parent)return null;path.unshift([...parent.children].indexOf(node));node=parent;}
  const saved={path,tag:target.tagName,scrollTop:target.scrollTop||0,scrollLeft:target.scrollLeft||0};
  try{if(Number.isInteger(target.selectionStart)&&Number.isInteger(target.selectionEnd))saved.selection=[target.selectionStart,target.selectionEnd,target.selectionDirection||'none'];}catch{}
  return saved;
}
function sheetFocusTarget(saved){
  if(!saved?.path)return null;
  let target=sheet;for(const index of saved.path)target=target?.children?.[index];
  return target?.tagName===saved.tag?target:null;
}
function sheetSnapshot(){const clone=sheet.cloneNode(true),original=[...sheet.querySelectorAll('input,textarea,select')],copies=[...clone.querySelectorAll('input,textarea,select')];original.forEach((input,i)=>{const copy=copies[i];if(input.tagName==='TEXTAREA')copy.textContent=input.value;else if(input.tagName==='SELECT')[...copy.options].forEach(x=>{if(x.value===input.value)x.setAttribute('selected','');else x.removeAttribute('selected');});else{copy.setAttribute('value',input.value);if(input.checked)copy.setAttribute('checked','');else copy.removeAttribute('checked');}});return {title:sheet.querySelector('#sheet-title')?.textContent,html:clone.innerHTML,data:{...sheet.dataset},scroll:sheet.querySelector('.sheet-content')?.scrollTop||0,focus:captureSheetFocus(),editorFocus:captureSheetFocus(lastEditorFocus),baseline:initialDraft?JSON.parse(JSON.stringify(initialDraft)):null};}
function open(title, contents) {
  document.body.append(toast);
  destroyExitConfirmation();
  flushDurableDraft();
  if(!sheet.open)sheetOpener=app.contains(document.activeElement)?document.activeElement:null;
  const previousTitle=sheet.querySelector('#sheet-title')?.textContent;
  const returningToWeather = title === '今日天气' && ['选择天气城市','选择城市或区县','预警地区'].includes(previousTitle);
  if (returningToWeather && sheetHistory.at(-1)?.title === title) sheetHistory.pop();
  const leavingMealPlan=sheet.dataset.view==='kitchen-plan-edit';
  const leavingFeatureEditor=sheet.querySelector('[data-form="kitchen-shopping-edit"],[data-form="pantry-item"],[data-form="pantry-intake"],[data-form="pantry-plan-date"],[data-form="pantry-missing"],[data-form="happy-box-save"],[data-form="wish"],[data-form="wish-contribution"],[data-form="wish-complete"],[data-form="gold-goal"],[data-form="gold-purchase"]');
  if(leavingMealPlan&&title==='一周吃什么'&&sheetHistory.at(-1)?.data.view==='kitchen-planner')sheetHistory.pop();
  if(sheet.open&&!returningSheet&&!returningToWeather&&!durableForm()&&!leavingMealPlan&&!leavingFeatureEditor&&!['confirmation','pantry-delete','pantry-erase','happy-box-remove'].includes(sheet.dataset.view)&&previousTitle!==title){sheetHistory.push(sheetSnapshot());if(sheetHistory.length>15)sheetHistory.shift();}
  clearInterval(countdownTimer);
  initialDraft = null;lastEditorFocus=null;
  sheet.dataset.view = ["删除这份草稿？","永久删除？","删除这条记录？","删除这道菜谱？","删除这笔账？","把这封信移到最近删除？"].includes(title)?'confirmation':"";
  sheet.dataset.returnDay = "";
  sheet.dataset.photoId = "";
  sheet.dataset.photoStore = "";
  sheet.innerHTML = `<section class="sheet-content"><div class="sheet-header"><div class="sheet-grabber" aria-hidden="true"></div>${sheetHistory.length?`<button type="button" class="sheet-back" data-action="sheet-back" aria-label="返回上一页">${icon('back')}</button>`:''}<h2 id="sheet-title" tabindex="-1">${html(title)}</h2><button type="button" class="close" data-action="close" aria-label="关闭">${icon('close')}</button></div>${contents}</section>`;
  sheet.setAttribute("aria-labelledby", "sheet-title");
  if (!sheet.open) sheet.showModal();
  if (toast.classList.contains('show')) sheet.append(toast);
  // Announce a new sheet without raising the on-screen keyboard.
  focusSheetTarget(sheet.querySelector('#sheet-title'));
  sheet.querySelector(".sheet-content").scrollTop = 0;
}
function close() { document.body.append(toast);destroyExitConfirmation();lastEditorFocus=null;flushDurableDraft();stopAudio(); cancelReceipt(); cancelRecipeImport(); clearInterval(countdownTimer);const opener=sheetOpener;sheetOpener=null;sheet.close();sheet.replaceChildren();sheet.dataset.view="";sheetHistory.length=0;initialDraft=null;if(!app.contains(opener)||!focusSheetTarget(opener))focusSheetTarget(app.querySelector('.tabs [aria-current]')); }
function draftSnapshot() {
  const form = sheet.querySelector('[data-form="entry"], [data-form="recipe"], [data-form="capsule"], [data-form="date-settings"], [data-form="ledger"], [data-form="ledger-category"], [data-form="ledger-budget"], [data-form="ledger-period"], [data-form="preferences"], [data-form="kitchen-plan"], [data-form="kitchen-shopping-edit"], [data-form="pantry-item"], [data-form="pantry-intake"], [data-form="pantry-plan-date"], [data-form="pantry-missing"], [data-form="happy-box-save"], [data-form="wish"], [data-form="wish-contribution"], [data-form="wish-complete"],[data-form="gold-goal"],[data-form="gold-purchase"]');
  if(form?.dataset.form==='kitchen-plan')return {values:JSON.stringify([...form.elements].filter(input=>input.name).map(input=>({name:input.name,value:input.value,checked:input.checked})))};
  if(form&&durableForm())durableKey(form);
  return form ? { values: JSON.stringify([...new FormData(form)].filter(([name]) => !["photos","foodCoverFile"].includes(name))), photos: [...formPhotos], cover: foodRecipeCover,focus:JSON.stringify(formCoverFocus) } : null;
}
function restorePreviousSheet() {
  document.body.append(toast);
  const previous=sheetHistory.pop();initialDraft=previous.baseline||null;returningSheet=true;lastEditorFocus=null;
  sheet.innerHTML=previous.html;for(const key of Object.keys(sheet.dataset))delete sheet.dataset[key];Object.assign(sheet.dataset,previous.data);
  lastEditorFocus=sheetFocusTarget(previous.editorFocus);
  const content=sheet.querySelector('.sheet-content');content.scrollTop=previous.scroll;
  if(!focusSheetTarget(sheetFocusTarget(previous.focus),previous.focus))focusSheetTarget(sheet.querySelector('#sheet-title'));
  content.scrollTop=previous.scroll;returningSheet=false;
  if (toast.classList.contains('show')) sheet.append(toast);
  if(sheet.dataset.view==='gold-detail'||sheet.dataset.view==='gold-list'){returningSheet=true;try{refreshGoldView();}finally{returningSheet=false;}}
  refreshGoldPricesView();
  if(sheet.querySelector('#weather-status'))paintWeather();
  if(sheet.dataset.view==='day'){const target=sheet.querySelector('[data-day-meal-plan]');if(target)loadDayMealPlan(target,target.dataset.dayMealPlan);}
}
function requestClose(afterExit=null, leave=close) {
  const finish = () => {
    leave();
    if (typeof afterExit === 'function') Promise.resolve(afterExit()).catch(error=>announce(error.message||'页面暂时没有打开，请重试'));
  };
  const changed = hasDraftChanges();
  if (!changed && !audioHasChanges()) { finish(); return; }
  const form=sheet.querySelector('form');
  showExitConfirmation({canSaveDraft:Boolean(durableForm()),editingExisting:Boolean(form?.dataset.id)||!durableForm(),
    art:bearArt('daily','exit-confirm','',0),
    focusTarget:lastEditorFocus?.isConnected&&sheet.contains(lastEditorFocus)?lastEditorFocus:sheet.querySelector('[data-action="close"]'),
    region:sheet.querySelector('.sheet-content'),saveDraft:flushDurableDraft,discard:clearCurrentDraft,
    onExit:choice=>{initialDraft=null;finish();if(choice==='draft')announce('已留在我的草稿，下次接着写');}
  });
}
function goBackInSheet() {
  if(exitConfirmationBack())return;
  if(photoExperienceBack())return;
  if(hasDraftChanges()||audioHasChanges()){
    if(sheetHistory.length) requestClose(null, () => {
      stopAudio();
      cancelReceipt();
      cancelRecipeImport();
      restorePreviousSheet();
    });
    else requestClose();
    return;
  }
  if(sheetHistory.length){restorePreviousSheet();return;}
  if(memoriesBack())return;
  if (ledgerBack()) return;
  if (["photo", "entry", "mood", "ledger-detail"].includes(sheet.dataset.view) && sheet.dataset.returnDay) {
    chosen = sheet.dataset.returnDay; showDaySheet(true); return;
  }
  if (sheet.dataset.view === "photo") {
    const id = sheet.dataset.photoId, store = sheet.dataset.photoStore;
    if (store === "recipe") showRecipe(recipeById(id)); else showEntry(entryById(id));
    return;
  }
  requestClose();
}

function chooseKind() {
  const returnDay = sheet.dataset.view === "day" ? chosen : "";
  if(!returnDay)chosen=today();
  play("tap");
  open("想记点什么？", `<div class="kind-list">${Object.entries(kinds).map(([key, kind]) => `<button data-kind="${key}"><span class="entry-icon ${kind.color}" aria-hidden="true">${kindIcon(key)}</span>${kind.name}<span aria-hidden="true">›</span></button>`).join("")}</div>`);
  sheet.dataset.returnDay = returnDay;
}
function photoFields(limit, context = "") {
  return `<section class="photo-field" data-photo-context="${context}" aria-labelledby="photo-label">
    <div class="photo-heading"><span id="photo-label">${context === "wish" ? "愿望封面" : context === "ledger" ? "消费照片" : limit === 1 ? "菜谱封面" : "生活相册"}<small>选填</small></span><span class="photo-count" aria-live="polite"></span></div>
    <input name="photos" id="photos" type="file" accept="image/*" ${limit > 1 ? "multiple" : ""} data-limit="${limit}" hidden>
    <div class="photo-preview"></div><p class="photo-hint" role="status"></p>
  </section>`;
}
function showPhotoFields() {
  const field = sheet.querySelector(".photo-field");
  const preview = sheet.querySelector(".photo-preview");
  if (!field || !preview) return;
  const limit = Number(field.querySelector("input").dataset.limit);
  const cover = limit === 1, ledger = field.dataset.photoContext === "ledger", wish = field.dataset.photoContext === "wish";
  const processing = Boolean(uploadTask);
  const disabled = processing ? "disabled" : "";
  const camera = `<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M8 6 9.5 4h5L16 6h3a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h3Z"/><circle cx="12" cy="13" r="4"/></svg>`;
  field.classList.toggle("is-processing", processing);
  field.setAttribute("aria-busy", String(processing));
  field.querySelector(".photo-count").textContent = `${formPhotos.length} / ${limit}`;
  preview.className = `photo-preview ${formPhotos.length ? (cover ? "photo-cover" : "photo-grid") : "photo-blank"}`;
  if (!formPhotos.length) {
    preview.innerHTML = `<button type="button" class="photo-empty" data-action="add-photo" ${disabled} aria-label="${wish ? "添加愿望封面" : ledger ? "添加消费照片" : cover ? "添加菜谱封面" : "添加生活照片"}">
      <span class="photo-stamp" aria-hidden="true">${bearArt(ledger ? "moments" : cover ? "kitchen" : "daily",today()+(cover ? "cover" : "photo"),"stamp-bears")}<span>♡</span></span>
      <span class="photo-invitation"><strong>${wish ? "给愿望贴一张喜欢的照片" : ledger ? "今天吃了啥，买了啥？" : cover ? "给这道菜贴张封面" : "把这一刻贴进手账"}</strong><span>${wish ? "慢慢攒，离小心愿再近一点" : ledger ? "给这笔花费，留点看得见的回忆" : `和一二布布一起，收好${cover ? "美味" : "小日子"}`}</span><span class="photo-choose">${camera}${processing ? "正在整理照片…" : "从相册选择"}</span></span>
    </button>`;
  } else {
    preview.innerHTML = formPhotos.map((photo, index) => `<div class="photo-card">
      <button type="button" class="photo-edit-view" data-editor-photo="${index}" aria-label="预览第 ${index+1} 张照片">${imageMarkup(photo, "form-photo", wish ? "愿望封面预览" : cover ? "菜谱封面预览" : `第 ${index + 1} 张照片预览`)}</button>
      <span class="photo-number" aria-hidden="true">${wish ? "小小心愿" : cover ? "美味封面" : String(index + 1).padStart(2, "0")}</span>
      <button type="button" class="photo-remove" data-remove-photo="${index}" aria-label="${wish ? "移除愿望封面" : cover ? "移除菜谱封面" : `移除第 ${index + 1} 张照片`}" ${disabled}><span aria-hidden="true">×</span></button>
      ${cover ? `<button type="button" class="photo-replace" data-action="replace-photo" ${disabled}>${camera}换一张</button>` : ""}
    </div>`).join("");
    if (!cover && formPhotos.length < limit) preview.innerHTML += `<button type="button" class="photo-add" data-action="add-photo" ${disabled} aria-label="继续添加照片"><span aria-hidden="true">＋</span><span>再添一张</span></button>`;
  }
  field.querySelector(".photo-hint").textContent = processing ? "正在整理照片，请稍等…" :
    cover ? "封面铺满 · 可调整主体位置 · 点开查看完整画面" : ledger ? `最多 5 张 · 与截图凭证分开保存 · ${formPhotos.length === limit ? "已选满，移除后可更换" : "照片仅保存在本机"}` : `只存在你的手机里 · ${formPhotos.length === limit ? "已选满，移除后可换一张" : `最多放 ${limit} 张喜欢的瞬间`}`;
  decoratePhotoEditor(field,{cover,focus:formCoverFocus});
  const quality=field.querySelector('[name="photoQuality"]');if(quality)quality.value=photoQualityMode;
}
function choosePhotos(replace = false) {
  const input = sheet.querySelector('input[name="photos"]');
  if (!input || busy || uploadTask) return;
  input.dataset.replace = String(replace);
  pickImage(input,replace?1:Number(input.dataset.limit)-formPhotos.length);
}
function recipeOptions(selected) {
  return '<option value="">手动填写菜名</option>' + recipes.map((recipe) =>
    `<option value="${recipe.id}" ${recipe.id === selected ? "selected" : ""}>${html(recipe.title)}</option>`
  ).join("");
}
function xhsField(value='') {
  return `<label for="xhs-url">小红书链接或分享文案 <small>选填</small></label><textarea id="xhs-url" name="xhsUrl" rows="3" maxlength="12000" placeholder="整段粘贴即可，标题、链接、口令都可以保留">${html(value)}</textarea><p class="photo-hint">自动识别文案中的网址，保存后点「打开小红书笔记」查看。暂时没有网址也可以先保存。</p>`;
}
function xhsButton(value,raw=''){
  const url=xhsLink(value||raw);
  if(!url)return raw?'<p class="photo-hint">小红书文案已保留，可在编辑时补充链接。</p>':'';
  return `<button type="button" class="secondary xhs-link" data-xhs-url="${html(url)}"><span aria-hidden="true">↗</span> 打开小红书笔记</button>`;
}
function openXhs(value){
  const url=xhsLink(value);if(!url){announce('这段文案里还没有网址，可先编辑补充');return;}
  if(window.BearApp?.openRecipeLink){if(!window.BearApp.openRecipeLink(url))throw new Error('暂时无法打开，请检查分享链接是否完整');}
  else window.open(url,'_blank','noopener,noreferrer');
}
function foodFields(link,linked){
  return `${xhsField(link)}<section class="food-to-recipe"><label class="checkbox"><input type="checkbox" name="addToRecipes" ${linked?'disabled':''}>同时加入我的菜谱</label><p class="photo-hint food-link-hint">${linked?'已关联已有菜谱，不重复创建。可到菜谱详情编辑。':'只想记录吃过的美味？不勾选也可以直接保存。'}</p><fieldset class="food-recipe-details" hidden disabled><legend class="visually-hidden">新菜谱选填信息</legend><label for="food-category">菜谱分类</label><select id="food-category" name="foodCategory">${categories.map(category=>`<option ${category==='其他'?'selected':''}>${category}</option>`).join('')}</select><div class="food-cover-editor"></div><input id="food-cover-file" name="foodCoverFile" type="file" accept="image/*" hidden><label for="food-ingredients">食材 <small>选填</small></label><textarea id="food-ingredients" name="foodIngredients" maxlength="2000" rows="3" placeholder="例如：番茄 2 个、鸡蛋 2 个"></textarea><label for="food-steps">做法 <small>选填</small></label><textarea id="food-steps" name="foodSteps" maxlength="5000" rows="4" placeholder="今天先收藏，以后慢慢补步骤也可以"></textarea><p class="photo-hint">菜名和小红书链接沿用这条美食记录，照片可另选封面。</p></fieldset></section>`;
}
function updateFoodRecipeFields(){
  const form=sheet.querySelector('[data-form="entry"][data-kind="meal"]');if(!form)return;
  const linked=Boolean(form.elements.recipeId.value),checkbox=form.elements.addToRecipes,fields=form.querySelector('.food-recipe-details');
  checkbox.disabled=linked;fields.hidden=linked||!checkbox.checked;fields.disabled=fields.hidden;
  form.querySelector('.food-link-hint').textContent=linked?'已关联已有菜谱，不重复创建。可到菜谱详情编辑。':'只想记录吃过的美味？不勾选也可以直接保存。';
  renderFoodCover();
}
function renderFoodCover(){
  const host=sheet.querySelector('.food-cover-editor');if(!host)return;
  host.innerHTML=`<div class="photo-heading"><span>菜谱封面 <small>选填 · 自动铺满</small></span></div>${foodRecipeCover?`<div class="food-cover-preview">${imageMarkup(foodRecipeCover,'food-cover-image','菜谱封面铺满预览')}</div>`:'<p class="photo-hint">从本次照片中选一张，或单独选择封面。</p>'}${formPhotos.length?`<div class="food-cover-options">${formPhotos.map((photo,index)=>`<button type="button" data-food-cover="${index}" aria-label="将第 ${index+1} 张照片设为菜谱封面" aria-pressed="${foodRecipeCover===photo}">${imageMarkup(photo,'','候选封面 '+(index+1))}<span>${foodRecipeCover===photo?'已选':'选作封面'}</span></button>`).join('')}</div>`:''}<div class="food-cover-actions"><button type="button" class="secondary" data-action="food-cover-upload">${foodRecipeCover?'更换封面':'单独选择封面'}</button>${foodRecipeCover?'<button type="button" class="text-button" data-action="food-cover-clear">取消封面</button>':''}</div>`;
}
function updateEntryDateContext(form){
  if(form?.dataset.form!=='entry')return;
  const label=form.querySelector('.entry-date-context'),date=form.elements.date?.value;
  if(label&&date)label.innerHTML=`${icon('calendar')} ${date===today()?'记录今天':`正在记录 ${html(date)}`} · 可修改日期`;
}
function updateCountdownFields(form){
  if(form?.dataset.kind!=='event'||!form.elements.countdown)return;
  const enabled=form.elements.countdown.checked;
  form.elements.time.required=enabled;
  const label=form.querySelector('label[for="time"] small'),submit=form.querySelector('[type="submit"]');
  if(label)label.textContent=enabled?'倒计时必填':'选填';
  if(submit)submit.textContent=enabled?'保存倒计时':'保存活动';
}
function editEntry(kind, item, recipeId, countdown = false, returnDay = "") {
  if(kind==="capsule"){editCapsule(item);return;}
  const type = kinds[kind];
  const date = item?.date || returnDay || (recipeId?recipeDate:chosen);
  const recipe = recipes.find((row) => row.id === recipeId);
  const linkedRecipe = item?.recipeId || recipeId || "";
  const linkMissing = linkedRecipe && !recipes.some((row) => row.id === linkedRecipe);
  open(kind==='event'&&(item?.countdown||countdown)?(item?'编辑倒计时':'新建倒计时'):(item ? "编辑" : "记录") + type.name, `<form data-form="entry" data-kind="${kind}" data-id="${item?.id || ""}" data-return-day="${returnDay}">
    ${kind==='event'?holidayPickerMarkup(item,today()):''}
    <p class="entry-date-context">${icon("calendar")} ${date===today()?"记录今天":`正在记录 ${date}`} · 可修改日期</p>
    ${kind === "meal" ? `<label for="recipe-link">关联菜谱</label><select id="recipe-link" name="recipeId">${recipeOptions(linkMissing ? "" : linkedRecipe)}</select>` : ""}
    <label for="title">${kind === "meal" ? "菜名" : "标题"}</label><input id="title" name="title" value="${html(item?.title || recipe?.title || "")}" maxlength="60" placeholder="${{ life: "给这一天取个名字", meal: "今天吃到的美味", memo: "要记住的小事", anniversary: "想纪念的日子", event: "活动名称" }[kind]}" ${kind==="life"?"":"required"}>
    <div class="form-row"><div><label for="date">日期</label><input id="date" name="date" type="date" value="${date}" min="1900-01-01" max="9999-12-31" required></div>
      <div><label for="time">时间 <small>${item?.countdown || countdown ? "倒计时必填" : "选填"}</small></label><input id="time" type="time" name="time" value="${item?.time || ""}" ${item?.countdown || countdown ? "required" : ""}></div></div>
    ${reminderKinds.includes(kind) ? ruleFields(item ? recurrenceFor(item) : { type: kind === "anniversary" ? "yearly" : "none" }, date) : ""}${item && recurrenceFor(item).type !== "none" ? '<p class="photo-hint">这是重复记录，修改会应用于整个系列。</p>' : ""}
    ${kind === "event" ? `<label class="checkbox"><input type="checkbox" name="countdown" ${item?.countdown || countdown ? "checked" : ""}>显示精确到秒的倒计时</label><p class="photo-hint">选中后请填写时间，可在“接下来”中查看。</p>` : ""}
    ${reminderKinds.includes(kind) ? `<div class="reminder-fields"><div class="form-row"><div><label for="reminder-days">通知栏提醒</label><select id="reminder-days" name="reminderDays">${reminderChoices.map(([value, title]) => `<option value="${value}" ${(item?.reminder ? String(item.reminder.days) : "off") === value ? "selected" : ""}>${title}</option>`).join("")}</select></div>
      <div><label for="reminder-time">提醒时间</label><input id="reminder-time" type="time" name="reminderTime" value="${item?.reminder?.time || item?.time || "09:00"}" ${item?.reminder ? "required" : "disabled"}></div></div><p>在所选提醒日的这个时间通知你；通知内容不包含备注和照片。</p></div>` : ""}
    <label for="note">${kind === "life" ? "这一天的故事" : "备注"}</label><textarea id="note" name="note" maxlength="3000" rows="4" placeholder="写下想留住的细节…">${html(item?.note || "")}</textarea>
    ${photoFields(5)}${["life","meal"].includes(kind)?entryLinkFields(item):""}${kind === "meal" ? foodFields(item?.xhsText || item?.xhsUrl || recipe?.xhsText || recipe?.xhsUrl || "", linkedRecipe && !linkMissing) : ""}<p class="form-error" role="alert"></p><button type="submit" class="primary">保存${type.name}</button></form>`);
  formPhotos=[...(item?.photos||[])];foodRecipeCover="";formCoverFocus={x:50,y:50};photoQualityMode="standard";recipeImportContext=null;
  showPhotoFields();
  updateRulePreview(sheet.querySelector("form"));
  updateFoodRecipeFields();
  updateCountdownFields(sheet.querySelector('form'));
  initialDraft = draftSnapshot();
}
function editRecipe(recipe,imported=null) {
  open(imported ? "核对图片菜谱" : recipe ? "编辑菜谱" : "新建菜谱", `<form data-form="recipe" data-id="${recipe?.id || ""}" data-image-import="${Boolean(imported)}">
    ${imported ? `<div class="recipe-import-review"><strong>识别结果，请核对后保存</strong><p>菜名、分类、食材和做法都可以修改。</p>${imported.warnings.map(w=>`<p>${html(w)}</p>`).join('')}<details><summary>查看原图与识别文字</summary>${imageMarkup(imported.photo,'receipt-preview','原始菜谱截图')}<pre>${html(imported.raw||'未识别出文字')}</pre></details></div>` : ""}
    <label for="title">菜名</label><input id="title" name="title" maxlength="60" value="${html(recipe?.title || "")}" placeholder="这道菜叫什么？" required>
    <label for="category">分类</label><select id="category" name="category">${categories.map((category) => `<option ${(recipe?.category || (foodFilter === "全部" ? "面食" : foodFilter)) === category ? "selected" : ""}>${category}</option>`).join("")}</select>
    <label for="ingredients">食材 <small>选填</small></label><textarea id="ingredients" name="ingredients" rows="3" maxlength="2000" placeholder="写下用到的食材和分量">${html(recipe?.ingredients || "")}</textarea>
    <label for="steps">做法 <small>选填</small></label><textarea id="steps" name="steps" rows="4" maxlength="5000" placeholder="把步骤记下来，下次照着做">${html(recipe?.steps || "")}</textarea>
    ${effortEditor(recipe)}${xhsField(recipe?.xhsText || recipe?.xhsUrl || "")}${imported?'<label class="checkbox"><input type="checkbox" name="useRecipeScreenshot">将这张截图设为封面</label>':""}${photoFields(1)}${imported?'<label class="checkbox"><input type="checkbox" name="recipeReviewed" required>我已核对菜名、食材和做法</label>':""}<p class="form-error" role="alert"></p><button type="submit" class="primary">保存菜谱</button></form>`);
  recipeImportPhoto=imported?.photo||"";recipeImportContext=imported;formPhotos=[...(recipe?.photos||[])];foodRecipeCover="";formCoverFocus=recipe?.coverFocus||{x:50,y:50};photoQualityMode="standard";
  showPhotoFields();
  updateRulePreview(sheet.querySelector("form"));
  initialDraft = imported?{values:"",photos:[],cover:"",focus:""}:draftSnapshot();
  if(imported)scheduleDraft();
}
function photoGallery(photos, id, store = "entry", returnDay = "") {
  return photos.length ? `<div class="photo-gallery${store === "recipe" ? " recipe-photo-gallery" : ""}">${photos.map((photo, index) => `<button type="button" class="gallery-photo" data-photo-${store}="${id}" data-photo-index="${index}" data-return-day="${returnDay}" aria-label="放大照片 ${index + 1}">${imageMarkup(photo, "detail-photo", "照片 " + (index + 1)).replace('<img ',`<img style="${store==='recipe'?coverStyle(recipeById(id)?.coverFocus):''}" `)}${store === "recipe" ? '<span class="recipe-photo-hint">查看完整图片 ↗</span>' : ""}</button>`).join("")}</div>` : "";
}
function showPhotoViewer(id,index,returnDay='',store='entry') {
  const item=store==='entry'?entryById(id):recipeById(id);
  if(!item?.photos?.length||capsuleIsHidden(item)){announce('这张照片暂时无法打开');return;}
  fullscreenPhotos({photos:item.photos,index,title:item.title});
}

function showEntry(item, occurrence, returnDate = "") {
  if(!item){announce("这条记录已移除，可到最近删除查看");return;}
  if(item.kind==="capsule"){openCapsule(item.id);return;}
  const visibleDate = occurrence || item.date;
  const collectible=['life','meal','memo'].includes(item.kind);
  open(item.title, `<article class="record-detail">${returnDate ? `<button type="button" class="day-back text-button" data-day-back="${returnDate}">‹ 返回当天概览</button>` : ""}
    <div class="record-detail-meta"><span class="record-kind-pill">${kinds[item.kind].name}</span><span>${html(visibleDate)} · ${fullDate(visibleDate)}${item.time ? " · " + item.time : ""}</span></div>
    ${recurrenceFor(item).type !== "none" ? `<p class="record-detail-note">${html(ruleDescription(recurrenceFor(item),item.date))}</p>` : ''}
    ${item.reminder ? `<p class="reminder-detail">${reminderDescription(item)}</p>` : ""}
    <div class="record-detail-body">${item.note ? `<p class="detail-text">${html(item.note)}</p>` : ""}${photoGallery(item.photos||[], item.id, "entry", returnDate)}</div>
    ${item.kind === "meal" ? xhsButton(item.xhsUrl,item.xhsText) : ""}
    ${item.countdown ? `<div class="record-main-actions"><button type="button" class="primary" data-count-card="${item.id}">${icon('clock')}<span>查看倒计时</span></button></div>` : ""}
    ${collectible||item.ledgerId||(item.kind==='meal'&&recipeById(item.recipeId))?`<div class="record-secondary-actions">${collectible?`<button type="button" class="secondary" data-happy-collect="${html(item.id)}">${icon('heart')}<span>放进开心盒</span></button>`:''}${item.kind==='meal'&&recipeById(item.recipeId)?`<button type="button" class="secondary" data-recipe="${html(item.recipeId)}"><span>查看关联菜谱</span></button>`:''}${item.ledgerId?`<button type="button" class="secondary" data-linked-ledger="${html(item.ledgerId)}"><span>${getLedgerRows().some(x=>x.id===item.ledgerId)?'查看这次花费':'查看关联账单'}</span></button>`:''}</div>`:''}
    <footer class="record-management"><button type="button" class="text-button" data-edit-entry="${item.id}">${icon('draft')}<span>编辑记录</span></button><button type="button" class="text-button danger" data-delete-entry="${item.id}">${icon('trash')}<span>删除</span></button></footer></article>`);
  sheet.dataset.returnDay = returnDate;
  sheet.dataset.view = "entry";
}
function showRecipe(recipe,targetDate=recipeDate) {
  if(!recipe){announce("这道菜已移除，可到最近删除查看");return;}
  const last = entries.filter((item) => item.kind === "meal" && item.recipeId === recipe.id && item.date <= today()).map((item) => item.date).sort().pop();
  open(recipe.title, `<article class="recipe-detail">
    <div class="recipe-detail-meta"><span class="recipe-category-pill">${html(recipe.category||'我的菜谱')}</span>${last?`<span>上次记录 · ${shortDate(last)}</span>`:''}</div>
    ${photoGallery(recipe.photos||[],recipe.id,"recipe")}
    ${effortSummary(recipe)}
    <div class="recipe-detail-body">
      ${recipe.ingredients?`<section class="recipe-detail-section recipe-ingredients-note"><h3>准备食材</h3><p class="detail-text">${html(recipe.ingredients)}</p></section>`:''}
      ${recipe.steps?`<section class="recipe-detail-section"><h3>做法</h3><p class="detail-text">${html(recipe.steps)}</p></section>`:''}
      ${!recipe.ingredients&&!recipe.steps?'<p class="recipe-details-empty">先收好这道菜，食材和做法可以慢慢补充。</p>':''}
    </div>
    ${xhsButton(recipe.xhsUrl,recipe.xhsText)}
    <p class="recipe-record-date">${icon('calendar')}<span>${targetDate===today()?'记录今天的美食':`记录日期 · ${html(targetDate)}`}<small>保存前可以调整日期</small></span></p>
    <section class="recipe-main-actions" aria-label="做菜与美食记录">
      <button type="button" class="primary" data-kitchen-cook="${html(recipe.id)}" data-kitchen-date="${targetDate}">${icon('recipes')}<span>开始做这道菜</span></button>
      <button type="button" class="secondary" data-log-meal="${html(recipe.id)}" data-record-date="${targetDate}">${icon('journal')}<span>记一份美食</span></button>
    </section>
    <div class="recipe-secondary-actions">
      <button type="button" data-kitchen-history="${html(recipe.id)}" aria-label="查看以前做过的成品">${icon('clock')}<span>成品记录</span></button>
      <button type="button" data-share-recipe="${html(recipe.id)}">${icon('share')}<span>分享这道菜</span></button>
    </div>
    <footer class="recipe-management">
      <button type="button" class="text-button" data-edit-recipe="${html(recipe.id)}">${icon('draft')}<span>编辑菜谱</span></button>
      <button type="button" class="text-button danger" data-delete-recipe="${html(recipe.id)}">${icon('trash')}<span>删除</span></button>
    </footer>
  </article>`);
}
function confirmDelete(store, id) {
  const isRecipe = store === "recipes";
  open(isRecipe ? "删除这道菜谱？" : "删除这条记录？",
    `<p class="detail-meta">${isRecipe ? "菜谱会移入最近删除，30 天内可以恢复。已经写进日历的美食记录会保留。" : "这条记录会移入最近删除，30 天内可以恢复。关联账单会保留。"}</p>
    <div class="sheet-actions"><button class="secondary" data-${isRecipe ? "recipe" : "entry"}="${id}">取消</button><button class="primary destructive" data-confirm-delete="${store}" data-id="${id}">确认删除</button></div>`);
}

async function photoData(file){return preparePhoto(file,{qualityMode:getPhotoQualityMode(durableForm())});}

function switchPage(next) {
  if (page === next) {
    window.scrollTo({top:0, behavior:getPreferences().reducedMotion || matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth'});
    return;
  }
  pageScroll.set(page, window.scrollY);
  page = next;
  render();
  window.scrollTo(0, pageScroll.get(next) || 0);
  if(!getPreferences().reducedMotion&&!matchMedia('(prefers-reduced-motion: reduce)').matches)app.querySelector('.screen').animate([{opacity:.55,transform:'translateY(5px)'},{opacity:1,transform:'translateY(0)'}],{duration:150,easing:'ease-out'});
}
function shareDay(date) {
  const mood=moodOn(date);
  showShareOptions({mode:"day",date,title:shareDateLabel(date),subtitle:lunarLabel(date).full,
    mood:mood ? moods[mood.mood] : null,
    entries:entries.filter(item=>onDate(item,date)&&!capsuleIsHidden(item)).map(item=>({...item,label:kinds[item.kind].name,recipe:item.recipeId ? recipeById(item.recipeId) : null})),
    ledger:ledgerShareEntries(date)});
}
function shareRecipe(recipe) {
  showShareOptions({mode:"recipe",title:recipe.title,subtitle:"熊熊的拿手菜 · "+recipe.category,
    entries:[{id:recipe.id,title:recipe.title,label:"菜谱",note:`食材\n${recipe.ingredients || "未填写"}\n\n做法\n${recipe.steps || "未填写"}`,photos:recipe.photos}],ledger:[]});
}
function showBearGallery() {
  open("一二布布的小图库", `<p class="mood-rule">36 幅不同的小场景，按页面、日期和心情搭配。是为熊熊宝典制作的主题插画。</p>${Object.entries(bearScenes).map(([group,names])=>`<h3 class="gallery-heading">${{daily:"日常陪伴",kitchen:"厨房里的幸福",moments:"值得记住的日子"}[group]}</h3><div class="bear-gallery">${names.map((name,index)=>`<div>${bearArt(group,"","",index)}<small>${name}</small></div>`).join("")}</div>`).join("")}`);
}
function changeMonth(delta) {
  const date = fromKey(month + "-01");
  date.setMonth(date.getMonth() + delta);
  if (date.getFullYear() < 1900 || date.getFullYear() > 9999) return;
  month = dateKey(date).slice(0, 7);
  chosen = month + "-01";
  recommendationOffset = 0;
  const calendar = app.querySelector(".calendar"), focused = document.activeElement?.dataset.action;
  if (!calendar) { render(); return; }
  const holder = document.createElement("div"); holder.innerHTML = monthCalendarMarkup();
  const next = holder.firstElementChild; calendar.replaceWith(next);
  if (!getPreferences().reducedMotion&&!matchMedia("(prefers-reduced-motion: reduce)").matches) next.querySelector(".day-grid").animate([
    { transform: `translateX(${delta > 0 ? 22 : -22}px)`, opacity: .55 }, { transform: "translateX(0)", opacity: 1 }
  ], { duration: 180, easing: "ease-out" });
  if (["month-prev", "month-next"].includes(focused)) next.querySelector(`[data-action="${focused}"]`).focus({preventScroll:true});
  document.querySelector("#month-change-status").textContent = `${date.getFullYear()}年${date.getMonth()+1}月`;

}
bindCalendarSwipe(app, { canStart: () => page === "calendar" && !sheet.open && !busy && !uploadTask, changeMonth });
function entryById(id) { return entries.find((row) => row.id === id); }
function recipeById(id) { return recipes.find((row) => row.id === id); }

document.addEventListener("click", async (event) => {
  const button = event.target.closest("button");
  if (!button || busy || uploadTask) return;
  const data = button.dataset;
  try {
    if(data.holidayMode||data.holidayPick){
      const form=sheet.querySelector('[data-form="entry"][data-kind="event"]');if(!form)return;
      if(data.holidayMode){setHolidayMode(form,data.holidayMode,today());return;}
      const holiday=applyHolidayChoice(form,data.holidayPick,today());
      if(!holiday){syncHolidayPicker(form,today());announce('这个假期已开始或暂不可选，请选择后续假期');return;}
      updateRulePreview(form);updateEntryDateContext(form);updateCountdownFields(form);
      focusSheetTarget(form.querySelector('[data-holiday-choice-summary]'));
      announce(`已选${holiday.name}假期，${holiday.start} 00:00 开始`);return;
    }
    if(Object.keys(data).some(key=>key.startsWith('work'))){if(sheet.querySelector('[data-form="preferences"]')&&hasDraftChanges()){requestClose(()=>workbenchClicked(data));return;}busy=true;await workbenchClicked(data);return;}
    if(photoExperienceClicked(data))return;
    if(data.editorPhoto!==undefined){fullscreenPhotos({photos:formPhotos,index:Number(data.editorPhoto)||0,title:'编辑中的照片'});return;}
    if(Object.keys(data).some(key=>key.startsWith('kitchen'))){busy=true;await kitchenClicked(data);return;}
    if(Object.keys(data).some(key=>key.startsWith('pantry'))){busy=true;await pantryClicked(data);return;}
    if(data.happyCollect){openHappyBoxPicker(data.happyCollect);return;}
    if(Object.keys(data).some(key=>key.startsWith('happy'))){busy=true;await happyBoxClicked(data);return;}
    if(data.marketAction){goldPricesClicked(data);return;}
    if(Object.keys(data).some(key=>key.startsWith('gold'))){busy=true;await goldClicked(data);return;}
    if(Object.keys(data).some(key=>key.startsWith('wish'))){busy=true;await wishesClicked(data);return;}
    if(Object.keys(data).some(key=>key.startsWith('memory'))){busy=true;await memoriesClicked(data);return;}
    if(data.linkedLedger){if(getLedgerRows().some(x=>x.id===data.linkedLedger))openLedger(data.linkedLedger);else announce('关联账单在最近删除中');return;}
    if(Object.keys(data).some(key=>key.startsWith("storage"))){busy=true;await storageClicked(data);return;}
    if (Object.keys(data).some(key=>key.startsWith("audio"))) { await audioClicked(data); return; }
    if (data.recipeImport) { await recipeImportClicked(data);return; }
    if (data.receiptAction) { await receiptClick(data); return; }
    if (data.shareDay) { shareDay(data.shareDay); return; }
    if (data.shareRecipe) { shareRecipe(recipeById(data.shareRecipe)); return; }
    if (data.shareAction) { busy=true; await sharingClick(data); return; }
    if (Object.keys(data).some(key => key.startsWith("ledger"))) { busy = true; await ledgerClick(data); return; }
    if (weatherClick(data)) return;
    if (data.page) { play("tap"); switchPage(data.page); return; }
    if (data.date) {
      chosen = data.date; recommendationOffset = 0; dayScroll = 0;
      for (const day of app.querySelectorAll("[data-date]")) {
        day.classList.toggle("selected", day.dataset.date === chosen);
        day.classList.toggle("today", day.dataset.date === today() && day.dataset.date !== chosen);
        day.setAttribute("aria-pressed", String(day.dataset.date === chosen));
      }
      showDaySheet(); return;
    }
    if(data.action==='recipe-today'){recipeDate=today();recommendationOffset=0;render();return;}
    if (data.journalFilter) { journalFilter = data.journalFilter;journalLimit=30; render(); return; }
    if (data.foodFilter) { foodFilter = data.foodFilter; recommendationOffset = 0; render(); return; }
    if (data.dayBack) { chosen = data.dayBack; showDaySheet(true); return; }
    if(data.dayPlanRetry){await loadDayMealPlan(sheet.querySelector('[data-day-meal-plan]'),data.dayPlanRetry);return;}
    if (data.photoEntry || data.photoRecipe) {
      if (sheet.dataset.view === "day") dayScroll = sheet.querySelector(".sheet-content").scrollTop;
      showPhotoViewer(data.photoEntry || data.photoRecipe, Number(data.photoIndex) || 0, data.returnDay || "", data.photoEntry ? "entry" : "recipe"); return;
    }
    if (data.countCard) { showCountdown(dateCards().find((item) => item.id === data.countCard) || entryCountdown(entryById(data.countCard))); return; }
    if (data.moodDate) {
      if (sheet.dataset.view === "day") dayScroll = sheet.querySelector(".sheet-content").scrollTop;
      showMood(data.moodDate, sheet.dataset.view === "day" ? chosen : ""); return;
    }
    if (data.pickMood) {
      pendingMood = data.pickMood;
      for (const choice of sheet.querySelectorAll("[data-pick-mood]")) {
        const selected = choice.dataset.pickMood === pendingMood;
        choice.setAttribute("aria-pressed", String(selected));
      }
      sheet.querySelector(".mood-selection").textContent = moods[pendingMood].copy;
      sheet.querySelector('[data-action="save-mood"]').disabled = false;
      return;
    }
    if (data.xhsUrl) { openXhs(data.xhsUrl); return; }
    if (data.foodCover !== undefined) { foodRecipeCover=formPhotos[Number(data.foodCover)]||"";renderFoodCover();return; }
    if (data.action === "food-cover-upload") { pickImage(sheet.querySelector('#food-cover-file'));return; }
    if (data.action === "food-cover-clear") { foodRecipeCover="";renderFoodCover();return; }
    if (data.kind) { editEntry(data.kind, null, null, false, sheet.dataset.returnDay); return; }
    if (data.entry) {
      if (sheet.dataset.view === "day") dayScroll = sheet.querySelector(".sheet-content").scrollTop;
      showEntry(entryById(data.entry), data.occurrence, sheet.dataset.view === "day" ? chosen : data.returnDay || ""); return;
    }
    if (data.recipe) { showRecipe(recipeById(data.recipe)); return; }
    if (data.editEntry) { const item = entryById(data.editEntry); editEntry(item.kind, item, null, false, sheet.dataset.returnDay); return; }
    if (data.editRecipe) { editRecipe(recipeById(data.editRecipe)); return; }
    if (data.logMeal) { editEntry("meal", null, data.logMeal,false,data.recordDate||recipeDate); return; }
    if (data.removePhoto !== undefined) { formPhotos.splice(Number(data.removePhoto), 1); const screenshotChoice=sheet.querySelector('[name="useRecipeScreenshot"]');if(screenshotChoice&&!formPhotos.includes(recipeImportPhoto))screenshotChoice.checked=false;showPhotoFields();renderFoodCover();scheduleDraft(); return; }
    if (data.deleteEntry) { confirmDelete("entries", data.deleteEntry); return; }
    if (data.deleteRecipe) { confirmDelete("recipes", data.deleteRecipe); return; }
    if (data.confirmDelete) {
      busy = true;
      await removeItem(data.confirmDelete, data.id);
      if (data.confirmDelete === "entries") entries = entries.filter((item) => item.id !== data.id);
      else recipes = recipes.filter((item) => item.id !== data.id);
      const reminderResult = syncReminders();
      close();
      render();
      offerUndo({store:data.confirmDelete,id:data.id});syncWidgets();announce(reminderResult.error || "已移入最近删除");
      return;
    }
    const actions = {
      close: requestClose,"sheet-back":goBackInSheet,
      "more-journal":()=>{journalLimit+=30;render();},
      "choose-kind": chooseKind, "add-recipe": () => editRecipe(), "add-ledger": () => editLedger(),
      "choose-mood": () => showMood(), "save-mood": confirmMood,
      "mood-response": moodResponse, about: showAbout, "bear-gallery": showBearGallery,
      "open-today": () => { chosen = today(); month = chosen.slice(0, 7); dayScroll = 0; render(); showDaySheet(); },
      "refresh-interface": () => { if (window.BearApp) window.BearApp.refreshInterface(); else location.reload(); },
      reminders: showReminderSettings,
      dates: showAllDates, "date-settings": showDateSettings,
      "new-countdown": () => { chosen = today(); editEntry("event", null, null, true); },
      "enable-reminders": () => window.BearReminders?.requestPermission(),
      "test-reminder": () => window.BearReminders?.test(),
      "exact-reminders": () => window.BearReminders?.exactSettings(),
      "reminder-system": () => window.BearReminders?.settings(),
      "add-photo": () => choosePhotos(), "replace-photo": () => choosePhotos(true),
      "month-prev": () => changeMonth(-1), "month-next": () => changeMonth(1),
      today: () => { chosen = today(); month = chosen.slice(0, 7); recommendationOffset = 0; render(); },
      reroll: () => { recommendationOffset++; play("recommend"); render(); },
      "audio-settings":openAudioSettings,
      sound: async () => {
        busy = true;
        const next = !soundEnabled;
        await setSound(next);
        soundEnabled = next;
        if (next) play("tap"); else stopAudio();
        const control = app.querySelector('[data-action="sound"]');
        const updated = document.createElement("div"); updated.innerHTML = head();
        control.replaceWith(updated.querySelector('[data-action="sound"]'));
        announce(next ? "音效已开启" : "音效已关闭");
      },
    };
    if (actions[data.action]) await actions[data.action]();
  } catch (error) {
    announce(error.message || "操作未完成，请重试");
  } finally { busy = false;if(durableForm())scheduleDraft(); }
});
sheet.addEventListener("click", (event) => { if (event.target === sheet && !busy && !uploadTask) requestClose(); });
sheet.addEventListener('focusin',event=>{if(event.target.matches('input:not([type="file"]),textarea,select'))lastEditorFocus=event.target;});
sheet.addEventListener("cancel", (event) => { event.preventDefault(); if (!busy && !uploadTask) goBackInSheet(); });
let sheetDrag=null;
sheet.addEventListener('pointerdown',event=>{if(event.target.closest('button,input,select,textarea')||!event.target.closest('.sheet-header,.sheet-grabber')||busy||uploadTask)return;sheetDrag={id:event.pointerId,y:event.clientY,delta:0};sheet.setPointerCapture(event.pointerId);});
sheet.addEventListener('pointermove',event=>{if(!sheetDrag||sheetDrag.id!==event.pointerId)return;sheetDrag.delta=Math.max(0,event.clientY-sheetDrag.y);if(!getPreferences().reducedMotion&&!matchMedia('(prefers-reduced-motion: reduce)').matches)sheet.style.transform=`translateY(${Math.min(130,sheetDrag.delta*.65)}px)`;});
function finishSheetDrag(event){if(!sheetDrag||sheetDrag.id!==event.pointerId)return;const delta=sheetDrag.delta;sheetDrag=null;sheet.style.transform='';if(event.type==='pointerup'&&delta>90)requestClose();}
sheet.addEventListener('pointerup',finishSheetDrag);sheet.addEventListener('pointercancel',finishSheetDrag);

app.addEventListener('change',event=>{if(event.target.matches('[data-recipe-date]')&&/^\d{4}-\d{2}-\d{2}$/.test(event.target.value)){recipeDate=event.target.value;recommendationOffset=0;render();}});
sheet.addEventListener('input',scheduleDraft);
sheet.addEventListener('change',scheduleDraft);
sheet.addEventListener('photoqualitychange',event=>{photoQualityMode=getPhotoQualityMode(durableForm());scheduleDraft();});
sheet.addEventListener("change", async (event) => {
  const input = event.target;
  try {
  if(await kitchenChanged(input))return;
  if(await pantryChanged(input))return;
  if(await happyBoxChanged(input))return;
  if(await wishesChanged(input))return;
  if(await memoriesChanged(input))return;
  if(photoExperienceChanged(input))return;
  if(input.name==='photoQuality'){photoQualityMode=input.value;scheduleDraft();return;}
  if(input.name==='linkLedger'){updateEntryLinkFields();return;}
  if (input.id === "recipe-image-file") {await recipeImageChanged(input);return;}
  if (input.name === "useRecipeScreenshot") {if(input.checked)formPhotos=[recipeImportPhoto];else if(formPhotos[0]===recipeImportPhoto)formPhotos=[];showPhotoFields();return;}
  if (input.id === "receipt-file") { await receiptChanged(input); return; }
  if (ledgerChange(input)) return;
  if (["repeatType", "monthDay", "monthOverflow", "workMode", "date"].includes(input.name)) {
    updateRulePreview(input.form);
    updateEntryDateContext(input.form);syncHolidayPicker(input.form,today());
    return;
  }
  if (input.name === "countdown") {
    updateCountdownFields(input.form);syncHolidayPicker(input.form,today());
    return;
  }
  if (input.name === "reminderDays") {
    const clock = input.form.elements.reminderTime;
    clock.disabled = input.value === "off";
    clock.required = input.value !== "off";
    return;
  }
  if (input.name === "recipeId") {
    const linked=recipeById(input.value);
    if(linked){input.form.elements.title.value=linked.title;if(!input.form.elements.xhsUrl.value)input.form.elements.xhsUrl.value=linked.xhsText||linked.xhsUrl||"";}
    updateFoodRecipeFields();return;
  }
  if(input.name === 'addToRecipes'){updateFoodRecipeFields();return;}
  if(input.name === 'foodCoverFile'){
    const file=input.files?.[0];if(!file)return;
    const submit=input.form.querySelector('[type="submit"]'),notice=input.form.querySelector('.form-error');submit.disabled=true;
    uploadTask=photoData(file);
    try{foodRecipeCover=await uploadTask;renderFoodCover();}catch(error){notice.textContent=error.message;}finally{uploadTask=null;submit.disabled=false;input.value='';scheduleDraft();}
    return;
  }
  if (input.name !== "photos" || uploadTask) return;
  const form = input.form;
  const button = form.querySelector('[type="submit"]');
  const notice = form.querySelector(".form-error");
  button.disabled = true;
  notice.textContent = "";
  const pending = Array.from(input.files);
  if (!pending.length) { button.disabled = false; return; }
  const replacing = input.dataset.replace === "true" && Number(input.dataset.limit) === 1;
  const remaining = replacing ? 1 : Number(input.dataset.limit) - formPhotos.length;
  uploadTask = Promise.allSettled(pending.slice(0, remaining).map(photoData));
  showPhotoFields();
  try {
    const results = await uploadTask;
    const added = results.filter((result) => result.status === "fulfilled").map((result) => result.value);
    const failed = results.filter((result) => result.status === "rejected");
    if(added.length&&form.elements.useRecipeScreenshot)form.elements.useRecipeScreenshot.checked=false;
    if (replacing && added.length) formPhotos = added;
    else formPhotos.push(...added);
    const messages = [];
    if (failed.length) messages.push(`${failed.length} 张照片未能添加：${failed[0].reason?.message || "请换一张试试"}`);
    if (pending.length > remaining) messages.push(`这次最多还能添加 ${remaining} 张照片`);
    notice.textContent = messages.join("；");
  } catch (error) { notice.textContent = error.message; }
  finally {
    uploadTask = null;
    input.value = "";
    input.dataset.replace = "false";
    button.disabled = false;
    showPhotoFields();
    renderFoodCover();scheduleDraft();
  }
  } catch(error) { announce(error.message||'这项修改暂时没能保存，请重试'); }
});

sheet.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (busy || uploadTask) return;
  const form = event.target;
  const values = new FormData(form);
  const button = form.querySelector('[type="submit"]');
  clearFormErrors(form);
  busy = true;
  const savingRecord = !['weather-search','global-search'].includes(form.dataset.form);
  const busyLabel = form.dataset.form === 'share-options' ? '正在生成…' : ['entry','recipe','ledger','preferences','date-settings','capsule','wish','pantry-item','kitchen-shopping-edit','kitchen-plan'].includes(form.dataset.form) ? '正在保存…' : '正在处理…';
  const originalLabel = button?.textContent;
  if (button) {
    button.disabled = true;
    if (savingRecord) { button.textContent = busyLabel; form.setAttribute('aria-busy','true'); }
  }
  let committedId="",followupWarning="";
  try {
    if(await workbenchSubmitted(form))return;
    if(await kitchenSubmitted(form))return;
    if(await pantrySubmitted(form))return;
    if(await happyBoxSubmitted(form))return;
    if(await goldSubmitted(form))return;
    if(await wishesSubmitted(form))return;
    if(await memoriesSubmitted(form))return;
    if (form.dataset.form === "audio-settings") { await submitAudio(form); return; }
    if (form.dataset.form === "share-options") { await submitShare(form); return; }
    if (form.dataset.form === "weather-search") { weatherSearch(form); return; }
    if (form.dataset.form === "date-settings") { await submitDateSettings(form); return; }
    if (["ledger", "ledger-category", "ledger-budget", "ledger-period"].includes(form.dataset.form)) { await submitLedger(form); return; }
    const trimmed = (name) => String(values.get(name) || "").trim();
    const title = trimmed("title") || (form.dataset.kind==='life'&&(trimmed('note')||formPhotos.length)?(trimmed('note').split('\n')[0].slice(0,40)||'今天的小日子'):'');
    if (!title) throw new Error("请先写一个标题");
    const id = form.dataset.id || newId();
    const photos = [...formPhotos];
    let wantsReminder = false;
    if (form.dataset.form === "entry") {
      const existing = entryById(id);
      const date = trimmed("date");
      if (dateKey(fromKey(date)) !== date) throw new Error("请填写正确的日期");
      const kind = form.dataset.kind;
      if (kind === "event" && values.has("countdown") && !trimmed("time")) throw new Error("请填写倒计时的目标时间");
      const recurrence = reminderKinds.includes(kind) ? readRule(form) : { type: "none" };
      let reminder = null;
      if (reminderKinds.includes(kind) && trimmed("reminderDays") !== "off") {
        const days = Number(trimmed("reminderDays")), time = trimmed("reminderTime");
        if (![0, 1, 3, 7].includes(days) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) throw new Error("请填写正确的提醒时间");
        const reminderDate = fromKey(date);
        reminderDate.setDate(reminderDate.getDate() - days);
        const [hour, minute] = time.split(":").map(Number);
        reminderDate.setHours(hour, minute, 0, 0);
        const scheduleUnchanged = existing?.date === date && existing?.reminder?.days === days && existing?.reminder?.time === time;
        if (recurrence.type === "none" && reminderDate.getTime() <= Date.now() && !scheduleUnchanged)
          throw new Error("提醒时间已经过去，请换一个未来时间或选择不提醒");
        reminder = { days, time };
        wantsReminder = true;
      }
      const item = { ...existing,id, kind, title, date, time: trimmed("time"), note: trimmed("note"), photos,
        repeat: recurrence.type === "yearly", recurrence,
        countdown: kind === "event" && values.has("countdown"),
        holidayId:kind==='event'?savedHolidayId(form):'',
        recipeId: trimmed("recipeId"), xhsText: kind === "meal" ? trimmed("xhsUrl") : "", xhsUrl: kind === "meal" ? xhsLink(trimmed("xhsUrl")) : "", reminder, created: existing?.created || Date.now() };
      const writes=[{store:'entries',value:item}];
      if(kind==='meal'&&!item.recipeId&&values.has('addToRecipes')){
        const recipe=recipeFromMeal(item,{category:trimmed('foodCategory'),cover:foodRecipeCover,ingredients:trimmed('foodIngredients'),steps:trimmed('foodSteps'),xhsUrl:item.xhsUrl,xhsText:item.xhsText},newId());recipe.coverFocus={...formCoverFocus};item.recipeId=recipe.id;writes.push({store:'recipes',value:recipe});
      }
      const linked=existing?.ledgerId?getLedgerRows().find(x=>x.id===existing.ledgerId):null;
      if(values.has('linkLedger')&&(!existing?.ledgerId||linked)){
        const category=trimmed('linkedCategory');if(!getLedgerCategories().some(x=>x.id===category&&x.type==='expense'))throw new Error('请选择花费分类');
        const bill={...linked,id:linked?.id||newId(),type:'expense',category,cents:parseAmount(trimmed('linkedAmount')),date,entryId:item.id,note:linked?linked.note:item.title,photos:linked?linked.photos:[...photos],created:linked?.created||Date.now()};item.ledgerId=bill.id;writes.push({store:'ledger',value:bill});
      }else if(linked&&linked.date!==date)writes.push({store:'ledger',value:{...linked,date}});
      await saveItemsAtomically(writes);
      form.dataset.id=item.id;committedId=item.id;
      entries = [...entries.filter((entry) => entry.id !== id), item];
      recipes=[...recipes,...writes.filter(x=>x.store==='recipes').map(x=>x.value)];
      try{await reloadLedger();}catch{followupWarning="记录已保存，账本显示将在重新打开后刷新";}
      chosen = form.dataset.returnDay && onDate(item, form.dataset.returnDay) ? form.dataset.returnDay : nextOccurrence(item, form.dataset.returnDay || date) || date;
      month = chosen.slice(0, 7);
      recommendationOffset = 0;

    } else {
      if(form.dataset.imageImport==='true'&&!values.has('recipeReviewed'))throw new Error('请核对识别结果后再保存');
      const existing = recipeById(id);
      const recipe = { ...existing,id, title, photos,coverFocus:{...formCoverFocus}, category: trimmed("category"), ingredients: trimmed("ingredients"),
        steps: trimmed("steps"), effort:readRecipeEffort(values), xhsText: trimmed("xhsUrl"), xhsUrl: xhsLink(trimmed("xhsUrl")), starter: false, created: existing?.created || Date.now() };
      await saveItem("recipes", recipe);form.dataset.id=recipe.id;committedId=recipe.id;
      recipes = [...recipes.filter((item) => item.id !== id), recipe];
      foodFilter = "全部";
      recommendationOffset = 0;
      page = "recipes";
    }
    try{await clearCurrentDraft(form);}catch{initialDraft=null;followupWarning="记录已保存，草稿暂未清理，可稍后到设置整理";}
    const reminderResult = syncReminders();syncWidgets();
    close();render();
    if(form.dataset.form==='entry'){showEntry(entryById(id),chosen,form.dataset.returnDay||'');celebrate(form.dataset.kind);}else showRecipe(recipeById(id));
    play("saved");
    announce(followupWarning||reminderResult.error || (wantsReminder && !reminderResult.native ? "记录已保存；系统通知需在安卓 App 中使用" : values.has("addToRecipes") && !trimmed("recipeId") ? "美食已保存，也收进菜谱啦" : "已经记进熊熊手账"), !reminderResult.error);
    if (wantsReminder && reminderResult.native && !reminderResult.enabled && !reminderResult.error) window.BearReminders.requestPermission();
  } catch (error) {
    if(committedId){initialDraft=null;close();render();announce('记录已经保存，显示暂未刷新。请重新打开对应记录查看');return;}
    const message=error.name === "QuotaExceededError" ? "本机存储不足，请腾出空间后重试" : error.message || "保存未完成，请重试";
    if (!reportFormError(form, message)) announce(message);
  } finally {
    busy = false;
    if (button) button.disabled = false;
    if (savingRecord && button) { button.textContent = originalLabel; form.removeAttribute('aria-busy'); }
  }
});

window.bearCalendarBack = () => {
  if(exitConfirmationBack())return true;
  if(photoExperienceBack())return true;
  if (sheet.open) { if (!busy && !uploadTask) goBackInSheet(); return true; }
  if (page !== "calendar") { switchPage("calendar"); return true; }
  return false;
};

function refreshDay() {
  const current = today();
  if (current === lastToday || sheet.open) return;
  if (chosen === lastToday) { chosen = current; month = current.slice(0, 7); }
  if (recipeDate === lastToday) { recipeDate = current; recommendationOffset = 0; }
  lastToday = current;
  render();
}
window.bearReminderStatusChanged = (message) => {
  if (sheet.dataset.view === "reminders") showReminderSettings();
  if (message) announce(message);
  refreshDay();
};
window.bearOpenNotification = () => {
  if (!appReady || !window.BearReminders) return;
  let target;
  try { target = JSON.parse(window.BearReminders.consumeOpenEntry() || "null"); } catch { return; }
  if (!target?.id) return;
  openNotificationTarget(target);
};
function openNotificationTarget(target) {
  if(busy||uploadTask){setTimeout(()=>openNotificationTarget(target),250);return;}
  const navigate=()=>{
  close();
  page = "calendar";
  const item = entryById(target.id);
  if (item) {
    chosen = /^\d{4}-\d{2}-\d{2}$/.test(target.date) ? target.date : item.date;
    month = chosen.slice(0, 7); render(); showEntry(item, chosen);
  } else if (ledgerReminderTarget(target.id)) {openLedger(ledgerReminderTarget(target.id));
  } else if (target.id.startsWith("auto-")) {
    chosen = target.date || today(); month = chosen.slice(0, 7); render();
    const holiday = holidays.find((value) => value.id === target.id);
    showCountdown(holiday ? { ...holiday, kind: "holiday", title: `${holiday.name}假期`, date: holiday.start, icon: "✦", caption: `${holiday.start}—${holiday.end}` } : { id: target.id, kind: "payday", title: "发薪日", date: chosen, icon: "¥", caption: `${chosen} · ${ruleDescription(paydayRule())}` });
  } else { chosen = today(); month = chosen.slice(0, 7); render(); if (target.id !== "test") announce("这条记录已经移除"); }
  };
  if(hasDraftChanges()||audioHasChanges())requestClose(navigate);else navigate();
}
document.addEventListener("visibilitychange", () => { if (!document.hidden) {refreshDay();syncWidgets();}else flushDurableDraft(); });
setInterval(refreshDay, 60000);

async function start() {
  try {
    initWeather({ open, announce, onWeatherUpdated:sharingWeatherChanged });
    initSharing({ open, announce, sheet, weatherState:sharingWeatherState, refreshWeather:refreshSharingWeather });
    initStorageSettings({open,announce,sheet});
    initRecipeImport({open,sheet,edit:editRecipe});
    initReceipts({open, sheet, edit:(item)=>editLedger(item,item.date)});
    await openStore();
    initPhotoExperience({announce,imageMarkup,getPhotos:()=>[...formPhotos],setPhotos:photos=>{formPhotos=[...photos];},onPhotosChanged:()=>{showPhotoFields();renderFoodCover();scheduleDraft();},getCoverFocus:()=>formCoverFocus,setCoverFocus:focus=>{formCoverFocus=focus;scheduleDraft();}});
    await initAudio({open,close,announce,sheet,enabled:()=>soundEnabled,setEnabled:(value)=>{soundEnabled=value;},setDraft:()=>{initialDraft=draftSnapshot();},refresh:()=>{const control=app.querySelector('[data-action="sound"]'),holder=document.createElement("div");holder.innerHTML=head();control?.replaceWith(holder.querySelector('[data-action="sound"]'));}});
    await initLedger({ open, close, render, announce, sheet, openReceipt, imageMarkup, photoFields,
      initPhotos: (photos) => { formPhotos = [...photos]; foodRecipeCover = "";formCoverFocus={x:50,y:50};photoQualityMode='standard';recipeImportContext=null; showPhotoFields(); },
      getPhotos: () => [...formPhotos], setDraft: () => { initialDraft = getLedgerDraftContext()?.receiptImport?{values:"",photos:[],cover:"",focus:""}:draftSnapshot();if(getLedgerDraftContext()?.receiptImport)scheduleDraft(); },
      onRecordsChanged:refreshData,onDeleted:offerUndo,onSaved:clearCurrentDraft,openGoldPurchase,
      openEntry:(id,date)=>showEntry(entryById(id),date,date),showPhotos:fullscreenPhotos,
      showLedgerPage: () => { page = "ledger"; render(); window.scrollTo(0,0); },
      showDay: (date) => { chosen = date; month = date.slice(0,7); page = "calendar"; render(); showDaySheet(); }
    });
    const saved = await Promise.all([loadAll("entries"), loadAll("recipes"), getSound(), loadAll("moods"), getDateSettings()]);
    [entries, recipes] = saved;
    moodHistory = saved[3];
    soundEnabled = saved[2] ?? true;
    dateSettings = { ...dateSettings, ...saved[4] };
    const confirmFeatureLeave=next=>{if(hasDraftChanges())requestClose(next);else return next();};
    const featurePhotos=(photos,focus)=>{formPhotos=[...photos];foodRecipeCover='';formCoverFocus=focus||{x:50,y:50};photoQualityMode='standard';recipeImportContext=null;showPhotoFields();};
    await initKitchen({open,close,sheet,announce,refreshData,onRecipeSaved:recipe=>{recipes=[...recipes.filter(item=>item.id!==recipe.id),recipe];},setDraft:()=>{initialDraft=draftSnapshot();},confirmLeave:confirmFeatureLeave,getRecipes:()=>recipes,getEntries:()=>entries,recordMeal:(recipe,date)=>{recipeDate=date;editEntry('meal',null,recipe.id,false,date);},recordPlannedMeal:plan=>{recipeDate=plan.date;editEntry('meal',null,plan.recipeId||null,false,plan.date);const title=sheet.querySelector('[name="title"]');if(title)title.value=plan.title;initialDraft=draftSnapshot();},openEntry:(id,date)=>showEntry(entryById(id),date),recordShopping:note=>editLedger({note,type:'expense'},today()),openPantryIntake,imageMarkup});
    await initPantry({open,close,sheet,announce,getRecipes:()=>recipes,getEntries:()=>entries,openRecipe:(id,date)=>showRecipe(typeof id==='object'?id:recipeById(id),date||recipeDate),setDraft:()=>{initialDraft=draftSnapshot();},confirmLeave:confirmFeatureLeave,getMealPlan,addShoppingItems,openMealPlanner});
    await initHappyBox({open,close,sheet,announce,getEntries:()=>entries,imageMarkup,setDraft:()=>{initialDraft=draftSnapshot();},confirmLeave:confirmFeatureLeave,showPhotos:(photos,index,title)=>fullscreenPhotos({photos,index,title}),showEntry:(item,date)=>showEntry(typeof item==='object'?item:entryById(item),date)});
    initGoldPrices({open,sheet,announce});
    await initGold({open,close,sheet,announce,setDraft:()=>{initialDraft=draftSnapshot();},clearDraft:()=>{initialDraft=null;},confirmLeave:confirmFeatureLeave,refreshData,getLedger:getLedgerRows});
    await initWishes({open,close,sheet,announce,photoFields,initPhotos:featurePhotos,getPhotos:()=>[...formPhotos],getCoverFocus:()=>({...formCoverFocus}),imageMarkup,setDraft:()=>{initialDraft=draftSnapshot();},confirmLeave:confirmFeatureLeave,refreshData,onSaved:clearCurrentDraft,getEntries:()=>entries,showEntry:(item,date)=>showEntry(typeof item==='object'?item:entryById(item),date),showPhotos:(photos,index,title)=>fullscreenPhotos({photos,index,title})});
    initMemories({open,close,sheet,announce,getEntries:()=>entries,getRecipes:()=>recipes,getMoods:()=>moodHistory,getLedger:getLedgerRows,getLedgerCategories,refreshData,photoFields,initPhotos:photos=>{formPhotos=[...photos];formCoverFocus={x:50,y:50};foodRecipeCover='';photoQualityMode='standard';recipeImportContext=null;showPhotoFields();},getPhotos:()=>[...formPhotos],setDraft:()=>{initialDraft=draftSnapshot();},showEntry:(item,date)=>showEntry(typeof item==='object'?item:entryById(item),date),showPhotos:(photos,index,title)=>fullscreenPhotos({photos,index,title}),onSaved:clearCurrentDraft,onDeleted:offerUndo});
    await initWorkbench({open,close,sheet,announce,setDraft:()=>{initialDraft=draftSnapshot();},version:APP_VERSION,render,refreshData,restoreDraft:restoreDurableDraft,getEntries:()=>entries,getMoods:()=>moodHistory,getRecipes:()=>recipes,getLedger:getLedgerRows,getLedgerCategories,getCountdowns:dateCards,capsuleIsHidden,imageMarkup,openEntry:id=>showEntry(entryById(id)),openRecipe:id=>showRecipe(recipeById(id)),openLedger,openMagazine,openMealPlanner:()=>openMealPlanner(recipeDate),openPantry:()=>openPantry(recipeDate),openEasyMeals:()=>openEasyMeals(recipeDate),openHappyBox,openWishes,openCapsules,openMemories,openBackup:showStorageSettings,openReminders:showReminderSettings,openAudio:openAudioSettings,openAbout:showAbout,syncWidgets});
    backupMarkup=await backupReminder();
    appReady = true;
    render();
    mountKitchenTimer();
    mascotMotion=initMascotMotion(app);
    syncWidgets();window.bearWidgetAction=widgetAction;
    const reminderResult = syncReminders();
    if (reminderResult.error) announce(reminderResult.error);
    window.bearOpenNotification();
    if(window.BearApp?.consumeWidgetAction){try{await widgetAction(JSON.parse(window.BearApp.consumeWidgetAction()||'null'));}catch{}}
  } catch (error) {
    app.innerHTML = `<div class="initial-error"><h1>熊熊宝典</h1><p>${html(error.message || "暂时打不开本机数据")}</p><button class="secondary" id="retry">重新打开</button></div>`;
    document.querySelector("#retry").addEventListener("click", () => location.reload());
  }
}
start();
sheet.addEventListener("close", () => clearInterval(countdownTimer));
