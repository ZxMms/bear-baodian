import {saveItem,removeItem,getSetting,putSetting,dateKey,moods} from "./model.js?v=37";
import {amountText,monthShift} from "./ledger-core.js?v=37";
import {bearArt,artMeta} from "./illustrations.js?v=37";
import {capsuleDue,capsuleIsHidden,validMemoryDate,memoryRows,magazineMonthData,normalizeMagazineSelection,magazineSections} from "./memories-core.js?v=37";
export {capsuleIsHidden,capsuleDue};

let ui,magazineMonth=dateKey().slice(0,7),magazineData,magazineSelection,magazinePrepared=null,magazinePage=0,memoryMode="year";
const escape=value=>String(value??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const uid=()=>globalThis.crypto?.randomUUID?.()||Date.now().toString(36)+Math.random().toString(36).slice(2);
const entries=()=>ui.getEntries?.()||[];
const safeImage=src=>/^data:image\/(jpeg|png|webp|gif);base64,[A-Za-z0-9+/=]+$/.test(src||"")||/^media\/[a-f0-9]{64}\.(jpg|png|webp|gif)$/.test(src||"");
const image=(src,css,alt)=>safeImage(src)?`<img class="${css}" src="${escape(src)}" alt="${escape(alt)}" loading="lazy">`:"";
const countCaption=count=>`${count} 张照片`;
const categoryNames=()=>ui.getLedgerCategories?.()||[];
export function initMemories(callbacks){ui=callbacks;}
function dataForMonth(month){return magazineMonthData({entries:entries(),moods:ui.getMoods?.()||[],ledger:ui.getLedger?.()||[],recipes:ui.getRecipes?.()||[],categories:categoryNames()},month);}
function selectionFrom(form){
  const values=new FormData(form),excerpts={};
  for(const input of form.querySelectorAll('[data-magazine-excerpt]'))excerpts[input.dataset.magazineExcerpt]=input.value;
  return normalizeMagazineSelection(magazineData,{title:values.get("magazineTitle"),letter:values.get("magazineLetter"),entryIds:values.getAll("magazineEntry"),photoKeys:values.getAll("magazinePhoto"),includeMood:values.has("magazineMood"),includeMeals:values.has("magazineMeals"),includeLedger:values.has("magazineLedger"),excerpts});
}
async function rememberMagazine(){
  const form=ui.sheet.querySelector('[data-form="magazine"]');
  if(form){magazineSelection=selectionFrom(form);await putSetting(`feature:magazine:${magazineMonth}`,magazineSelection);}
}
export async function openMagazine(month=magazineMonth){
  const data=dataForMonth(month);magazineMonth=month;magazineData=data;
  magazineSelection=normalizeMagazineSelection(magazineData,await getSetting(`feature:magazine:${month}`)||{});
  renderMagazine();
}
function renderMagazine(){
  const data=magazineData,s=magazineSelection;
  ui.open("熊熊月刊",`<section class="memory-intro">${bearArt("moments",data.month,"memory-bears",9)}<p class="eyebrow">把日子翻成一本小杂志</p><h3>${Number(data.month.slice(0,4))} 年 ${Number(data.month.slice(5))} 月</h3><p>${data.entries.length} 条生活记录 · ${data.photos.length} 张不重复的照片</p></section><div class="memory-month"><button type="button" class="secondary" data-memory-action="magazine-prev" aria-label="上个月的月刊">‹</button><label for="magazine-month" class="visually-hidden">月刊月份</label><input id="magazine-month" name="magazineMonth" type="month" min="1900-01" max="${dateKey().slice(0,7)}" value="${data.month}"><button type="button" class="secondary" data-memory-action="magazine-next" aria-label="下个月的月刊" ${data.month>=dateKey().slice(0,7)?"disabled":""}>›</button></div><p class="photo-hint">统计来自本月已到来的日期和你实际保存的记录；未来安排、时光胶囊与最近删除不会收入月刊。</p><form data-form="magazine"><label for="magazine-title">月刊标题</label><input id="magazine-title" name="magazineTitle" value="${escape(s.title)}" maxlength="48" required><label for="magazine-letter">写在月末的话 <small>可自行改写</small></label><textarea id="magazine-letter" name="magazineLetter" rows="4" maxlength="600">${escape(s.letter)}</textarea><p class="photo-hint">熊熊寄语使用本机文字模板，不会上传记录或推测心情原因。</p><div class="memory-options"><label class="checkbox"><input type="checkbox" name="magazineMood" ${s.includeMood?"checked":""}>心情分布</label><label class="checkbox"><input type="checkbox" name="magazineMeals" ${s.includeMeals?"checked":""}>美食小结</label><label class="checkbox"><input type="checkbox" name="magazineLedger" ${s.includeLedger?"checked":""}>包含收支金额与分类统计</label></div><p class="photo-hint memory-privacy">金额默认隐藏。选中的照片和文字将出现在导出图片中，生成后可以先检查。</p><div class="section-title"><h3>精选照片</h3><span class="memory-photo-count">${s.photoKeys.length} / ${data.photos.length}</span></div>${data.photos.length?`<div class="magazine-photo-picker">${data.photos.map(photo=>`<label class="magazine-photo-choice"><input type="checkbox" name="magazinePhoto" value="${escape(photo.key)}" ${s.photoKeys.includes(photo.key)?"checked":""}><span>${image(photo.src,"magazine-pick-image",`${photo.date} ${photo.label}`)}<b aria-hidden="true">✓</b></span><small>${photo.date.slice(5)} · ${photo.store==="ledger"?"消费照片":"生活照片"}</small></label>`).join("")}</div><p class="photo-hint">生活照片默认精选最多 9 张；消费照片需主动勾选，不会附带账单金额。</p>`:'<p class="memory-empty-note">这个月还没有照片，也可以生成文字月刊。</p>'}<div class="section-title"><h3>值得记住的小事</h3><span class="memory-entry-count">${s.entryIds.length} 项已选</span></div><p class="photo-hint">默认精选最近 8 条。可以取消、补选，并修改每条摘录。</p>${data.entries.length?`<div class="magazine-entry-picker">${data.entries.map(row=>`<div class="magazine-entry"><label class="share-check"><input type="checkbox" name="magazineEntry" value="${escape(row.id)}" ${s.entryIds.includes(row.id)?"checked":""}><span><strong>${escape(row.title||"生活小事")}</strong><small>${row.date}</small></span></label><textarea name="magazineExcerpt:${escape(row.id)}" data-magazine-excerpt="${escape(row.id)}" aria-label="${escape(row.title||"生活小事")}的月刊摘录" rows="2" maxlength="500" ${s.entryIds.includes(row.id)?"":"hidden"}>${escape(s.excerpts[row.id]??String(row.note||"").slice(0,180))}</textarea></div>`).join("")}</div>`:'<p class="memory-empty-note">可以先写一段月末寄语，再慢慢添上新的生活记录。</p>'}<p class="form-error" role="alert"></p><button type="submit" class="primary">保存选择并生成月刊</button><p class="photo-hint">较长内容自动分页，最多 9 张图片；数据仍只保存在本机。</p></form>`);
  ui.sheet.dataset.view="magazine";ui.setDraft?.();
}
const loadImage=url=>new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>resolve(img);img.onerror=()=>reject(new Error("有一张精选照片无法读取，请取消勾选后重试"));img.src=url;});
function wrapped(context,text,width){const lines=[];for(const paragraph of String(text||"").split("\n")){let line="";for(const char of paragraph){if(line&&context.measureText(line+char).width>width){lines.push(line);line="";}line+=char;}lines.push(line);}return lines;}
async function drawMagazine(content){
  const WIDTH=720,MAX=2200,PAD=44,colors=["#b87d59","#8d9e73","#d2a660","#9d83a3","#7c9ca2","#bf8b89"];
  const art=artMeta("moments",magazineMonth,9);let bears=null;try{bears=await loadImage(art.src);}catch{}
  const pages=[];let canvas,ctx,y;
  function begin(){
    if(pages.length>=9)throw new Error("月刊超过 9 张图片，请减少精选照片或摘录后再生成");
    canvas=document.createElement("canvas");canvas.width=WIDTH;canvas.height=MAX;ctx=canvas.getContext("2d");ctx.fillStyle="#fff8ed";ctx.fillRect(0,0,WIDTH,MAX);ctx.fillStyle="#d9b68e";ctx.fillRect(0,0,WIDTH,13);
    ctx.font="18px sans-serif";ctx.fillStyle="#957358";ctx.fillText("熊熊月刊 · 只属于你的小日子",PAD,58);ctx.font="bold 32px sans-serif";ctx.fillStyle="#573f31";y=108;
    for(const line of wrapped(ctx,content.title,WIDTH-PAD*2-130)){ctx.fillText(line,PAD,y);y+=42;}
    if(bears)ctx.drawImage(bears,art.x*bears.width/4,art.y*bears.height/3,bears.width/4,bears.height/3,WIDTH-150,40,112,108);
    ctx.font="17px sans-serif";ctx.fillStyle="#8c755e";ctx.fillText(content.subtitle,PAD,y+8);y+=50;
  }
  function end(){const height=Math.max(430,Math.min(MAX,y+74));ctx.fillStyle="#a28a73";ctx.font="16px sans-serif";ctx.fillText("熊熊宝典 · 把小日子收好",PAD,height-28);ctx.textAlign="right";ctx.fillText(`${pages.length+1}`,WIDTH-PAD,height-28);ctx.textAlign="left";const result=document.createElement("canvas");result.width=WIDTH;result.height=height;result.getContext("2d").drawImage(canvas,0,0);pages.push(result.toDataURL("image/png"));canvas.width=0;canvas.height=0;}
  function space(size){if(y+size>MAX-95){end();begin();}}
  begin();
  for(const section of content.sections){
    space(140);ctx.fillStyle="#875636";ctx.font="bold 25px sans-serif";
    for(const line of wrapped(ctx,section.title,WIDTH-PAD*2)){space(34);ctx.font="bold 25px sans-serif";ctx.fillStyle="#875636";ctx.fillText(line,PAD,y);y+=34;}y+=9;
    ctx.font="21px sans-serif";for(const line of wrapped(ctx,section.text,WIDTH-PAD*2)){space(32);ctx.font="21px sans-serif";ctx.fillStyle="#654f3f";ctx.fillText(line,PAD,y);y+=32;}
    for(let i=0;i<(section.photos||[]).length;i+=2){space(300);const subset=section.photos.slice(i,i+2),size=(WIDTH-PAD*2-14)/2;for(let j=0;j<subset.length;j++){const photo=await loadImage(subset[j]);const scale=Math.max(size/photo.width,260/photo.height);ctx.save();ctx.beginPath();ctx.rect(PAD+j*(size+14),y,size,260);ctx.clip();ctx.drawImage(photo,PAD+j*(size+14)+(size-photo.width*scale)/2,y+(260-photo.height*scale)/2,photo.width*scale,photo.height*scale);ctx.restore();}y+=279;}
    for(let i=0;i<(section.spending||[]).length;i++){const item=section.spending[i];space(76);ctx.font="19px sans-serif";ctx.fillStyle="#654f3f";ctx.fillText(`${item.name} · ${(item.ratio*100).toFixed(1)}%`,PAD,y+22);ctx.textAlign="right";ctx.fillText(`¥${amountText(item.cents)}`,WIDTH-PAD,y+22);ctx.textAlign="left";ctx.fillStyle="#efe2d2";ctx.fillRect(PAD,y+36,WIDTH-PAD*2,11);ctx.fillStyle=colors[i%colors.length];ctx.fillRect(PAD,y+36,(WIDTH-PAD*2)*item.ratio,11);y+=67;}
    y+=20;if(y<MAX-115){ctx.strokeStyle="#e8d7c0";ctx.beginPath();ctx.moveTo(PAD,y);ctx.lineTo(WIDTH-PAD,y);ctx.stroke();y+=32;}
  }
  end();return pages;
}
function magazineText(content){return `${content.title}\n${content.subtitle}\n\n${content.sections.map(section=>section.title+"\n"+(section.text||"")+(section.spending?.length?"\n"+section.spending.map(item=>`${item.name} ¥${amountText(item.cents)}`).join("\n"):"")).join("\n\n")}\n\n熊熊宝典`;}
function previewMagazine(){
  const count=magazinePrepared.pages.length;
  ui.open("熊熊月刊 · 分享前看一眼",`<button type="button" class="day-back text-button" data-memory-action="magazine-edit">‹ 返回修改月刊</button><p class="memory-privacy">${magazineSelection.includeLedger?"已包含收支金额与分类统计，请确认后分享。":"未包含收支金额。"}${count>1?`内容分为 ${count} 张图片。`:""}</p><img class="share-preview-image" src="${magazinePrepared.pages[magazinePage]}" alt="${escape(magazineSelection.title)}，第 ${magazinePage+1} 页">${count>1?`<div class="photo-controls"><button type="button" class="secondary" data-memory-action="magazine-page-prev" ${magazinePage===0?"disabled":""}>‹ 上一张</button><span>${magazinePage+1} / ${count}</span><button type="button" class="secondary" data-memory-action="magazine-page-next" ${magazinePage===count-1?"disabled":""}>下一张 ›</button></div>`:""}<button type="button" class="primary" data-memory-action="magazine-share" ${window.BearShare?"":"disabled"}>分享月刊 · 选择微信</button><div class="sheet-actions"><button type="button" class="secondary" data-memory-action="magazine-save">${count>1?"保存当前图片":"保存月刊图片"}</button><button type="button" class="secondary" data-memory-action="magazine-copy">复制月刊文字</button></div><p class="photo-hint">${window.BearShare?"在系统分享面板选择应用与联系人，最后由你发送。":"浏览器可保存图片和复制文字；安卓 App 可打开系统分享面板。"}</p>`);ui.sheet.dataset.view="magazine-preview";
}
export function openCapsules(){
  const list=entries().filter(row=>row.kind==="capsule").sort((a,b)=>a.date.localeCompare(b.date)||(a.time||"").localeCompare(b.time||""));
  ui.open("熊熊时光胶囊",`<section class="memory-intro">${bearArt("moments",dateKey(),"memory-bears",4)}<p class="eyebrow">给未来的自己留一页</p><h3>等到那天，再一起打开</h3><p>写一封信，藏几张照片，让未来的你收到今天的心意。</p></section><button type="button" class="primary" data-memory-action="capsule-new">＋ 写给未来的自己</button><div class="capsule-list">${list.length?list.map(row=>`<button type="button" class="capsule-card ${capsuleDue(row)?"ready":""}" data-memory-action="capsule" data-memory-id="${escape(row.id)}"><span aria-hidden="true">${capsuleDue(row)?"✉":"♡"}</span><span><strong>${escape(row.title)}</strong><small>${row.date} ${row.time||"09:00"} · ${capsuleDue(row)?row.capsuleOpenedAt?"已经打开":"可以打开啦":"等待开启"}</small></span><b aria-hidden="true">›</b></button>`).join(""):'<p class="memory-empty-note">可以写给下个月的自己，也可以留到生日或纪念日。</p>'}</div><p class="photo-hint">按手机本地时间开启；信件和照片保存在本机，可随完整备份带走。</p>`);ui.sheet.dataset.view="capsules";
}
export function editCapsule(item=null){
  const tomorrow=new Date();tomorrow.setDate(tomorrow.getDate()+1);
  ui.open(item?"编辑时光胶囊":"写给未来的自己",`<form data-form="capsule" data-id="${escape(item?.id||"")}"><label for="capsule-title">信封上的一句话</label><input id="capsule-title" name="capsuleTitle" maxlength="60" required value="${escape(item?.title||"")}" placeholder="比如：送给生日那天的自己"><label for="capsule-date">在哪天打开</label><input id="capsule-date" name="capsuleDate" type="date" min="1900-01-01" max="9999-12-31" required value="${item?.date||dateKey(tomorrow)}"><label for="capsule-time">开启时间</label><input id="capsule-time" name="capsuleTime" type="time" required value="${item?.time||"09:00"}"><label for="capsule-note">想对未来的自己说</label><textarea id="capsule-note" name="capsuleNote" rows="6" maxlength="5000" placeholder="今天发生了什么？此刻在期待什么？">${escape(item?.note||"")}</textarea>${ui.photoFields(5,"capsule")}<label class="checkbox"><input type="checkbox" name="capsuleReminder" ${item?.reminder?"checked":""}>到开启时间提醒我</label><p class="photo-hint">提醒使用手机通知栏，需开启通知权限。开启前仍可进入编辑页修改自己的信件。</p><p class="form-error" role="alert"></p><button type="submit" class="primary">${item?"保存这封信":"封好这封信"}</button></form>`);
  ui.initPhotos(item?.photos||[]);ui.sheet.dataset.view="capsule-edit";ui.setDraft?.();
}
export function openCapsule(id){
  const item=entries().find(row=>row.kind==="capsule"&&row.id===id);if(!item){ui.announce("这封信已经不在当前记录中");return;}
  const due=capsuleDue(item),opened=due&&item.capsuleOpenedAt;
  ui.open(item.title,`<button type="button" class="day-back text-button" data-memory-action="capsules">‹ 返回时光胶囊</button><section class="capsule-envelope">${bearArt("moments",id,"memory-bears",4)}<p>${due?opened?"这封信，已经来到今天":"今天，可以打开这封信啦":"熊熊替你收好了"}</p><strong>${item.date} ${item.time||"09:00"}</strong>${!due?`<small>${countCaption(item.photos?.length||0)} · 信里的内容等到开启时再展示</small>`:""}</section>${opened?`<p class="detail-text">${escape(item.note||"留给未来的一份心意。")}</p>${item.photos?.length?`<div class="memory-photo-grid">${item.photos.map((photo,index)=>`<button type="button" data-memory-action="capsule-photo" data-memory-id="${escape(id)}" data-memory-index="${index}" aria-label="查看胶囊照片 ${index+1}">${image(photo,"memory-thumb",`胶囊照片 ${index+1}`)}</button>`).join("")}</div>`:""}`:due?`<button type="button" class="primary" data-memory-action="capsule-open" data-memory-id="${escape(id)}">打开这封信</button>`:""}<div class="sheet-actions"><button type="button" class="secondary" data-memory-action="capsule-edit" data-memory-id="${escape(id)}">编辑原信</button><button type="button" class="text-button danger" data-memory-action="capsule-delete" data-memory-id="${escape(id)}">移到最近删除</button></div>`);ui.sheet.dataset.view="capsule";ui.sheet.dataset.memoryId=id;
}
function showCapsulePhoto(id,index=0){
  const item=entries().find(row=>row.kind==="capsule"&&row.id===id);if(!item||!capsuleDue(item)||!item.capsuleOpenedAt||!item.photos?.length)return;
  index=Math.max(0,Math.min(item.photos.length-1,Number.isFinite(index)?Math.floor(index):0));
  if(ui.showPhotos){ui.showPhotos(item.photos,index,item.title||"时光胶囊");return;}
  ui.open(`胶囊照片 ${index+1} / ${item.photos.length}`,`<button type="button" class="day-back text-button" data-memory-action="capsule" data-memory-id="${escape(id)}">‹ 返回这封信</button><div class="photo-viewer">${image(item.photos[index],"photo-full",`胶囊照片 ${index+1}`)}</div><div class="photo-controls"><button type="button" class="secondary" data-memory-action="capsule-photo" data-memory-id="${escape(id)}" data-memory-index="${index-1}" ${index===0?"disabled":""}>‹ 上一张</button><span>${index+1} / ${item.photos.length}</span><button type="button" class="secondary" data-memory-action="capsule-photo" data-memory-id="${escape(id)}" data-memory-index="${index+1}" ${index===item.photos.length-1?"disabled":""}>下一张 ›</button></div>`);ui.sheet.dataset.view="capsule-photo";ui.sheet.dataset.memoryId=id;
}
export function openMemories(mode=memoryMode){
  memoryMode=mode;const group=memoryRows(entries(),dateKey(),mode);
  ui.open("翻翻往日的小幸福",`<section class="memory-intro">${bearArt("moments",group.date||dateKey(),"memory-bears",9)}<p class="eyebrow">有些日子，值得再看一遍</p><h3>${mode==="quarter"?"三个月前的这一天":"去年的今天"}</h3><p>${group.date||"那个月没有同样的日期"}</p></section><div class="memory-options memory-tabs"><button type="button" class="secondary" data-memory-action="memories-year" aria-pressed="${mode==="year"}">去年的今天</button><button type="button" class="secondary" data-memory-action="memories-quarter" aria-pressed="${mode==="quarter"}">三个月前</button></div>${group.rows.length?group.rows.map(row=>`<button type="button" class="memory-recall-card" data-memory-action="recall-entry" data-memory-id="${escape(row.id)}">${image(row.photos?.[0],"memory-recall-thumb","记录照片")}<span><strong>${escape(row.title)}</strong><small>${escape(String(row.note||"").slice(0,80)||"点开看看那一天")}</small></span><b aria-hidden="true">›</b></button>`).join(""):'<div class="memory-empty-note">这一天还没有留下记录。今天写下的小事，以后就能在这里遇见。</div>'}<button type="button" class="secondary" data-memory-action="magazine">看看这个月的回忆 ›</button>`);ui.sheet.dataset.view="memories";
}
export async function memoriesChanged(input){
  if(input.name==="magazineMonth"){const month=input.value;if(!month)return true;await rememberMagazine();await openMagazine(month);return true;}
  if(input.name==="magazineEntry"){input.closest('.magazine-entry').querySelector('textarea').hidden=!input.checked;ui.sheet.querySelector('.memory-entry-count').textContent=`${ui.sheet.querySelectorAll('[name="magazineEntry"]:checked').length} 项已选`;return true;}
  if(input.name==="magazinePhoto"){const count=ui.sheet.querySelectorAll('[name="magazinePhoto"]:checked').length;ui.sheet.querySelector('.memory-photo-count').textContent=`${count} / ${magazineData.photos.length}`;return true;}
  return ["magazineTitle","magazineLetter","magazineMood","magazineMeals","magazineLedger","capsuleTitle","capsuleDate","capsuleTime","capsuleNote","capsuleReminder"].includes(input.name);
}
async function finishCapsuleSave(item,message,form=null){
  let draftError=false;
  if(form)try{await ui.onSaved?.(form);}catch{draftError=true;}
  try{await ui.refreshData?.();}
  catch{
    ui.open("这封信已经保存",`<section class="memory-intro">${bearArt("moments",item.id,"memory-bears",4)}<h3>熊熊已经收好啦</h3><p>本机写入已完成，列表暂时没能刷新。可以重试刷新，无需再保存一遍。</p></section><button type="button" class="primary" data-memory-action="capsule-refresh" data-memory-id="${escape(item.id)}">刷新并查看这封信</button><p class="photo-hint">也可以先关闭，下次打开 App 后查看。</p>`);ui.sheet.dataset.view="capsule-saved";ui.announce("这封信已保存，稍后刷新即可查看");return;
  }
  openCapsule(item.id);ui.announce(draftError?"这封信已保存；旧草稿暂未清理，无需重复提交":message);
}
export async function memoriesSubmitted(form){
  if(form.dataset.form==="magazine"){
    magazineSelection=selectionFrom(form);await putSetting(`feature:magazine:${magazineMonth}`,magazineSelection);
    const content=magazineSections(magazineData,magazineSelection,Object.fromEntries(Object.entries(moods).map(([key,value])=>[key,value.name])));
    const pages=await drawMagazine(content);let token="";if(window.BearShare){const result=JSON.parse(window.BearShare.prepare(JSON.stringify(pages)));if(!result.ok)throw new Error(result.error||"暂时无法准备月刊图片");token=result.token;}
    magazinePrepared={pages,token,text:magazineText(content)};magazinePage=0;previewMagazine();return true;
  }
  if(form.dataset.form!=="capsule")return false;
  const values=new FormData(form),old=entries().find(row=>row.id===form.dataset.id&&row.kind==="capsule"),date=String(values.get("capsuleDate")||""),time=String(values.get("capsuleTime")||""),title=String(values.get("capsuleTitle")||"").trim();
  if(!title)throw new Error("先在信封上写一句话吧");if(!validMemoryDate(date)||!/^([01]\d|2[0-3]):[0-5]\d$/.test(time))throw new Error("请填写正确的开启日期和时间");
  if(!old&&new Date(`${date}T${time}:00`).getTime()<=Date.now())throw new Error("为这封新信选一个未来的开启时间吧");
  const photos=ui.getPhotos();if(photos.length>5)throw new Error("一封信最多放 5 张照片");
  const item={...old,id:old?.id||uid(),kind:"capsule",title,date,time,note:String(values.get("capsuleNote")||"").trim(),photos,created:old?.created||Date.now(),updated:Date.now(),recurrence:{type:"none"},reminder:values.has("capsuleReminder")?{days:0,time}:null};
  if(!capsuleDue(item))delete item.capsuleOpenedAt;
  await saveItem("entries",item);await finishCapsuleSave(item,"这封信，熊熊收好啦",form);return true;
}
export async function memoriesClicked(data){
  const action=data.memoryAction;if(!action)return false;
  if(action==="magazine")await openMagazine(dateKey().slice(0,7));
  else if(action==="magazine-prev"||action==="magazine-next"){await rememberMagazine();await openMagazine(monthShift(magazineMonth,action==="magazine-prev"?-1:1));}
  else if(action==="magazine-edit")renderMagazine();
  else if(action==="magazine-page-prev"||action==="magazine-page-next"){if(magazinePrepared){magazinePage=Math.max(0,Math.min(magazinePrepared.pages.length-1,magazinePage+(action==="magazine-page-next"?1:-1)));previewMagazine();}}
  else if(action==="magazine-share"&&magazinePrepared&&window.BearShare)window.BearShare.share(magazinePrepared.token);
  else if(action==="magazine-save"&&magazinePrepared){if(window.BearShare)window.BearShare.save(magazinePrepared.token,magazinePage);else{const link=document.createElement("a");link.href=magazinePrepared.pages[magazinePage];link.download=`熊熊月刊_${magazineMonth}_${magazinePage+1}.png`;link.click();}}
  else if(action==="magazine-copy"&&magazinePrepared){if(window.BearShare)window.BearShare.copy(magazinePrepared.text);else{await navigator.clipboard.writeText(magazinePrepared.text);ui.announce("月刊文字已复制");}}
  else if(action==="capsules")openCapsules();
  else if(action==="capsule-new")editCapsule();
  else if(action==="capsule")openCapsule(data.memoryId);
  else if(action==="capsule-edit")editCapsule(entries().find(row=>row.kind==="capsule"&&row.id===data.memoryId));
  else if(action==="capsule-photo")showCapsulePhoto(data.memoryId,Number(data.memoryIndex));
  else if(action==="capsule-refresh"){await ui.refreshData?.();openCapsule(data.memoryId);}
  else if(action==="capsule-open"){
    const item=entries().find(row=>row.kind==="capsule"&&row.id===data.memoryId);if(!item||!capsuleDue(item)){ui.announce("还没有到开启时间，再等一等吧");return true;}
    const opened={...item,capsuleOpenedAt:item.capsuleOpenedAt||Date.now()};await saveItem("entries",opened);await finishCapsuleSave(opened,"来自过去的心意，送到今天啦");
  }else if(action==="capsule-delete"){
    const item=entries().find(row=>row.kind==="capsule"&&row.id===data.memoryId);if(item)ui.open("把这封信移到最近删除？",`<p class="detail-text">${escape(item.title)}</p><p class="photo-hint">可以在最近删除里恢复，开启提醒会暂停。</p><div class="sheet-actions"><button type="button" class="secondary" data-memory-action="capsule" data-memory-id="${escape(item.id)}">保留这封信</button><button type="button" class="primary" data-memory-action="capsule-remove" data-memory-id="${escape(item.id)}">移到最近删除</button></div>`);
  }else if(action==="capsule-remove"){await removeItem("entries",data.memoryId);await ui.refreshData?.();openCapsules();ui.announce("已移到最近删除");}
  else if(action==="memories"||action==="memories-year")openMemories("year");
  else if(action==="memories-quarter")openMemories("quarter");
  else if(action==="recall-entry"){const item=entries().find(row=>row.id===data.memoryId);if(item)ui.showEntry?.(item);}
  return true;
}
export function memoriesBack(){
  if(ui.sheet.dataset.view==="capsule-photo"){openCapsule(ui.sheet.dataset.memoryId);return true;}
  if(ui.sheet.dataset.view==="capsule"){openCapsules();return true;}
  if(ui.sheet.dataset.view==="magazine-preview"){renderMagazine();return true;}
  return false;
}
