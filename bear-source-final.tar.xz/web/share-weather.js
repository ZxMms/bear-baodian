import {weatherLook,windDirectionLabel,windValue,windPowerInfo,isWeatherStale} from './weather.js?v=38';

const clean=value=>typeof value==='string'?value.replace(/[\r\n\t]/g,' ').trim().slice(0,120):'';
const localDay=time=>{const d=new Date(time);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;};
const chinaDay=time=>new Date(time+8*3600000).toISOString().slice(0,10);
// Only publish a dated, fresh report for the selected day. Never substitute today's
// conditions for a historical journal, or a query time for its observation time.
export function shareWeatherForDate(date,state={},now=Date.now()) {
  const unavailable=(reason,canRefresh=false,loading=false)=>({report:null,reason,canRefresh,loading});
  const today=localDay(now);
  if(date!==today)return unavailable(date<today?'这一天没有留存天气资料，分享时只显示日期和星期。':'未来天气暂不附上，分享时只显示日期和星期。');
  if(!state.native)return unavailable('安装安卓 App 并开启天气后，可附上当天的天气。');
  if(!state.place)return unavailable('先在首页定位或选择城市，再回来附上天气。');
  if(state.loading||state.locationPending)return unavailable('天气查询中；可以稍等，或不附天气直接分享。',false,true);
  if(state.error)return unavailable('这次天气没有查到，可以重试；也可以直接分享记录。',true);
  const data=state.weather;
  if(!data)return unavailable('还没有天气资料，点“查询天气”获取。',true);
  if(!Number.isFinite(data.observedAt)||data.observedAt<=0||data.observedAt>now+300000||isWeatherStale(data,now))return unavailable('天气资料较早或缺少时间，查询后再附上。',true);
  if(chinaDay(data.observedAt)!==date)return unavailable('当前天气资料不属于所选日期，暂不附上。',true);
  const look=weatherLook(data.code,data.isDay),condition=clean(data.conditionText)||(look.kind!=='unknown'?look.label:'');
  const temperature=typeof data.temperature==='number'&&Number.isFinite(data.temperature)&&Math.abs(data.temperature)<=100?`${Math.round(data.temperature)}°C`:'';
  const summary=[condition,temperature].filter(Boolean).join(' · ');
  const speed=windValue(data.windSpeed),gust=windValue(data.windGust),power=windPowerInfo(data);
  const direction=clean(data.windDirectionText)||(windDirectionLabel(data.windDirection)==='未提供风向'?'':windDirectionLabel(data.windDirection));
  const wind=[power.scale===0?'静风':direction,power.label?`风力${power.estimated?'约':''} ${power.label}`:'',speed!==null?`风速 ${speed} m/s`:'',gust!==null?`阵风 ${gust} m/s`:''].filter(Boolean).join(' · ');
  if(!summary&&!wind)return unavailable('来源暂未提供可分享的天气内容。',true);
  const time=new Date(data.observedAt+8*3600000).toISOString().slice(11,16);
  const provider=data.provider==='nmc'?'中央气象台':data.provider==='open-meteo'?'Open-Meteo 模型数据 · CC BY 4.0':'天气来源';
  const station=data.provider==='nmc'?clean(data.stationName||data.city):'';
  return {report:{location:clean(state.placeLabel)||clean(state.place.displayName)||clean(state.place.name)||'所选地区',condition,temperature,kind:look.kind,isDay:data.isDay!==false,summary,wind,meta:`${time} 资料（北京时间） · ${provider}${station?' · '+station+'站点':''}`},reason:'按首页所选地区展示，附上资料时间；不包含经纬度。',canRefresh:true,loading:false};
}
